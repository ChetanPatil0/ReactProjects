export const BRAND = {
  name: "OneFam Fashion",
  colors: {
    royalViolet: "#7137C8",
    electricLime: "#C6F542",
    vermilion: "#F45B45",
    ink: "#191720",
    paper: "#FCFAF4",
  },
} as const;

export const PRODUCT_IMAGE = {
  maxUploadBytes: 2 * 1024 * 1024, // 2 MB
  recommendedWidth: 1200,
  recommendedHeight: 1500,
  thumbnailWidth: 400,
  thumbnailHeight: 500,
  formats: ["image/jpeg", "image/png", "image/webp"] as const,
} as const;

export const ORDER_STATUSES = [
  "PENDING_CONFIRMATION",
  "CONFIRMED",
  "PROCESSING",
  "PACKED",
  "SHIPPED",
  "OUT_FOR_DELIVERY",
  "DELIVERED",
  "CANCELLED",
  "RETURNED",
] as const;

export const PAYMENT_STATUSES = [
  "UNPAID",
  "PARTIALLY_PAID",
  "PAID",
  "REFUNDED",
  "PARTIALLY_REFUNDED",
] as const;

export type OrderStatus = (typeof ORDER_STATUSES)[number];
export type PaymentStatus = (typeof PAYMENT_STATUSES)[number];

/**
 * Pure TypeScript QR Code Generator (Zero external dependencies).
 * Generates standards-compliant QR Code Matrix and outputs SVG or Data URLs.
 * Optimized for order verification and invoice tracking URLs.
 */

// QR Code Error Correction Levels
export type QrErrorCorrectionLevel = "L" | "M" | "Q" | "H";

// Galois Field GF(256) log and antilog tables for Reed-Solomon error correction
const EXP_TABLE = new Uint8Array(256);
const LOG_TABLE = new Uint8Array(256);

(function initGaloisField() {
  let val = 1;
  for (let i = 0; i < 255; i++) {
    EXP_TABLE[i] = val;
    LOG_TABLE[val] = i;
    val = (val << 1) ^ (val >= 128 ? 0x11d : 0);
  }
  EXP_TABLE[255] = EXP_TABLE[0];
})();

function glog(n: number): number {
  if (n < 1) throw new Error("glog(" + n + ")");
  return LOG_TABLE[n];
}

function gexp(n: number): number {
  while (n < 0) n += 255;
  while (n >= 256) n -= 255;
  return EXP_TABLE[n];
}

// Polynomial operations
function polyMultiply(p1: number[], p2: number[]): number[] {
  const result = new Array(p1.length + p2.length - 1).fill(0);
  for (let i = 0; i < p1.length; i++) {
    for (let j = 0; j < p2.length; j++) {
      if (p1[i] !== 0 && p2[j] !== 0) {
        result[i + j] ^= gexp(glog(p1[i]) + glog(p2[j]));
      }
    }
  }
  return result;
}

function getGeneratorPoly(degree: number): number[] {
  let gen = [1];
  for (let i = 0; i < degree; i++) {
    gen = polyMultiply(gen, [1, gexp(i)]);
  }
  return gen;
}

function rsEncode(data: number[], ecCount: number): number[] {
  const gen = getGeneratorPoly(ecCount);
  const info = data.concat(new Array(ecCount).fill(0));
  for (let i = 0; i < data.length; i++) {
    const lead = info[i];
    if (lead !== 0) {
      const leadLog = glog(lead);
      for (let j = 0; j < gen.length; j++) {
        if (gen[j] !== 0) {
          info[i + j] ^= gexp(leadLog + glog(gen[j]));
        }
      }
    }
  }
  return info.slice(data.length);
}

// QR Code Specifications per version (Versions 1 to 6)
interface VersionSpec {
  version: number;
  dataCapacityM: number;
  totalCodewords: number;
  ecCodewordsPerBlock: number;
  numBlocks: number;
  alignPositions: number[];
}

const VERSION_SPECS: VersionSpec[] = [
  { version: 1, dataCapacityM: 14, totalCodewords: 26, ecCodewordsPerBlock: 10, numBlocks: 1, alignPositions: [] },
  { version: 2, dataCapacityM: 26, totalCodewords: 44, ecCodewordsPerBlock: 16, numBlocks: 1, alignPositions: [6, 18] },
  { version: 3, dataCapacityM: 42, totalCodewords: 70, ecCodewordsPerBlock: 26, numBlocks: 1, alignPositions: [6, 22] },
  { version: 4, dataCapacityM: 62, totalCodewords: 100, ecCodewordsPerBlock: 18, numBlocks: 2, alignPositions: [6, 26] },
  { version: 5, dataCapacityM: 84, totalCodewords: 134, ecCodewordsPerBlock: 24, numBlocks: 2, alignPositions: [6, 30] },
  { version: 6, dataCapacityM: 106, totalCodewords: 172, ecCodewordsPerBlock: 16, numBlocks: 4, alignPositions: [6, 34] },
];

function selectVersion(byteLength: number): VersionSpec {
  for (const spec of VERSION_SPECS) {
    if (spec.dataCapacityM >= byteLength) {
      return spec;
    }
  }
  return VERSION_SPECS[VERSION_SPECS.length - 1];
}

class BitBuffer {
  private buffer: number[] = [];
  private length = 0;

  put(num: number, length: number) {
    for (let i = 0; i < length; i++) {
      this.putBit(((num >>> (length - i - 1)) & 1) === 1);
    }
  }

  putBit(bit: boolean) {
    const byteIndex = Math.floor(this.length / 8);
    if (this.buffer.length <= byteIndex) {
      this.buffer.push(0);
    }
    if (bit) {
      this.buffer[byteIndex] |= 0x80 >>> (this.length % 8);
    }
    this.length++;
  }

  getBuffer(): number[] {
    return this.buffer;
  }

  getLength(): number {
    return this.length;
  }
}

export interface QrOptions {
  size?: number; // Output SVG dimension in pixels (default: 160)
  color?: string; // Foreground color (default: #191720)
  bgColor?: string; // Background color (default: #ffffff)
  includeMargin?: boolean; // 4-module quiet zone (default: true)
}

/**
 * Generates an SVG string representation of a standard QR Code for any text or URL.
 */
export function generateQrSvg(text: string, options: QrOptions = {}): string {
  const {
    size = 160,
    color = "#191720",
    bgColor = "#ffffff",
    includeMargin = true,
  } = options;

  const utf8Bytes: number[] = [];
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    if (code < 0x80) {
      utf8Bytes.push(code);
    } else if (code < 0x800) {
      utf8Bytes.push(0xc0 | (code >> 6), 0x80 | (code & 0x3f));
    } else {
      utf8Bytes.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 0x3f), 0x80 | (code & 0x3f));
    }
  }

  const spec = selectVersion(utf8Bytes.length);
  const moduleCount = spec.version * 4 + 17;

  // Build bitstream: 8-bit byte mode (0100) + character count indicator (8 bits)
  const bb = new BitBuffer();
  bb.put(0x4, 4); // Byte mode indicator
  bb.put(utf8Bytes.length, 8); // Character count
  for (const b of utf8Bytes) {
    bb.put(b, 8);
  }

  // Terminator & padding to capacity
  const capacityBits = spec.dataCapacityM * 8;
  const remaining = capacityBits - bb.getLength();
  if (remaining > 0) {
    bb.put(0, Math.min(4, remaining));
  }
  while (bb.getLength() % 8 !== 0) {
    bb.putBit(false);
  }
  const padBytes = [0xec, 0x11];
  let padIdx = 0;
  while (bb.getLength() < capacityBits) {
    bb.put(padBytes[padIdx % 2], 8);
    padIdx++;
  }

  const dataBytes = bb.getBuffer();
  const dataPerBlock = Math.floor(spec.dataCapacityM / spec.numBlocks);
  const blocks: number[][] = [];
  const ecBlocks: number[][] = [];

  for (let b = 0; b < spec.numBlocks; b++) {
    const blockData = dataBytes.slice(b * dataPerBlock, (b + 1) * dataPerBlock);
    blocks.push(blockData);
    ecBlocks.push(rsEncode(blockData, spec.ecCodewordsPerBlock));
  }

  // Interleave codewords
  const interleaved: number[] = [];
  for (let i = 0; i < dataPerBlock; i++) {
    for (let b = 0; b < spec.numBlocks; b++) {
      interleaved.push(blocks[b][i]);
    }
  }
  for (let i = 0; i < spec.ecCodewordsPerBlock; i++) {
    for (let b = 0; b < spec.numBlocks; b++) {
      interleaved.push(ecBlocks[b][i]);
    }
  }

  // 2D Matrix of modules
  const matrix: (boolean | null)[][] = Array.from({ length: moduleCount }, () =>
    new Array(moduleCount).fill(null)
  );

  function setModule(r: number, c: number, val: boolean) {
    if (r >= 0 && r < moduleCount && c >= 0 && c < moduleCount) {
      matrix[r][c] = val;
    }
  }

  // Finder Patterns (7x7) + separators
  function addFinder(top: number, left: number) {
    for (let r = -1; r <= 7; r++) {
      for (let c = -1; c <= 7; c++) {
        const row = top + r;
        const col = left + c;
        if (row < 0 || row >= moduleCount || col < 0 || col >= moduleCount) continue;
        if (
          (r >= 0 && r <= 6 && (c === 0 || c === 6)) ||
          (c >= 0 && c <= 6 && (r === 0 || r === 6)) ||
          (r >= 2 && r <= 4 && c >= 2 && c <= 4)
        ) {
          matrix[row][col] = true;
        } else {
          matrix[row][col] = false;
        }
      }
    }
  }

  addFinder(0, 0);
  addFinder(0, moduleCount - 7);
  addFinder(moduleCount - 7, 0);

  // Timing patterns
  for (let i = 8; i < moduleCount - 8; i++) {
    if (matrix[6][i] === null) matrix[6][i] = i % 2 === 0;
    if (matrix[i][6] === null) matrix[i][6] = i % 2 === 0;
  }

  // Alignment patterns
  if (spec.alignPositions.length > 0) {
    for (const r of spec.alignPositions) {
      for (const c of spec.alignPositions) {
        if (matrix[r][c] !== null) continue;
        for (let dr = -2; dr <= 2; dr++) {
          for (let dc = -2; dc <= 2; dc++) {
            const isBorder = Math.abs(dr) === 2 || Math.abs(dc) === 2;
            const isCenter = dr === 0 && dc === 0;
            setModule(r + dr, c + dc, isBorder || isCenter);
          }
        }
      }
    }
  }

  // Dark module
  setModule(moduleCount - 8, 8, true);

  // Reserve format information areas
  for (let i = 0; i < 9; i++) {
    if (matrix[8][i] === null) matrix[8][i] = false;
    if (matrix[i][8] === null) matrix[i][8] = false;
  }
  for (let i = 0; i < 8; i++) {
    if (matrix[8][moduleCount - 1 - i] === null) matrix[8][moduleCount - 1 - i] = false;
    if (matrix[moduleCount - 1 - i][8] === null) matrix[moduleCount - 1 - i][8] = false;
  }

  // Place data bits with Mask Pattern 0 ( (row + col) % 2 === 0 )
  let bitIdx = 0;
  const totalDataBits = interleaved.length * 8;
  let direction = -1;
  let r = moduleCount - 1;
  let c = moduleCount - 1;

  while (c > 0) {
    if (c === 6) c--; // Skip timing column
    for (let count = 0; count < moduleCount; count++) {
      const curRow = r;
      for (let i = 0; i < 2; i++) {
        const curCol = c - i;
        if (matrix[curRow][curCol] === null) {
          let bit = false;
          if (bitIdx < totalDataBits) {
            const byte = interleaved[Math.floor(bitIdx / 8)];
            bit = ((byte >>> (7 - (bitIdx % 8))) & 1) === 1;
            bitIdx++;
          }
          // Apply mask 0: invert if (row + col) % 2 === 0
          if ((curRow + curCol) % 2 === 0) {
            bit = !bit;
          }
          matrix[curRow][curCol] = bit;
        }
      }
      r += direction;
    }
    direction = -direction;
    r += direction;
    c -= 2;
  }

  // Format info for Error Correction M (00) and Mask 0 (000): Format bits = 101010000010010
  const formatBits = [1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0];
  // Apply to top-left and split corners
  const formatPosTopLeft = [
    [8, 0], [8, 1], [8, 2], [8, 3], [8, 4], [8, 5], [8, 7], [8, 8],
    [7, 8], [5, 8], [4, 8], [3, 8], [2, 8], [1, 8], [0, 8],
  ];
  for (let i = 0; i < 15; i++) {
    const [row, col] = formatPosTopLeft[i];
    matrix[row][col] = formatBits[i] === 1;
  }
  const formatPosOther = [
    [moduleCount - 1, 8], [moduleCount - 2, 8], [moduleCount - 3, 8], [moduleCount - 4, 8],
    [moduleCount - 5, 8], [moduleCount - 6, 8], [moduleCount - 7, 8],
    [8, moduleCount - 8], [8, moduleCount - 7], [8, moduleCount - 6], [8, moduleCount - 5],
    [8, moduleCount - 4], [8, moduleCount - 3], [8, moduleCount - 2], [8, moduleCount - 1],
  ];
  for (let i = 0; i < 15; i++) {
    const [row, col] = formatPosOther[i];
    matrix[row][col] = formatBits[i] === 1;
  }

  // Render SVG Path
  const margin = includeMargin ? 4 : 1;
  const viewBoxSize = moduleCount + margin * 2;
  let pathData = "";

  for (let row = 0; row < moduleCount; row++) {
    for (let col = 0; col < moduleCount; col++) {
      if (matrix[row][col] === true) {
        pathData += `M${col + margin},${row + margin}h1v1h-1z `;
      }
    }
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${viewBoxSize} ${viewBoxSize}" width="${size}" height="${size}" shape-rendering="crispEdges">
  <rect width="100%" height="100%" fill="${bgColor}" />
  <path d="${pathData.trim()}" fill="${color}" />
</svg>`;
}

/**
 * Returns an inline data:image/svg+xml Data URL suitable for img src attributes
 */
export function generateQrDataUrl(text: string, options: QrOptions = {}): string {
  const svg = generateQrSvg(text, options);
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}


export const queryKeys = {
  auth: {
    me: ["auth", "me"] as const,
  },
  products: {
    all: ["products"] as const,
    list: (filters?: Record<string, any>) => ["products", "list", filters] as const,
    detail: (slugOrId: string) => ["products", "detail", slugOrId] as const,
  },
  categories: {
    all: ["categories"] as const,
    tree: ["categories", "tree"] as const,
    detail: (slugOrId: string) => ["categories", "detail", slugOrId] as const,
  },
  collections: {
    all: ["collections"] as const,
    detail: (slugOrId: string) => ["collections", "detail", slugOrId] as const,
  },
  orders: {
    all: ["orders"] as const,
    list: (filters?: Record<string, any>) => ["orders", "list", filters] as const,
    detail: (idOrRef: string) => ["orders", "detail", idOrRef] as const,
    dashboardSummary: ["orders", "dashboard-summary"] as const,
  },
  payments: {
    all: ["payments"] as const,
    list: (filters?: Record<string, any>) => ["payments", "list", filters] as const,
  },
  invoices: {
    all: ["invoices"] as const,
    detail: (id: string) => ["invoices", "detail", id] as const,
    templates: ["invoices", "templates"] as const,
  },
  promotions: {
    all: ["promotions"] as const,
  },
  heroSlides: {
    all: ["hero-slides"] as const,
  },
  banners: {
    all: ["banners"] as const,
  },
  settings: {
    current: ["settings", "current"] as const,
  },
  tracking: {
    lookup: (email: string, ref: string) => ["tracking", "lookup", email, ref] as const,
  },
  inquiries: {
    all: ["inquiries"] as const,
    list: (filters?: Record<string, any>) => ["inquiries", "list", filters] as const,
    detail: (id: string) => ["inquiries", "detail", id] as const,
  },
};


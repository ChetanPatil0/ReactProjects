import { z } from "zod";

/**
 * Product Schema
 */
export const productSchema = z.object({
  name: z.string().min(2, "Product name must be at least 2 characters"),
  sku: z.string().min(3, "SKU must be at least 3 characters").toUpperCase(),
  regularPrice: z.coerce.number().positive("Regular price must be greater than 0"),
  discountPrice: z.coerce.number().nonnegative("Discount price cannot be negative").optional(),
  categoryId: z.string().min(1, "Please select a category"),
  shortDescription: z.string().optional(),
  description: z.string().optional(),
  status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]).default("DRAFT"),
  isFeatured: z.boolean().default(false),
  isTrending: z.boolean().default(false),
  isNewArrival: z.boolean().default(false),
});

export type ProductFormValues = z.infer<typeof productSchema>;

/**
 * Variant Schema
 */
export const variantSchema = z.object({
  sku: z.string().min(3, "Variant SKU must be at least 3 characters").toUpperCase(),
  size: z.string().min(1, "Size is required (e.g. S, M, L, XL)"),
  color: z.string().min(1, "Color name is required (e.g. Bone White)"),
  colorHex: z.string().regex(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/, "Valid hex color required (e.g. #7137C8)").optional(),
  stock: z.coerce.number().int().min(0, "Stock cannot be negative"),
  isAvailable: z.boolean().default(true),
});

export type VariantFormValues = z.infer<typeof variantSchema>;

/**
 * Category Schema
 */
export const categorySchema = z.object({
  name: z.string().min(2, "Category title must be at least 2 characters"),
  slug: z.string().min(2, "Slug must be at least 2 characters").regex(/^[a-z0-9-]+$/, "Slug must be lowercase alphanumeric with hyphens"),
  description: z.string().optional(),
  imageUrl: z.string().url("Must be a valid image URL").optional().or(z.literal("")),
  parentId: z.string().nullable().optional(),
  displayOrder: z.coerce.number().int().default(0),
  isActive: z.boolean().default(true),
});

export type CategoryFormValues = z.infer<typeof categorySchema>;

/**
 * Collection Schema (Cover image is optional as requested)
 */
export const collectionSchema = z.object({
  title: z.string().min(2, "Collection title must be at least 2 characters"),
  slug: z.string().min(2, "Slug must be at least 2 characters").regex(/^[a-z0-9-]+$/, "Slug must be lowercase alphanumeric with hyphens"),
  description: z.string().optional(),
  imageUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  isActive: z.boolean().default(true),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
});

export type CollectionFormValues = z.infer<typeof collectionSchema>;

/**
 * Manual Order Registration & Negotiation Schema
 */
export const orderRegistrationSchema = z.object({
  customerName: z.string().min(2, "Customer full name is required"),
  customerPhone: z.string().min(10, "Valid phone or WhatsApp number is required (min 10 digits)"),
  customerEmail: z.string().email("Valid email address is required").optional().or(z.literal("")),
  shippingAddress: z.string().min(5, "Delivery address is required"),
  city: z.string().min(2, "City is required"),
  state: z.string().min(2, "State/Province is required"),
  postalCode: z.string().min(3, "Postal/PIN code is required"),
  discountType: z.enum(["FLAT", "PERCENTAGE"]).default("FLAT"),
  discountValue: z.coerce.number().min(0, "Discount cannot be negative").default(0),
  shippingFee: z.coerce.number().min(0, "Shipping fee cannot be negative").default(0),
  advancePaid: z.coerce.number().min(0, "Advance paid cannot be negative").default(0),
  notes: z.string().optional(),
  items: z
    .array(
      z.object({
        productId: z.string().min(1, "Select a product"),
        variantId: z.string().optional(),
        title: z.string().min(1, "Product title required"),
        sku: z.string().optional(),
        size: z.string().optional(),
        color: z.string().optional(),
        unitPrice: z.coerce.number().positive("Item unit price must be greater than 0"),
        quantity: z.coerce.number().int().positive("Quantity must be at least 1"),
      })
    )
    .min(1, "Order must contain at least one item"),
});

export type OrderRegistrationFormValues = z.infer<typeof orderRegistrationSchema>;

/**
 * Hero Slide Schema
 */
export const heroSlideSchema = z.object({
  title: z.string().min(2, "Slide headline is required"),
  subtitle: z.string().optional(),
  buttonText: z.string().default("Explore Collection"),
  buttonLink: z.string().min(1, "Button link is required (e.g. /men, /women)"),
  imageUrl: z.string().min(1, "Desktop slide banner image is required"),
  mobileImageUrl: z.string().optional(),
  displayOrder: z.coerce.number().int().default(0),
  isActive: z.boolean().default(true),
});

export type HeroSlideFormValues = z.infer<typeof heroSlideSchema>;

/**
 * Validate and normalize order reference
 * Format must be: ORD-[Char][Digit][Char][Digit][4-Digit Serial]
 * e.g. ORD-K7M20001, ORDK7M20001, ord-k7m20001, ORD-K7M2-0001
 * Position 1 & 3 must be characters, Position 2 & 4 must be numbers.
 */
export function validateOrderReferenceFormat(input: string): {
  valid: boolean;
  normalized?: string;
  error?: string;
} {
  const clean = (input || "").trim();
  if (!clean) {
    return {
      valid: false,
      error: "Please enter your Order ID (e.g. ORD-XXXXXXXX).",
    };
  }

  // Regex matching ORD- followed by [Char][No][Char][No] and 4 digits (with optional hyphens)
  const pattern = /^(?:ORD-?)([A-Za-z])([0-9])([A-Za-z])([0-9])-?([0-9]{4})$/i;
  const match = clean.match(pattern);

  if (!match) {
    return {
      valid: false,
      error:
        "Invalid Order ID format. Please enter a valid Order ID like ORD-XXXXXXXX (1st & 3rd must be letters, 2nd & 4th must be numbers, followed by 4 digits).",
    };
  }

  const [, c1, n1, c2, n2, serial] = match;
  const normalized = `ORD-${c1.toUpperCase()}${n1}${c2.toUpperCase()}${n2}${serial}`;
  return { valid: true, normalized };
}

/**
 * Validate customer contact (either valid email or valid 10-digit mobile phone number)
 */
export function validateTrackingContact(input: string): {
  valid: boolean;
  type?: "email" | "phone";
  cleanValue?: string;
  error?: string;
} {
  const clean = (input || "").trim();
  if (!clean) {
    return {
      valid: false,
      error: "Please enter your registered email address or 10-digit mobile number.",
    };
  }

  if (clean.includes("@")) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(clean)) {
      return {
        valid: false,
        error: "Invalid email format. Please enter a valid email address (e.g. name@example.com).",
      };
    }
    return { valid: true, type: "email", cleanValue: clean.toLowerCase() };
  }

  // Mobile phone number validation
  const digits = clean.replace(/[^0-9]/g, "");
  if (digits.length < 10) {
    return {
      valid: false,
      error: "Invalid mobile number. Please enter a valid 10-digit mobile number.",
    };
  }

  const phone10 = digits.slice(-10);
  if (!/^[6-9]\d{9}$/.test(phone10)) {
    return {
      valid: false,
      error: "Invalid mobile number. Indian mobile numbers must be 10 digits starting with 6, 7, 8, or 9.",
    };
  }

  return { valid: true, type: "phone", cleanValue: phone10 };
}

/**
 * Malicious content detector to protect contact forms and API inputs from XSS,
 * script execution, and malicious payloads.
 */
export function isMaliciousContent(text: string): boolean {
  if (!text || typeof text !== "string") return false;
  const lower = text.toLowerCase();
  const dangerousPatterns = [
    /<script\b[^>]*>/i,
    /<\/script>/i,
    /javascript:/i,
    /data:text\/html/i,
    /vbscript:/i,
    /onload\s*=/i,
    /onerror\s*=/i,
    /onclick\s*=/i,
    /onmouseover\s*=/i,
    /<iframe/i,
    /<object/i,
    /<embed/i,
    /<svg.*onload/i,
    /document\.cookie/i,
    /window\.location/i,
    /eval\s*\(/i,
  ];

  return dangerousPatterns.some((pattern) => pattern.test(lower));
}

/**
 * Sanitize string input: strips HTML tags, control characters, and unsafe schemas
 */
export function sanitizeString(val: string): string {
  if (typeof val !== "string") return "";
  return val
    .replace(/<[^>]*>?/gm, "") // Strip HTML tags
    .replace(/javascript:/gi, "")
    .replace(/data:text\/html/gi, "")
    .replace(/vbscript:/gi, "")
    .replace(/on\w+\s*=/gi, "")
    .trim();
}

/**
 * Contact Inquiry Validator with strict 10-digit Indian Mobile constraint (+91)
 * and malicious payload protection.
 */
export interface ContactInquiryValidationResult {
  valid: boolean;
  errors: {
    name?: string;
    email?: string;
    phone?: string;
    orderNumber?: string;
    message?: string;
    general?: string;
  };
  sanitized: {
    name: string;
    email: string;
    phone: string;
    subject: string;
    orderNumber?: string;
    message: string;
  };
}

export function validateContactInquiry(data: {
  name: string;
  email: string;
  phone: string;
  subject?: string;
  orderNumber?: string;
  message: string;
}): ContactInquiryValidationResult {
  const errors: ContactInquiryValidationResult["errors"] = {};

  // Check for malicious payload attempts
  if (
    isMaliciousContent(data.name) ||
    isMaliciousContent(data.email) ||
    isMaliciousContent(data.phone) ||
    isMaliciousContent(data.orderNumber || "") ||
    isMaliciousContent(data.message)
  ) {
    errors.general = "Malicious or unsafe characters detected. Please remove HTML/scripts.";
  }

  // Name validation
  const cleanName = sanitizeString(data.name || "");
  if (!cleanName) {
    errors.name = "Please enter your name.";
  } else if (cleanName.length < 2) {
    errors.name = "Name must be at least 2 characters.";
  } else if (cleanName.length > 80) {
    errors.name = "Name cannot exceed 80 characters.";
  } else if (!/^[a-zA-Z\s.'-]+$/.test(cleanName)) {
    errors.name = "Name can only contain letters, spaces, and hyphens.";
  }

  // Email validation
  const cleanEmail = sanitizeString(data.email || "").toLowerCase();
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!cleanEmail) {
    errors.email = "Please enter your email address.";
  } else if (!emailRegex.test(cleanEmail)) {
    errors.email = "Please enter a valid email address (e.g. name@example.com).";
  } else if (cleanEmail.length > 120) {
    errors.email = "Email cannot exceed 120 characters.";
  }

  // Mobile number validation (strictly 10-digit Indian mobile number)
  const rawPhone = data.phone || "";
  const digitsOnly = rawPhone.replace(/\D/g, "");
  // Take last 10 digits if someone pasted with 91 or 0
  const normalizedPhone =
    digitsOnly.length > 10 && digitsOnly.startsWith("91")
      ? digitsOnly.slice(2, 12)
      : digitsOnly.length > 10 && digitsOnly.startsWith("0")
      ? digitsOnly.slice(1, 11)
      : digitsOnly.slice(0, 10);

  if (!normalizedPhone) {
    errors.phone = "Mobile number is required.";
  } else if (normalizedPhone.length !== 10) {
    errors.phone = `Mobile number must be exactly 10 digits (currently ${normalizedPhone.length}/10).`;
  } else if (!/^[6-9]\d{9}$/.test(normalizedPhone)) {
    errors.phone = "Indian mobile number must start with 6, 7, 8, or 9.";
  }

  // Order Number validation (optional)
  const cleanOrder = sanitizeString(data.orderNumber || "").toUpperCase();
  if (cleanOrder) {
    if (cleanOrder.length < 3 || cleanOrder.length > 30) {
      errors.orderNumber = "Order ID should be between 3 and 30 characters.";
    } else if (!/^[A-Z0-9\-_#]+$/.test(cleanOrder)) {
      errors.orderNumber = "Order ID can only contain letters, numbers, and dashes.";
    }
  }

  // Message validation
  const cleanMessage = sanitizeString(data.message || "");
  if (!cleanMessage) {
    errors.message = "Please enter your question or message.";
  } else if (cleanMessage.length < 10) {
    errors.message = "Message must be at least 10 characters long.";
  } else if (cleanMessage.length > 2000) {
    errors.message = "Message cannot exceed 2000 characters.";
  }

  const valid = Object.keys(errors).length === 0;

  return {
    valid,
    errors,
    sanitized: {
      name: cleanName,
      email: cleanEmail,
      phone: normalizedPhone,
      subject: sanitizeString(data.subject || "General Question / Feedback"),
      orderNumber: cleanOrder || undefined,
      message: cleanMessage,
    },
  };
}




import { calculateDynamicOffer } from "./dynamic-offers";

/**
 * Serializes Prisma models into plain JavaScript primitives suitable for
 * Next.js Server Component -> Client Component boundaries.
 * 
 * Prevents the runtime error:
 * "Only plain objects can be passed to Client Components from Server Components.
 * Decimal objects are not supported."
 */

export function serializeProduct<T extends Record<string, any>>(product: T | null | undefined): any {
  if (!product) return product;

  const regularPrice =
    product.regularPrice !== null && product.regularPrice !== undefined
      ? Number(product.regularPrice)
      : 0;

  // Calculate dynamic offer from backend promotions
  const dynamicOffer = calculateDynamicOffer(regularPrice, product.promotionProducts);
  const discountPrice =
    dynamicOffer.discountPrice !== null
      ? dynamicOffer.discountPrice
      : product.discountPrice !== null && product.discountPrice !== undefined
      ? Number(product.discountPrice)
      : null;

  return {
    ...product,
    regularPrice,
    discountPrice,
    activeOffer: dynamicOffer.activeOffer,
    discountPercent: dynamicOffer.discountPercent,
    variants: Array.isArray(product.variants)
      ? product.variants.map((v: any) => {
          const matchingImg = Array.isArray(product.images)
            ? product.images.find(
                (img: any) =>
                  img.altText === `variant:${v.color}` ||
                  img.altText === `variant:${v.sku}` ||
                  (v.color && img.altText?.toLowerCase() === v.color.toLowerCase())
              )
            : null;

          return {
            ...v,
            imagePath: v.imagePath || matchingImg?.path || null,
            priceOverride:
              v.priceOverride !== null && v.priceOverride !== undefined
                ? Number(v.priceOverride)
                : null,
          };
        })
      : product.variants,
  };
}

export function serializeProducts<T extends Record<string, any>>(
  products: T[] | null | undefined
): any[] {
  if (!Array.isArray(products)) return [];
  return products.map(serializeProduct);
}

import { format, formatDistanceToNow, parseISO } from "date-fns";

/**
 * Format currency into standard Indian Rupee format (e.g. ₹1,499.00 or ₹1,499)
 */
export function formatCurrency(amount: any, showDecimals = false): string {
  if (amount === null || amount === undefined || isNaN(Number(amount))) {
    return "₹0";
  }
  const numeric = Number(amount);
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: showDecimals ? 2 : 0,
    minimumFractionDigits: showDecimals ? 2 : 0,
  }).format(numeric);
}

/**
 * Calculate discount percentage
 */
export function calculateDiscountPercent(regularPrice: number, discountPrice: number | null | undefined): number {
  if (!discountPrice || discountPrice >= regularPrice || regularPrice <= 0) return 0;
  return Math.round(((regularPrice - discountPrice) / regularPrice) * 100);
}

/**
 * Format dates cleanly
 */
export function formatDate(date: string | Date | null | undefined, pattern = "dd MMM yyyy"): string {
  if (!date) return "-";
  try {
    const d = typeof date === "string" ? parseISO(date) : date;
    return format(d, pattern);
  } catch {
    return "-";
  }
}

/**
 * Format relative time (e.g. "2 hours ago")
 */
export function formatRelativeTime(date: string | Date | null | undefined): string {
  if (!date) return "-";
  try {
    const d = typeof date === "string" ? parseISO(date) : date;
    return formatDistanceToNow(d, { addSuffix: true });
  } catch {
    return "-";
  }
}

/**
 * Generate a structured, unique public order reference
 * Format: ORD-[Letter][Digit][Letter][Digit][4-Digit Serial]
 * Example: ORD-K7M20001 (Position 1 & 3 are uppercase letters, Position 2 & 4 are numbers, followed by 4-digit serial)
 */
export function generateOrderReference(serialNumber: number = 1): string {
  const letters = "ABCDEFGHJKLMNPQRSTUVWXYZ"; // Uppercase letters (excluding ambiguous O, I)
  const digits = "0123456789";

  const c1 = letters.charAt(Math.floor(Math.random() * letters.length));
  const n1 = digits.charAt(Math.floor(Math.random() * digits.length));
  const c2 = letters.charAt(Math.floor(Math.random() * letters.length));
  const n2 = digits.charAt(Math.floor(Math.random() * digits.length));

  const serial = String(serialNumber).padStart(4, "0").slice(-4);
  return `ORD-${c1}${n1}${c2}${n2}${serial}`;
}

/**
 * Generate invoice number
 */
export function generateInvoiceNumber(sequence: number): string {
  const year = new Date().getFullYear();
  return `INV-${year}-${String(sequence).padStart(4, "0")}`;
}

/**
 * Generate 6-digit numeric OTP for order tracking verification
 */
export function generateVerificationOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

/**
 * Mask mobile phone number to prevent identity exposure in public storefronts
 * Example: "9820154321" -> "******4321"
 */
export function maskMobile(phone: string | null | undefined): string {
  if (!phone) return "";
  const digits = phone.replace(/[^0-9]/g, "");
  if (digits.length < 4) return "******";
  const last4 = digits.slice(-4);
  return `******${last4}`;
}

/**
 * Mask email address to protect customer privacy
 * Example: "aarav.sharma@example.com" -> "a***a@example.com"
 */
export function maskEmail(email: string | null | undefined): string {
  if (!email || !email.includes("@")) return "";
  const [local, domain] = email.split("@");
  if (local.length <= 2) return `${local[0]}***@${domain}`;
  return `${local[0]}***${local[local.length - 1]}@${domain}`;
}

/**
 * Build WhatsApp order enquiry URL with pre-filled message
 */
export function buildWhatsAppUrl(params: {
  whatsappNumber: string;
  productName: string;
  productSku?: string | null;
  size?: string | null;
  color?: string | null;
  price: number | string;
  productUrl?: string;
}): string {
  const cleanNumber = params.whatsappNumber.replace(/[^0-9]/g, "");
  const lines = [
    `*Hello OneFam Fashion Concierge,*`,
    `I am interested in placing an order for:`,
    `• *Product:* ${params.productName}`,
    params.productSku ? `• *SKU:* ${params.productSku}` : null,
    params.size ? `• *Size Selected:* ${params.size}` : null,
    params.color ? `• *Colour Selected:* ${params.color}` : null,
    `• *Price:* ${formatCurrency(params.price)}`,
    params.productUrl ? `• *Link:* ${params.productUrl}` : null,
    ``,
    `Please confirm availability, delivery timeline, and payment instructions. Thank you!`,
  ].filter(Boolean);

  const text = encodeURIComponent(lines.join("\n"));
  return `https://wa.me/${cleanNumber}?text=${text}`;
}

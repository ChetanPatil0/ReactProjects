/**
 * Dynamic Offers & Discounts Calculation Engine
 * 
 * Computes the active discount price and applied offer badge strictly on the backend/server.
 * No frontend calculations required.
 */

export interface ActiveOfferDetail {
  id: string;
  name: string;
  discountType: "PERCENTAGE" | "FIXED";
  discountValue: number;
}

export interface DynamicOfferResult {
  discountPrice: number | null;
  activeOffer: ActiveOfferDetail | null;
  discountPercent: number;
}

export function calculateDynamicOffer(
  regularPrice: number,
  promotionProducts?: Array<{
    promotion?: {
      id: string;
      name: string;
      discountType: string;
      discountValue: any;
      minPurchase?: any;
      maxDiscount?: any;
      startDate?: Date | string | null;
      endDate?: Date | string | null;
      isActive: boolean;
    } | null;
  }> | null
): DynamicOfferResult {
  if (!promotionProducts || promotionProducts.length === 0 || regularPrice <= 0) {
    return { discountPrice: null, activeOffer: null, discountPercent: 0 };
  }

  const now = new Date();

  // Find the first matching active promotion that is within valid date bounds
  const activeEntry = promotionProducts.find((entry) => {
    const promo = entry.promotion;
    if (!promo || !promo.isActive) return false;

    if (promo.startDate) {
      const start = new Date(promo.startDate);
      if (now < start) return false;
    }

    if (promo.endDate) {
      const end = new Date(promo.endDate);
      if (now > end) return false;
    }

    return true;
  });

  if (!activeEntry || !activeEntry.promotion) {
    return { discountPrice: null, activeOffer: null, discountPercent: 0 };
  }

  const promo = activeEntry.promotion;
  const rawVal = Number(promo.discountValue) || 0;
  const discountType = (promo.discountType === "FIXED" ? "FIXED" : "PERCENTAGE") as "PERCENTAGE" | "FIXED";

  let discountAmount = 0;
  let percent = 0;

  if (discountType === "PERCENTAGE") {
    percent = Math.min(100, Math.max(0, rawVal));
    discountAmount = Math.round((regularPrice * percent) / 100);

    if (promo.maxDiscount) {
      const maxD = Number(promo.maxDiscount);
      if (discountAmount > maxD) {
        discountAmount = maxD;
      }
    }
  } else {
    // FIXED amount discount
    discountAmount = Math.min(regularPrice, Math.max(0, rawVal));
    percent = regularPrice > 0 ? Math.round((discountAmount / regularPrice) * 100) : 0;
  }

  const calculatedDiscountPrice = Math.max(0, regularPrice - discountAmount);

  return {
    discountPrice: calculatedDiscountPrice,
    activeOffer: {
      id: promo.id,
      name: promo.name,
      discountType,
      discountValue: rawVal,
    },
    discountPercent: percent,
  };
}


import { create } from "zustand";

interface StorefrontState {
  isMobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
  toggleMobileMenu: () => void;
  isSearchOpen: boolean;
  setSearchOpen: (open: boolean) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const useStorefrontStore = create<StorefrontState>((set) => ({
  isMobileMenuOpen: false,
  setMobileMenuOpen: (open) => set({ isMobileMenuOpen: open }),
  toggleMobileMenu: () => set((state) => ({ isMobileMenuOpen: !state.isMobileMenuOpen })),
  isSearchOpen: false,
  setSearchOpen: (open) => set({ isSearchOpen: open }),
  searchQuery: "",
  setSearchQuery: (query) => set({ searchQuery: query }),
}));


import { create } from "zustand";

interface AdminUIState {
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (collapsed: boolean) => void;
  toggleSidebar: () => void;
  selectedProductIds: string[];
  setSelectedProductIds: (ids: string[]) => void;
  toggleProductSelection: (id: string) => void;
  clearProductSelection: () => void;
  selectedOrderIds: string[];
  setSelectedOrderIds: (ids: string[]) => void;
  toggleOrderSelection: (id: string) => void;
  clearOrderSelection: () => void;
}

export const useAdminUIStore = create<AdminUIState>((set) => ({
  sidebarCollapsed: false,
  setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),
  toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
  selectedProductIds: [],
  setSelectedProductIds: (ids) => set({ selectedProductIds: ids }),
  toggleProductSelection: (id) =>
    set((state) => ({
      selectedProductIds: state.selectedProductIds.includes(id)
        ? state.selectedProductIds.filter((item) => item !== id)
        : [...state.selectedProductIds, id],
    })),
  clearProductSelection: () => set({ selectedProductIds: [] }),
  selectedOrderIds: [],
  setSelectedOrderIds: (ids) => set({ selectedOrderIds: ids }),
  toggleOrderSelection: (id) =>
    set((state) => ({
      selectedOrderIds: state.selectedOrderIds.includes(id)
        ? state.selectedOrderIds.filter((item) => item !== id)
        : [...state.selectedOrderIds, id],
    })),
  clearOrderSelection: () => set({ selectedOrderIds: [] }),
}));


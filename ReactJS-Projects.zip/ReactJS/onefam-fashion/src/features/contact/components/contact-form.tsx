"use client";

import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Send,
  CheckCircle2,
  HelpCircle,
  AlertCircle,
  ShieldAlert,
  RotateCcw,
} from "lucide-react";
import { toast } from "sonner";
import {
  validateContactInquiry,
  isMaliciousContent,
  sanitizeString,
} from "@/lib/validations";

interface ContactFormProps {
  whatsappNumber?: string;
}

const INQUIRY_SUBJECTS = [
  "Question About My Order",
  "Product, Sizing & Fit Help",
  "Delivery & Shipping Inquiry",
  "Order Issue / Complaint",
  "Damaged or Defect Item Report",
  "Custom & Bulk Orders",
  "General Question / Feedback",
];

export function ContactForm({}: ContactFormProps = {}) {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    subject: INQUIRY_SUBJECTS[0],
    orderNumber: "",
    message: "",
  });

  const [touched, setTouched] = useState<Record<string, boolean>>({
    name: false,
    email: false,
    phone: false,
    orderNumber: false,
    message: false,
  });

  const [loading, setLoading] = useState(false);
  const [ticketResult, setTicketResult] = useState<{
    ticketId: string;
    name: string;
  } | null>(null);

  // Real-time onchange validation
  const validation = useMemo(() => {
    return validateContactInquiry(form);
  }, [form]);

  // Check if any field contains malicious injection patterns
  const hasMaliciousInput = useMemo(() => {
    return (
      isMaliciousContent(form.name) ||
      isMaliciousContent(form.email) ||
      isMaliciousContent(form.phone) ||
      isMaliciousContent(form.orderNumber) ||
      isMaliciousContent(form.message)
    );
  }, [form]);

  const handleBlur = (field: string) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Restrict strictly to digits only, default to 10-digit Indian mobile
    const raw = e.target.value.replace(/\D/g, "");
    let clean = raw;
    if (raw.length > 10 && raw.startsWith("91")) {
      clean = raw.slice(2, 12);
    } else if (raw.length > 10 && raw.startsWith("0")) {
      clean = raw.slice(1, 11);
    } else {
      clean = raw.slice(0, 10);
    }

    setForm((prev) => ({ ...prev, phone: clean }));
    setTouched((prev) => ({ ...prev, phone: true }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Mark all as touched on submit
    setTouched({
      name: true,
      email: true,
      phone: true,
      orderNumber: true,
      message: true,
    });

    if (hasMaliciousInput) {
      toast.error("Form contains unsafe script tags or code. Please remove them to proceed.");
      return;
    }

    if (!validation.valid) {
      const firstError =
        validation.errors.name ||
        validation.errors.email ||
        validation.errors.phone ||
        validation.errors.orderNumber ||
        validation.errors.message ||
        "Please fix the validation errors before submitting.";
      toast.error(firstError);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: validation.sanitized.name,
          email: validation.sanitized.email,
          phone: validation.sanitized.phone,
          subject: validation.sanitized.subject,
          orderNumber: validation.sanitized.orderNumber,
          message: validation.sanitized.message,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Failed to submit inquiry.");
      }

      setTicketResult({
        ticketId: data.data.ticketId,
        name: data.data.name,
      });
      toast.success("Message received! Ticket ID: " + data.data.ticketId);
    } catch (err: any) {
      toast.error(err.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setTicketResult(null);
    setForm({
      name: "",
      email: "",
      phone: "",
      subject: INQUIRY_SUBJECTS[0],
      orderNumber: "",
      message: "",
    });
    setTouched({
      name: false,
      email: false,
      phone: false,
      orderNumber: false,
      message: false,
    });
  };

  if (ticketResult) {
    return (
      <div className="p-8 sm:p-10 rounded-2xl bg-card border border-border/80 shadow-md space-y-6 text-center animate-in fade-in zoom-in-95">
        <div className="w-16 h-16 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center">
          <CheckCircle2 className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <span className="text-xs font-bold uppercase tracking-widest text-royal-violet dark:text-[#C6F542]">
            Inquiry Successfully Logged
          </span>
          <h3 className="text-2xl font-black text-foreground">
            Thank you, {ticketResult.name}!
          </h3>
          <p className="text-sm text-muted-foreground max-w-md mx-auto leading-relaxed">
            Your message has been assigned a dedicated ticket. Our customer care team will review your details and respond via email or WhatsApp promptly.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-muted/40 border border-border max-w-sm mx-auto space-y-1">
          <span className="text-[11px] uppercase tracking-wider text-muted-foreground font-bold">
            Reference Ticket ID
          </span>
          <p className="text-lg font-mono font-bold text-royal-violet dark:text-[#C6F542]">
            {ticketResult.ticketId}
          </p>
        </div>

        <div className="pt-2 flex items-center justify-center">
          <Button
            onClick={handleReset}
            variant="outline"
            className="text-xs font-bold rounded-xl flex items-center gap-2 h-11 px-6"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Submit Another Question
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 sm:p-8 rounded-2xl bg-card border border-border/80 shadow-sm space-y-6">
      <div className="space-y-1.5 pb-4 border-b border-border/60">
        <div className="flex items-center gap-2 text-xs font-bold tracking-widest text-royal-violet uppercase">
          <HelpCircle className="w-3.5 h-3.5" />
          Customer Care Form
        </div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-foreground">
          Send Us a Direct Message
        </h2>
        <p className="text-xs text-muted-foreground">
          Fill out your inquiry below. Our team reviews all requests within 2-4 business hours.
        </p>
      </div>

      {hasMaliciousInput && (
        <div className="p-3.5 rounded-xl bg-vermilion/10 border border-vermilion/30 text-vermilion text-xs flex items-center gap-2.5 animate-in fade-in">
          <ShieldAlert className="w-4 h-4 shrink-0" />
          <span className="font-semibold">
            Security Notice: Unsafe scripts or HTML tags detected. For your protection, inputs are restricted to standard plain text.
          </span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4 text-xs" noValidate>
        {/* Name and Email */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="font-bold text-foreground block">
              Your Full Name <span className="text-vermilion">*</span>
            </label>
            <Input
              placeholder="e.g. Priyanshu Roy"
              value={form.name}
              maxLength={80}
              onChange={(e) => {
                setForm((prev) => ({ ...prev, name: e.target.value }));
                setTouched((prev) => ({ ...prev, name: true }));
              }}
              onBlur={() => handleBlur("name")}
              className={`h-10 text-xs rounded-xl transition-colors ${
                touched.name && validation.errors.name
                  ? "border-vermilion bg-vermilion/5 focus-visible:ring-vermilion/30"
                  : ""
              }`}
            />
            {touched.name && validation.errors.name && (
              <p className="text-[11px] font-medium text-vermilion flex items-center gap-1 mt-1 animate-in fade-in slide-in-from-top-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                {validation.errors.name}
              </p>
            )}
          </div>

          <div className="space-y-1.5">
            <label className="font-bold text-foreground block">
              Email Address <span className="text-vermilion">*</span>
            </label>
            <Input
              type="email"
              placeholder="name@example.com"
              value={form.email}
              maxLength={120}
              onChange={(e) => {
                setForm((prev) => ({ ...prev, email: e.target.value }));
                setTouched((prev) => ({ ...prev, email: true }));
              }}
              onBlur={() => handleBlur("email")}
              className={`h-10 text-xs rounded-xl transition-colors ${
                touched.email && validation.errors.email
                  ? "border-vermilion bg-vermilion/5 focus-visible:ring-vermilion/30"
                  : ""
              }`}
            />
            {touched.email && validation.errors.email && (
              <p className="text-[11px] font-medium text-vermilion flex items-center gap-1 mt-1 animate-in fade-in slide-in-from-top-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                {validation.errors.email}
              </p>
            )}
          </div>
        </div>

        {/* Mobile Number (Restricted to 10 Digits, India +91) & Order ID */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="font-bold text-foreground">
                Mobile Number <span className="text-vermilion">*</span>
              </label>
              <span className="text-[10px] font-mono text-muted-foreground">
                {form.phone.length}/10 digits
              </span>
            </div>

            {/* Country code prefix default to India (+91) */}
            <div className="flex items-center">
              <div className="h-10 px-3 bg-muted border border-r-0 border-input rounded-l-xl text-xs font-bold text-foreground flex items-center gap-1.5 select-none shrink-0">
                <span className="text-sm">🇮🇳</span>
                <span>+91</span>
              </div>
              <Input
                type="tel"
                placeholder="10-digit mobile number"
                value={form.phone}
                maxLength={10}
                onChange={handlePhoneChange}
                onBlur={() => handleBlur("phone")}
                className={`h-10 text-xs rounded-l-none rounded-r-xl transition-colors font-mono tracking-wider ${
                  touched.phone && validation.errors.phone
                    ? "border-vermilion bg-vermilion/5 focus-visible:ring-vermilion/30"
                    : ""
                }`}
              />
            </div>
            {touched.phone && validation.errors.phone && (
              <p className="text-[11px] font-medium text-vermilion flex items-center gap-1 mt-1 animate-in fade-in slide-in-from-top-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                {validation.errors.phone}
              </p>
            )}
          </div>

          <div className="space-y-1.5">
            <label className="font-bold text-foreground block">
              Order ID <span className="text-muted-foreground font-normal">(Optional)</span>
            </label>
            <Input
              placeholder="e.g. ORD-K7M2-0001"
              value={form.orderNumber}
              maxLength={30}
              onChange={(e) => {
                setForm((prev) => ({ ...prev, orderNumber: e.target.value.toUpperCase() }));
                setTouched((prev) => ({ ...prev, orderNumber: true }));
              }}
              onBlur={() => handleBlur("orderNumber")}
              className={`h-10 text-xs rounded-xl font-mono uppercase transition-colors ${
                touched.orderNumber && validation.errors.orderNumber
                  ? "border-vermilion bg-vermilion/5 focus-visible:ring-vermilion/30"
                  : ""
              }`}
            />
            {touched.orderNumber && validation.errors.orderNumber && (
              <p className="text-[11px] font-medium text-vermilion flex items-center gap-1 mt-1 animate-in fade-in slide-in-from-top-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                {validation.errors.orderNumber}
              </p>
            )}
          </div>
        </div>

        {/* Subject Category */}
        <div className="space-y-1.5">
          <label className="font-bold text-foreground block">
            What is your inquiry regarding? <span className="text-vermilion">*</span>
          </label>
          <select
            value={form.subject}
            onChange={(e) => setForm((prev) => ({ ...prev, subject: e.target.value }))}
            className="w-full h-10 px-3 rounded-xl border border-input bg-background text-foreground text-xs focus:ring-2 focus:ring-royal-violet outline-hidden transition-all"
          >
            {INQUIRY_SUBJECTS.map((subj) => (
              <option key={subj} value={subj}>
                {subj}
              </option>
            ))}
          </select>
        </div>

        {/* Message */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="font-bold text-foreground">
              How can our team help you? <span className="text-vermilion">*</span>
            </label>
            <span className="text-[10px] text-muted-foreground font-mono">
              {form.message.length}/2000 chars
            </span>
          </div>
          <Textarea
            rows={4}
            maxLength={2000}
            placeholder="Please detail your question, sizing concerns, fabric queries, delivery date request, or any complaint..."
            value={form.message}
            onChange={(e) => {
              setForm((prev) => ({ ...prev, message: e.target.value }));
              setTouched((prev) => ({ ...prev, message: true }));
            }}
            onBlur={() => handleBlur("message")}
            className={`text-xs rounded-xl resize-none transition-colors ${
              touched.message && validation.errors.message
                ? "border-vermilion bg-vermilion/5 focus-visible:ring-vermilion/30"
                : ""
            }`}
          />
          {touched.message && validation.errors.message && (
            <p className="text-[11px] font-medium text-vermilion flex items-center gap-1 mt-1 animate-in fade-in slide-in-from-top-1">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              {validation.errors.message}
            </p>
          )}
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <Button
            type="submit"
            disabled={loading || hasMaliciousInput}
            className="w-full bg-royal-violet hover:bg-royal-violet/90 text-white font-bold h-11 rounded-xl text-xs shadow-md transition-all disabled:opacity-50"
          >
            {loading ? (
              "Submitting Inquiry..."
            ) : (
              <>
                <Send className="w-3.5 h-3.5 mr-2" />
                Submit Message to Support
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}

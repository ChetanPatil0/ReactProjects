"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import { formatCurrency, calculateDiscountPercent, buildWhatsAppUrl } from "@/lib/formatters";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/features/storefront/components/product-card/product-card";
import {
  Dialog,
  DialogContent,
} from "@/components/ui/dialog";
import {
  MessageSquare,
  Truck,
  ShieldCheck,
  Check,
  AlertCircle,
  Share2,
  ChevronRight,
  Maximize2,
  X,
  ChevronLeft,
  ZoomIn,
  Sparkles,
  Layers,
  ArrowRight,
  RotateCcw,
} from "lucide-react";
import { toast } from "sonner";

interface ProductDetailViewProps {
  product: {
    id: string;
    name: string;
    slug: string;
    sku?: string | null;
    shortDescription?: string | null;
    description?: string | null;
    regularPrice: any;
    discountPrice?: any;
    isFeatured?: boolean;
    isNewArrival?: boolean;
    category?: { name: string; slug: string } | null;
    images: Array<{ id: string; path: string; altText?: string | null; isPrimary: boolean }>;
    variants: Array<{
      id: string;
      size?: string | null;
      color?: string | null;
      colorHex?: string | null;
      sku?: string | null;
      isAvailable: boolean;
      stock?: number | null;
      priceOverride?: any;
      imagePath?: string | null;
    }>;
    collectionProducts?: Array<{ collection: { title: string; slug: string } }>;
  };
  relatedProducts: any[];
  whatsappNumber?: string;
}

export function ProductDetailView({
  product,
  relatedProducts,
  whatsappNumber = "919876543210",
}: ProductDetailViewProps) {
  const images =
    product.images.length > 0
      ? product.images
      : [{ id: "def", path: "", altText: product.name, isPrimary: true }];

  // Gallery state
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isFullscreenOpen, setIsFullscreenOpen] = useState(false);

  // Hover Zoom state
  const [isZooming, setIsZooming] = useState(false);
  const [zoomCoords, setZoomCoords] = useState({ x: 50, y: 50 });
  const imageContainerRef = useRef<HTMLDivElement>(null);

  // Unique sizes and colors
  const sizes = Array.from(
    new Set(product.variants.map((v) => v.size).filter((s): s is string => Boolean(s)))
  );
  const colors = Array.from(
    new Set(product.variants.map((v) => v.color).filter((c): c is string => Boolean(c)))
  );

  // Selections
  const [selectedSize, setSelectedSize] = useState<string | null>(sizes[0] || null);
  const [selectedColor, setSelectedColor] = useState<string | null>(colors[0] || null);

  // Active variant matching selections
  const activeVariant = product.variants.find((v) => {
    const sizeMatches = !selectedSize || v.size === selectedSize;
    const colorMatches = !selectedColor || v.color === selectedColor;
    return sizeMatches && colorMatches;
  });

  // Variant-wise Image Media switching!
  useEffect(() => {
    if (!selectedColor && !activeVariant) return;

    // 1. Direct variant image matching
    if (activeVariant?.imagePath) {
      const directIndex = images.findIndex((img) => img.path === activeVariant.imagePath);
      if (directIndex !== -1) {
        setActiveImageIndex(directIndex);
        return;
      }
    }

    // 2. Color-tagged image matching
    if (selectedColor) {
      const colorLower = selectedColor.toLowerCase();
      const matchingImgIndex = images.findIndex((img) => {
        const alt = (img.altText || "").toLowerCase();
        const path = img.path.toLowerCase();
        return (
          alt === `variant:${colorLower}` ||
          alt.includes(colorLower) ||
          path.includes(colorLower)
        );
      });

      if (matchingImgIndex !== -1) {
        setActiveImageIndex(matchingImgIndex);
      }
    }
  }, [selectedColor, activeVariant, images]);

  // Out of stock detection for current selection
  const isSelectedVariantOutOfStock =
    activeVariant && (activeVariant.isAvailable === false || activeVariant.stock === 0);

  const regularPrice = Number(product.regularPrice);
  const discountPrice = product.discountPrice ? Number(product.discountPrice) : null;
  const activePrice = activeVariant?.priceOverride
    ? Number(activeVariant.priceOverride)
    : discountPrice || regularPrice;

  const discountPercent = calculateDiscountPercent(regularPrice, discountPrice);
  const currentImage = images[activeImageIndex] || images[0];

  // Mouse hover zoom calculation
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!imageContainerRef.current) return;
    const { left, top, width, height } = imageContainerRef.current.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    setZoomCoords({ x: Math.max(0, Math.min(100, x)), y: Math.max(0, Math.min(100, y)) });
  };

  const [pageUrl, setPageUrl] = useState<string | undefined>(undefined);

  useEffect(() => {
    if (typeof window !== "undefined") {
      setPageUrl(window.location.href);
    }
  }, []);

  const handleShare = () => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      toast.success("Product link copied to clipboard!");
    }
  };

  // Pre-filled WhatsApp message
  const whatsappUrl = buildWhatsAppUrl({
    whatsappNumber,
    productName: product.name,
    productSku: activeVariant?.sku || product.sku,
    size: selectedSize,
    color: selectedColor,
    price: activePrice,
    productUrl: pageUrl,
  });

  const whatsappRestockUrl = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(
    `Hello OneFam Concierge! I am interested in "${product.name}" (${selectedColor || ""} / ${selectedSize || ""}, SKU: ${activeVariant?.sku || product.sku || ""}), but it is currently marked as Sold Out. Could you please notify me when restocked or if made-to-order is possible? Thank you!`
  )}`;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16">
      {/* Breadcrumb Navigation */}
      <nav className="flex items-center space-x-2 text-xs text-muted-foreground">
        <Link href="/" className="hover:text-foreground transition-colors">
          Home
        </Link>
        <ChevronRight className="w-3.5 h-3.5" />
        {product.category && (
          <>
            <Link href={`/${product.category.slug}`} className="hover:text-foreground transition-colors">
              {product.category.name}
            </Link>
            <ChevronRight className="w-3.5 h-3.5" />
          </>
        )}
        <span className="text-foreground font-semibold truncate max-w-xs">{product.name}</span>
      </nav>

      {/* Main Grid: Regular-Sized Gallery on Left (5 cols), Details & Order Box on Right (7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        {/* Left: Gallery Column (Balanced width, no oversized image) */}
        <div className="lg:col-span-5 max-w-[480px] mx-auto lg:mx-0 w-full flex flex-col-reverse sm:flex-row gap-3.5 sm:gap-4">
          {/* Whole Gallery Thumbnails Strip */}
          {images.length > 1 && (
            <div className="flex sm:flex-col gap-2.5 overflow-x-auto sm:overflow-y-auto max-h-[500px] shrink-0 p-0.5 no-scrollbar">
              {images.map((img, idx) => (
                <button
                  key={img.id || idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`w-14 h-18 sm:w-16 sm:h-20 rounded-xl overflow-hidden border-2 transition-all shrink-0 ${
                    activeImageIndex === idx
                      ? "border-royal-violet ring-2 ring-royal-violet/30 scale-102 shadow-xs"
                      : "border-border/80 hover:border-foreground/40 opacity-70 hover:opacity-100"
                  }`}
                  title={`View image ${idx + 1}`}
                >
                  <img
                    src={img.path}
                    alt={img.altText || `Thumbnail ${idx + 1}`}
                    className="w-full h-full object-cover object-top"
                  />
                </button>
              ))}
            </div>
          )}

          {/* Main Regular-Sized Display with Zoom Lens & Lightbox Trigger */}
          <div className="flex-1 flex flex-col gap-2">
            <div
              ref={imageContainerRef}
              onMouseEnter={() => setIsZooming(true)}
              onMouseLeave={() => setIsZooming(false)}
              onMouseMove={handleMouseMove}
              onClick={() => setIsFullscreenOpen(true)}
              className="relative aspect-[3/4] max-h-[500px] rounded-2xl overflow-hidden bg-muted/30 dark:bg-[#1a1725] border border-border/80 shadow-xs cursor-zoom-in group"
            >
              {/* Badges */}
              <div className="absolute top-3.5 left-3.5 z-10 flex flex-col gap-1.5 pointer-events-none">
                {isSelectedVariantOutOfStock ? (
                  <span className="px-3 py-1 rounded-full bg-black/90 text-white text-[11px] font-black uppercase tracking-wider backdrop-blur-xs shadow-md">
                    Sold Out
                  </span>
                ) : (
                  discountPercent > 0 && (
                    <span className="px-3 py-1 rounded-full bg-vermilion text-white text-[11px] font-black uppercase tracking-wider shadow-md">
                      {discountPercent}% OFF
                    </span>
                  )
                )}
              </div>

              {/* Gallery Image Counter Badge */}
              {images.length > 1 && (
                <div className="absolute bottom-3 left-3 z-10 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-white text-[11px] font-mono pointer-events-none">
                  {activeImageIndex + 1} / {images.length}
                </div>
              )}

              {/* Left / Right Quick Cycle Buttons on Hover */}
              {images.length > 1 && (
                <>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveImageIndex((prev) => (prev - 1 + images.length) % images.length);
                    }}
                    className="absolute left-2.5 top-1/2 -translate-y-1/2 z-10 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-ink shadow-md backdrop-blur-xs transition opacity-0 group-hover:opacity-100 flex items-center justify-center hover:scale-110"
                    title="Previous photo"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveImageIndex((prev) => (prev + 1) % images.length);
                    }}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 z-10 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-ink shadow-md backdrop-blur-xs transition opacity-0 group-hover:opacity-100 flex items-center justify-center hover:scale-110"
                    title="Next photo"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </>
              )}

              {/* Fullscreen Expand Action Pill */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsFullscreenOpen(true);
                }}
                className="absolute top-3.5 right-3.5 z-10 p-2 rounded-full bg-white/90 dark:bg-[#1f1b2c]/90 hover:bg-white dark:hover:bg-[#1f1b2c] text-foreground shadow-md backdrop-blur-xs transition hover:scale-110"
                title="View in Fullscreen Lightbox"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>

              {/* Main Image with Zoom Transform */}
              {currentImage.path ? (
                <img
                  src={currentImage.path}
                  alt={currentImage.altText || product.name}
                  style={{
                    transformOrigin: `${zoomCoords.x}% ${zoomCoords.y}%`,
                    transform: isZooming ? "scale(2.2)" : "scale(1)",
                  }}
                  className={`w-full h-full object-cover object-top transition-transform duration-200 ease-out ${
                    isSelectedVariantOutOfStock ? "grayscale-20 opacity-80" : ""
                  }`}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">
                  No Preview Image Available
                </div>
              )}
            </div>

            {/* Whole Gallery Trigger Button */}
            {images.length > 1 && (
              <button
                type="button"
                onClick={() => setIsFullscreenOpen(true)}
                className="w-full py-2 px-3 rounded-xl border border-border/80 bg-card hover:bg-muted/50 text-xs font-semibold text-foreground flex items-center justify-center gap-1.5 transition shadow-2xs"
              >
                <Layers className="w-3.5 h-3.5 text-royal-violet" />
                <span>View Whole Gallery ({images.length} Photos)</span>
              </button>
            )}
          </div>
        </div>

        {/* Right: Info, Variant Matrix & Concierge Order Box (7 cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
          <div className="space-y-5">
            {/* Category Tag & SKU */}
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-royal-violet uppercase tracking-wider">
                {product.category?.name || "OneFam Atelier"}
              </span>
              {activeVariant?.sku ? (
                <span className="text-muted-foreground font-mono text-[11px]">
                  SKU: {activeVariant.sku}
                </span>
              ) : product.sku ? (
                <span className="text-muted-foreground font-mono text-[11px]">
                  SKU: {product.sku}
                </span>
              ) : null}
            </div>

            {/* Title */}
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-foreground leading-tight">
              {product.name}
            </h1>

            {/* Short Hook */}
            {product.shortDescription && (
              <p className="text-sm text-muted-foreground leading-relaxed">
                {product.shortDescription}
              </p>
            )}

            {/* Pricing Section */}
            <div className="pt-1 flex items-baseline gap-3">
              <span className="text-2xl sm:text-3xl font-black text-foreground">
                {formatCurrency(activePrice)}
              </span>
              {discountPrice && (
                <span className="text-base text-muted-foreground line-through">
                  {formatCurrency(regularPrice)}
                </span>
              )}
              {discountPercent > 0 && (
                <span className="text-xs font-black text-vermilion bg-rose-50 dark:bg-rose-950/40 px-2.5 py-0.5 rounded-full border border-rose-200 dark:border-rose-900/60">
                  {discountPercent}% OFF · Save {formatCurrency(regularPrice - activePrice)}
                </span>
              )}
            </div>

            {/* Color Selector */}
            {colors.length > 0 && (
              <div className="pt-4 border-t border-border">
                <div className="flex items-center justify-between mb-2.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-foreground">
                    Colour: <span className="font-extrabold text-royal-violet ml-1">{selectedColor}</span>
                  </label>
                </div>
                <div className="flex flex-wrap gap-2.5">
                  {colors.map((c) => {
                    const isSelected = selectedColor === c;
                    const variantForColor = product.variants.find((v) => v.color === c);
                    const hex = variantForColor?.colorHex || "#191720";
                    const isColorOutOfStock =
                      variantForColor && (variantForColor.isAvailable === false || variantForColor.stock === 0);

                    return (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setSelectedColor(c)}
                        title={`${c} ${isColorOutOfStock ? "(Sold Out)" : ""}`}
                        className={`relative w-9 h-9 rounded-full border-2 transition-all p-0.5 flex items-center justify-center overflow-hidden ${
                          isSelected
                            ? "border-royal-violet ring-2 ring-royal-violet/30 scale-110"
                            : "border-border hover:scale-105"
                        } ${isColorOutOfStock ? "opacity-60" : ""}`}
                      >
                        <span
                          className="w-full h-full rounded-full block border border-black/15 shadow-2xs"
                          style={{ backgroundColor: hex }}
                        />
                        {isSelected && (
                          <Check className="absolute w-4 h-4 text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] z-10" />
                        )}
                        {isColorOutOfStock && !isSelected && (
                          <span className="absolute inset-0 flex items-center justify-center z-10">
                            <span className="w-5 h-0.5 bg-vermilion rotate-45 block" />
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Sizing Selector */}
            {sizes.length > 0 && (
              <div className="pt-4 border-t border-border">
                <div className="flex items-center justify-between mb-2.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-foreground">
                    Size: <span className="font-extrabold text-royal-violet ml-1">{selectedSize}</span>
                  </label>
                  <span className="text-[11px] text-muted-foreground">Standard Fashion Fit</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {sizes.map((s) => {
                    const isSelected = selectedSize === s;
                    const matchingVar = product.variants.find(
                      (v) => v.size === s && (!selectedColor || v.color === selectedColor)
                    );
                    const isSizeOutOfStock =
                      matchingVar && (matchingVar.isAvailable === false || matchingVar.stock === 0);

                    return (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setSelectedSize(s)}
                        className={`min-w-12 h-10 px-3.5 rounded-xl border text-xs font-bold transition flex items-center justify-center relative ${
                          isSelected
                            ? "bg-royal-violet text-white border-royal-violet ring-2 ring-royal-violet/25 shadow-xs"
                            : isSizeOutOfStock
                            ? "bg-muted/40 border-border text-muted-foreground line-through opacity-60"
                            : "bg-card border-border text-foreground hover:border-royal-violet hover:text-royal-violet"
                        }`}
                      >
                        {s}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Stock Status Banner */}
            <div className="pt-2">
              {isSelectedVariantOutOfStock ? (
                <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-vermilion flex items-center gap-2 text-xs font-bold">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>
                    Currently Sold Out in {selectedColor} ({selectedSize}). You can still message our Concierge to request priority restock!
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                  <Check className="w-4 h-4" />
                  <span>
                    In Stock at Bengaluru Atelier · Ready for 24h Express Dispatch
                  </span>
                </div>
              )}
            </div>

            {/* Order Action Buttons */}
            <div className="pt-2 space-y-3">
              {isSelectedVariantOutOfStock ? (
                <Button
                  asChild
                  size="lg"
                  className="w-full h-13 bg-card border border-border/80 hover:bg-muted text-foreground font-extrabold text-sm rounded-xl shadow-md transition-all"
                >
                  <a href={whatsappRestockUrl} target="_blank" rel="noopener noreferrer">
                    <MessageSquare className="w-5 h-5 mr-2 text-emerald-500" />
                    Inquire Restock / Pre-order on WhatsApp
                  </a>
                </Button>
              ) : (
                <Button
                  asChild
                  size="lg"
                  className="w-full h-13 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm sm:text-base rounded-xl shadow-lg hover:shadow-emerald-600/25 transition-all hover:scale-[1.01] active:scale-[0.99]"
                >
                  <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
                    <MessageSquare className="w-5 h-5 mr-2 text-white" />
                    Order on WhatsApp
                  </a>
                </Button>
              )}

              <div className="flex items-center justify-between text-xs text-muted-foreground pt-1">
                <button
                  type="button"
                  onClick={handleShare}
                  className="flex items-center gap-1.5 hover:text-foreground font-semibold transition-colors"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  Share Style Link
                </button>
                <Link
                  href="/track-order"
                  className="flex items-center gap-1.5 hover:text-foreground font-semibold transition-colors"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-royal-violet" />
                  Track Existing Order
                </Link>
              </div>
            </div>
          </div>

          {/* Value Props & Guarantees */}
          <div className="pt-6 border-t border-border grid grid-cols-2 gap-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-royal-violet shrink-0" />
              <span>Insured 2-4 day domestic delivery</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-royal-violet shrink-0" />
              <span>100% Verified Pure Atelier Fabric</span>
            </div>
          </div>
        </div>
      </div>

      {/* Full Description & Care Section */}
      {product.description && (
        <div className="pt-10 border-t border-border space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-royal-violet">
            <Sparkles className="w-4 h-4 text-royal-violet" />
            <span>Garment Anatomy</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-foreground">
            Craftsmanship, Silhouette &amp; Fabric Care
          </h2>
          <div className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line max-w-3xl">
            {product.description}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* RELATED PRODUCTS SECTION (ALWAYS SHOWN BELOW) */}
      {/* ========================================================================= */}
      {relatedProducts && relatedProducts.length > 0 && (
        <section className="pt-12 border-t border-border space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <div className="flex items-center gap-1.5 text-xs font-bold tracking-widest text-royal-violet uppercase">
                <Sparkles className="w-3.5 h-3.5 text-royal-violet" />
                Curated Pairings
              </div>
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-foreground mt-1">
                Related Pieces &amp; Completing Styles
              </h2>
              <p className="text-xs sm:text-sm text-muted-foreground mt-1">
                Tailored garments crafted to effortlessly pair with this aesthetic.
              </p>
            </div>

            <Button asChild variant="outline" size="sm" className="rounded-full text-xs font-semibold self-start sm:self-auto">
              <Link href={product.category ? `/${product.category.slug}` : "/collections/new-arrivals"}>
                View More in Collection <ArrowRight className="ml-1.5 w-3.5 h-3.5" />
              </Link>
            </Button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {relatedProducts.slice(0, 4).map((rel) => (
              <ProductCard key={rel.id} product={rel} whatsappNumber={whatsappNumber} />
            ))}
          </div>
        </section>
      )}

      {/* Fullscreen Lightbox / Whole Gallery Modal */}
      <Dialog open={isFullscreenOpen} onOpenChange={setIsFullscreenOpen}>
        <DialogContent className="max-w-6xl w-[95vw] h-[92vh] p-0 overflow-hidden bg-black/95 border-0 text-white flex flex-col justify-between">
          {/* Top Bar */}
          <div className="p-4 flex items-center justify-between z-20 bg-gradient-to-b from-black/80 to-transparent">
            <div>
              <span className="text-sm font-bold text-white block">{product.name}</span>
              <span className="text-xs text-white/60">
                Image {activeImageIndex + 1} of {images.length} · Fullscreen Gallery View
              </span>
            </div>
            <button
              type="button"
              onClick={() => setIsFullscreenOpen(false)}
              className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Central High-Res View with Previous / Next Arrows */}
          <div className="relative flex-1 flex items-center justify-center p-4 overflow-hidden">
            {images.length > 1 && (
              <button
                type="button"
                onClick={() =>
                  setActiveImageIndex((prev) => (prev - 1 + images.length) % images.length)
                }
                className="absolute left-6 z-20 w-12 h-12 rounded-full bg-white/10 hover:bg-white/25 text-white flex items-center justify-center backdrop-blur-md transition"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
            )}

            <img
              src={currentImage.path}
              alt={currentImage.altText || product.name}
              className="max-h-full max-w-full object-contain select-none shadow-2xl"
            />

            {images.length > 1 && (
              <button
                type="button"
                onClick={() => setActiveImageIndex((prev) => (prev + 1) % images.length)}
                className="absolute right-6 z-20 w-12 h-12 rounded-full bg-white/10 hover:bg-white/25 text-white flex items-center justify-center backdrop-blur-md transition"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            )}
          </div>

          {/* Bottom Thumbnails Strip */}
          {images.length > 1 && (
            <div className="p-4 bg-gradient-to-t from-black/80 to-transparent flex items-center justify-center gap-3 overflow-x-auto z-20">
              {images.map((img, idx) => (
                <button
                  key={img.id || idx}
                  type="button"
                  onClick={() => setActiveImageIndex(idx)}
                  className={`w-14 h-16 rounded-lg overflow-hidden border-2 transition ${
                    activeImageIndex === idx ? "border-electric-lime scale-110" : "border-white/20 opacity-60 hover:opacity-100"
                  }`}
                >
                  <img src={img.path} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

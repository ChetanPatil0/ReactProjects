import Link from "next/link";
import { MessageSquare, Mail, ShieldCheck, ArrowUpRight, Instagram, Facebook, Headphones, Clock } from "lucide-react";
import { OneFamLogo } from "@/components/brand/onefam-logo";
import { siteConfig } from "@/config/site";

interface StorefrontFooterProps {
  settings?: {
    whatsappNumber?: string | null;
    supportEmail?: string | null;
    instagramUrl?: string | null;
    facebookUrl?: string | null;
  } | null;
}

export function StorefrontFooter({ settings }: StorefrontFooterProps) {
  const whatsappNumber = settings?.whatsappNumber || siteConfig.contact.whatsappNumber;
  const supportEmail = settings?.supportEmail || siteConfig.contact.supportEmail;
  const instagramUrl = settings?.instagramUrl || siteConfig.social.instagram;
  const facebookUrl = settings?.facebookUrl || siteConfig.social.facebook;

  const cleanPhone = whatsappNumber.replace(/[^0-9]/g, "");

  return (
    <footer className="bg-[#15131C] dark:bg-[#0D0B12] text-[#FCFAF4] pt-16 pb-12 border-t border-white/10 select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          {/* 1. Official Brand Identity Logo on Dark Background */}
          <div className="lg:col-span-2 space-y-4">
            <Link href="/" prefetch={true} className="inline-block">
              <OneFamLogo variant="dark" size="md" />
            </Link>
            <p className="text-sm text-white/75 leading-relaxed max-w-sm">
              {siteConfig.brand.description}
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 text-xs font-bold px-4 py-2.5 rounded-full bg-royal-violet hover:bg-royal-violet/90 text-white shadow-md transition-all hover:scale-102"
              >
                <Mail className="w-4 h-4 text-white" />
                Contact Customer Support
              </Link>
            </div>

            {/* Social Channels Icons */}
            <div className="pt-3 flex items-center gap-3">
              <span className="text-xs text-white/60 font-medium mr-1">Follow Us:</span>
              <a
                href={instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Follow OneFam on Instagram"
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-gradient-to-tr hover:from-amber-500 hover:to-pink-500 flex items-center justify-center text-white/80 hover:text-white transition-all hover:scale-110 shadow-xs"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Follow OneFam on Facebook"
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-[#1877F2] flex items-center justify-center text-white/80 hover:text-white transition-all hover:scale-110 shadow-xs"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href={`https://wa.me/${cleanPhone}`}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Chat with OneFam on WhatsApp"
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-emerald-600 flex items-center justify-center text-white/80 hover:text-white transition-all hover:scale-110 shadow-xs"
              >
                <MessageSquare className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* 2. Quick Collections Links */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-electric-lime mb-4">
              Explore Collections
            </h3>
            <ul className="space-y-2.5 text-sm text-white/80">
              <li>
                <Link href="/men" prefetch={true} className="hover:text-white transition-colors">
                  Men&apos;s Tailoring &amp; Linen
                </Link>
              </li>
              <li>
                <Link href="/women" prefetch={true} className="hover:text-white transition-colors">
                  Women&apos;s Evening &amp; Everyday
                </Link>
              </li>
              <li>
                <Link href="/kids" prefetch={true} className="hover:text-white transition-colors">
                  Kids Festive &amp; Playwear
                </Link>
              </li>
              <li>
                <Link href="/collections" prefetch={true} className="hover:text-white transition-colors font-medium text-white">
                  All Collections
                </Link>
              </li>
              <li>
                <Link href="/offers" prefetch={true} className="text-vermilion hover:underline font-semibold">
                  Exclusive Offers
                </Link>
              </li>
            </ul>
          </div>

          {/* 3. Customer Care & Inquiries */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-electric-lime mb-4">
              Client Care
            </h3>
            <ul className="space-y-2.5 text-sm text-white/80">
              <li>
                <Link href="/track-order" className="hover:text-white flex items-center gap-1.5 font-medium text-white/90">
                  <ShieldCheck className="w-3.5 h-3.5 text-electric-lime" />
                  Track Your Order
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-white transition-colors font-medium text-white">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/faq" className="hover:text-white transition-colors">
                  FAQ &amp; Shopping Guide
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-white transition-colors">
                  The OneFam Story
                </Link>
              </li>
              <li>
                <Link href="/policies/shipping" className="hover:text-white transition-colors">
                  Shipping &amp; Delivery
                </Link>
              </li>
              <li>
                <Link href="/policies/privacy" className="hover:text-white transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/policies/terms" className="hover:text-white transition-colors">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>

          {/* 4. Customer Support & Hours */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-electric-lime mb-4">
              Care &amp; Support
            </h3>
            <ul className="space-y-3 text-xs text-white/75">
              <li className="flex items-center gap-2">
                <Headphones className="w-4 h-4 text-royal-violet shrink-0" />
                <span className="font-semibold text-white/90">{siteConfig.contact.storeModel}</span>
              </li>
              <li className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                <a
                  href={`https://wa.me/${cleanPhone}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-emerald-400 transition-colors"
                >
                  WhatsApp: +{whatsappNumber}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-royal-violet shrink-0" />
                <a href={`mailto:${supportEmail}`} className="hover:text-white transition-colors">
                  {supportEmail}
                </a>
              </li>
              <li className="flex items-center gap-2 pt-2 border-t border-white/10 text-[11px] text-white/60">
                <Clock className="w-3.5 h-3.5 shrink-0 text-white/50" />
                <span>{siteConfig.contact.operatingHoursShort}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright & staff link */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between text-xs text-white/60 gap-4">
          <p>© {new Date().getFullYear()} {siteConfig.brand.name}. All rights reserved.</p>

          <div className="flex items-center space-x-6">
            <Link href="/contact" className="hover:text-white transition">
              Contact Desk
            </Link>
            <Link href="/track-order" className="hover:text-white transition">
              Order Tracking
            </Link>
            <Link href="/admin/login" className="hover:text-white transition flex items-center gap-1">
              Staff Portal <ArrowUpRight className="w-3 h-3 text-electric-lime" />
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

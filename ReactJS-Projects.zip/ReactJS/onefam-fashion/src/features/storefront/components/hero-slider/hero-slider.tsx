"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { ChevronLeft, ChevronRight, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export interface HeroSlideItem {
  id: string;
  title: string;
  subtitle?: string | null;
  description?: string | null;
  primaryCtaText?: string | null;
  primaryCtaUrl?: string | null;
  secondaryCtaText?: string | null;
  secondaryCtaUrl?: string | null;
  desktopImage: string;
  mobileImage?: string | null;
}

interface HeroSliderProps {
  slides: HeroSlideItem[];
}

export function HeroSlider({ slides }: HeroSliderProps) {
  const [current, setCurrent] = useState(0);
  const [touchStart, setTouchStart] = useState<number | null>(null);

  const nextSlide = useCallback(() => {
    if (slides.length <= 1) return;
    setCurrent((prev) => (prev + 1) % slides.length);
  }, [slides.length]);

  const prevSlide = useCallback(() => {
    if (slides.length <= 1) return;
    setCurrent((prev) => (prev - 1 + slides.length) % slides.length);
  }, [slides.length]);

  // Autoplay
  useEffect(() => {
    if (slides.length <= 1) return;
    const interval = setInterval(nextSlide, 6500);
    return () => clearInterval(interval);
  }, [nextSlide, slides.length]);

  if (!slides || slides.length === 0) return null;

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStart === null) return;
    const touchEnd = e.changedTouches[0].clientX;
    const diff = touchStart - touchEnd;
    if (diff > 50) nextSlide();
    if (diff < -50) prevSlide();
    setTouchStart(null);
  };

  return (
    <div
      className="relative w-full h-[520px] sm:h-[620px] lg:h-[720px] bg-ink overflow-hidden select-none"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {slides.map((slide, index) => {
        const isActive = index === current;
        return (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              isActive ? "opacity-100 z-10 pointer-events-auto" : "opacity-0 z-0 pointer-events-none"
            }`}
          >
            {/* Background Image with Dark Vignette */}
            <div
              className="absolute inset-0 bg-cover bg-center transition-transform duration-7000 ease-out transform scale-100"
              style={{
                backgroundImage: `url(${slide.desktopImage})`,
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-ink/90 via-ink/60 to-transparent" />
            </div>

            {/* Content Container */}
            <div className="relative max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
              {slide.description && slide.description.includes("<") ? (
                /* Pure HTML-rendered slide overlay */
                <div
                  className="hero-html-overlay max-w-2xl text-paper"
                  dangerouslySetInnerHTML={{ __html: slide.description }}
                />
              ) : (
                /* Standard layout for slides with discrete fields */
                <div className="max-w-xl text-paper space-y-4">
                  {slide.subtitle && (
                    <span className="inline-block text-xs uppercase tracking-[0.25em] font-bold text-electric-lime px-3 py-1 bg-ink/50 backdrop-blur-xs rounded-full border border-electric-lime/30">
                      {slide.subtitle}
                    </span>
                  )}

                  <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-[1.08] text-paper">
                    {slide.title}
                  </h1>

                  {slide.description && (
                    <div
                      className="text-sm sm:text-base text-paper/85 line-clamp-3 leading-relaxed max-w-lg prose-invert [&_strong]:text-white [&_strong]:font-bold [&_em]:italic [&_span]:text-electric-lime"
                      dangerouslySetInnerHTML={{ __html: slide.description }}
                    />
                  )}

                  <div className="pt-4 flex flex-wrap items-center gap-3">
                    {slide.primaryCtaText && (
                      <Button
                        asChild
                        size="lg"
                        className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-full px-8 shadow-lg hover:shadow-royal-violet/25"
                      >
                        <Link href={slide.primaryCtaUrl || "/collections/new-arrivals"}>
                          {slide.primaryCtaText}
                          <ArrowRight className="ml-2 w-4 h-4" />
                        </Link>
                      </Button>
                    )}

                    {slide.secondaryCtaText && (
                      <Button
                        asChild
                        variant="outline"
                        size="lg"
                        className="border-paper/40 text-paper hover:bg-paper/10 hover:text-white rounded-full px-6 font-semibold"
                      >
                        <Link href={slide.secondaryCtaUrl || "/women"}>
                          {slide.secondaryCtaText}
                        </Link>
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        );
      })}

      {/* Navigation Arrows */}
      {slides.length > 1 && (
        <>
          <button
            onClick={prevSlide}
            aria-label="Previous Slide"
            className="hidden sm:flex absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-ink/50 backdrop-blur-xs text-white border border-paper/20 items-center justify-center hover:bg-royal-violet transition"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={nextSlide}
            aria-label="Next Slide"
            className="hidden sm:flex absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-ink/50 backdrop-blur-xs text-white border border-paper/20 items-center justify-center hover:bg-royal-violet transition"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </>
      )}

      {/* Slide Dots Indicator */}
      {slides.length > 1 && (
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex items-center space-x-2">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              aria-label={`Go to slide ${i + 1}`}
              className={`h-2 rounded-full transition-all duration-300 ${
                i === current ? "w-8 bg-electric-lime" : "w-2 bg-paper/40 hover:bg-paper/70"
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
}


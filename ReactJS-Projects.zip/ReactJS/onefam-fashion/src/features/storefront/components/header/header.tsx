"use client";

import Link from "next/link";
import { useState, useRef, useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Search, MessageSquare, Menu, X, ArrowRight, ShieldCheck, ChevronDown, ChevronRight, Sparkles, Mail } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { OneFamLogo } from "@/components/brand/onefam-logo";
import { ThemeToggle } from "@/components/theme/theme-toggle";
import { siteConfig } from "@/config/site";

export interface HeaderCategory {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  imagePath?: string | null;
  displayOrder?: number;
  isActive?: boolean;
  children?: Array<{
    id: string;
    name: string;
    slug: string;
    description?: string | null;
    imagePath?: string | null;
    displayOrder?: number;
    isActive?: boolean;
  }>;
}

export interface HeaderCollection {
  id: string;
  title: string;
  slug: string;
  description?: string | null;
  coverImage?: string | null;
}

interface HeaderProps {
  announcement?: string;
  whatsappNumber?: string;
  categories?: HeaderCategory[];
  collections?: HeaderCollection[];
}

const defaultCategoryList: HeaderCategory[] = [
  {
    id: "cat-men",
    name: "Men",
    slug: "men",
    description: "Contemporary tailoring, linen camp shirts, and everyday essentials.",
    imagePath: siteConfig.images.banners.men,
    children: [
      { id: "sub-m1", name: "T-Shirts & Polos", slug: "men-t-shirts", description: "Heavyweight cotton oversized tees and slim piqué polos." },
      { id: "sub-m2", name: "Casual & Linen Shirts", slug: "men-shirts", description: "Bespoke linen, resort-collar shirts and overshirts." },
      { id: "sub-m3", name: "Denim & Jeans", slug: "men-jeans", description: "Selvedge denim, relaxed straight cuts and tapered silhouettes." },
      { id: "sub-m4", name: "Trousers & Chinos", slug: "men-trousers", description: "Pleated tailored trousers and stretch cotton chinos." },
    ],
  },
  {
    id: "cat-women",
    name: "Women",
    slug: "women",
    description: "Fluid elegance, architectural tops, modern kurtis and statement dresses.",
    imagePath: siteConfig.images.banners.women,
    children: [
      { id: "sub-w1", name: "Dresses & Jumpsuits", slug: "women-dresses", description: "Daytime maxi dresses, slip gowns and jumpsuits." },
      { id: "sub-w2", name: "Tops & Blouses", slug: "women-tops", description: "Architectural tops and draped silk-blend blouses." },
      { id: "sub-w3", name: "Ethnic Kurtis & Sets", slug: "women-kurtis", description: "Hand-embellished contemporary kurtis and co-ord sets." },
      { id: "sub-w4", name: "Pants & Skirts", slug: "women-pants", description: "Wide-leg trousers and bias-cut satin skirts." },
    ],
  },
  {
    id: "cat-kids",
    name: "Kids",
    slug: "kids",
    description: "Playful, comfortable and durable apparel designed for children.",
    imagePath: siteConfig.images.banners.kids,
    children: [
      { id: "sub-k1", name: "Boys Apparel", slug: "kids-boys", description: "Soft cotton shirts, graphic tees and joggers." },
      { id: "sub-k2", name: "Girls Apparel", slug: "kids-girls", description: "Floral frocks, dungarees and everyday basics." },
      { id: "sub-k3", name: "Clothing Sets & Rompers", slug: "kids-sets", description: "Coordinated festive sets and breathable rompers." },
    ],
  },
];

const defaultCollectionList: HeaderCollection[] = [
  { id: "col-urban", title: "Urban Minimalist", slug: "urban-minimalist" },
  { id: "col-autumn", title: "Autumn / Winter '26", slug: "autumn-winter-26" },
  { id: "col-linen", title: "Linen Heritage", slug: "linen-heritage" },
];

export function StorefrontHeader({
  announcement = "Express Delivery Across India | New Autumn/Winter '26 Collection",
  whatsappNumber = siteConfig.contact.whatsappNumber,
  categories,
  collections,
}: HeaderProps) {
  const router = useRouter();
  const pathname = usePathname();
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Smoothly hide top announcement section on scroll
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Desktop Dropdown state with hover delay debounce
  const [activeDropdownId, setActiveDropdownId] = useState<string | null>(null);
  const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Mobile Accordion state
  const [openMobileCategories, setOpenMobileCategories] = useState<Record<string, boolean>>({});

  // Close dropdown on route change
  useEffect(() => {
    setActiveDropdownId(null);
    setIsMobileOpen(false);
  }, [pathname]);

  const handleMouseEnter = (id: string) => {
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
    }
    setActiveDropdownId(id);
  };

  const handleMouseLeave = () => {
    hoverTimeoutRef.current = setTimeout(() => {
      setActiveDropdownId(null), 150;
    });
  };

  const toggleMobileCategory = (catId: string) => {
    setOpenMobileCategories((prev) => ({
      ...prev,
      [catId]: !prev[catId],
    }));
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setIsSearchOpen(false);
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  // Build active lists
  const displayCategories: HeaderCategory[] =
    categories && categories.length > 0 ? categories : defaultCategoryList;

  const displayCollections: HeaderCollection[] =
    collections && collections.length > 0 ? collections : defaultCollectionList;

  // Build category nav items
  const categoryNavItems = displayCategories.map((cat) => ({
    id: cat.id,
    label: cat.name,
    href: `/${cat.slug}`,
    category: cat,
  }));

  const standardNavItems = [
    { id: "nav-new-arrivals", label: "New Arrivals", href: "/collections/new-arrivals", isNew: true },
    { id: "nav-offers", label: "Offers", href: "/offers", isSale: true },
  ];

  const isCollectionsActive =
    pathname === "/collections" ||
    (pathname.startsWith("/collections/") && pathname !== "/collections/new-arrivals");

  return (
    <header className="sticky top-0 z-40 w-full bg-background/95 backdrop-blur-md border-b border-border transition-all">
      {/* 1. Announcement Bar - Smoothly hides on scroll */}
      <div
        className={`overflow-hidden transition-all duration-300 ease-in-out bg-[#15131C] dark:bg-[#0D0B12] text-[#FCFAF4] text-[11px] sm:text-xs text-center font-medium tracking-normal sm:tracking-wide flex items-center justify-center leading-snug sm:leading-normal ${
          isScrolled
            ? "max-h-0 opacity-0 py-0 px-0 pointer-events-none"
            : "max-h-16 opacity-100 py-1.5 px-3 sm:px-4"
        }`}
      >
        <p className="max-w-2xl break-words text-balance">
          {announcement}
        </p>
        <Link
          href="/collections/new-arrivals"
          prefetch={true}
          className="hidden md:inline-flex items-center gap-1 font-semibold text-electric-lime hover:underline underline-offset-2 ml-1 shrink-0"
        >
          Explore <ArrowRight className="w-3 h-3" />
        </Link>
      </div>

      {/* 2. Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Mobile menu trigger */}
        <div className="flex items-center lg:hidden">
          <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="hover:bg-muted text-foreground"
                aria-label="Open Navigation Menu"
              >
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[320px] p-6 bg-card flex flex-col justify-between overflow-y-auto">
              <div>
                <div className="flex items-center justify-between pb-6 border-b border-border">
                  <OneFamLogo variant="auto" size="sm" />
                </div>

                <nav className="flex flex-col space-y-3 mt-6">
                  {/* Category links with expandable subcategory accordion */}
                  {categoryNavItems.map((item) => {
                    const isActive = pathname === item.href;
                    const hasChildren = item.category?.children && item.category.children.length > 0;
                    const isExpanded = openMobileCategories[item.id];

                    return (
                      <div key={item.id} className="border-b border-border/40 pb-2">
                        <div className="flex items-center justify-between">
                          <Link
                            href={item.href}
                            prefetch={true}
                            onClick={() => setIsMobileOpen(false)}
                            className={`text-base font-bold transition-colors ${
                              isActive ? "text-royal-violet" : "text-foreground hover:text-royal-violet"
                            }`}
                          >
                            {item.label}
                          </Link>

                          {hasChildren && (
                            <button
                              type="button"
                              onClick={() => toggleMobileCategory(item.id)}
                              className="p-1.5 text-muted-foreground hover:text-royal-violet transition-transform"
                              aria-label={`Toggle subcategories for ${item.label}`}
                            >
                              <ChevronDown
                                className={`w-4 h-4 transition-transform duration-200 ${
                                  isExpanded ? "rotate-180 text-royal-violet" : ""
                                }`}
                              />
                            </button>
                          )}
                        </div>

                        {/* Expanded subcategories in mobile */}
                        {hasChildren && isExpanded && (
                          <div className="mt-2 pl-3 border-l-2 border-royal-violet/30 space-y-2 py-1 animate-in fade-in slide-in-from-top-1 duration-150">
                            {item.category.children?.map((sub) => (
                              <Link
                                key={sub.id}
                                href={`/categories/${sub.slug}`}
                                prefetch={true}
                                onClick={() => setIsMobileOpen(false)}
                                className="block text-xs text-muted-foreground hover:text-royal-violet font-medium py-1"
                              >
                                {sub.name}
                              </Link>
                            ))}
                            <Link
                              href={item.href}
                              prefetch={true}
                              onClick={() => setIsMobileOpen(false)}
                              className="inline-flex items-center gap-1 text-[11px] font-bold text-royal-violet pt-1 hover:underline"
                            >
                              All {item.label} Collection <ArrowRight className="w-3 h-3" />
                            </Link>
                          </div>
                        )}
                      </div>
                    );
                  })}

                  {/* Collections accordion item in mobile */}
                  <div className="border-b border-border/40 pb-2">
                    <div className="flex items-center justify-between">
                      <Link
                        href="/collections"
                        prefetch={true}
                        onClick={() => setIsMobileOpen(false)}
                        className={`text-base font-bold transition-colors ${
                          isCollectionsActive ? "text-royal-violet" : "text-foreground hover:text-royal-violet"
                        }`}
                      >
                        Collections
                      </Link>

                      <button
                        type="button"
                        onClick={() => toggleMobileCategory("mobile-collections")}
                        className="p-1.5 text-muted-foreground hover:text-royal-violet transition-transform"
                        aria-label="Toggle collections"
                      >
                        <ChevronDown
                          className={`w-4 h-4 transition-transform duration-200 ${
                            openMobileCategories["mobile-collections"] ? "rotate-180 text-royal-violet" : ""
                          }`}
                        />
                      </button>
                    </div>

                    {openMobileCategories["mobile-collections"] && (
                      <div className="mt-2 pl-3 border-l-2 border-royal-violet/30 space-y-2 py-1 animate-in fade-in slide-in-from-top-1 duration-150">
                        {displayCollections.map((col) => (
                          <Link
                            key={col.id}
                            href={`/collections/${col.slug}`}
                            prefetch={true}
                            onClick={() => setIsMobileOpen(false)}
                            className="block text-xs text-muted-foreground hover:text-royal-violet font-medium py-1"
                          >
                            {col.title}
                          </Link>
                        ))}
                        <Link
                          href="/collections"
                          prefetch={true}
                          onClick={() => setIsMobileOpen(false)}
                          className="inline-flex items-center gap-1 text-[11px] font-bold text-royal-violet pt-1 hover:underline"
                        >
                          All Collections <ArrowRight className="w-3 h-3" />
                        </Link>
                      </div>
                    )}
                  </div>

                  {/* Standard supplementary items */}
                  {standardNavItems.map((link) => {
                    const isActive = pathname === link.href;
                    return (
                      <Link
                        key={link.id}
                        href={link.href}
                        prefetch={true}
                        onClick={() => setIsMobileOpen(false)}
                        className={`text-sm font-semibold transition-colors flex items-center justify-between py-1.5 ${
                          isActive
                            ? "text-royal-violet"
                            : link.isSale
                              ? "text-vermilion"
                              : "text-foreground hover:text-royal-violet"
                        }`}
                      >
                        <span>{link.label}</span>
                        {link.isSale && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-vermilion text-white">
                            Sale
                          </span>
                        )}
                        {link.isNew && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-electric-lime text-[#191720]">
                            New
                          </span>
                        )}
                      </Link>
                    );
                  })}

                  <div className="h-px bg-border my-2" />
                  <Link
                    href="/track-order"
                    prefetch={true}
                    onClick={() => setIsMobileOpen(false)}
                    className="flex items-center gap-2 text-sm text-foreground/80 hover:text-royal-violet font-medium py-1"
                  >
                    <ShieldCheck className="w-4 h-4 text-royal-violet" />
                    Track Customer Order
                  </Link>
                  <Link
                    href="/contact"
                    prefetch={true}
                    onClick={() => setIsMobileOpen(false)}
                    className="flex items-center gap-2 text-sm text-foreground/80 hover:text-royal-violet font-medium py-1"
                  >
                    Contact Us
                  </Link>
                  <Link
                    href="/faq"
                    prefetch={true}
                    onClick={() => setIsMobileOpen(false)}
                    className="flex items-center gap-2 text-sm text-foreground/80 hover:text-royal-violet font-medium py-1"
                  >
                    FAQs &amp; Help Desk
                  </Link>
                </nav>
              </div>

              <div className="pt-6 border-t border-border space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-muted-foreground">Theme</span>
                  <ThemeToggle variant="segmented" />
                </div>
                <Button
                  asChild
                  className="flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-xl bg-royal-violet hover:bg-royal-violet/90 text-white font-bold text-xs shadow-xs transition"
                >
                  <Link href="/contact" prefetch={true} onClick={() => setIsMobileOpen(false)}>
                    <Mail className="w-4 h-4 text-white" />
                    <span>Contact Us</span>
                  </Link>
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>

        {/* Brand Logo / Identity */}
        <Link href="/" prefetch={true} className="flex items-center group transition-transform active:scale-98">
          <OneFamLogo variant="auto" size="md" />
        </Link>

        {/* Desktop Navigation Links with Category Dropdowns and Collections Dropdown */}
        <nav className="hidden lg:flex items-center space-x-6">
          {/* 1. Category Items with Dropdowns */}
          {categoryNavItems.map((item) => {
            const isActive = pathname === item.href;
            const hasChildren = item.category?.children && item.category.children.length > 0;
            const isDropdownOpen = activeDropdownId === item.id;

            return (
              <div
                key={item.id}
                className="relative"
                onMouseEnter={() => handleMouseEnter(item.id)}
                onMouseLeave={handleMouseLeave}
              >
                <Link
                  href={item.href}
                  prefetch={true}
                  className={`text-sm font-semibold tracking-wide transition-colors relative py-2 flex items-center gap-1.5 ${
                    isActive
                      ? "text-royal-violet"
                      : "text-foreground/85 hover:text-royal-violet"
                  }`}
                >
                  <span>{item.label}</span>
                  {hasChildren && (
                    <ChevronDown
                      className={`w-3.5 h-3.5 transition-transform duration-200 ${
                        isDropdownOpen ? "rotate-180 text-royal-violet" : "text-muted-foreground"
                      }`}
                    />
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-royal-violet" />
                  )}
                </Link>

                {/* Precision E-Commerce Dropdown (Meesho / Flipkart style) Curated Visual Editorial Capsule */}
                {hasChildren && isDropdownOpen && (
                  <div
                    className="absolute top-full left-0 pt-1.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150"
                    onMouseEnter={() => handleMouseEnter(item.id)}
                    onMouseLeave={handleMouseLeave}
                  >
                    <div className="w-56 rounded-xl bg-card border border-border shadow-xl py-1 text-foreground divide-y divide-border/40">
                      {/* Subcategory links list */}
                      <div className="py-1">
                        <div className="px-3.5 py-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground/80">
                          Shop {item.label}
                        </div>
                        {item.category.children?.map((sub) => (
                          <Link
                            key={sub.id}
                            href={`/categories/${sub.slug}`}
                            prefetch={true}
                            onClick={() => setActiveDropdownId(null)}
                            className="group/item flex items-center justify-between px-3.5 py-2 text-xs font-medium text-foreground hover:bg-muted hover:text-royal-violet transition-colors"
                          >
                            <span>{sub.name}</span>
                            <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/40 group-hover/item:text-royal-violet group-hover/item:translate-x-0.5 transition-all" />
                          </Link>
                        ))}
                      </div>

                      {/* Bottom "View All" link */}
                      <div className="pt-1 pb-0.5">
                        <Link
                          href={item.href}
                          prefetch={true}
                          onClick={() => setActiveDropdownId(null)}
                          className="flex items-center justify-between px-3.5 py-2 text-xs font-bold text-royal-violet hover:bg-royal-violet/5 transition-colors"
                        >
                          <span>View All {item.label}</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </Link>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {/* 2. Collections Item with Precision Dropdown */}
          <div
            className="relative"
            onMouseEnter={() => handleMouseEnter("nav-collections")}
            onMouseLeave={handleMouseLeave}
          >
            <Link
              href="/collections"
              prefetch={true}
              className={`text-sm font-semibold tracking-wide transition-colors relative py-2 flex items-center gap-1.5 ${
                isCollectionsActive
                  ? "text-royal-violet"
                  : "text-foreground/85 hover:text-royal-violet"
              }`}
            >
              <span>Collections</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform duration-200 ${
                  activeDropdownId === "nav-collections"
                    ? "rotate-180 text-royal-violet"
                    : "text-muted-foreground"
                }`}
              />
              {isCollectionsActive && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-royal-violet" />
              )}
            </Link>

            {/* Precision Collections Dropdown */}
            {activeDropdownId === "nav-collections" && (
              <div
                className="absolute top-full left-0 pt-1.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150"
                onMouseEnter={() => handleMouseEnter("nav-collections")}
                onMouseLeave={handleMouseLeave}
              >
                <div className="w-60 rounded-xl bg-card border border-border shadow-xl py-1 text-foreground divide-y divide-border/40">
                  <div className="py-1">
                    <div className="px-3.5 py-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground/80">
                      Shop Collections
                    </div>
                    {displayCollections.map((col) => (
                      <Link
                        key={col.id}
                        href={`/collections/${col.slug}`}
                        prefetch={true}
                        onClick={() => setActiveDropdownId(null)}
                        className="group/item flex items-center justify-between px-3.5 py-2 text-xs font-medium text-foreground hover:bg-muted hover:text-royal-violet transition-colors"
                      >
                        <span className="truncate">{col.title}</span>
                        <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/40 group-hover/item:text-royal-violet group-hover/item:translate-x-0.5 transition-all shrink-0 ml-1.5" />
                      </Link>
                    ))}
                  </div>

                  <div className="pt-1 pb-0.5">
                    <Link
                      href="/collections"
                      prefetch={true}
                      onClick={() => setActiveDropdownId(null)}
                      className="flex items-center justify-between px-3.5 py-2 text-xs font-bold text-royal-violet hover:bg-royal-violet/5 transition-colors"
                    >
                      <span>View All Collections</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 3. Standard Nav Links (New Arrivals, Offers) */}
          {standardNavItems.map((link) => {
            const isActive = pathname === link.href;
            return (
              <Link
                key={link.id}
                href={link.href}
                prefetch={true}
                className={`text-sm font-semibold tracking-wide transition-colors relative py-1 flex items-center gap-1.5 ${
                  isActive
                    ? "text-royal-violet"
                    : link.isSale
                      ? "text-vermilion hover:text-vermilion/80"
                      : "text-foreground/85 hover:text-royal-violet"
                }`}
              >
                <span>{link.label}</span>
                {link.isSale && (
                  <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black uppercase tracking-wider bg-vermilion text-white">
                    Sale
                  </span>
                )}
                {link.isNew && (
                  <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black uppercase tracking-wider bg-electric-lime text-[#191720]">
                    New
                  </span>
                )}
                {isActive && (
                  <span className="absolute -bottom-1 left-0 right-0 h-0.5 rounded-full bg-royal-violet" />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Action Controls */}
        <div className="flex items-center space-x-3">
          {/* Search Trigger */}
          <div className="relative">
            {isSearchOpen ? (
              <form onSubmit={handleSearchSubmit} className="flex items-center animate-in fade-in duration-200">
                <Input
                  type="search"
                  placeholder="Search linen, silk, shirts..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  autoFocus
                  className="w-48 sm:w-64 h-9 text-xs pr-8 bg-card border-royal-violet focus-visible:ring-1 focus-visible:ring-royal-violet rounded-full shadow-xs"
                />
                <button
                  type="button"
                  onClick={() => setIsSearchOpen(false)}
                  className="absolute right-2.5 text-muted-foreground hover:text-foreground"
                  aria-label="Close search"
                >
                  <X className="w-4 h-4" />
                </button>
              </form>
            ) : (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsSearchOpen(true)}
                className="hover:bg-muted text-foreground/80 hover:text-foreground"
                aria-label="Open search bar"
              >
                <Search className="w-4 h-4" />
              </Button>
            )}
          </div>

          {/* Theme Toggle */}
          <div className="hidden sm:block">
            <ThemeToggle variant="icon" />
          </div>

          {/* Contact Us Button */}
          <Button
            asChild
            className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold text-xs h-9 px-4 rounded-full shadow-xs transition-all hover:scale-102 active:scale-98"
          >
            <Link href="/contact" prefetch={true} className="flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5" />
              <span>Contact Us</span>
            </Link>
          </Button>
        </div>
      </div>
    </header>
  );
}

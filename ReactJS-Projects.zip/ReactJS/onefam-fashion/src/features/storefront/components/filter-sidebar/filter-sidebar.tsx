"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { useCallback, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SheetClose } from "@/components/ui/sheet";
import {
  RotateCcw,
  Filter,
  Check,
  X,
  ChevronDown,
  ArrowRight,
  SlidersHorizontal,
} from "lucide-react";

interface FilterSidebarProps {
  categories?: Array<{
    id: string;
    name: string;
    slug: string;
    children?: Array<{ id: string; name: string; slug: string }>;
  }>;
  collections?: Array<{ id: string; title: string; slug: string }>;
  isMobileDrawer?: boolean;
  onClose?: () => void;
  totalStylesCount?: number;
}

const AVAILABLE_SIZES = ["XS", "S", "M", "L", "XL", "XXL", "3-4Y", "5-6Y", "7-8Y"];

const COLOR_SWATCHES = [
  { name: "Obsidian Black", hex: "#191720" },
  { name: "Bone White", hex: "#F5F3EF" },
  { name: "Sage Olive", hex: "#708238" },
  { name: "Royal Plum", hex: "#7137C8" },
  { name: "Sand Dune", hex: "#E6D7B9" },
  { name: "Emerald Mint", hex: "#2E8B57" },
  { name: "Sunny Ochre", hex: "#DAA520" },
  { name: "Blush Pink", hex: "#FFB6C1" },
];

const PRICE_PRESETS = [
  { label: "Under ₹999", min: null, max: 999 },
  { label: "₹1,000 – ₹1,999", min: 1000, max: 1999 },
  { label: "₹2,000 – ₹3,499", min: 2000, max: 3499 },
  { label: "₹3,500 & Above", min: 3500, max: null },
];

export function FilterSidebar({
  categories,
  collections,
  isMobileDrawer = false,
  onClose,
  totalStylesCount,
}: FilterSidebarProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const currentCategory = searchParams.get("categorySlug") || "";
  const currentCollection = searchParams.get("collectionSlug") || "";
  const currentSize = searchParams.get("size") || "";
  const currentColor = searchParams.get("color") || "";
  const currentMinPrice = searchParams.get("minPrice") || "";
  const currentMaxPrice = searchParams.get("maxPrice") || "";
  const currentInStockOnly = searchParams.get("inStockOnly") === "true";
  const currentSort = searchParams.get("sortBy") || "newest";

  const [minPriceInput, setMinPriceInput] = useState(currentMinPrice);
  const [maxPriceInput, setMaxPriceInput] = useState(currentMaxPrice);

  // Accordion section collapse states
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    price: true,
    categories: true,
    collections: true,
    size: true,
    color: true,
    sort: true,
  });

  const toggleSection = (sec: string) => {
    setOpenSections((prev) => ({ ...prev, [sec]: !prev[sec] }));
  };

  const updateParam = useCallback(
    (key: string, value: string | null) => {
      const params = new URLSearchParams(searchParams.toString());
      if (value) {
        params.set(key, value);
      } else {
        params.delete(key);
      }
      params.delete("page");
      router.push(`${pathname}?${params.toString()}`);
    },
    [pathname, router, searchParams]
  );

  const handlePriceApply = () => {
    const params = new URLSearchParams(searchParams.toString());
    if (minPriceInput) params.set("minPrice", minPriceInput);
    else params.delete("minPrice");

    if (maxPriceInput) params.set("maxPrice", maxPriceInput);
    else params.delete("maxPrice");

    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  };

  const handlePricePreset = (min: number | null, max: number | null) => {
    const isAlreadySelected =
      (min === null ? !currentMinPrice : currentMinPrice === String(min)) &&
      (max === null ? !currentMaxPrice : currentMaxPrice === String(max));

    const params = new URLSearchParams(searchParams.toString());
    if (isAlreadySelected) {
      params.delete("minPrice");
      params.delete("maxPrice");
      setMinPriceInput("");
      setMaxPriceInput("");
    } else {
      if (min !== null) {
        params.set("minPrice", String(min));
        setMinPriceInput(String(min));
      } else {
        params.delete("minPrice");
        setMinPriceInput("");
      }
      if (max !== null) {
        params.set("maxPrice", String(max));
        setMaxPriceInput(String(max));
      } else {
        params.delete("maxPrice");
        setMaxPriceInput("");
      }
    }
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  };

  const handleResetAll = () => {
    setMinPriceInput("");
    setMaxPriceInput("");
    router.push(pathname);
  };

  // Active filters count
  const activeCount = [
    Boolean(currentCategory),
    Boolean(currentCollection),
    Boolean(currentSize),
    Boolean(currentColor),
    Boolean(currentMinPrice || currentMaxPrice),
    currentInStockOnly,
  ].filter(Boolean).length;

  const hasActiveFilters = activeCount > 0;

  // Find active category label
  let activeCategoryName = "";
  if (currentCategory && categories) {
    for (const cat of categories) {
      if (cat.slug === currentCategory) {
        activeCategoryName = cat.name;
        break;
      }
      const sub = cat.children?.find((c) => c.slug === currentCategory);
      if (sub) {
        activeCategoryName = sub.name;
        break;
      }
    }
  }

  // Find active collection title
  const activeCollectionTitle =
    collections?.find((c) => c.slug === currentCollection)?.title || currentCollection;

  return (
    <div
      className={
        isMobileDrawer
          ? "w-full h-full flex flex-col bg-card text-foreground overflow-hidden"
          : "w-full bg-card rounded-2xl border border-border/80 shadow-xs text-foreground overflow-hidden"
      }
    >
      {/* 1. Flipkart-Style Header (Fixed / Sticky at top on Mobile Drawer & Desktop) */}
      <div className="sticky top-0 z-30 p-4 flex items-center justify-between bg-card/95 backdrop-blur-md border-b border-border/80 shrink-0 shadow-2xs">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-royal-violet" />
          <h2 className="font-extrabold text-sm uppercase tracking-wider">
            Filters
          </h2>
          {hasActiveFilters && (
            <span className="w-5 h-5 rounded-full bg-royal-violet text-white text-[10px] font-black flex items-center justify-center">
              {activeCount}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {hasActiveFilters && (
            <button
              type="button"
              onClick={handleResetAll}
              className="text-[11px] font-black tracking-wider uppercase text-royal-violet dark:text-[#C6F542] hover:underline"
            >
              CLEAR ALL
            </button>
          )}

          {isMobileDrawer && (
            <SheetClose asChild>
              <button
                type="button"
                onClick={onClose}
                className="w-8 h-8 rounded-full hover:bg-muted flex items-center justify-center text-foreground transition-colors ml-1"
                aria-label="Close filters"
              >
                <X className="w-4 h-4" />
              </button>
            </SheetClose>
          )}
        </div>
      </div>

      {/* Main Filter Content (Scrollable Container on Mobile Drawer) */}
      <div className={isMobileDrawer ? "flex-1 overflow-y-auto divide-y divide-border/60" : "divide-y divide-border/60"}>

      {/* 2. Active Refinements Filter Chips (Flipkart style) */}
      {hasActiveFilters && (
        <div className="p-3.5 bg-royal-violet/5 space-y-2">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
            Applied Filters:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {currentCategory && (
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold bg-background px-2.5 py-1 rounded-full border border-border/80 shadow-2xs">
                <span>{activeCategoryName || currentCategory}</span>
                <button
                  type="button"
                  onClick={() => updateParam("categorySlug", null)}
                  className="text-muted-foreground hover:text-vermilion"
                  aria-label="Remove category filter"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {currentCollection && (
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold bg-background px-2.5 py-1 rounded-full border border-border/80 shadow-2xs">
                <span>{activeCollectionTitle}</span>
                <button
                  type="button"
                  onClick={() => updateParam("collectionSlug", null)}
                  className="text-muted-foreground hover:text-vermilion"
                  aria-label="Remove collection filter"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {(currentMinPrice || currentMaxPrice) && (
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold bg-background px-2.5 py-1 rounded-full border border-border/80 shadow-2xs">
                <span>₹{currentMinPrice || "0"} – ₹{currentMaxPrice || "Max"}</span>
                <button
                  type="button"
                  onClick={() => {
                    setMinPriceInput("");
                    setMaxPriceInput("");
                    updateParam("minPrice", null);
                    updateParam("maxPrice", null);
                  }}
                  className="text-muted-foreground hover:text-vermilion"
                  aria-label="Remove price filter"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {currentSize && (
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold bg-background px-2.5 py-1 rounded-full border border-border/80 shadow-2xs">
                <span>Size: {currentSize}</span>
                <button
                  type="button"
                  onClick={() => updateParam("size", null)}
                  className="text-muted-foreground hover:text-vermilion"
                  aria-label="Remove size filter"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {currentColor && (
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold bg-background px-2.5 py-1 rounded-full border border-border/80 shadow-2xs">
                <span>{currentColor}</span>
                <button
                  type="button"
                  onClick={() => updateParam("color", null)}
                  className="text-muted-foreground hover:text-vermilion"
                  aria-label="Remove color filter"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {currentInStockOnly && (
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold bg-background px-2.5 py-1 rounded-full border border-border/80 shadow-2xs text-emerald-600 dark:text-emerald-400">
                <span>In Stock</span>
                <button
                  type="button"
                  onClick={() => updateParam("inStockOnly", null)}
                  className="text-muted-foreground hover:text-vermilion"
                  aria-label="Remove stock filter"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
          </div>
        </div>
      )}

      {/* 3. Sort Order Section */}
      <div className="p-4 space-y-3">
        <button
          type="button"
          onClick={() => toggleSection("sort")}
          className="w-full flex items-center justify-between text-xs font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground"
        >
          <span>Sort By</span>
          <ChevronDown
            className={`w-4 h-4 transition-transform duration-200 ${
              openSections.sort ? "rotate-180" : ""
            }`}
          />
        </button>

        {openSections.sort && (
          <div className="space-y-1.5 pt-1 text-xs">
            {[
              { id: "newest", label: "Newest Arrivals" },
              { id: "price_asc", label: "Price -- Low to High" },
              { id: "price_desc", label: "Price -- High to Low" },
              { id: "popularity", label: "Popularity" },
            ].map((sortOpt) => {
              const isSelected = currentSort === sortOpt.id;
              return (
                <label
                  key={sortOpt.id}
                  onClick={() => updateParam("sortBy", sortOpt.id)}
                  className={`flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg cursor-pointer transition ${
                    isSelected
                      ? "bg-royal-violet/10 font-bold text-royal-violet dark:text-[#C6F542]"
                      : "hover:bg-muted text-muted-foreground hover:text-foreground font-medium"
                  }`}
                >
                  <span
                    className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                      isSelected
                        ? "border-royal-violet bg-royal-violet"
                        : "border-border bg-background"
                    }`}
                  >
                    {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                  </span>
                  <span>{sortOpt.label}</span>
                </label>
              );
            })}
          </div>
        )}
      </div>

      {/* 4. Price Filter Section (Flipkart style brackets + inputs) */}
      <div className="p-4 space-y-3">
        <button
          type="button"
          onClick={() => toggleSection("price")}
          className="w-full flex items-center justify-between text-xs font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground"
        >
          <span>Price</span>
          <ChevronDown
            className={`w-4 h-4 transition-transform duration-200 ${
              openSections.price ? "rotate-180" : ""
            }`}
          />
        </button>

        {openSections.price && (
          <div className="space-y-3 pt-1 text-xs">
            {/* Quick Clickable Price Brackets (Flipkart Style) */}
            <div className="space-y-1.5">
              {PRICE_PRESETS.map((preset) => {
                const isSelected =
                  (preset.min === null ? !currentMinPrice : currentMinPrice === String(preset.min)) &&
                  (preset.max === null ? !currentMaxPrice : currentMaxPrice === String(preset.max));

                return (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => handlePricePreset(preset.min, preset.max)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left text-xs transition ${
                      isSelected
                        ? "bg-royal-violet/10 font-bold text-royal-violet dark:text-[#C6F542]"
                        : "hover:bg-muted text-muted-foreground hover:text-foreground font-medium"
                    }`}
                  >
                    <span>{preset.label}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-royal-violet" />}
                  </button>
                );
              })}
            </div>

            {/* Custom Min / Max Input Row with GO button */}
            <div className="pt-2 border-t border-border/50">
              <span className="text-[10px] font-bold text-muted-foreground block mb-1.5 uppercase">
                Custom Range
              </span>
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  placeholder="Min ₹"
                  value={minPriceInput}
                  onChange={(e) => setMinPriceInput(e.target.value)}
                  className="h-8 text-xs bg-background rounded-lg"
                />
                <span className="text-muted-foreground text-xs font-bold">to</span>
                <Input
                  type="number"
                  placeholder="Max ₹"
                  value={maxPriceInput}
                  onChange={(e) => setMaxPriceInput(e.target.value)}
                  className="h-8 text-xs bg-background rounded-lg"
                />
                <Button
                  type="button"
                  size="sm"
                  onClick={handlePriceApply}
                  className="h-8 px-3 text-xs font-bold bg-royal-violet hover:bg-royal-violet/90 text-white rounded-lg shrink-0"
                >
                  GO
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 5. Categories Filter Section */}
      {categories && categories.length > 0 && (
        <div className="p-4 space-y-3">
          <button
            type="button"
            onClick={() => toggleSection("categories")}
            className="w-full flex items-center justify-between text-xs font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground"
          >
            <span>Categories</span>
            <ChevronDown
              className={`w-4 h-4 transition-transform duration-200 ${
                openSections.categories ? "rotate-180" : ""
              }`}
            />
          </button>

          {openSections.categories && (
            <div className="space-y-1 pt-1 text-xs">
              <button
                type="button"
                onClick={() => updateParam("categorySlug", null)}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left transition ${
                  !currentCategory
                    ? "bg-royal-violet/10 font-bold text-royal-violet dark:text-[#C6F542]"
                    : "hover:bg-muted text-muted-foreground hover:text-foreground font-medium"
                }`}
              >
                <span>All Categories</span>
                {!currentCategory && <Check className="w-3.5 h-3.5 text-royal-violet" />}
              </button>

              {categories.map((cat) => {
                const isCatActive = currentCategory === cat.slug;
                const hasActiveSub = cat.children?.some((sub) => sub.slug === currentCategory);

                return (
                  <div key={cat.id} className="space-y-0.5">
                    <button
                      type="button"
                      onClick={() => updateParam("categorySlug", cat.slug)}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left transition ${
                        isCatActive
                          ? "bg-royal-violet/10 font-bold text-royal-violet dark:text-[#C6F542]"
                          : "hover:bg-muted text-foreground font-semibold"
                      }`}
                    >
                      <span>{cat.name}</span>
                      {isCatActive && <Check className="w-3.5 h-3.5 text-royal-violet" />}
                    </button>

                    {/* Subcategories */}
                    {cat.children && cat.children.length > 0 && (
                      <div className="pl-4 space-y-0.5 border-l-2 border-border/70 my-1 ml-2">
                        {cat.children.map((sub) => {
                          const isSubActive = currentCategory === sub.slug;
                          return (
                            <button
                              key={sub.id}
                              type="button"
                              onClick={() => updateParam("categorySlug", sub.slug)}
                              className={`w-full flex items-center justify-between px-2 py-1 rounded-md text-left text-[11px] transition ${
                                isSubActive
                                  ? "bg-royal-violet/15 font-bold text-royal-violet dark:text-[#C6F542]"
                                  : "hover:bg-muted text-muted-foreground hover:text-foreground"
                              }`}
                            >
                              <span>{sub.name}</span>
                              {isSubActive && <Check className="w-3 h-3 text-royal-violet" />}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 6. Signature Collections Filter Section */}
      {collections && collections.length > 0 && (
        <div className="p-4 space-y-3">
          <button
            type="button"
            onClick={() => toggleSection("collections")}
            className="w-full flex items-center justify-between text-xs font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground"
          >
            <span>Collections</span>
            <ChevronDown
              className={`w-4 h-4 transition-transform duration-200 ${
                openSections.collections ? "rotate-180" : ""
              }`}
            />
          </button>

          {openSections.collections && (
            <div className="space-y-1 pt-1 text-xs">
              <button
                type="button"
                onClick={() => updateParam("collectionSlug", null)}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left transition ${
                  !currentCollection
                    ? "bg-royal-violet/10 font-bold text-royal-violet dark:text-[#C6F542]"
                    : "hover:bg-muted text-muted-foreground hover:text-foreground font-medium"
                }`}
              >
                <span>All Collections</span>
                {!currentCollection && <Check className="w-3.5 h-3.5 text-royal-violet" />}
              </button>

              {collections.map((col) => {
                const isColActive = currentCollection === col.slug;
                return (
                  <button
                    key={col.id}
                    type="button"
                    onClick={() => updateParam("collectionSlug", col.slug)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left transition ${
                      isColActive
                        ? "bg-royal-violet/10 font-bold text-royal-violet dark:text-[#C6F542]"
                        : "hover:bg-muted text-foreground font-medium"
                    }`}
                  >
                    <span>{col.title}</span>
                    {isColActive && <Check className="w-3.5 h-3.5 text-royal-violet" />}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 7. Size Filter Section (Flipkart Grid) */}
      <div className="p-4 space-y-3">
        <button
          type="button"
          onClick={() => toggleSection("size")}
          className="w-full flex items-center justify-between text-xs font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground"
        >
          <span>Size</span>
          <ChevronDown
            className={`w-4 h-4 transition-transform duration-200 ${
              openSections.size ? "rotate-180" : ""
            }`}
          />
        </button>

        {openSections.size && (
          <div className="grid grid-cols-4 gap-1.5 pt-1">
            {AVAILABLE_SIZES.map((size) => {
              const isSelected = currentSize === size;
              return (
                <button
                  key={size}
                  type="button"
                  onClick={() => updateParam("size", isSelected ? null : size)}
                  className={`h-9 rounded-lg border text-xs font-bold transition flex items-center justify-center ${
                    isSelected
                      ? "bg-royal-violet text-white border-royal-violet shadow-xs ring-2 ring-royal-violet/20"
                      : "bg-background border-border text-foreground hover:border-royal-violet hover:text-royal-violet"
                  }`}
                >
                  {size}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 8. Color Palette Swatches */}
      <div className="p-4 space-y-3">
        <button
          type="button"
          onClick={() => toggleSection("color")}
          className="w-full flex items-center justify-between text-xs font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground"
        >
          <span>Color</span>
          <ChevronDown
            className={`w-4 h-4 transition-transform duration-200 ${
              openSections.color ? "rotate-180" : ""
            }`}
          />
        </button>

        {openSections.color && (
          <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
            {COLOR_SWATCHES.map((swatch) => {
              const isSelected = currentColor.toLowerCase() === swatch.name.toLowerCase();
              return (
                <button
                  key={swatch.name}
                  type="button"
                  onClick={() => updateParam("color", isSelected ? null : swatch.name)}
                  className={`flex items-center gap-2 p-1.5 rounded-lg border text-left transition ${
                    isSelected
                      ? "border-royal-violet bg-royal-violet/10 font-bold"
                      : "border-border/70 bg-background hover:border-foreground/40 font-medium"
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full border border-black/20 shrink-0"
                    style={{ backgroundColor: swatch.hex }}
                  />
                  <span className="truncate text-[11px]">{swatch.name.split(" ")[0]}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 9. Stock Availability Toggle */}
      <div className="p-4">
        <label
          onClick={() => updateParam("inStockOnly", currentInStockOnly ? null : "true")}
          className="flex items-center justify-between p-2.5 rounded-xl border border-border bg-background hover:border-royal-violet cursor-pointer transition select-none"
        >
          <span className="text-xs font-semibold text-foreground">
            In-Stock Styles Only
          </span>
          <span
            className={`w-4 h-4 rounded border flex items-center justify-center transition ${
              currentInStockOnly
                ? "bg-royal-violet border-royal-violet text-white"
                : "border-border bg-background"
            }`}
          >
            {currentInStockOnly && <Check className="w-3 h-3" />}
          </span>
        </label>
      </div>
      </div>

      {/* 10. Sticky Bottom Footer on Mobile Drawer */}
      {isMobileDrawer && (
        <div className="sticky bottom-0 z-30 p-3.5 bg-card/95 backdrop-blur-md border-t border-border flex items-center gap-3 shrink-0 shadow-lg">
          {hasActiveFilters && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleResetAll}
              className="text-xs font-bold rounded-xl h-10 px-3"
            >
              Reset
            </Button>
          )}
          <SheetClose asChild>
            <Button
              type="button"
              size="sm"
              onClick={onClose}
              className="flex-1 bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl h-10 text-xs shadow-md"
            >
              {totalStylesCount ? `Show ${totalStylesCount} Styles` : "Apply Filters"}
            </Button>
          </SheetClose>
        </div>
      )}
    </div>
  );
}

"use client";

import { useRouter, usePathname, useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { SlidersHorizontal, RotateCcw, MessageCircle, ArrowRight, CheckCircle2 } from "lucide-react";
import Link from "next/link";

interface CatalogueEmptyStateProps {
  whatsappNumber?: string;
}

export function CatalogueEmptyState({ whatsappNumber = "919876543210" }: CatalogueEmptyStateProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const activeParams: { key: string; label: string; value: string }[] = [];

  const size = searchParams.get("size");
  if (size) activeParams.push({ key: "size", label: "Size", value: size });

  const color = searchParams.get("color");
  if (color) activeParams.push({ key: "color", label: "Color", value: color });

  const minPrice = searchParams.get("minPrice");
  const maxPrice = searchParams.get("maxPrice");
  if (minPrice || maxPrice) {
    activeParams.push({
      key: "price",
      label: "Price Range",
      value: `₹${minPrice || 0} - ₹${maxPrice || "Any"}`,
    });
  }

  const inStockOnly = searchParams.get("inStockOnly") === "true";
  if (inStockOnly) activeParams.push({ key: "inStockOnly", label: "Availability", value: "In-Stock Only" });

  const search = searchParams.get("q") || searchParams.get("search");
  if (search) activeParams.push({ key: "q", label: "Keyword", value: `"${search}"` });

  const handleReset = () => {
    router.push(pathname);
  };

  const cleanWhatsappNumber = whatsappNumber.replace(/[^0-9]/g, "");
  const whatsappUrl = `https://wa.me/${cleanWhatsappNumber}?text=${encodeURIComponent(
    `Hello OneFam Fashion Concierge! I was browsing your collection on ${pathname} and was looking for specific pieces/sizes. Could you help me with availability or custom requests?`
  )}`;

  return (
    <div className="relative overflow-hidden rounded-3xl border border-dashed border-border/80 bg-linear-to-b from-card to-muted/40 p-8 sm:p-14 text-center shadow-xs">
      {/* Decorative background glows */}
      <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-royal-violet/5 blur-2xl pointer-events-none" />
      <div className="absolute -bottom-12 -left-12 w-48 h-48 rounded-full bg-electric-lime/10 blur-2xl pointer-events-none" />

      <div className="relative mx-auto max-w-lg">
        {/* Modern Icon Badge */}
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-royal-violet/10 ring-8 ring-royal-violet/5 text-royal-violet">
          <SlidersHorizontal className="h-8 w-8 stroke-[1.75]" />
        </div>

        <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-royal-violet/10 text-royal-violet mb-3">
          <span className="w-1.5 h-1.5 rounded-full bg-royal-violet shrink-0" /> Filter Refinements
        </span>

        <h3 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-foreground">
          No Wardrobe Pieces Match Your Refinements
        </h3>

        <p className="mt-3 text-sm sm:text-base text-muted-foreground leading-relaxed">
          We couldn&apos;t find any active styles matching your exact combination of size, color, or price filters.
        </p>

        {/* Active Filters Pill Recap */}
        {activeParams.length > 0 && (
          <div className="mt-6 p-4 rounded-xl bg-muted/40 border border-border/50 text-left">
            <p className="text-2xs font-bold uppercase tracking-wider text-muted-foreground mb-2">
              Active Refinements Applied:
            </p>
            <div className="flex flex-wrap gap-2">
              {activeParams.map((param) => (
                <span
                  key={param.key}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium bg-white text-ink border border-border shadow-2xs"
                >
                  <span className="text-muted-foreground">{param.label}:</span>
                  <span className="font-bold">{param.value}</span>
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Helpful Tips Box */}
        <div className="mt-6 text-left rounded-xl bg-paper border border-border/60 p-4 text-xs text-muted-foreground space-y-2">
          <p className="font-semibold text-ink flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-royal-violet" /> Quick suggestions to find your fit:
          </p>
          <ul className="list-disc list-inside space-y-1 pl-1">
            <li>Deselect specific colors or size pills to view broader collections.</li>
            <li>Broaden or reset the min/max price sliders.</li>
            {inStockOnly && <li>Toggle off &quot;In-Stock Styles Only&quot; to discover made-to-order &amp; restock styles.</li>}
            <li>Check for spelling if you entered a custom search query.</li>
          </ul>
        </div>

        {/* Action Buttons */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Button
            onClick={handleReset}
            size="lg"
            className="w-full sm:w-auto font-bold bg-royal-violet text-white hover:bg-royal-violet/90 gap-2 h-11 px-6 shadow-xs"
          >
            <RotateCcw className="w-4 h-4" />
            Reset All Filters
          </Button>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 h-11 px-6 rounded-md font-bold text-sm bg-card border border-border hover:bg-muted text-foreground transition-colors shadow-2xs"
          >
            <MessageCircle className="w-4 h-4 text-emerald-500" />
            Inquire via WhatsApp
          </a>
        </div>

        {/* Alternative Links */}
        <div className="mt-6 pt-6 border-t border-border/60 flex items-center justify-center gap-6 text-xs text-muted-foreground">
          <Link href="/men" className="hover:text-royal-violet hover:underline inline-flex items-center gap-1">
            Men&apos;s Store <ArrowRight className="w-3 h-3" />
          </Link>
          <Link href="/women" className="hover:text-royal-violet hover:underline inline-flex items-center gap-1">
            Women&apos;s Store <ArrowRight className="w-3 h-3" />
          </Link>
          <Link href="/kids" className="hover:text-royal-violet hover:underline inline-flex items-center gap-1">
            Kids Store <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
      </div>
    </div>
  );
}


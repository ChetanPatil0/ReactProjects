import { prisma } from "@/lib/prisma";
import { productService, ProductFilters } from "@/server/services/product-service";
import { ProductCard } from "@/features/storefront/components/product-card/product-card";
import { FilterSidebar } from "@/features/storefront/components/filter-sidebar/filter-sidebar";
import { CatalogueEmptyState } from "@/features/storefront/components/catalogue-empty-state";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Filter } from "lucide-react";

interface CatalogueViewProps {
  title: string;
  subtitle?: string;
  filters: ProductFilters;
}

export async function CatalogueView({ title, subtitle, filters }: CatalogueViewProps) {
  const [result, categories, collections, settings] = await Promise.all([
    productService.getProducts({ ...filters, status: "PUBLISHED" }),
    prisma.category.findMany({
      where: { parentId: null, isActive: true },
      include: { children: true },
      orderBy: { displayOrder: "asc" },
    }),
    prisma.collection.findMany({
      where: { isActive: true },
      orderBy: { createdAt: "desc" },
    }),
    prisma.storeSettings.findFirst().catch(() => null),
  ]);

  const { products, pagination } = result;
  const whatsappNumber = settings?.whatsappNumber || "919876543210";

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Page Header */}
      <div className="mb-8 pb-6 border-b border-border">
        <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-ink">
          {title}
        </h1>
        {subtitle && (
          <p className="mt-2 text-sm text-muted-foreground max-w-2xl">
            {subtitle}
          </p>
        )}
        <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
          <span>
            Showing <strong className="text-ink">{products.length}</strong> of{" "}
            <strong className="text-ink">{pagination.totalCount}</strong> styles
          </span>

          {/* Mobile Filter Sheet Trigger */}
          <div className="lg:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs font-semibold">
                  <Filter className="w-3.5 h-3.5 text-royal-violet" />
                  Filter &amp; Sort
                </Button>
              </SheetTrigger>
              <SheetContent
                side="right"
                className="w-[88vw] sm:w-full sm:max-w-md p-0 flex flex-col h-full bg-card overflow-hidden border-l border-border [&>button]:hidden shadow-2xl"
              >
                <FilterSidebar
                  categories={categories}
                  collections={collections}
                  isMobileDrawer={true}
                  totalStylesCount={pagination.totalCount}
                />
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>

      {/* Main Grid & Desktop Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:block lg:col-span-1">
          <div className="sticky top-24 p-6 bg-white rounded-2xl border border-border/80 shadow-2xs">
            <FilterSidebar categories={categories} collections={collections} />
          </div>
        </aside>

        {/* Products Grid */}
        <div className="lg:col-span-3">
          {products.length === 0 ? (
            <CatalogueEmptyState whatsappNumber={whatsappNumber} />
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
              {products.map((p) => (
                <ProductCard key={p.id} product={p as any} whatsappNumber={whatsappNumber} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}


"use client";

import Link from "next/link";
import { formatCurrency, calculateDiscountPercent, buildWhatsAppUrl } from "@/lib/formatters";
import { MessageSquare, ArrowUpRight, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";

export interface ProductCardProps {
  product: {
    id: string;
    name: string;
    slug: string;
    sku?: string | null;
    regularPrice: number | string;
    discountPrice?: number | string | null;
    isFeatured?: boolean;
    isNewArrival?: boolean;
    images: Array<{ path: string; altText?: string | null; isPrimary: boolean }>;
    variants?: Array<{
      size?: string | null;
      color?: string | null;
      colorHex?: string | null;
      isAvailable?: boolean;
      stock?: number | null;
    }>;
  };
  whatsappNumber?: string;
}

export function ProductCard({ product, whatsappNumber = "919876543210" }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [productUrl, setProductUrl] = useState<string | undefined>(undefined);

  useEffect(() => {
    if (typeof window !== "undefined") {
      setProductUrl(`${window.location.origin}/products/${product.slug}`);
    }
  }, [product.slug]);

  const primaryImage = product.images.find((img) => img.isPrimary) || product.images[0];
  const secondaryImage = product.images[1] || primaryImage;

  const regular = Number(product.regularPrice);
  const discount = product.discountPrice ? Number(product.discountPrice) : null;
  const discountPercent = calculateDiscountPercent(regular, discount);

  // Check overall stock status
  const variants = product.variants || [];
  const isOutOfStock =
    variants.length > 0 &&
    !variants.some((v) => v.isAvailable !== false && (v.stock === null || (v.stock !== undefined && v.stock > 0)));

  // Compute total available stock if specified
  const totalStock = variants.reduce(
    (acc, v) => acc + (v.isAvailable !== false && typeof v.stock === "number" ? v.stock : 0),
    0
  );
  const isLowStock = !isOutOfStock && totalStock > 0 && totalStock <= 5;

  // Unique sizes & colors
  const availableSizes = Array.from(
    new Set(variants.map((v) => v.size).filter(Boolean) as string[])
  );
  const uniqueColorObjects = Array.from(
    new Map(
      variants
        .filter((v) => v.color)
        .map((v) => [v.color, v.colorHex || "#191720"])
    ).entries()
  );

  const displayPrice = discount ? discount : regular;

  const whatsappLink = buildWhatsAppUrl({
    whatsappNumber,
    productName: product.name,
    productSku: product.sku,
    price: displayPrice,
    productUrl,
  });

  return (
    <div
      className="group relative flex flex-col bg-card rounded-2xl overflow-hidden border border-border/80 shadow-2xs hover:shadow-xl hover:border-royal-violet/30 transition-all duration-500 ease-out"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* 4:5 Aspect Ratio Image Canvas */}
      <div className="relative aspect-[4/5] w-full overflow-hidden bg-muted/40 dark:bg-[#1a1725]">
        {/* Floating Badges */}
        <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5 pointer-events-none">
          {isOutOfStock ? (
            <span className="px-2.5 py-1 rounded-full bg-[#110f16]/90 text-white text-[10px] font-extrabold uppercase tracking-widest backdrop-blur-xs shadow-md border border-white/10">
              Sold Out
            </span>
          ) : (
            <>
              {discountPercent > 0 && (
                <span className="px-2.5 py-0.5 rounded-full bg-vermilion text-white text-[10px] font-black uppercase tracking-wider shadow-sm">
                  {discountPercent}% OFF
                </span>
              )}
              {product.isNewArrival && (
                <span className="px-2.5 py-0.5 rounded-full bg-electric-lime text-[#191720] text-[10px] font-bold uppercase tracking-wider shadow-2xs">
                  New Arrival
                </span>
              )}
              {isLowStock && (
                <span className="px-2 py-0.5 rounded-full bg-amber-500 text-[#191720] text-[10px] font-black uppercase tracking-wider shadow-sm">
                  Only {totalStock} Left
                </span>
              )}
            </>
          )}
        </div>

        {/* Quick WhatsApp Concierge Hover Action */}
        <a
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          title={isOutOfStock ? "Inquire Restock on WhatsApp" : "Quick Order on WhatsApp"}
          className={`absolute top-3 right-3 z-10 w-9 h-9 rounded-full backdrop-blur-md flex items-center justify-center shadow-md transition-all duration-300 transform ${
            isOutOfStock
              ? "bg-[#110f16]/85 text-white hover:bg-[#110f16] hover:scale-110"
              : "bg-white/95 dark:bg-[#1f1b2c]/95 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-600 hover:text-white dark:hover:text-white hover:scale-110"
          } opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0`}
        >
          <MessageSquare className="w-4 h-4" />
        </a>

        {/* Product Image Link with Smooth Zoom & Instant Prefetch */}
        <Link href={`/products/${product.slug}`} prefetch={true} className="block w-full h-full relative">
          {primaryImage ? (
            <img
              src={isHovered && secondaryImage ? secondaryImage.path : primaryImage.path}
              alt={primaryImage.altText || product.name}
              className={`w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-108 ${
                isOutOfStock ? "grayscale-30 opacity-80" : ""
              }`}
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground text-xs gap-1">
              <span className="text-[11px] font-semibold">OneFam Atelier</span>
            </div>
          )}

          {/* Quick-view Bottom Overlay on Desktop Hover */}
          <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/60 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-between text-white text-[11px] font-bold">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-electric-lime animate-pulse shrink-0" />
              {isOutOfStock ? "Restock Inquiries Open" : "Available in Atelier"}
            </span>
            <span className="underline underline-offset-2 flex items-center gap-0.5">
              Details <ArrowUpRight className="w-3 h-3" />
            </span>
          </div>
        </Link>
      </div>

      {/* Product Information */}
      <div className="p-4 flex flex-col flex-1 justify-between bg-card">
        <div>
          {/* Sizes and Color Swatches Preview */}
          <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-2">
            <span className="font-medium tracking-tight">
              {availableSizes.length > 0 ? availableSizes.slice(0, 4).join(" · ") : "Standard Sizing"}
            </span>

            {uniqueColorObjects.length > 0 && (
              <div className="flex items-center gap-1">
                {uniqueColorObjects.slice(0, 4).map(([colorName, hex]) => (
                  <span
                    key={colorName || "default"}
                    title={colorName || undefined}
                    className="w-2.5 h-2.5 rounded-full border border-black/15 shadow-2xs block"
                    style={{ backgroundColor: hex || "#7137C8" }}
                  />
                ))}
                {uniqueColorObjects.length > 4 && (
                  <span className="text-[9px] font-bold text-muted-foreground ml-0.5">
                    +{uniqueColorObjects.length - 4}
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Title */}
          <Link href={`/products/${product.slug}`} prefetch={true}>
            <h3 className="font-bold text-sm text-foreground line-clamp-1 group-hover:text-royal-violet transition-colors">
              {product.name}
            </h3>
          </Link>
        </div>

        {/* Pricing & Stock Status */}
        <div className="mt-3 pt-3 border-t border-border/60 flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span className={`text-base font-black ${isOutOfStock ? "text-muted-foreground" : "text-foreground"}`}>
              {formatCurrency(displayPrice)}
            </span>
            {discount && (
              <span className="text-xs text-muted-foreground line-through">
                {formatCurrency(regular)}
              </span>
            )}
          </div>

          {isOutOfStock ? (
            <span className="text-[11px] font-bold text-vermilion flex items-center gap-0.5">
              <AlertCircle className="w-3 h-3" /> Sold Out
            </span>
          ) : (
            <Link
              href={`/products/${product.slug}`}
              prefetch={true}
              className="text-xs font-bold text-royal-violet hover:underline flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform"
            >
              Order <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}

export function CatalogueSkeleton({
  titleWidth = "w-56",
  hasSidebar = true,
}: {
  titleWidth?: string;
  hasSidebar?: boolean;
}) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 animate-pulse space-y-8">
      {/* Header Skeleton */}
      <div className="pb-6 border-b border-border/60">
        <div className={`h-8 sm:h-9 ${titleWidth} bg-muted rounded-xl`} />
        <div className="mt-2.5 h-4 w-80 max-w-full bg-muted/60 rounded-md" />
        <div className="mt-4 flex items-center justify-between">
          <div className="h-4 w-36 bg-muted/40 rounded-md" />
          <div className="lg:hidden h-8 w-28 bg-muted/50 rounded-lg" />
        </div>
      </div>

      {/* Main Layout */}
      <div className="flex gap-8 items-start">
        {/* Desktop Filter Sidebar Skeleton */}
        {hasSidebar && (
          <aside className="hidden lg:block w-64 shrink-0 rounded-2xl border border-border/60 bg-card/60 p-5 space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-border/40">
              <div className="h-4 w-20 bg-muted rounded" />
              <div className="h-3 w-10 bg-muted/40 rounded" />
            </div>

            {/* Filter Section: Categories */}
            <div className="space-y-2.5">
              <div className="h-3.5 w-24 bg-muted/70 rounded" />
              <div className="space-y-2 pl-1">
                <div className="h-3 w-32 bg-muted/40 rounded" />
                <div className="h-3 w-28 bg-muted/40 rounded" />
                <div className="h-3 w-36 bg-muted/40 rounded" />
                <div className="h-3 w-24 bg-muted/40 rounded" />
              </div>
            </div>

            {/* Filter Section: Price Range */}
            <div className="space-y-2.5 pt-3 border-t border-border/30">
              <div className="h-3.5 w-20 bg-muted/70 rounded" />
              <div className="flex items-center gap-2">
                <div className="h-8 flex-1 bg-muted/40 rounded-lg" />
                <div className="h-3 w-3 bg-muted/30 rounded" />
                <div className="h-8 flex-1 bg-muted/40 rounded-lg" />
              </div>
            </div>

            {/* Filter Section: Color Swatches */}
            <div className="space-y-2.5 pt-3 border-t border-border/30">
              <div className="h-3.5 w-16 bg-muted/70 rounded" />
              <div className="flex flex-wrap gap-2">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="w-6 h-6 rounded-full bg-muted/50" />
                ))}
              </div>
            </div>

            {/* Filter Section: Sizes */}
            <div className="space-y-2.5 pt-3 border-t border-border/30">
              <div className="h-3.5 w-14 bg-muted/70 rounded" />
              <div className="flex flex-wrap gap-1.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="w-9 h-7 rounded-md bg-muted/40" />
                ))}
              </div>
            </div>
          </aside>
        )}

        {/* Product Cards Grid Skeleton */}
        <div className="flex-1 grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
          {Array.from({ length: 6 }).map((_, idx) => (
            <div
              key={idx}
              className="flex flex-col rounded-2xl overflow-hidden border border-border/60 bg-card p-3 space-y-3"
            >
              {/* Product Image Skeleton */}
              <div className="aspect-[4/5] w-full rounded-xl bg-muted/60 relative overflow-hidden">
                <div className="absolute top-2.5 left-2.5 h-4 w-12 rounded-full bg-muted-foreground/10" />
              </div>

              {/* Title & Category Skeleton */}
              <div className="space-y-1.5">
                <div className="h-3 w-1/3 bg-muted/50 rounded" />
                <div className="h-4 w-4/5 bg-muted rounded" />
              </div>

              {/* Price & Action Skeleton */}
              <div className="pt-2 border-t border-border/40 flex items-center justify-between">
                <div className="h-4 w-20 bg-muted/80 rounded" />
                <div className="h-7 w-7 rounded-lg bg-muted/50" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


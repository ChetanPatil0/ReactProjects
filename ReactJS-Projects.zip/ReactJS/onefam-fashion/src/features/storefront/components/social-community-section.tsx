import {
  Instagram,
  Facebook,
  MessageCircle,
  ArrowUpRight,
  Truck,
  MessageSquare,
  Shield,
  RefreshCw,
} from "lucide-react";
import { siteConfig } from "@/config/site";

interface SocialCommunitySectionProps {
  whatsappNumber?: string;
  instagramUrl?: string;
  facebookUrl?: string;
  showValueProps?: boolean;
}

export function SocialCommunitySection({
  whatsappNumber = siteConfig.contact.whatsappNumber,
  instagramUrl = siteConfig.social.instagram,
  facebookUrl = siteConfig.social.facebook,
  showValueProps = true,
}: SocialCommunitySectionProps) {
  const cleanPhone = whatsappNumber.replace(/[^0-9]/g, "");

  return (
    <section aria-label="Social Community & Brand Assurance" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden bg-gradient-to-r from-[#171422] via-[#120F1A] to-[#0D0B12] border border-white/10 px-6 sm:px-8 py-6 sm:py-8 text-white shadow-xl">
        {/* Subtle decorative glow circles */}
        <div className="absolute top-0 right-1/4 w-60 h-60 bg-royal-violet/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-48 h-48 bg-[#C6F542]/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Portion: Community Headline & Social Action Pills */}
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          {/* Left: Headline & Marketing Sentence */}
          <div className="space-y-1.5 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-0.5 rounded-full bg-white/10 border border-white/15 text-[10px] font-bold tracking-widest uppercase text-[#C6F542]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C6F542] animate-pulse shrink-0" />
              <span>Connect With OneFam • {siteConfig.seo.twitterHandle}</span>
            </div>

            <h3 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              Join Our Sartorial Community
            </h3>

            <p className="text-xs text-white/75 leading-relaxed font-light">
              Follow us on Instagram &amp; Facebook for weekly styling diaries, behind-the-scenes drops, and exclusive community discounts.
            </p>
          </div>

          {/* Right: Sleek Pill Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 shrink-0">
            {/* Instagram Pill */}
            <a
              href={instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Follow OneFam on Instagram"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 hover:bg-gradient-to-r hover:from-amber-500 hover:to-pink-500 border border-white/15 text-xs font-bold text-white shadow-xs transition-all hover:scale-105 active:scale-95"
            >
              <Instagram className="w-4 h-4 text-pink-300 group-hover:text-white" />
              <span>Instagram</span>
              <ArrowUpRight className="w-3 h-3 opacity-70" />
            </a>

            {/* WhatsApp VIP Pill */}
            <a
              href={`https://wa.me/${cleanPhone}?text=${encodeURIComponent(
                "Hi OneFam Fashion! I'd like to join the OneFam styling channel & get updates."
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Chat with OneFam on WhatsApp"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-600 hover:bg-emerald-500 border border-emerald-400/30 text-xs font-bold text-white shadow-xs transition-all hover:scale-105 active:scale-95"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp VIP</span>
              <ArrowUpRight className="w-3 h-3 opacity-70" />
            </a>

            {/* Facebook Pill */}
            <a
              href={facebookUrl}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Follow OneFam on Facebook"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 hover:bg-[#1877F2] border border-white/15 text-xs font-bold text-white shadow-xs transition-all hover:scale-105 active:scale-95"
            >
              <Facebook className="w-4 h-4 text-blue-300 group-hover:text-white" />
              <span>Facebook</span>
              <ArrowUpRight className="w-3 h-3 opacity-70" />
            </a>
          </div>
        </div>

        {/* Bottom Portion: Brand Value Props with Original Purple Theme Icons */}
        {showValueProps && (
          <div className="relative z-10 pt-6 sm:pt-7 mt-6 sm:mt-7 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6">
            {/* 1. Express Shipping */}
            <div className="flex items-start gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-royal-violet/20 text-[#C49BFF] flex items-center justify-center shrink-0 border border-royal-violet/30 shadow-xs">
                <Truck className="w-5 h-5 text-[#C49BFF]" />
              </div>
              <div className="space-y-0.5">
                <h4 className="font-bold text-xs sm:text-sm text-white tracking-tight">Express Shipping</h4>
                <p className="text-[11px] sm:text-xs text-white/70 leading-relaxed font-light">
                  Fast, insured delivery across India with end-to-end milestone tracking.
                </p>
              </div>
            </div>

            {/* 2. Customer Support */}
            <div className="flex items-start gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-royal-violet/20 text-[#C49BFF] flex items-center justify-center shrink-0 border border-royal-violet/30 shadow-xs">
                <MessageSquare className="w-5 h-5 text-[#C49BFF]" />
              </div>
              <div className="space-y-0.5">
                <h4 className="font-bold text-xs sm:text-sm text-white tracking-tight">Customer Support</h4>
                <p className="text-[11px] sm:text-xs text-white/70 leading-relaxed font-light">
                  Direct styling guidance, fit recommendations, and prompt assistance.
                </p>
              </div>
            </div>

            {/* 3. Pure Materials */}
            <div className="flex items-start gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-royal-violet/20 text-[#C49BFF] flex items-center justify-center shrink-0 border border-royal-violet/30 shadow-xs">
                <Shield className="w-5 h-5 text-[#C49BFF]" />
              </div>
              <div className="space-y-0.5">
                <h4 className="font-bold text-xs sm:text-sm text-white tracking-tight">Pure Materials</h4>
                <p className="text-[11px] sm:text-xs text-white/70 leading-relaxed font-light">
                  100% certified cottons, natural linens and artisanal weaves.
                </p>
              </div>
            </div>

            {/* 4. Transparent Tracking */}
            <div className="flex items-start gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-royal-violet/20 text-[#C49BFF] flex items-center justify-center shrink-0 border border-royal-violet/30 shadow-xs">
                <RefreshCw className="w-5 h-5 text-[#C49BFF]" />
              </div>
              <div className="space-y-0.5">
                <h4 className="font-bold text-xs sm:text-sm text-white tracking-tight">Transparent Tracking</h4>
                <p className="text-[11px] sm:text-xs text-white/70 leading-relaxed font-light">
                  Instant order status lookups with OTP verification anytime.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

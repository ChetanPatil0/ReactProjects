"use client";

import { useState } from "react";
import { formatCurrency, formatDate, maskMobile, maskEmail } from "@/lib/formatters";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  ShieldCheck,
  Search,
  KeyRound,
  CheckCircle2,
  Clock,
  Package,
  Truck,
  MapPin,
  AlertCircle,
  HelpCircle,
} from "lucide-react";
import { toast } from "sonner";
import {
  validateOrderReferenceFormat,
  validateTrackingContact,
} from "@/lib/validations";

interface OrderTrackingClientProps {
  initialRef?: string;
  initialContact?: string;
  initialEmail?: string;
}

const LIFECYCLE_STEPS = [
  { key: "PENDING_CONFIRMATION", label: "Registered", icon: Clock },
  { key: "CONFIRMED", label: "Confirmed", icon: CheckCircle2 },
  { key: "PROCESSING", label: "Processing", icon: Package },
  { key: "PACKED", label: "Packed", icon: Package },
  { key: "SHIPPED", label: "Shipped", icon: Truck },
  { key: "OUT_FOR_DELIVERY", label: "Out for Delivery", icon: Truck },
  { key: "DELIVERED", label: "Delivered", icon: MapPin },
];

export function OrderTrackingClient({
  initialRef = "",
  initialContact = "",
  initialEmail = "",
}: OrderTrackingClientProps) {
  const [contact, setContact] = useState(initialContact || initialEmail);
  const [orderRef, setOrderRef] = useState(initialRef);
  const [otpCode, setOtpCode] = useState("");
  const [mode, setMode] = useState<"ref" | "otp">("ref");
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [orders, setOrders] = useState<any[] | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const handleRequestOtp = async () => {
    setFormError(null);
    const contactCheck = validateTrackingContact(contact);
    if (!contactCheck.valid) {
      setFormError(contactCheck.error || "Please enter a valid email address or 10-digit mobile number.");
      toast.error(contactCheck.error);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/tracking", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "request_otp", identifier: contact.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to generate verification code.");

      setOtpSent(true);
      toast.success(data.message || "OTP code generated successfully!");
      if (data.data?.demoOtp) {
        toast.info(`Development test code: ${data.data.demoOtp}`);
      }
    } catch (err: any) {
      toast.error(err.message);
      setFormError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    // 1. Validate Email or Mobile phone format
    const contactCheck = validateTrackingContact(contact);
    if (!contactCheck.valid) {
      setFormError(contactCheck.error || "Please enter a valid email address or 10-digit mobile number.");
      toast.error(contactCheck.error);
      return;
    }

    // 2. Validate Order ID format if in reference mode
    let targetRef: string | undefined = undefined;
    if (mode === "ref") {
      const refCheck = validateOrderReferenceFormat(orderRef);
      if (!refCheck.valid) {
        setFormError(
          refCheck.error ||
            "Invalid Order ID format. Please enter a valid Order ID like ORD-XXXXXXXX (1st & 3rd must be letters, 2nd & 4th must be numbers, followed by 4 digits)."
        );
        toast.error(refCheck.error);
        return;
      }
      targetRef = refCheck.normalized;
    }

    if (mode === "otp" && !otpCode.trim()) {
      setFormError("Please enter the 6-digit verification code.");
      toast.error("Please enter the 6-digit verification code.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/tracking", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          identifier: contact.trim(),
          orderRef: targetRef || (mode === "ref" ? orderRef.trim() : undefined),
          code: mode === "otp" ? otpCode.trim() : undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Order not found.");

      const list = Array.isArray(data.data) ? data.data : [data.data];
      setOrders(list);
      toast.success("Order status retrieved successfully!");
    } catch (err: any) {
      toast.error(err.message);
      setFormError(err.message);
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  const getStepStatus = (currentStatus: string, stepKey: string) => {
    const orderIndex = LIFECYCLE_STEPS.findIndex((s) => s.key === currentStatus);
    const stepIndex = LIFECYCLE_STEPS.findIndex((s) => s.key === stepKey);

    if (currentStatus === "CANCELLED") return "cancelled";
    if (stepIndex <= orderIndex && orderIndex !== -1) return "completed";
    return "pending";
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      {/* Lookup Form Card */}
      <div className="bg-card rounded-2xl border border-border shadow-xs p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-royal-violet/10 text-royal-violet flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-foreground">Verify Order Ownership</h2>
              <p className="text-xs text-muted-foreground">
                For customer privacy, provide your registered email and reference or OTP.
              </p>
            </div>
          </div>

          {/* Mode Switcher */}
          <div className="flex items-center bg-muted/80 p-1 rounded-xl text-xs font-semibold self-start sm:self-auto">
            <button
              onClick={() => {
                setMode("ref");
                setOrders(null);
              }}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                mode === "ref"
                  ? "bg-card text-foreground shadow-xs font-bold"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Order Reference
            </button>
            <button
              onClick={() => {
                setMode("otp");
                setOrders(null);
              }}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                mode === "otp"
                  ? "bg-card text-foreground shadow-xs font-bold"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Email OTP
            </button>
          </div>
        </div>

        <form onSubmit={handleLookup} className="mt-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1.5">
                Registered Email or Mobile Number
              </label>
              <Input
                type="text"
                placeholder="name@example.com or 9876543210"
                value={contact}
                onChange={(e) => setContact(e.target.value)}
                required
                className="h-11 text-sm bg-card dark:bg-[#201D2E] border-border dark:border-[#38334C] text-foreground"
              />
            </div>

            {mode === "ref" ? (
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1.5">
                  Order ID / Reference
                </label>
                <Input
                  type="text"
                  placeholder="e.g. ORD-XXXXXXXX"
                  value={orderRef}
                  onChange={(e) => setOrderRef(e.target.value.toUpperCase())}
                  required
                  className="h-11 text-sm uppercase font-mono bg-card dark:bg-[#201D2E] border-border dark:border-[#38334C] text-foreground"
                />
                <p className="text-[10px] text-muted-foreground mt-1">
                  Format: ORD-XXXXXXXX (Pos 1 &amp; 3 letters, Pos 2 &amp; 4 numbers, followed by 4 digits)
                </p>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    6-Digit Verification Code
                  </label>
                  {!otpSent ? (
                    <button
                      type="button"
                      onClick={handleRequestOtp}
                      disabled={loading}
                      className="text-xs font-bold text-royal-violet hover:underline flex items-center gap-1"
                    >
                      <KeyRound className="w-3 h-3" />
                      Send Code
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleRequestOtp}
                      disabled={loading}
                      className="text-[11px] text-muted-foreground hover:text-royal-violet"
                    >
                      Resend Code
                    </button>
                  )}
                </div>
                <Input
                  type="text"
                  placeholder="Enter 6-digit OTP"
                  value={otpCode}
                  maxLength={6}
                  onChange={(e) => setOtpCode(e.target.value)}
                  className="h-11 text-sm font-mono tracking-widest bg-card dark:bg-[#201D2E] border-border dark:border-[#38334C] text-foreground"
                />
              </div>
            )}
          </div>

          {formError && (
            <div className="p-3.5 rounded-xl bg-destructive/10 border border-destructive/30 text-destructive text-xs font-semibold flex items-center gap-2.5 animate-in fade-in duration-200">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <div className="pt-2 flex justify-end">
            <Button
              type="submit"
              disabled={loading}
              className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold h-11 px-8 rounded-xl shadow-xs"
            >
              <Search className="w-4 h-4 mr-2" />
              {loading ? "Verifying..." : "Track Order"}
            </Button>
          </div>
        </form>
      </div>

      {/* Orders Results View */}
      {orders !== null && (
        <div className="space-y-8">
          {orders.length === 0 ? (
            <div className="text-center py-16 bg-card rounded-2xl border border-border p-6 shadow-xs">
              <AlertCircle className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
              <h3 className="font-bold text-lg text-foreground">No matching orders found</h3>
              <p className="text-xs text-muted-foreground mt-1 max-w-sm mx-auto leading-relaxed">
                Please double check your email and order reference. If you ordered through WhatsApp recently, allow our staff a few minutes to register your order.
              </p>
            </div>
          ) : (
            orders.map((order) => {
              const isPaid = order.paymentStatus === "PAID";
              return (
                <div
                  key={order.orderRef}
                  className="bg-card rounded-2xl border border-border shadow-xs p-6 sm:p-8 space-y-8"
                >
                  {/* Order Top Bar */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-border">
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="text-xl font-mono font-bold text-foreground">
                          {order.orderRef}
                        </span>
                        <Badge
                          variant={
                            order.status === "DELIVERED"
                              ? "success"
                              : order.status === "CANCELLED"
                              ? "destructive"
                              : "default"
                          }
                        >
                          {order.status.replace(/_/g, " ")}
                        </Badge>
                      </div>
                      <span className="text-xs text-muted-foreground mt-1 block">
                        Ordered on {formatDate(order.createdAt)}
                      </span>
                    </div>

                    <div className="flex items-center gap-4 text-right">
                      <div>
                        <span className="text-xs text-muted-foreground block">Total Amount</span>
                        <span className="text-base font-bold text-foreground">
                          {formatCurrency(order.total)}
                        </span>
                      </div>
                      <div>
                        <span className="text-xs text-muted-foreground block">Payment Status</span>
                        <span
                          className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                            isPaid
                              ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30"
                              : "bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30"
                          }`}
                        >
                          {order.paymentStatus.replace(/_/g, " ")}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Visual Status Progress Stepper */}
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-6">
                      Order Journey
                    </h3>
                    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
                      {LIFECYCLE_STEPS.map((step) => {
                        const status = getStepStatus(order.status, step.key);
                        const isDone = status === "completed";
                        const Icon = step.icon;

                        return (
                          <div
                            key={step.key}
                            className={`p-3 rounded-xl border text-center transition flex flex-col items-center justify-center space-y-1.5 ${
                              isDone
                                ? "bg-royal-violet/10 border-royal-violet/30 text-royal-violet"
                                : "bg-muted/40 border-border/70 text-muted-foreground opacity-60"
                            }`}
                          >
                            <Icon className={`w-5 h-5 ${isDone ? "text-royal-violet" : "text-muted-foreground"}`} />
                            <span className="text-[11px] font-bold leading-tight">
                              {step.label}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Shipping Info when available */}
                  {(order.shippingCarrier || order.trackingNumber) && (
                    <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between text-xs text-foreground">
                      <div className="flex items-center gap-2">
                        <Truck className="w-4 h-4 text-emerald-500" />
                        <span>
                          Carrier: <strong>{order.shippingCarrier || "Express Logistics"}</strong> | Tracking No:{" "}
                          <strong className="font-mono">{order.trackingNumber}</strong>
                        </span>
                      </div>
                    </div>
                  )}

                  {/* Items Ordered List */}
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">
                      Items in this Order
                    </h3>
                    <div className="divide-y divide-border/60 border border-border rounded-xl overflow-hidden bg-card">
                      {order.items.map((item: any, i: number) => (
                        <div key={i} className="p-3.5 flex items-center justify-between text-xs">
                          <div>
                            <span className="font-bold text-foreground block">{item.productName}</span>
                            <span className="text-muted-foreground">
                              Variant: {[item.size, item.color].filter(Boolean).join(" / ") || "Standard"} · Qty: {item.quantity}
                            </span>
                          </div>
                          <span className="font-semibold text-foreground">
                            {formatCurrency(Number(item.unitPrice) * item.quantity)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Need Help CTA */}
                  <div className="pt-2 flex items-center justify-between text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <HelpCircle className="w-3.5 h-3.5" />
                      Need modifications to your address or size?
                    </span>
                    <a
                      href={`https://wa.me/919876543210?text=${encodeURIComponent(`Hello OneFam Concierge! I am inquiring regarding my order ${order.orderRef}.`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
                    >
                      WhatsApp Concierge
                    </a>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}

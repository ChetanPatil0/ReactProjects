import { MetadataRoute } from "next";
import { siteConfig } from "@/config/site";

export default function robots(): MetadataRoute.Robots {
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || siteConfig.seo.siteUrl;

  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: [
          "/admin",
          "/admin/*",
          "/api/*",
          "/checkout",
        ],
      },
      {
        userAgent: "Googlebot-Image",
        allow: ["/uploads/*", "/images/*", "/logo/*"],
      },
    ],
    sitemap: `${baseUrl}/sitemap.xml`,
  };
}

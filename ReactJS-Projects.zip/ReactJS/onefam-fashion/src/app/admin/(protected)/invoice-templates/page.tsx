"use client";

import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { siteConfig } from "@/config/site";
import { generateQrSvg } from "@/lib/qr-code";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ConfirmModal } from "@/components/shared/confirm-modal";
import {
  Eye,
  Save,
  Code,
  Sliders,
  Check,
  Copy,
  Sparkles,
  QrCode,
  Image as ImageIcon,
  RotateCcw,
} from "lucide-react";
import { toast } from "sonner";

export const OFFICIAL_DEFAULT_HTML = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Invoice - {{invoice_number}}</title>
<style>
  @page { size: A4; margin: 15mm; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #191720; margin: 0; padding: 40px; background: #fff; line-height: 1.5; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid {{primary_color}}; padding-bottom: 20px; margin-bottom: 24px; }
  .logo-box { display: flex; flex-direction: column; gap: 4px; }
  .inv-meta { text-align: right; }
  .customer-box { margin-bottom: 24px; background: #FCFAF4; padding: 16px; border-radius: 8px; border: 1px solid #E8E6E1; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
  th { text-align: left; padding: 10px 12px; background: #F5F3EF; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #E8E6E1; }
  td { padding: 12px; border-bottom: 1px solid #E8E6E1; font-size: 13px; }
  .bottom-layout { display: flex; justify-content: space-between; align-items: flex-start; margin-top: 10px; }
  .qr-box { width: 240px; padding: 12px; background: #FCFAF4; border: 1px solid #E8E6E1; border-radius: 8px; text-align: center; }
  .totals { width: 300px; }
  .totals-row { display: flex; justify-content: space-between; padding: 5px 0; font-size: 13px; }
  .totals-row.grand { font-size: 16px; font-weight: 700; color: {{primary_color}}; border-top: 2px solid #191720; padding-top: 8px; margin-top: 6px; }
  .footer { text-align: center; font-size: 11px; color: #6B6A72; border-top: 1px solid #E8E6E1; padding-top: 16px; margin-top: 24px; }
</style>
</head>
<body>
  <div class="header">
    <div class="logo-box">
      {{logo}}
      <p style="margin:4px 0 0; color:#6B6A72; font-size:12px;">Official Store Receipt &amp; Invoice</p>
      <p style="margin:2px 0 0; color:#6B6A72; font-size:11px; font-weight:600;">{{gst_number}}</p>
      <p style="margin:2px 0 0; color:#6B6A72; font-size:11px;">Email: {{store_email}} | WhatsApp: +{{whatsapp_number}}</p>
    </div>
    <div class="inv-meta">
      <h2 style="margin:0; font-size:22px; color:{{primary_color}}; font-weight:800;">INVOICE</h2>
      <p style="margin:4px 0; font-size:13px;"><strong>No:</strong> {{invoice_number}}</p>
      <p style="margin:0; font-size:13px;"><strong>Date:</strong> {{invoice_date}}</p>
      <p style="margin:4px 0 0; font-size:13px;"><strong>Order Ref:</strong> {{order_reference}}</p>
    </div>
  </div>

  <div class="customer-box">
    <div style="font-size:11px; text-transform:uppercase; color:#6B6A72; font-weight:700; margin-bottom:4px;">Billed &amp; Shipped To:</div>
    <div style="font-weight:700; font-size:14px; color:#191720;">{{customer_name}}</div>
    <div style="color:#6B6A72; font-size:12px; margin-top:2px;">{{customer_email}} | {{customer_phone}}</div>
    <div style="color:#6B6A72; font-size:12px; margin-top:2px;">{{customer_address}}</div>
  </div>

  <table>
    <thead>
      <tr>
        <th>Item</th>
        <th>Variant</th>
        <th style="text-align:center;">Qty</th>
        <th style="text-align:right;">Price</th>
        <th style="text-align:right;">Total</th>
      </tr>
    </thead>
    <tbody>
      {{items_table}}
    </tbody>
  </table>

  <div class="bottom-layout">
    <div class="qr-box">
      <div style="display:flex; justify-content:center; margin-bottom:6px;">
        {{qr_code}}
      </div>
      <div style="font-size:11px; font-weight:700; color:#191720;">Digital Order Verification</div>
      <div style="font-size:9.5px; color:#6B6A72; margin-top:2px;">Scan with phone to verify authentic order &amp; track parcel.</div>
    </div>

    <div class="totals">
      <div class="totals-row"><span>Subtotal:</span><span>{{subtotal}}</span></div>
      <div class="totals-row"><span>Discount:</span><span style="color:#F45B45;">-{{discount}}</span></div>
      <div class="totals-row"><span>Shipping:</span><span>{{shipping}}</span></div>
      <div class="totals-row grand"><span>Total Payable:</span><span>{{total}}</span></div>
      <div class="totals-row" style="color:#2E8B57; font-weight:600;"><span>Amount Paid:</span><span>{{amount_paid}}</span></div>
      <div class="totals-row" style="color:{{primary_color}}; font-weight:600;"><span>Balance Due:</span><span>{{balance_due}}</span></div>
    </div>
  </div>

  <div class="footer">
    <p>Thank you for shopping with OneFam Fashion. Handcrafted with mindful natural fibres.</p>
  </div>
</body>
</html>`;

export default function AdminInvoiceTemplatesPage() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("html");
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [isRevertCodeModalOpen, setIsRevertCodeModalOpen] = useState(false);

  const { data: settings } = useQuery({
    queryKey: queryKeys.settings.current,
    queryFn: () => apiClient.get("/settings"),
  });

  const { data: templates } = useQuery({
    queryKey: queryKeys.invoices.templates,
    queryFn: () => apiClient.get("/invoice-templates"),
  });

  // Visual Editor Config
  const [primaryColor, setPrimaryColor] = useState("#7137C8");
  const [headerNote, setHeaderNote] = useState("Official Store Receipt & Invoice");
  const [footerText, setFooterText] = useState(
    "Thank you for shopping with OneFam Fashion. Handcrafted with mindful natural fibres."
  );

  // HTML Editor Template
  const [customHtml, setCustomHtml] = useState(OFFICIAL_DEFAULT_HTML);

  // Populate from saved database template if one exists
  useEffect(() => {
    if (templates && Array.isArray(templates) && templates.length > 0) {
      const defaultTmpl = templates.find((t: any) => t.isDefault) || templates[0];
      if (defaultTmpl?.customHtml) {
        setCustomHtml(defaultTmpl.customHtml);
      }
      if (defaultTmpl?.visualConfig) {
        if (defaultTmpl.visualConfig.primaryColor) setPrimaryColor(defaultTmpl.visualConfig.primaryColor);
        if (defaultTmpl.visualConfig.headerNote) setHeaderNote(defaultTmpl.visualConfig.headerNote);
        if (defaultTmpl.visualConfig.footerText) setFooterText(defaultTmpl.visualConfig.footerText);
      }
    }
  }, [templates]);

  const saveMutation = useMutation({
    mutationFn: (body: any) => apiClient.post("/invoice-templates", body),
    onSuccess: () => {
      toast.success("Invoice template saved successfully!");
      queryClient.invalidateQueries({ queryKey: queryKeys.invoices.templates });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const resetMutation = useMutation({
    mutationFn: () => apiClient.delete("/invoice-templates"),
    onSuccess: () => {
      setCustomHtml(OFFICIAL_DEFAULT_HTML);
      setPrimaryColor("#7137C8");
      setHeaderNote("Official Store Receipt & Invoice");
      setFooterText(
        "Thank you for shopping with OneFam Fashion. Handcrafted with mindful natural fibres."
      );
      toast.success("Invoice template reset to official default successfully!");
      queryClient.invalidateQueries({ queryKey: queryKeys.invoices.templates });
    },
    onError: (err: any) => toast.error(err.message || "Failed to reset template"),
  });

  const handleSave = () => {
    saveMutation.mutate({
      name: "Custom OneFam Template",
      type: activeTab === "visual" ? "VISUAL" : "CUSTOM_HTML",
      isDefault: true,
      customHtml: customHtml.replace(/{{primary_color}}/g, primaryColor),
      visualConfig: {
        primaryColor,
        headerNote,
        footerText,
      },
    });
  };

  const copyVariable = (varName: string) => {
    navigator.clipboard.writeText(varName);
    toast.success(`Copied ${varName} to clipboard!`);
  };

  // Sample data for preview
  const sampleLogoSrc = settings?.logoUrl || siteConfig.images.logo.light;
  const sampleLogoHtml = `<img src="${sampleLogoSrc}" alt="OneFam Fashion" style="height:44px; max-width:200px; object-fit:contain; display:block;" />`;
  const sampleQrSvg = generateQrSvg("https://onefamfashion.com/orders/verify/ORD-K7M20001", { size: 90 });

  // Generate live preview string with sample variables replaced
  const previewHtml = customHtml
    .replace(/{{primary_color}}/g, primaryColor)
    .replace(/{{logo}}/g, sampleLogoHtml)
    .replace(/{{store_logo}}/g, sampleLogoHtml)
    .replace(/{{qr_code}}/g, sampleQrSvg)
    .replace(/{{verification_url}}/g, "https://onefamfashion.com/orders/verify/ORD-K7M20001")
    .replace(/{{store_name}}/g, settings?.storeName || "OneFam Fashion")
    .replace(/{{gst_number}}/g, settings?.gstNumber ? `GSTIN: ${settings.gstNumber}` : "GSTIN: 29AAAAA0000A1Z5")
    .replace(/{{store_email}}/g, settings?.supportEmail || siteConfig.contact.supportEmail)
    .replace(/{{support_email}}/g, settings?.supportEmail || siteConfig.contact.supportEmail)
    .replace(/{{whatsapp_number}}/g, settings?.whatsappNumber || siteConfig.contact.whatsappNumber)
    .replace(/{{whatsapp_no}}/g, settings?.whatsappNumber || siteConfig.contact.whatsappNumber)
    .replace(/{{store_whatsapp}}/g, settings?.whatsappNumber || siteConfig.contact.whatsappNumber)
    .replace(/{{store_phone}}/g, settings?.supportPhone || settings?.whatsappNumber || siteConfig.contact.whatsappNumber)
    .replace(/{{store_address}}/g, settings?.address || "OneFam Boutique, India")
    .replace(/{{invoice_number}}/g, "INV-2026-0042")
    .replace(/{{invoice_date}}/g, "04 Nov 2026")
    .replace(/{{order_reference}}/g, "ORD-K7M20001")
    .replace(/{{customer_name}}/g, "Aarav Sharma")
    .replace(/{{customer_email}}/g, "aarav@example.com")
    .replace(/{{customer_phone}}/g, "+91 98201 54321")
    .replace(/{{customer_address}}/g, "Flat 402, Royal Palms, Indiranagar, Bengaluru, KA 560038")
    .replace(
      /{{items_table}}/g,
      `<tr>
        <td style="padding:12px;border-bottom:1px solid #E8E6E1;font-weight:500;">Bespoke Linen Camp Shirt</td>
        <td style="padding:12px;border-bottom:1px solid #E8E6E1;color:#6B6A72;">M / Sage Green</td>
        <td style="padding:12px;border-bottom:1px solid #E8E6E1;text-align:center;">1</td>
        <td style="padding:12px;border-bottom:1px solid #E8E6E1;text-align:right;">₹1,999</td>
        <td style="padding:12px;border-bottom:1px solid #E8E6E1;text-align:right;font-weight:600;">₹1,999</td>
      </tr>`
    )
    .replace(/{{subtotal}}/g, "₹1,999")
    .replace(/{{discount}}/g, "₹200")
    .replace(/{{shipping}}/g, "FREE")
    .replace(/{{total}}/g, "₹1,799")
    .replace(/{{amount_paid}}/g, "₹1,799")
    .replace(/{{balance_due}}/g, "₹0")
    .replace(/{{footer_note}}/g, footerText);

  const TEMPLATE_VARIABLES = [
    { tag: "{{logo}}", desc: "Main store logo <img> tag", highlight: true },
    { tag: "{{qr_code}}", desc: "Order verification QR SVG", highlight: true },
    { tag: "{{store_email}}", desc: "Store / Support Email address", highlight: true },
    { tag: "{{whatsapp_number}}", desc: "WhatsApp Contact Number", highlight: true },
    { tag: "{{gst_number}}", desc: "Store GSTIN Tax Number" },
    { tag: "{{store_name}}", desc: "Store Name" },
    { tag: "{{store_phone}}", desc: "Store Phone" },
    { tag: "{{store_address}}", desc: "Store Business Address" },
    { tag: "{{invoice_number}}", desc: "Unique Invoice No." },
    { tag: "{{invoice_date}}", desc: "Date Issued" },
    { tag: "{{order_reference}}", desc: "Order Reference ID" },
    { tag: "{{customer_name}}", desc: "Customer Full Name" },
    { tag: "{{customer_email}}", desc: "Customer Email" },
    { tag: "{{customer_phone}}", desc: "Customer Phone" },
    { tag: "{{customer_address}}", desc: "Shipping Delivery Address" },
    { tag: "{{items_table}}", desc: "Itemized Products Table HTML" },
    { tag: "{{subtotal}}", desc: "Subtotal" },
    { tag: "{{discount}}", desc: "Discount" },
    { tag: "{{shipping}}", desc: "Shipping" },
    { tag: "{{total}}", desc: "Total Payable" },
    { tag: "{{amount_paid}}", desc: "Amount Paid" },
    { tag: "{{balance_due}}", desc: "Balance Due" },
    { tag: "{{verification_url}}", desc: "Public Verification URL" },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-ink">
            Custom Invoice Template Builder
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Design your official GST invoice template with HTML, CSS, custom logo, and verification QR code.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => setIsResetModalOpen(true)}
            disabled={resetMutation.isPending}
            className="border-border text-foreground hover:bg-muted font-bold rounded-xl text-xs gap-1.5 cursor-pointer"
            title="Reset to official factory default"
          >
            <RotateCcw className="w-3.5 h-3.5 text-muted-foreground" />
            <span>{resetMutation.isPending ? "Resetting..." : "Reset to Default"}</span>
          </Button>

          <Button
            onClick={handleSave}
            disabled={saveMutation.isPending}
            className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl text-xs"
          >
            <Save className="w-4 h-4 mr-1.5" />
            {saveMutation.isPending ? "Saving..." : "Save Template"}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* Left: Editor Options */}
        <div className="p-6 bg-white rounded-2xl border border-border shadow-2xs space-y-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full grid grid-cols-2">
              <TabsTrigger value="html" className="text-xs font-bold gap-1.5">
                <Code className="w-3.5 h-3.5" /> Option A: Custom HTML Editor
              </TabsTrigger>
              <TabsTrigger value="visual" className="text-xs font-bold gap-1.5">
                <Sliders className="w-3.5 h-3.5" /> Option B: Visual Stylist
              </TabsTrigger>
            </TabsList>

            <TabsContent value="html" className="space-y-4 pt-4 text-xs">
              {/* Dynamic Variables Pill Bar */}
              <div className="p-3.5 bg-muted/40 rounded-xl space-y-2 border border-border/60">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-ink text-xs flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-royal-violet" />
                    Available Template Fields &amp; Variables (Click to Copy):
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {TEMPLATE_VARIABLES.map((v) => (
                    <button
                      key={v.tag}
                      type="button"
                      onClick={() => copyVariable(v.tag)}
                      title={`Click to copy: ${v.desc}`}
                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-mono text-[11px] font-semibold transition cursor-pointer ${
                        v.highlight
                          ? "bg-royal-violet text-white shadow-xs hover:bg-royal-violet/90"
                          : "bg-card border border-border text-foreground hover:bg-muted"
                      }`}
                    >
                      {v.highlight && <Sparkles className="w-3 h-3 text-[#C6F542]" />}
                      <span>{v.tag}</span>
                    </button>
                  ))}
                </div>
                <p className="text-[10px] text-muted-foreground mt-1">
                  Use <code>{"{{logo}}"}</code> to insert the main store logo, <code>{"{{qr_code}}"}</code> for the verification QR code, and <code>{"{{store_email}}"}</code> / <code>{"{{whatsapp_number}}"}</code> for contact info.
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-bold text-muted-foreground block">
                    HTML &amp; Inline CSS Code
                  </label>
                  <button
                    type="button"
                    onClick={() => setIsRevertCodeModalOpen(true)}
                    className="text-[11px] font-semibold text-royal-violet hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Revert Code to Default</span>
                  </button>
                </div>
                <Textarea
                  value={customHtml}
                  onChange={(e) => setCustomHtml(e.target.value)}
                  rows={20}
                  className="font-mono text-xs leading-relaxed bg-paper/60 border-border focus-visible:ring-royal-violet"
                />
              </div>
            </TabsContent>

            <TabsContent value="visual" className="space-y-4 pt-4 text-xs">
              <div>
                <label className="font-bold text-muted-foreground block mb-1">
                  Brand Primary Accent Color
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                    className="w-10 h-10 rounded-lg cursor-pointer border border-border"
                  />
                  <Input
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                    className="h-9 w-32 font-mono text-xs uppercase"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-muted-foreground block mb-1">
                  Header Tagline / Subtitle
                </label>
                <Input
                  value={headerNote}
                  onChange={(e) => setHeaderNote(e.target.value)}
                  className="h-9 text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-muted-foreground block mb-1">
                  Footer Thank-You Text
                </label>
                <Textarea
                  value={footerText}
                  onChange={(e) => setFooterText(e.target.value)}
                  rows={3}
                  className="text-xs"
                />
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Right: Live Preview Iframe */}
        <div className="p-6 bg-white rounded-2xl border border-border shadow-2xs space-y-4 sticky top-6">
          <div className="flex items-center justify-between pb-3 border-b border-border">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-royal-violet" />
              <h2 className="font-bold text-sm text-ink">Live Invoice Preview</h2>
            </div>
            <span className="text-[11px] text-muted-foreground font-semibold">
              Live Sample with Real Logo &amp; QR
            </span>
          </div>

          <div className="border border-border/80 rounded-xl overflow-hidden h-[640px] bg-white shadow-inner">
            <iframe
              srcDoc={previewHtml}
              title="Invoice Live Preview"
              className="w-full h-full border-0"
            />
          </div>
        </div>
      </div>

      {/* Confirmation Modal for Resetting to Official Default */}
      <ConfirmModal
        open={isResetModalOpen}
        onOpenChange={setIsResetModalOpen}
        title="Reset Invoice Template to Default?"
        description="Are you sure you want to reset the invoice template back to the official default? Any custom HTML formatting, colors, or CSS edits will be permanently replaced with the system standard template."
        confirmLabel="Yes, Reset to Default"
        cancelLabel="Cancel"
        variant="destructive"
        isLoading={resetMutation.isPending}
        onConfirm={() => {
          resetMutation.mutate();
          setIsResetModalOpen(false);
        }}
      />

      {/* Confirmation Modal for Reverting Code */}
      <ConfirmModal
        open={isRevertCodeModalOpen}
        onOpenChange={setIsRevertCodeModalOpen}
        title="Revert HTML Code to Starter Template?"
        description="This will replace your current HTML editor content with the official OneFam starter code containing {{logo}}, {{qr_code}}, {{store_email}}, and {{whatsapp_number}}."
        confirmLabel="Revert Code"
        cancelLabel="Keep Current Code"
        onConfirm={() => {
          setCustomHtml(OFFICIAL_DEFAULT_HTML);
          setIsRevertCodeModalOpen(false);
          toast.info("HTML code restored to default template structure.");
        }}
      />
    </div>
  );
}

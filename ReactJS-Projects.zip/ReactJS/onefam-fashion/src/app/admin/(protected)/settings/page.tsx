"use client";

import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Settings, Save, Store, MessageSquare, ShieldCheck, Image as ImageIcon } from "lucide-react";
import { ImageUploader, uploadImageFile } from "@/components/shared/image-uploader";
import { OneFamLogo } from "@/components/brand/onefam-logo";
import { toast } from "sonner";

export default function AdminSettingsPage() {
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery({
    queryKey: queryKeys.settings.current,
    queryFn: () => apiClient.get("/settings"),
  });

  const [storeName, setStoreName] = useState("");
  const [logoUrl, setLogoUrl] = useState("");
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [supportEmail, setSupportEmail] = useState("");
  const [supportPhone, setSupportPhone] = useState("");
  const [whatsappNumber, setWhatsappNumber] = useState("");
  const [address, setAddress] = useState("");
  const [gstNumber, setGstNumber] = useState("");
  const [announcementBar, setAnnouncementBar] = useState("");

  useEffect(() => {
    if (settings) {
      setStoreName(settings.storeName || "");
      setLogoUrl(settings.logoUrl || "");
      setSupportEmail(settings.supportEmail || "");
      setSupportPhone(settings.supportPhone || "");
      setWhatsappNumber(settings.whatsappNumber || "");
      setAddress(settings.address || "");
      setGstNumber(settings.gstNumber || "");
      setAnnouncementBar(settings.announcementBar || "");
    }
  }, [settings]);

  const updateMutation = useMutation({
    mutationFn: (body: any) => apiClient.patch("/settings", body),
    onSuccess: () => {
      toast.success("Store profile and invoice settings updated successfully");
      queryClient.invalidateQueries({ queryKey: queryKeys.settings.current });
      setIsSubmitting(false);
    },
    onError: (err: any) => {
      toast.error(err.message);
      setIsSubmitting(false);
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      let finalLogoUrl = logoUrl;
      if (logoFile) {
        toast.info("Uploading and optimizing store logo...");
        const uploadRes = await uploadImageFile(logoFile);
        finalLogoUrl = uploadRes.url;
        setLogoUrl(finalLogoUrl);
        setLogoFile(null);
      }

      updateMutation.mutate({
        storeName,
        logoUrl: finalLogoUrl,
        supportEmail,
        supportPhone,
        whatsappNumber,
        address,
        gstNumber,
        announcementBar,
      });
    } catch (err: any) {
      toast.error(err.message || "Failed to process logo upload");
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return <div className="p-8 text-xs text-muted-foreground animate-pulse">Loading settings...</div>;
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-ink">
            Store Profile &amp; Business Settings
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Configure official brand logo, GST invoices, contact details, and WhatsApp support.
          </p>
        </div>

        <Button
          onClick={handleSubmit}
          disabled={isSubmitting || updateMutation.isPending}
          className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl text-xs"
        >
          <Save className="w-4 h-4 mr-1.5" />
          {isSubmitting || updateMutation.isPending ? "Saving..." : "Save Settings"}
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Main Store Brand Logo */}
        <div className="p-6 bg-white rounded-2xl border border-border shadow-2xs space-y-4 text-xs">
          <div className="pb-2 border-b border-border">
            <h2 className="font-bold text-sm text-ink flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-royal-violet" />
              Store Brand Logo
            </h2>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              Upload your main store brand logo. Click <strong>Snip / Crop</strong> directly on the image to adjust framing and dimensions before uploading.
            </p>
          </div>

          <div className="max-w-md">
            <ImageUploader
              value={logoUrl}
              onChange={setLogoUrl}
              onFileSelect={setLogoFile}
              label="Main Store Logo"
            />
          </div>
        </div>

        {/* Core Store Profile */}
        <div className="p-6 bg-white rounded-2xl border border-border shadow-2xs space-y-4 text-xs">
          <h2 className="font-bold text-sm text-ink pb-2 border-b border-border flex items-center gap-2">
            <Store className="w-4 h-4 text-royal-violet" />
            General Information
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="font-bold text-muted-foreground block mb-1">
                Store Name <span className="text-vermilion">*</span>
              </label>
              <Input
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                required
                className="h-10 text-xs"
              />
            </div>

            <div>
              <label className="font-bold text-muted-foreground block mb-1">
                GSTIN / Tax Registration Number (Optional)
              </label>
              <Input
                placeholder="29AAAAA0000A1Z5"
                value={gstNumber}
                onChange={(e) => setGstNumber(e.target.value)}
                className="h-10 text-xs font-mono uppercase"
              />
            </div>
          </div>

          <div>
            <label className="font-bold text-muted-foreground block mb-1">
              Storefront Top Announcement Bar
            </label>
            <Input
              value={announcementBar}
              onChange={(e) => setAnnouncementBar(e.target.value)}
              className="h-10 text-xs"
            />
          </div>
        </div>

        {/* WhatsApp & Concierge Channels */}
        <div className="p-6 bg-white rounded-2xl border border-border shadow-2xs space-y-4 text-xs">
          <h2 className="font-bold text-sm text-ink pb-2 border-b border-border flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-emerald-600" />
            WhatsApp Concierge &amp; Customer Care
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="font-bold text-muted-foreground block mb-1">
                WhatsApp Phone Number (with Country Code) <span className="text-vermilion">*</span>
              </label>
              <Input
                placeholder="919876543210"
                value={whatsappNumber}
                onChange={(e) => setWhatsappNumber(e.target.value)}
                required
                className="h-10 text-xs font-mono"
              />
              <span className="text-[10px] text-muted-foreground mt-1 block">
                Storefront product order buttons will open this WhatsApp number.
              </span>
            </div>

            <div>
              <label className="font-bold text-muted-foreground block mb-1">
                Support Email
              </label>
              <Input
                type="email"
                value={supportEmail}
                onChange={(e) => setSupportEmail(e.target.value)}
                className="h-10 text-xs"
              />
            </div>

            <div>
              <label className="font-bold text-muted-foreground block mb-1">
                Support Phone
              </label>
              <Input
                value={supportPhone}
                onChange={(e) => setSupportPhone(e.target.value)}
                className="h-10 text-xs"
              />
            </div>
          </div>

          <div>
            <label className="font-bold text-muted-foreground block mb-1">
              Studio / Business Address
            </label>
            <Textarea
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              rows={3}
              className="text-xs"
            />
          </div>
        </div>
      </form>
    </div>
  );
}


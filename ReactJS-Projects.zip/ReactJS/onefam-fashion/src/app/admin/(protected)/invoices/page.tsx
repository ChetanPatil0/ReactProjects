"use client";

import { useQuery } from "@tanstack/react-query";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import { FileText, ExternalLink, Printer, Download } from "lucide-react";

export default function AdminInvoicesPage() {
  const { data: invoices = [], isLoading } = useQuery({
    queryKey: queryKeys.invoices.all,
    queryFn: () => apiClient.get("/invoices"),
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-ink">
            Official Store Invoices
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Generated GST-compliant sales invoices, receipts, and printable PDFs.
          </p>
        </div>

        <Button asChild size="sm" variant="outline" className="rounded-xl font-semibold text-xs">
          <Link href="/admin/invoice-templates">
            <FileText className="w-3.5 h-3.5 mr-1.5 text-royal-violet" />
            Template Builder
          </Link>
        </Button>
      </div>

      <div className="bg-white rounded-2xl border border-border shadow-2xs overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Invoice No.</TableHead>
              <TableHead>Invoice Date</TableHead>
              <TableHead>Order Ref</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Total Payable</TableHead>
              <TableHead>Amount Paid</TableHead>
              <TableHead>Balance Due</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-xs text-muted-foreground">
                  Loading invoices...
                </TableCell>
              </TableRow>
            ) : invoices.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-xs text-muted-foreground">
                  No invoices generated yet. Click "Generate Invoice" on any confirmed order.
                </TableCell>
              </TableRow>
            ) : (
              invoices.map((inv: any) => (
                <TableRow key={inv.id}>
                  <TableCell className="font-mono font-bold text-xs text-ink">
                    {inv.invoiceNumber}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {formatDate(inv.invoiceDate)}
                  </TableCell>
                  <TableCell>
                    <Link
                      href={`/admin/orders/${inv.orderId}`}
                      className="font-mono font-bold text-xs text-royal-violet hover:underline"
                    >
                      {inv.order?.orderRef}
                    </Link>
                  </TableCell>
                  <TableCell className="text-xs">
                    <span className="font-bold text-ink block">{inv.order?.customer?.name}</span>
                    <span className="text-[11px] text-muted-foreground">
                      {inv.order?.customer?.phone}
                    </span>
                  </TableCell>
                  <TableCell className="font-bold text-xs text-ink">
                    {formatCurrency(inv.total)}
                  </TableCell>
                  <TableCell className="text-xs font-bold text-emerald-700">
                    {formatCurrency(inv.amountPaid)}
                  </TableCell>
                  <TableCell className="text-xs font-bold text-vermilion">
                    {formatCurrency(inv.balanceDue)}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-3">
                      <a
                        href={`/api/invoices/${inv.id}/preview`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-xs font-semibold text-royal-violet hover:underline"
                        title="View printable invoice"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Print</span>
                      </a>
                      <a
                        href={`/api/invoices/${inv.id}/preview?download=true`}
                        className="inline-flex items-center gap-1 text-xs font-bold text-ink dark:text-foreground hover:text-royal-violet hover:underline"
                        title="Download official PDF invoice"
                      >
                        <Download className="w-3.5 h-3.5 text-royal-violet" />
                        <span>PDF</span>
                      </a>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}


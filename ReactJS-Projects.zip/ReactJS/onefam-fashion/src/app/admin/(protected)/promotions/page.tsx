"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function PromotionsRedirect() {
  const router = useRouter();

  useEffect(() => {
    router.replace("/admin/offers");
  }, [router]);

  return (
    <div className="p-12 text-center text-xs text-muted-foreground">
      Redirecting to Offers &amp; Discounts...
    </div>
  );
}

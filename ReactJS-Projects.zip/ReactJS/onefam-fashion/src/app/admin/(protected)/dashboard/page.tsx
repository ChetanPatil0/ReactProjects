"use client";

import { useQuery } from "@tanstack/react-query";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ShoppingBag,
  Shirt,
  DollarSign,
  AlertTriangle,
  ArrowRight,
  PlusCircle,
  Clock,
  Sliders,
  Tag,
  ArrowUpRight,
  BarChart3,
  TrendingUp,
} from "lucide-react";
import {
  RevenueTrendChart,
  OrderStatusDonutChart,
  PaymentMethodsChart,
} from "@/components/admin/charts/analytics-charts";

export default function AdminDashboardPage() {
  const { data, isLoading } = useQuery({
    queryKey: queryKeys.orders.dashboardSummary,
    queryFn: () => apiClient.get("/orders/dashboard-summary"),
  });

  if (isLoading) {
    return (
      <div className="space-y-8 animate-pulse">
        <div className="h-8 bg-muted rounded-md w-48" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 bg-card rounded-2xl border border-border" />
          ))}
        </div>
      </div>
    );
  }

  const metrics = data?.metrics || {
    totalProducts: 0,
    publishedProducts: 0,
    draftProducts: 0,
    totalOrders: 0,
    pendingOrders: 0,
    processingOrders: 0,
    paidOrders: 0,
    unpaidOrders: 0,
    deliveredOrders: 0,
    cancelledOrders: 0,
    totalRevenue: 0,
    totalAmountPaid: 0,
    totalBalanceDue: 0,
  };

  const recentOrders = data?.recentOrders || [];
  const pendingAlerts = data?.pendingAlerts || [];
  const revenueTrend = data?.revenueTrend || [];
  const statusBreakdown = data?.statusBreakdown || [];
  const paymentMethods = data?.paymentMethods || [];

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      {/* Top Welcome & Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-foreground">
            Atelier Executive Overview
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            Real-time operations, catalogue performance and order fulfillment metrics.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            asChild
            size="sm"
            className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl"
          >
            <Link href="/admin/orders">
              <PlusCircle className="w-4 h-4 mr-1.5" />
              Register Order
            </Link>
          </Button>

          <Button asChild variant="outline" size="sm" className="rounded-xl font-semibold border-border bg-card">
            <Link href="/admin/reports">
              <BarChart3 className="w-4 h-4 mr-1.5 text-royal-violet dark:text-[#C6F542]" />
              Full Analytics
            </Link>
          </Button>

          <Button asChild variant="outline" size="sm" className="rounded-xl font-semibold border-border bg-card">
            <Link href="/admin/products">
              <Shirt className="w-4 h-4 mr-1.5 text-royal-violet" />
              Manage Products
            </Link>
          </Button>
        </div>
      </div>

      {/* Primary KPI Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Metric 1: Total Revenue */}
        <div className="p-6 rounded-2xl bg-card border border-border shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-muted-foreground">
            <span className="text-xs font-bold uppercase tracking-wider">Total Sales Volume</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-foreground">
            {formatCurrency(metrics.totalRevenue)}
          </div>
          <div className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
            <span>Collected: {formatCurrency(metrics.totalAmountPaid)}</span>
          </div>
        </div>

        {/* Metric 2: Balance Due / Unpaid */}
        <div className="p-6 rounded-2xl bg-card border border-border shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-muted-foreground">
            <span className="text-xs font-bold uppercase tracking-wider">Outstanding Balance</span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-vermilion dark:text-rose-400">
            {formatCurrency(metrics.totalBalanceDue)}
          </div>
          <div className="text-xs text-muted-foreground">
            Across {metrics.unpaidOrders} unpaid / partial orders
          </div>
        </div>

        {/* Metric 3: Total Orders */}
        <div className="p-6 rounded-2xl bg-card border border-border shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-muted-foreground">
            <span className="text-xs font-bold uppercase tracking-wider">Total Orders</span>
            <div className="w-8 h-8 rounded-lg bg-violet-500/10 text-royal-violet dark:text-[#C6F542] flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-foreground">
            {metrics.totalOrders}
          </div>
          <div className="text-xs text-muted-foreground">
            {metrics.deliveredOrders} Delivered · {metrics.processingOrders} Processing
          </div>
        </div>

        {/* Metric 4: Catalogue Health */}
        <div className="p-6 rounded-2xl bg-card border border-border shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-muted-foreground">
            <span className="text-xs font-bold uppercase tracking-wider">Active Catalogue</span>
            <div className="w-8 h-8 rounded-lg bg-lime-500/10 text-emerald-700 flex items-center justify-center">
              <Shirt className="w-4 h-4 text-emerald-600" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-foreground">
            {metrics.publishedProducts}
            <span className="text-xs text-muted-foreground font-normal ml-1">
              / {metrics.totalProducts} Total
            </span>
          </div>
          <div className="text-xs text-muted-foreground">
            {metrics.draftProducts} in Draft Status
          </div>
        </div>
      </div>

      {/* Embedded Executive Charts */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-royal-violet dark:text-[#C6F542]" />
            <h2 className="text-base font-bold text-foreground">7-Day Sales &amp; Performance Velocity</h2>
          </div>
          <Link
            href="/admin/reports"
            className="text-xs font-bold text-royal-violet dark:text-[#C6F542] hover:underline flex items-center gap-1"
          >
            Detailed Analytics <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <RevenueTrendChart
          data={revenueTrend}
          title="Past 7 Days Turnover"
          subtitle="Real-time daily cash inflows and volume"
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <OrderStatusDonutChart data={statusBreakdown} />
          <PaymentMethodsChart data={paymentMethods} />
        </div>
      </div>

      {/* Orders Requiring Attention Banner */}
      {pendingAlerts.length > 0 && (
        <div className="p-6 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-foreground space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300 font-bold text-sm">
              <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              Orders Requiring Attention ({pendingAlerts.length})
            </div>
            <Link
              href="/admin/orders"
              className="text-xs font-bold text-amber-700 dark:text-amber-300 hover:underline flex items-center gap-1"
            >
              View in Orders <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            {pendingAlerts.map((o: any) => (
              <Link
                key={o.id}
                href={`/admin/orders/${o.id}`}
                className="p-3 bg-card rounded-xl border border-border shadow-2xs flex items-center justify-between text-xs hover:border-amber-400 transition"
              >
                <div>
                  <span className="font-mono font-bold text-foreground block">{o.orderRef}</span>
                  <span className="text-muted-foreground text-[11px]">{o.customer?.name}</span>
                </div>
                <Badge variant="warning">{o.status.replace(/_/g, " ")}</Badge>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Split Section: Recent Orders & Quick Launchpad */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Orders Table */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-card border border-border shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-border">
            <h2 className="font-bold text-base text-foreground">Recent Registered Orders</h2>
            <Link
              href="/admin/orders"
              className="text-xs font-bold text-royal-violet dark:text-[#C6F542] hover:underline flex items-center gap-1"
            >
              See All Orders <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="divide-y divide-border/60 overflow-hidden">
            {recentOrders.length === 0 ? (
              <p className="text-xs text-muted-foreground py-6 text-center">No orders registered yet.</p>
            ) : (
              recentOrders.map((o: any) => (
                <div key={o.id} className="py-3.5 flex items-center justify-between text-xs">
                  <div>
                    <div className="flex items-center gap-2">
                      <Link
                        href={`/admin/orders/${o.id}`}
                        className="font-mono font-bold text-foreground hover:text-royal-violet dark:hover:text-[#C6F542] transition"
                      >
                        {o.orderRef}
                      </Link>
                      <Badge variant="default" className="text-[10px] py-0">
                        {o.status.replace(/_/g, " ")}
                      </Badge>
                    </div>
                    <span className="text-muted-foreground text-[11px] mt-0.5 block">
                      {o.customer?.name} · {formatDate(o.createdAt)}
                    </span>
                  </div>

                  <div className="text-right">
                    <span className="font-bold text-foreground block">{formatCurrency(o.total)}</span>
                    <span
                      className={`text-[10px] font-semibold ${
                        o.paymentStatus === "PAID"
                          ? "text-emerald-600 dark:text-emerald-400"
                          : "text-amber-600 dark:text-amber-400"
                      }`}
                    >
                      {o.paymentStatus.replace(/_/g, " ")}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Quick Operations Launchpad */}
        <div className="p-6 rounded-2xl bg-card border border-border shadow-2xs space-y-4">
          <h2 className="font-bold text-base text-foreground pb-3 border-b border-border">
            Operations Launchpad
          </h2>
          <div className="space-y-3">
            <Link
              href="/admin/reports"
              className="p-3.5 rounded-xl border border-border/80 hover:border-royal-violet hover:bg-violet-50/40 dark:hover:bg-violet-950/20 transition flex items-center justify-between text-xs font-semibold text-foreground group"
            >
              <div className="flex items-center gap-2.5">
                <BarChart3 className="w-4 h-4 text-royal-violet dark:text-[#C6F542]" />
                <span>Executive Reports &amp; Charts</span>
              </div>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground group-hover:text-royal-violet transition" />
            </Link>

            <Link
              href="/admin/products"
              className="p-3.5 rounded-xl border border-border/80 hover:border-royal-violet hover:bg-violet-50/40 dark:hover:bg-violet-950/20 transition flex items-center justify-between text-xs font-semibold text-foreground group"
            >
              <div className="flex items-center gap-2.5">
                <Shirt className="w-4 h-4 text-royal-violet dark:text-[#C6F542]" />
                <span>Create New Product</span>
              </div>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground group-hover:text-royal-violet transition" />
            </Link>

            <Link
              href="/admin/offers"
              className="p-3.5 rounded-xl border border-border/80 hover:border-royal-violet hover:bg-violet-50/40 dark:hover:bg-violet-950/20 transition flex items-center justify-between text-xs font-semibold text-foreground group"
            >
              <div className="flex items-center gap-2.5">
                <Tag className="w-4 h-4 text-vermilion" />
                <span>Offers &amp; Discounts</span>
              </div>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground group-hover:text-royal-violet transition" />
            </Link>

            <Link
              href="/admin/hero-sliders"
              className="p-3.5 rounded-xl border border-border/80 hover:border-royal-violet hover:bg-violet-50/40 dark:hover:bg-violet-950/20 transition flex items-center justify-between text-xs font-semibold text-foreground group"
            >
              <div className="flex items-center gap-2.5">
                <Sliders className="w-4 h-4 text-royal-violet dark:text-[#C6F542]" />
                <span>Manage Homepage Hero Slides</span>
              </div>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground group-hover:text-royal-violet transition" />
            </Link>

            <Link
              href="/admin/invoice-templates"
              className="p-3.5 rounded-xl border border-border/80 hover:border-royal-violet hover:bg-violet-50/40 dark:hover:bg-violet-950/20 transition flex items-center justify-between text-xs font-semibold text-foreground group"
            >
              <div className="flex items-center gap-2.5">
                <Sliders className="w-4 h-4 text-royal-violet dark:text-[#C6F542]" />
                <span>Customize Invoice Templates</span>
              </div>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground group-hover:text-royal-violet transition" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import { CreditCard, ExternalLink, DollarSign } from "lucide-react";

export default function AdminPaymentsPage() {
  const [methodFilter, setMethodFilter] = useState("");

  const { data, isLoading } = useQuery({
    queryKey: queryKeys.payments.list({ method: methodFilter }),
    queryFn: () =>
      apiClient.get(
        `/payments?${new URLSearchParams({
          ...(methodFilter ? { method: methodFilter } : {}),
          limit: "50",
        }).toString()}`
      ),
  });

  const payments = data?.payments || [];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-ink">
            Payment Transactions Ledger
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Every customer advance, UPI transfer, and balance receipt tracked independently.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={methodFilter}
            onChange={(e) => setMethodFilter(e.target.value)}
            className="text-xs rounded-md border border-border bg-white px-3 py-1.5 text-ink focus:outline-none"
          >
            <option value="">All Payment Methods</option>
            <option value="UPI">UPI</option>
            <option value="BANK_TRANSFER">Bank Transfer</option>
            <option value="CASH">Cash</option>
            <option value="OTHER">Other</option>
          </select>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-border shadow-2xs overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Payment Date</TableHead>
              <TableHead>Order Reference</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Method</TableHead>
              <TableHead>Transaction / UTR</TableHead>
              <TableHead>Notes</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-xs text-muted-foreground">
                  Loading payments ledger...
                </TableCell>
              </TableRow>
            ) : payments.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-xs text-muted-foreground">
                  No payment transactions recorded yet.
                </TableCell>
              </TableRow>
            ) : (
              payments.map((pm: any) => (
                <TableRow key={pm.id}>
                  <TableCell className="text-xs text-muted-foreground">
                    {formatDate(pm.paymentDate)}
                  </TableCell>
                  <TableCell>
                    <Link
                      href={`/admin/orders/${pm.orderId}`}
                      className="font-mono font-bold text-xs text-royal-violet hover:underline"
                    >
                      {pm.order?.orderRef}
                    </Link>
                  </TableCell>
                  <TableCell className="text-xs">
                    <span className="font-bold text-ink block">
                      {pm.order?.customer?.name || "-"}
                    </span>
                    <span className="text-muted-foreground text-[11px]">
                      {pm.order?.customer?.phone}
                    </span>
                  </TableCell>
                  <TableCell className="font-bold text-xs text-emerald-700">
                    {formatCurrency(pm.amount)}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{pm.method}</Badge>
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {pm.reference || "-"}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground max-w-xs truncate">
                    {pm.notes || "-"}
                  </TableCell>
                  <TableCell className="text-right">
                    <Link
                      href={`/admin/orders/${pm.orderId}`}
                      className="text-xs font-semibold text-royal-violet hover:underline inline-flex items-center gap-1"
                    >
                      View Order <ExternalLink className="w-3 h-3" />
                    </Link>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}


"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  HelpCircle,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle,
  MessageSquare,
  Mail,
  Phone,
  Trash2,
  ExternalLink,
  ChevronRight,
  Eye,
  RefreshCw,
  Copy,
  Check,
  ShoppingBag,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { ConfirmModal } from "@/components/shared/confirm-modal";
import { toast } from "sonner";
import { formatDate } from "@/lib/formatters";

interface Inquiry {
  id: string;
  ticketId: string;
  name: string;
  email: string;
  phone?: string;
  subject: string;
  orderNumber?: string;
  message: string;
  status: "NEW" | "IN_PROGRESS" | "RESOLVED" | "CLOSED";
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
}

const STATUS_CONFIG: Record<
  string,
  { label: string; bg: string; text: string; border: string }
> = {
  NEW: {
    label: "New",
    bg: "bg-purple-500/10 dark:bg-purple-500/20",
    text: "text-royal-violet dark:text-purple-300",
    border: "border-royal-violet/30",
  },
  IN_PROGRESS: {
    label: "In Progress",
    bg: "bg-amber-500/10 dark:bg-amber-500/20",
    text: "text-amber-700 dark:text-amber-300",
    border: "border-amber-500/30",
  },
  RESOLVED: {
    label: "Resolved",
    bg: "bg-emerald-500/10 dark:bg-emerald-500/20",
    text: "text-emerald-700 dark:text-emerald-300",
    border: "border-emerald-500/30",
  },
  CLOSED: {
    label: "Closed",
    bg: "bg-slate-500/10 dark:bg-slate-500/20",
    text: "text-slate-600 dark:text-slate-400",
    border: "border-slate-500/30",
  },
};

export default function AdminInquiriesPage() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [selectedInquiry, setSelectedInquiry] = useState<Inquiry | null>(null);
  const [adminNotes, setAdminNotes] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [inquiryToDelete, setInquiryToDelete] = useState<string | null>(null);

  const { data, isLoading, refetch, isFetching } = useQuery<{
    inquiries: Inquiry[];
    stats: { total: number; new: number; inProgress: number; resolved: number; closed: number };
  }>({
    queryKey: ["admin-inquiries", statusFilter, search],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (statusFilter !== "ALL") params.set("status", statusFilter);
      if (search.trim()) params.set("search", search.trim());
      const res = await fetch(`/api/inquiries?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch inquiries");
      const json = await res.json();
      return { inquiries: json.data || [], stats: json.stats || {} };
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({
      id,
      status,
      notes,
    }: {
      id: string;
      status?: string;
      notes?: string;
    }) => {
      const res = await fetch(`/api/inquiries/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, adminNotes: notes }),
      });
      if (!res.ok) throw new Error("Failed to update inquiry");
      return res.json();
    },
    onSuccess: () => {
      toast.success("Inquiry updated successfully");
      queryClient.invalidateQueries({ queryKey: ["admin-inquiries"] });
      if (selectedInquiry) {
        setSelectedInquiry((prev) => (prev ? { ...prev, adminNotes } : null));
      }
    },
    onError: (err: any) => toast.error(err.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/inquiries/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete inquiry");
      return res.json();
    },
    onSuccess: () => {
      toast.success("Inquiry deleted");
      setSelectedInquiry(null);
      queryClient.invalidateQueries({ queryKey: ["admin-inquiries"] });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const handleOpenDetail = (inquiry: Inquiry) => {
    setSelectedInquiry(inquiry);
    setAdminNotes(inquiry.adminNotes || "");
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    toast.success("Copied to clipboard");
    setTimeout(() => setCopiedId(null), 2000);
  };

  const inquiries = data?.inquiries || [];
  const stats = data?.stats || { total: 0, new: 0, inProgress: 0, resolved: 0, closed: 0 };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-foreground flex items-center gap-2.5">
            <HelpCircle className="w-6 h-6 text-royal-violet dark:text-[#C6F542]" />
            Customer Care &amp; Help Inquiries
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Manage inquiries and customer questions submitted through the storefront contact form.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={() => refetch()}
          disabled={isFetching}
          className="rounded-xl text-xs h-9 gap-1.5 self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isFetching ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          onClick={() => setStatusFilter("ALL")}
          className={`cursor-pointer p-5 rounded-2xl border bg-card transition-all hover:border-royal-violet/60 ${
            statusFilter === "ALL" ? "ring-2 ring-royal-violet border-royal-violet" : "border-border/60"
          }`}
        >
          <div className="flex items-center justify-between text-muted-foreground text-xs font-bold">
            <span>Total Inquiries</span>
            <HelpCircle className="w-4 h-4 text-muted-foreground/60" />
          </div>
          <p className="text-2xl font-black text-foreground mt-2">{stats.total}</p>
        </div>

        <div
          onClick={() => setStatusFilter("NEW")}
          className={`cursor-pointer p-5 rounded-2xl border bg-card transition-all hover:border-purple-500/60 ${
            statusFilter === "NEW" ? "ring-2 ring-royal-violet border-royal-violet" : "border-border/60"
          }`}
        >
          <div className="flex items-center justify-between text-royal-violet dark:text-purple-300 text-xs font-bold">
            <span>New (Pending)</span>
            <Clock className="w-4 h-4 text-royal-violet" />
          </div>
          <p className="text-2xl font-black text-royal-violet dark:text-purple-300 mt-2">{stats.new}</p>
        </div>

        <div
          onClick={() => setStatusFilter("IN_PROGRESS")}
          className={`cursor-pointer p-5 rounded-2xl border bg-card transition-all hover:border-amber-500/60 ${
            statusFilter === "IN_PROGRESS" ? "ring-2 ring-amber-500 border-amber-500" : "border-border/60"
          }`}
        >
          <div className="flex items-center justify-between text-amber-600 dark:text-amber-400 text-xs font-bold">
            <span>In Progress</span>
            <MessageSquare className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-2">{stats.inProgress}</p>
        </div>

        <div
          onClick={() => setStatusFilter("RESOLVED")}
          className={`cursor-pointer p-5 rounded-2xl border bg-card transition-all hover:border-emerald-500/60 ${
            statusFilter === "RESOLVED" ? "ring-2 ring-emerald-500 border-emerald-500" : "border-border/60"
          }`}
        >
          <div className="flex items-center justify-between text-emerald-600 dark:text-emerald-400 text-xs font-bold">
            <span>Resolved</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-2">{stats.resolved}</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-card p-3.5 rounded-2xl border border-border/60 shadow-2xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-muted-foreground absolute left-3.5 top-1/2 -translate-y-1/2" />
          <Input
            placeholder="Search by ticket ID, customer name, email, phone, or order #..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 h-10 text-xs rounded-xl"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="h-10 px-3 rounded-xl border border-input bg-background text-foreground text-xs font-semibold focus:ring-2 focus:ring-royal-violet outline-hidden w-full sm:w-44"
          >
            <option value="ALL">All Statuses</option>
            <option value="NEW">New Only</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="RESOLVED">Resolved</option>
            <option value="CLOSED">Closed</option>
          </select>
        </div>
      </div>

      {/* Inquiries Table / List */}
      <div className="bg-card rounded-2xl border border-border/60 overflow-hidden shadow-2xs">
        {isLoading ? (
          <div className="p-12 text-center text-xs text-muted-foreground space-y-3">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto text-royal-violet" />
            <p>Loading inquiries...</p>
          </div>
        ) : inquiries.length === 0 ? (
          <div className="p-12 text-center text-muted-foreground space-y-3">
            <CheckCircle2 className="w-8 h-8 mx-auto text-muted-foreground/40" />
            <p className="text-sm font-semibold text-foreground">No Inquiries Found</p>
            <p className="text-xs">
              {search || statusFilter !== "ALL"
                ? "Try adjusting your search filters or status selection."
                : "Customer help and contact requests will appear here once submitted."}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-muted/40 text-muted-foreground uppercase text-[10px] font-bold tracking-wider border-b border-border/60">
                <tr>
                  <th className="py-3.5 px-4">Ticket Ref</th>
                  <th className="py-3.5 px-4">Customer</th>
                  <th className="py-3.5 px-4">Inquiry Category</th>
                  <th className="py-3.5 px-4">Order Ref</th>
                  <th className="py-3.5 px-4">Message Preview</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Date</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/40">
                {inquiries.map((inq) => {
                  const cfg = STATUS_CONFIG[inq.status] || STATUS_CONFIG.NEW;
                  const cleanPhone = (inq.phone || "").replace(/[^0-9]/g, "");

                  return (
                    <tr
                      key={inq.id}
                      className="hover:bg-muted/30 transition-colors group cursor-pointer"
                      onClick={() => handleOpenDetail(inq)}
                    >
                      {/* Ticket Ref */}
                      <td className="py-4 px-4 font-mono font-bold text-foreground">
                        <span className="inline-flex items-center gap-1.5">
                          {inq.ticketId}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleCopy(inq.ticketId, inq.id);
                            }}
                            className="text-muted-foreground hover:text-foreground"
                          >
                            {copiedId === inq.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </span>
                      </td>

                      {/* Customer */}
                      <td className="py-4 px-4">
                        <div className="font-bold text-foreground">{inq.name}</div>
                        <div className="text-[11px] text-muted-foreground">{inq.email}</div>
                        {inq.phone && (
                          <div className="text-[10px] text-muted-foreground/80 font-mono">
                            {inq.phone}
                          </div>
                        )}
                      </td>

                      {/* Subject */}
                      <td className="py-4 px-4">
                        <span className="font-semibold text-foreground text-[11px]">
                          {inq.subject}
                        </span>
                      </td>

                      {/* Order Ref */}
                      <td className="py-4 px-4">
                        {inq.orderNumber ? (
                          <span className="inline-flex items-center gap-1 font-mono text-[11px] font-semibold text-royal-violet dark:text-[#C6F542] px-2 py-0.5 rounded-md bg-royal-violet/10">
                            <ShoppingBag className="w-3 h-3" />
                            {inq.orderNumber}
                          </span>
                        ) : (
                          <span className="text-muted-foreground/40">—</span>
                        )}
                      </td>

                      {/* Message Preview */}
                      <td className="py-4 px-4 max-w-xs">
                        <p className="line-clamp-2 text-muted-foreground text-[11px]">
                          {inq.message}
                        </p>
                      </td>

                      {/* Status */}
                      <td className="py-4 px-4" onClick={(e) => e.stopPropagation()}>
                        <select
                          value={inq.status}
                          onChange={(e) =>
                            updateMutation.mutate({
                              id: inq.id,
                              status: e.target.value,
                            })
                          }
                          className={`text-[11px] font-bold px-2.5 py-1 rounded-full border ${cfg.bg} ${cfg.text} ${cfg.border} outline-hidden cursor-pointer`}
                        >
                          <option value="NEW">New</option>
                          <option value="IN_PROGRESS">In Progress</option>
                          <option value="RESOLVED">Resolved</option>
                          <option value="CLOSED">Closed</option>
                        </select>
                      </td>

                      {/* Date */}
                      <td className="py-4 px-4 text-muted-foreground text-[11px] whitespace-nowrap">
                        {formatDate(inq.createdAt)}
                      </td>

                      {/* Actions */}
                      <td
                        className="py-4 px-4 text-right whitespace-nowrap"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="inline-flex items-center gap-1.5">
                          {cleanPhone && (
                            <a
                              href={`https://wa.me/${cleanPhone}?text=${encodeURIComponent(
                                `Hello ${inq.name}, this is OneFam Support regarding your question (${inq.ticketId}).`
                              )}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              title="Reply via WhatsApp"
                              className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </a>
                          )}
                          <a
                            href={`mailto:${inq.email}?subject=${encodeURIComponent(
                              `OneFam Support: Re: ${inq.subject} (${inq.ticketId})`
                            )}`}
                            title="Reply via Email"
                            className="p-1.5 rounded-lg text-royal-violet hover:bg-royal-violet/10 transition-colors"
                          >
                            <Mail className="w-3.5 h-3.5" />
                          </a>
                          <button
                            type="button"
                            onClick={() => handleOpenDetail(inq)}
                            title="View Full Details"
                            className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Inquiry Detail & Response Dialog */}
      <Dialog
        open={!!selectedInquiry}
        onOpenChange={(open) => !open && setSelectedInquiry(null)}
      >
        <DialogContent className="max-w-2xl bg-card border border-border/80">
          <DialogHeader>
            <div className="flex items-center justify-between gap-3 pr-6">
              <span className="font-mono text-xs font-bold text-royal-violet dark:text-[#C6F542] px-2.5 py-1 rounded-md bg-royal-violet/10">
                {selectedInquiry?.ticketId}
              </span>
              <span className="text-xs text-muted-foreground">
                Submitted {selectedInquiry?.createdAt ? formatDate(selectedInquiry.createdAt) : ""}
              </span>
            </div>
            <DialogTitle className="text-xl font-bold text-foreground mt-2">
              {selectedInquiry?.subject}
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground">
              Customer Contact &amp; Inquiry Details
            </DialogDescription>
          </DialogHeader>

          {selectedInquiry && (
            <div className="space-y-5 text-xs">
              {/* Customer Info Card */}
              <div className="p-4 rounded-xl bg-muted/30 border border-border/60 grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <span className="text-[10px] text-muted-foreground uppercase font-bold block">
                    Customer Name
                  </span>
                  <span className="font-bold text-foreground">{selectedInquiry.name}</span>
                </div>
                <div>
                  <span className="text-[10px] text-muted-foreground uppercase font-bold block">
                    Email Address
                  </span>
                  <a
                    href={`mailto:${selectedInquiry.email}`}
                    className="font-medium text-royal-violet hover:underline break-all"
                  >
                    {selectedInquiry.email}
                  </a>
                </div>
                <div>
                  <span className="text-[10px] text-muted-foreground uppercase font-bold block">
                    Mobile Phone
                  </span>
                  <span className="font-mono text-foreground">
                    {selectedInquiry.phone || "—"}
                  </span>
                </div>
              </div>

              {/* Order Reference if present */}
              {selectedInquiry.orderNumber && (
                <div className="p-3 rounded-xl bg-royal-violet/5 border border-royal-violet/20 flex items-center justify-between">
                  <span className="text-xs font-semibold text-foreground flex items-center gap-1.5">
                    <ShoppingBag className="w-4 h-4 text-royal-violet" />
                    Referenced Order:{" "}
                    <strong className="font-mono text-royal-violet dark:text-[#C6F542]">
                      {selectedInquiry.orderNumber}
                    </strong>
                  </span>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 text-xs rounded-lg"
                    onClick={() =>
                      (window.location.href = `/admin/orders?search=${selectedInquiry.orderNumber}`)
                    }
                  >
                    View in Orders
                  </Button>
                </div>
              )}

              {/* Message Box */}
              <div className="space-y-1.5">
                <span className="font-bold text-foreground block">Customer Message</span>
                <div className="p-4 rounded-xl bg-muted/40 border border-border/60 text-foreground leading-relaxed whitespace-pre-wrap">
                  {selectedInquiry.message}
                </div>
              </div>

              {/* Admin Internal Notes */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-foreground block">
                    Internal Staff Notes (Private)
                  </span>
                  <Button
                    size="sm"
                    onClick={() =>
                      updateMutation.mutate({
                        id: selectedInquiry.id,
                        notes: adminNotes,
                      })
                    }
                    disabled={updateMutation.isPending}
                    className="h-7 text-xs bg-royal-violet hover:bg-royal-violet/90 text-white rounded-lg"
                  >
                    {updateMutation.isPending ? "Saving..." : "Save Notes"}
                  </Button>
                </div>
                <Textarea
                  rows={3}
                  placeholder="Record customer follow-ups, resolution arrangements, or notes for support team..."
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  className="text-xs rounded-xl"
                />
              </div>

              {/* Dialog Actions & Status Update */}
              <div className="pt-3 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <span className="font-bold text-muted-foreground">Status:</span>
                  <select
                    value={selectedInquiry.status}
                    onChange={(e) => {
                      const newStatus = e.target.value as any;
                      setSelectedInquiry((prev) => (prev ? { ...prev, status: newStatus } : null));
                      updateMutation.mutate({
                        id: selectedInquiry.id,
                        status: newStatus,
                        notes: adminNotes,
                      });
                    }}
                    className="h-9 px-3 rounded-xl border border-input bg-background text-xs font-bold outline-hidden"
                  >
                    <option value="NEW">New</option>
                    <option value="IN_PROGRESS">In Progress</option>
                    <option value="RESOLVED">Resolved</option>
                    <option value="CLOSED">Closed</option>
                  </select>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  {selectedInquiry.phone && (
                    <Button
                      asChild
                      className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs h-9 rounded-xl gap-1.5"
                    >
                      <a
                        href={`https://wa.me/${selectedInquiry.phone.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(
                          `Hello ${selectedInquiry.name}, this is OneFam Support regarding your inquiry ${selectedInquiry.ticketId}.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        Reply WhatsApp
                      </a>
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    onClick={() => setInquiryToDelete(selectedInquiry.id)}
                    disabled={deleteMutation.isPending}
                    className="text-vermilion hover:bg-vermilion/10 border-vermilion/30 text-xs h-9 rounded-xl cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5 mr-1" />
                    Delete
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Confirmation Modal for Inquiry Deletion */}
      <ConfirmModal
        open={!!inquiryToDelete}
        onOpenChange={(open) => !open && setInquiryToDelete(null)}
        title="Delete Customer Inquiry?"
        description="Are you sure you want to delete this customer inquiry ticket? This action cannot be undone."
        confirmLabel="Delete Inquiry"
        cancelLabel="Cancel"
        variant="destructive"
        isLoading={deleteMutation.isPending}
        onConfirm={() => {
          if (inquiryToDelete) {
            deleteMutation.mutate(inquiryToDelete);
            setInquiryToDelete(null);
          }
        }}
      />
    </div>
  );
}


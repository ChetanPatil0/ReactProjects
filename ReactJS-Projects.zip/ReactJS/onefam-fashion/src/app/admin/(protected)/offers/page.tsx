"use client";

import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "@/lib/api-client";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { ConfirmModal } from "@/components/shared/confirm-modal";
import {
  Tag,
  Plus,
  Percent,
  Search,
  Sparkles,
  Calendar,
  Check,
  CheckSquare,
  Square,
  Pencil,
  Trash2,
  AlertCircle,
  Shirt,
  Filter,
  Layers,
  ArrowRight,
  TrendingDown,
} from "lucide-react";
import { toast } from "sonner";

interface OfferProduct {
  id: string;
  name: string;
  slug: string;
  regularPrice: number;
  categoryName?: string | null;
  image?: string | null;
}

interface OfferItem {
  id: string;
  name: string;
  description?: string | null;
  discountType: "PERCENTAGE" | "FIXED";
  discountValue: number;
  minPurchase?: number | null;
  maxDiscount?: number | null;
  startDate?: string | null;
  endDate?: string | null;
  isActive: boolean;
  productsCount: number;
  products?: OfferProduct[];
  productIds?: string[];
  createdAt: string;
}

export default function AdminOffersPage() {
  const queryClient = useQueryClient();

  // Dialog State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingOffer, setEditingOffer] = useState<OfferItem | null>(null);
  const [offerToDelete, setOfferToDelete] = useState<OfferItem | null>(null);

  // Form State
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [discountType, setDiscountType] = useState<"PERCENTAGE" | "FIXED">("PERCENTAGE");
  const [discountValue, setDiscountValue] = useState("20");
  const [minPurchase, setMinPurchase] = useState("");
  const [maxDiscount, setMaxDiscount] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [isActive, setIsActive] = useState(true);
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);

  // Product Picker Filter State
  const [productSearch, setProductSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");

  // Fetch Offers
  const { data: offersData, isLoading: isOffersLoading } = useQuery({
    queryKey: ["offers", "list"],
    queryFn: async () => {
      const res = await apiClient.get<OfferItem[]>("/offers");
      return res || [];
    },
  });

  const offers: OfferItem[] = offersData || [];

  // Fetch Available Products for Picker
  const { data: productsData } = useQuery({
    queryKey: ["products", "picker"],
    queryFn: async () => {
      const res = await apiClient.get<{ products: any[] }>("/products?limit=100");
      return res?.products || [];
    },
  });

  const allProducts = productsData || [];

  // Fetch Categories for Filter Dropdown
  const { data: categoriesData } = useQuery({
    queryKey: ["categories", "picker"],
    queryFn: async () => {
      const res = await apiClient.get<any[]>("/categories");
      return res || [];
    },
  });

  const allCategories = categoriesData || [];

  // Filtered Products for the Picker
  const filteredProducts = useMemo(() => {
    return allProducts.filter((p: any) => {
      const matchSearch =
        !productSearch.trim() ||
        p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
        p.slug.toLowerCase().includes(productSearch.toLowerCase()) ||
        (p.sku && p.sku.toLowerCase().includes(productSearch.toLowerCase()));

      const matchCategory =
        !categoryFilter ||
        p.categoryId === categoryFilter ||
        p.category?.slug === categoryFilter;

      return matchSearch && matchCategory;
    });
  }, [allProducts, productSearch, categoryFilter]);

  // Mutations
  const saveMutation = useMutation({
    mutationFn: async (payload: any) => {
      if (editingOffer) {
        return apiClient.put(`/offers/${editingOffer.id}`, payload);
      }
      return apiClient.post("/offers", payload);
    },
    onSuccess: () => {
      toast.success(
        editingOffer
          ? `Offer "${name}" updated successfully!`
          : `Offer "${name}" created with ${selectedProductIds.length} products!`
      );
      queryClient.invalidateQueries({ queryKey: ["offers"] });
      queryClient.invalidateQueries({ queryKey: ["products"] });
      handleCloseModal();
    },
    onError: (err: any) => {
      toast.error(err.message || "Failed to save offer");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => apiClient.delete(`/offers/${id}`),
    onSuccess: () => {
      toast.success("Offer deleted");
      queryClient.invalidateQueries({ queryKey: ["offers"] });
      queryClient.invalidateQueries({ queryKey: ["products"] });
    },
    onError: (err: any) => toast.error(err.message || "Failed to delete offer"),
  });

  const toggleActiveMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) =>
      apiClient.put(`/offers/${id}`, { isActive }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["offers"] });
      queryClient.invalidateQueries({ queryKey: ["products"] });
      toast.success("Offer status updated");
    },
    onError: (err: any) => toast.error(err.message || "Failed to update status"),
  });

  // Modal handlers
  const handleOpenCreate = () => {
    setEditingOffer(null);
    setName("");
    setDescription("");
    setDiscountType("PERCENTAGE");
    setDiscountValue("20");
    setMinPurchase("");
    setMaxDiscount("");
    setStartDate("");
    setEndDate("");
    setIsActive(true);
    setSelectedProductIds([]);
    setProductSearch("");
    setCategoryFilter("");
    setIsModalOpen(true);
  };

  const handleOpenEdit = async (offer: OfferItem) => {
    setEditingOffer(offer);
    setName(offer.name);
    setDescription(offer.description || "");
    setDiscountType(offer.discountType);
    setDiscountValue(String(offer.discountValue));
    setMinPurchase(offer.minPurchase ? String(offer.minPurchase) : "");
    setMaxDiscount(offer.maxDiscount ? String(offer.maxDiscount) : "");
    setStartDate(offer.startDate ? offer.startDate.slice(0, 10) : "");
    setEndDate(offer.endDate ? offer.endDate.slice(0, 10) : "");
    setIsActive(offer.isActive);
    setProductSearch("");
    setCategoryFilter("");

    // Load full offer to get selected product IDs
    try {
      const full = await apiClient.get<any>(`/offers/${offer.id}`);
      if (full?.productIds) {
        setSelectedProductIds(full.productIds);
      } else {
        setSelectedProductIds(offer.products?.map((p) => p.id) || []);
      }
    } catch {
      setSelectedProductIds(offer.products?.map((p) => p.id) || []);
    }

    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingOffer(null);
  };

  // Product Selection Handlers
  const handleToggleProduct = (id: string) => {
    setSelectedProductIds((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    );
  };

  const handleSelectAllFiltered = () => {
    const idsToAdd = filteredProducts.map((p: any) => p.id);
    setSelectedProductIds((prev) => Array.from(new Set([...prev, ...idsToAdd])));
  };

  const handleDeselectAllFiltered = () => {
    const idsToRemove = new Set(filteredProducts.map((p: any) => p.id));
    setSelectedProductIds((prev) => prev.filter((id) => !idsToRemove.has(id)));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("Offer name is required");
      return;
    }
    const val = parseFloat(discountValue);
    if (isNaN(val) || val <= 0) {
      toast.error("Please enter a valid positive discount value");
      return;
    }
    if (discountType === "PERCENTAGE" && val > 100) {
      toast.error("Percentage discount cannot exceed 100%");
      return;
    }

    saveMutation.mutate({
      name: name.trim(),
      description: description.trim() || undefined,
      discountType,
      discountValue: val,
      minPurchase: minPurchase ? parseFloat(minPurchase) : null,
      maxDiscount: maxDiscount ? parseFloat(maxDiscount) : null,
      startDate: startDate ? new Date(startDate).toISOString() : null,
      endDate: endDate ? new Date(endDate).toISOString() : null,
      isActive,
      productIds: selectedProductIds,
    });
  };

  // Metrics
  const activeOffersCount = offers.filter((o) => o.isActive).length;
  const totalProductsOnDiscount = offers
    .filter((o) => o.isActive)
    .reduce((sum, o) => sum + (o.productsCount || 0), 0);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-foreground flex items-center gap-2">
            <Tag className="w-6 h-6 text-royal-violet" />
            <span>Offers &amp; Discounts</span>
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Create percentage or flat rupee discounts and pick products to attach. The backend automatically computes and displays dynamic discounted prices across the store.
          </p>
        </div>

        <Button
          onClick={handleOpenCreate}
          size="sm"
          className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl text-xs h-9 px-4 shadow-sm flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Create Offer &amp; Discount</span>
        </Button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl border border-border bg-card shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
              Active Offers
            </span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-foreground mt-2">
            {activeOffersCount}
          </div>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            Running live on storefront
          </p>
        </div>

        <div className="p-4 rounded-2xl border border-border bg-card shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
              Total Campaigns
            </span>
            <div className="w-7 h-7 rounded-lg bg-royal-violet/10 text-royal-violet flex items-center justify-center">
              <Tag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-foreground mt-2">
            {offers.length}
          </div>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            Active, scheduled &amp; archived deals
          </p>
        </div>

        <div className="p-4 rounded-2xl border border-border bg-card shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
              Discounted Products
            </span>
            <div className="w-7 h-7 rounded-lg bg-vermilion/10 text-vermilion flex items-center justify-center">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-foreground mt-2">
            {totalProductsOnDiscount}
          </div>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            Pieces enjoying active price cuts
          </p>
        </div>
      </div>

      {/* Offers Table */}
      <div className="rounded-2xl border border-border bg-card overflow-hidden shadow-2xs">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h2 className="text-xs font-black uppercase tracking-wider text-foreground flex items-center gap-2">
            <Layers className="w-4 h-4 text-royal-violet" />
            <span>All Store Offers &amp; Discounts</span>
          </h2>
          <span className="text-xs text-muted-foreground">
            {offers.length} configured
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-border bg-muted/40 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                <th className="py-3 px-4">Offer Name</th>
                <th className="py-3 px-4 w-32">Discount</th>
                <th className="py-3 px-4 w-36">Attached Products</th>
                <th className="py-3 px-4 w-44">Schedule</th>
                <th className="py-3 px-4 w-28 text-center">Status</th>
                <th className="py-3 px-4 w-24 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border text-xs">
              {isOffersLoading ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-muted-foreground">
                    Loading offers...
                  </td>
                </tr>
              ) : offers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-muted-foreground space-y-3">
                    <p className="text-sm font-semibold">No Offers or Discounts Created Yet</p>
                    <p className="text-xs text-muted-foreground">
                      Click below to create your first discount and pick products to attach.
                    </p>
                    <Button
                      size="sm"
                      onClick={handleOpenCreate}
                      className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold text-xs"
                    >
                      <Plus className="w-3.5 h-3.5 mr-1" />
                      Create First Offer
                    </Button>
                  </td>
                </tr>
              ) : (
                offers.map((offer) => (
                  <tr key={offer.id} className="hover:bg-muted/20 transition-colors">
                    {/* Title & Description */}
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-foreground text-sm flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-royal-violet shrink-0" />
                        <span>{offer.name}</span>
                      </div>
                      {offer.description && (
                        <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">
                          {offer.description}
                        </p>
                      )}
                    </td>

                    {/* Discount Value */}
                    <td className="py-3.5 px-4">
                      <Badge
                        variant="secondary"
                        className="font-black text-xs uppercase px-2.5 py-0.5 bg-vermilion/10 text-vermilion border border-vermilion/20"
                      >
                        {offer.discountType === "PERCENTAGE"
                          ? `${offer.discountValue}% OFF`
                          : `₹${offer.discountValue} FLAT`}
                      </Badge>
                      {offer.minPurchase ? (
                        <span className="block text-[10px] text-muted-foreground mt-0.5">
                          Min. ₹{offer.minPurchase}
                        </span>
                      ) : null}
                    </td>

                    {/* Products Count */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-1.5">
                        <Shirt className="w-3.5 h-3.5 text-royal-violet" />
                        <span className="font-bold text-foreground">
                          {offer.productsCount} {offer.productsCount === 1 ? "Product" : "Products"}
                        </span>
                      </div>
                      <span className="text-[10px] text-muted-foreground block">
                        Dynamic price applied
                      </span>
                    </td>

                    {/* Date Schedule */}
                    <td className="py-3.5 px-4 text-[11px] text-muted-foreground">
                      {offer.startDate || offer.endDate ? (
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-royal-violet shrink-0" />
                          <span>
                            {offer.startDate ? formatDate(offer.startDate) : "Starts now"} &ndash;{" "}
                            {offer.endDate ? formatDate(offer.endDate) : "No expiry"}
                          </span>
                        </div>
                      ) : (
                        <span className="text-muted-foreground">Always active</span>
                      )}
                    </td>

                    {/* Status Toggle */}
                    <td className="py-3.5 px-4 text-center">
                      <button
                        type="button"
                        onClick={() =>
                          toggleActiveMutation.mutate({
                            id: offer.id,
                            isActive: !offer.isActive,
                          })
                        }
                        className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase transition-colors ${
                          offer.isActive
                            ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30"
                            : "bg-muted text-muted-foreground border border-border"
                        }`}
                        title="Click to toggle active state"
                      >
                        {offer.isActive ? "Active" : "Inactive"}
                      </button>
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleOpenEdit(offer)}
                          className="h-8 w-8 p-0 text-muted-foreground hover:text-royal-violet"
                          title="Edit offer"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setOfferToDelete(offer)}
                          className="h-8 w-8 p-0 text-muted-foreground hover:text-vermilion"
                          title="Delete offer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Offer Modal with Interactive Product Picker */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto p-6">
          <DialogHeader className="pb-3 border-b border-border">
            <DialogTitle className="text-lg font-black tracking-tight text-foreground flex items-center gap-2">
              <Tag className="w-5 h-5 text-royal-violet" />
              <span>{editingOffer ? "Edit Offer & Discount" : "Create Offer & Discount"}</span>
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground">
              Configure offer details and pick products to attach. The backend will automatically apply the calculated discount price.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-6 pt-2">
            {/* 1. Basic Offer Parameters */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-foreground block mb-1">
                  Offer Title <span className="text-vermilion">*</span>
                </label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Summer Clearance Sale"
                  className="h-9 text-xs font-semibold"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-foreground block mb-1">
                  Discount Type <span className="text-vermilion">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setDiscountType("PERCENTAGE")}
                    className={`h-9 px-3 rounded-lg border text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                      discountType === "PERCENTAGE"
                        ? "border-royal-violet bg-royal-violet text-white shadow-xs"
                        : "border-border bg-card text-muted-foreground hover:bg-muted/40"
                    }`}
                  >
                    <Percent className="w-3.5 h-3.5" />
                    <span>Percentage (%)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDiscountType("FIXED")}
                    className={`h-9 px-3 rounded-lg border text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                      discountType === "FIXED"
                        ? "border-royal-violet bg-royal-violet text-white shadow-xs"
                        : "border-border bg-card text-muted-foreground hover:bg-muted/40"
                    }`}
                  >
                    <span>₹ Flat Rupee</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-foreground block mb-1">
                  {discountType === "PERCENTAGE" ? "Discount Percentage (%)" : "Flat Amount (₹)"} <span className="text-vermilion">*</span>
                </label>
                <Input
                  type="number"
                  min={1}
                  max={discountType === "PERCENTAGE" ? 100 : undefined}
                  step="0.01"
                  value={discountValue}
                  onChange={(e) => setDiscountValue(e.target.value)}
                  placeholder={discountType === "PERCENTAGE" ? "20" : "500"}
                  className="h-9 text-xs font-bold"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                  Min Purchase Cart (₹) (Optional)
                </label>
                <Input
                  type="number"
                  min={0}
                  step="1"
                  value={minPurchase}
                  onChange={(e) => setMinPurchase(e.target.value)}
                  placeholder="e.g. 1999"
                  className="h-9 text-xs"
                />
              </div>

              {discountType === "PERCENTAGE" && (
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                    Max Cap (₹) (Optional)
                  </label>
                  <Input
                    type="number"
                    min={0}
                    step="1"
                    value={maxDiscount}
                    onChange={(e) => setMaxDiscount(e.target.value)}
                    placeholder="e.g. 1000"
                    className="h-9 text-xs"
                  />
                </div>
              )}
            </div>

            {/* Schedule & Active */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                  Start Date (Optional)
                </label>
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="h-9 text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                  End Date (Optional)
                </label>
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="h-9 text-xs"
                />
              </div>

              <div className="flex items-center pt-5">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="w-4 h-4 rounded border-border text-royal-violet focus:ring-royal-violet"
                  />
                  <span className="text-xs font-bold text-foreground">
                    Activate Immediately
                  </span>
                </label>
              </div>
            </div>

            {/* 2. Interactive Product Picker */}
            <div className="p-4 rounded-xl border border-royal-violet/30 bg-royal-violet/5 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="text-xs font-black uppercase tracking-wider text-royal-violet flex items-center gap-1.5">
                    <Shirt className="w-4 h-4" />
                    <span>Pick Products to Add to this Offer</span>
                  </span>
                  <p className="text-[11px] text-muted-foreground mt-0.5">
                    Selected products will dynamically show discounted prices calculated by the backend.
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleSelectAllFiltered}
                    className="h-7 text-[11px] font-bold"
                  >
                    Select Filtered ({filteredProducts.length})
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleDeselectAllFiltered}
                    className="h-7 text-[11px] text-muted-foreground hover:text-foreground"
                  >
                    Deselect Filtered
                  </Button>
                </div>
              </div>

              {/* Filters for Product Picker */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search by product name, slug, or SKU..."
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    className="h-8 pl-8 text-xs bg-background"
                  />
                </div>

                <div className="relative">
                  <select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    className="w-full h-8 px-2.5 rounded-lg border border-border bg-background text-xs font-medium focus:outline-none focus:ring-1 focus:ring-royal-violet"
                  >
                    <option value="">All Categories</option>
                    {allCategories.map((c: any) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Products Table with Dynamic Price Preview */}
              <div className="max-h-60 overflow-y-auto rounded-lg border border-border bg-background divide-y divide-border">
                {filteredProducts.length === 0 ? (
                  <div className="p-6 text-center text-xs text-muted-foreground">
                    No products match the search filter.
                  </div>
                ) : (
                  filteredProducts.map((p: any) => {
                    const isSelected = selectedProductIds.includes(p.id);
                    const reg = Number(p.regularPrice) || 0;
                    const val = parseFloat(discountValue) || 0;
                    let previewDiscount = 0;
                    if (discountType === "PERCENTAGE") {
                      previewDiscount = Math.round((reg * Math.min(100, Math.max(0, val))) / 100);
                      if (maxDiscount && previewDiscount > parseFloat(maxDiscount)) {
                        previewDiscount = parseFloat(maxDiscount);
                      }
                    } else {
                      previewDiscount = Math.min(reg, val);
                    }
                    const previewOfferPrice = Math.max(0, reg - previewDiscount);

                    return (
                      <div
                        key={p.id}
                        onClick={() => handleToggleProduct(p.id)}
                        className={`p-2.5 px-3 flex items-center justify-between gap-3 cursor-pointer transition text-xs ${
                          isSelected ? "bg-royal-violet/10 font-semibold" : "hover:bg-muted/30"
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <button
                            type="button"
                            className="text-royal-violet shrink-0"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleProduct(p.id);
                            }}
                          >
                            {isSelected ? (
                              <CheckSquare className="w-4 h-4 fill-royal-violet text-white" />
                            ) : (
                              <Square className="w-4 h-4 text-muted-foreground" />
                            )}
                          </button>

                          {p.images?.[0]?.path ? (
                            <img
                              src={p.images[0].path}
                              alt={p.name}
                              className="w-8 h-10 object-cover rounded border border-border shrink-0"
                            />
                          ) : (
                            <div className="w-8 h-10 bg-muted rounded flex items-center justify-center shrink-0 text-[9px] text-muted-foreground">
                              No Img
                            </div>
                          )}

                          <div className="min-w-0">
                            <span className="font-bold text-foreground truncate block">
                              {p.name}
                            </span>
                            <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                              {p.sku && <span>SKU: {p.sku}</span>}
                              {p.category?.name && <span>&bull; {p.category.name}</span>}
                            </div>
                          </div>
                        </div>

                        {/* Price Preview */}
                        <div className="text-right shrink-0">
                          <div className="flex items-baseline gap-1.5 justify-end">
                            <span className="font-black text-foreground">
                              {formatCurrency(previewOfferPrice)}
                            </span>
                            <span className="text-[10px] text-muted-foreground line-through">
                              {formatCurrency(reg)}
                            </span>
                          </div>
                          <span className="text-[10px] text-vermilion font-bold">
                            Save {formatCurrency(previewDiscount)}
                          </span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Selected Counter Bar */}
              <div className="flex items-center justify-between pt-1 text-xs">
                <span className="font-bold text-royal-violet flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5" />
                  <span>{selectedProductIds.length} Products Selected for this Offer</span>
                </span>
                <span className="text-[11px] text-muted-foreground">
                  Click on any row to toggle
                </span>
              </div>
            </div>

            {/* Dialog Footer Actions */}
            <div className="flex items-center justify-end gap-2 pt-3 border-t border-border">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleCloseModal}
                className="h-9 text-xs"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                size="sm"
                disabled={saveMutation.isPending}
                className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold text-xs h-9 px-5"
              >
                {saveMutation.isPending ? "Saving Offer..." : editingOffer ? "Update Offer" : "Create Offer & Apply"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Offer Confirmation Modal */}
      <ConfirmModal
        open={!!offerToDelete}
        onOpenChange={(open) => !open && setOfferToDelete(null)}
        title="Delete Promotional Offer?"
        description={`Are you sure you want to delete the offer "${offerToDelete?.name}"? Any active discounts associated with this campaign will be removed.`}
        confirmLabel="Delete Offer"
        cancelLabel="Cancel"
        variant="destructive"
        isLoading={deleteMutation.isPending}
        onConfirm={() => {
          if (offerToDelete) {
            deleteMutation.mutate(offerToDelete.id);
            setOfferToDelete(null);
          }
        }}
      />
    </div>
  );
}


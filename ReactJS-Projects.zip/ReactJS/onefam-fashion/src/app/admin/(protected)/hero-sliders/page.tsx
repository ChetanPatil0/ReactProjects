"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { HeroSlideBuilderModal } from "@/components/admin/hero-slide-builder-modal";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Plus,
  Trash2,
  AlertTriangle,
  Pencil,
  Sparkles,
  Sliders,
  CheckCircle2,
  XCircle,
  CodeXml,
  Eye,
  EyeOff,
  MoveUp,
  MoveDown,
} from "lucide-react";
import { toast } from "sonner";
import { formatDate } from "@/lib/formatters";

export default function AdminHeroSlidersPage() {
  const queryClient = useQueryClient();

  // Builder Modal State (used for both creation & editing)
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);
  const [editingSlide, setEditingSlide] = useState<any | null>(null);

  // Delete modal state
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [slideToDelete, setSlideToDelete] = useState<any>(null);

  const { data: slides = [], isLoading } = useQuery({
    queryKey: queryKeys.heroSlides.all,
    queryFn: () => apiClient.get("/hero-slides"),
  });

  const createMutation = useMutation({
    mutationFn: (body: any) => apiClient.post("/hero-slides", body),
    onSuccess: () => {
      toast.success("Hero slide created & published successfully");
      queryClient.invalidateQueries({ queryKey: queryKeys.heroSlides.all });
    },
    onError: (err: any) => toast.error(err.message || "Failed to create slide"),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) =>
      apiClient.patch(`/hero-slides/${id}`, data),
    onSuccess: () => {
      toast.success("Hero slide updated successfully");
      queryClient.invalidateQueries({ queryKey: queryKeys.heroSlides.all });
    },
    onError: (err: any) => toast.error(err.message || "Failed to update slide"),
  });

  // Direct active / inactive instant toggle mutation
  const toggleStatusMutation = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) =>
      apiClient.patch(`/hero-slides/${id}`, { isActive }),
    onSuccess: (_, variables) => {
      toast.success(
        variables.isActive
          ? "Slide is now Active & visible on the storefront"
          : "Slide is now Inactive & hidden from the storefront"
      );
      queryClient.invalidateQueries({ queryKey: queryKeys.heroSlides.all });
    },
    onError: (err: any) => toast.error(err.message || "Failed to update slide status"),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiClient.delete(`/hero-slides/${id}`),
    onSuccess: () => {
      toast.success("Slide deleted successfully");
      setDeleteModalOpen(false);
      setSlideToDelete(null);
      queryClient.invalidateQueries({ queryKey: queryKeys.heroSlides.all });
    },
    onError: (err: any) => toast.error(err.message || "Failed to delete slide"),
  });

  const handleOpenCreate = () => {
    setEditingSlide(null);
    setIsBuilderOpen(true);
  };

  const handleOpenEdit = (slide: any) => {
    setEditingSlide(slide);
    setIsBuilderOpen(true);
  };

  const handleSaveSlide = async (slideData: any) => {
    if (editingSlide?.id) {
      await updateMutation.mutateAsync({
        id: editingSlide.id,
        data: slideData,
      });
    } else {
      await createMutation.mutateAsync(slideData);
    }
  };

  const activeSlidesCount = slides.filter((s: any) => s.isActive).length;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-ink dark:text-foreground flex items-center gap-2">
            <Sliders className="w-6 h-6 text-royal-violet" />
            Homepage Hero Sliders
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Manage slide rotation order, active/inactive visibility, and custom HTML/CSS overlays for storefront banners.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-card border border-border text-xs">
            <span className="text-muted-foreground">Active Slides:</span>
            <span className="font-extrabold text-royal-violet">
              {activeSlidesCount} / {slides.length}
            </span>
          </div>

          <Button
            onClick={handleOpenCreate}
            size="sm"
            className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl text-xs shadow-md"
          >
            <Plus className="w-4 h-4 mr-1.5" />
            Create New Slide
          </Button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SLIDES DATA TABLE */}
      {/* ========================================================================= */}
      <div className="bg-card rounded-2xl border border-border shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-border bg-muted/40 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                <th className="py-3.5 px-4 text-center w-16">Order</th>
                <th className="py-3.5 px-4 w-36">Image</th>
                <th className="py-3.5 px-4">Slide Reference</th>
                <th className="py-3.5 px-4">Overlay Design</th>
                <th className="py-3.5 px-4 text-center w-36">Status</th>
                <th className="py-3.5 px-4 text-right w-44">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border text-xs">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-muted-foreground">
                    Loading hero slides...
                  </td>
                </tr>
              ) : slides.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-16 text-center">
                    <div className="w-12 h-12 rounded-full bg-violet-50 dark:bg-royal-violet/10 text-royal-violet flex items-center justify-center mx-auto mb-3">
                      <Sparkles className="w-6 h-6" />
                    </div>
                    <h3 className="font-bold text-sm text-foreground">No Hero Slides Configured</h3>
                    <p className="text-xs text-muted-foreground mt-1 max-w-sm mx-auto">
                      Create your first full-bleed hero banner with a background photo and custom HTML/CSS overlay.
                    </p>
                    <Button
                      onClick={handleOpenCreate}
                      size="sm"
                      className="mt-4 bg-royal-violet hover:bg-royal-violet/90 text-white font-bold text-xs rounded-xl shadow-md"
                    >
                      <Plus className="w-4 h-4 mr-1.5" />
                      Create First Slide
                    </Button>
                  </td>
                </tr>
              ) : (
                slides.map((slide: any, idx: number) => {
                  const hasHtml = Boolean(slide.description && slide.description.includes("<"));

                  return (
                    <tr
                      key={slide.id}
                      className="hover:bg-muted/30 transition-colors group"
                    >
                      {/* Sort Order */}
                      <td className="py-3.5 px-4 text-center">
                        <span className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-muted text-foreground font-black text-xs border border-border">
                          {slide.sortOrder ?? idx + 1}
                        </span>
                      </td>

                      {/* Image Thumbnail */}
                      <td className="py-3.5 px-4">
                        <div
                          onClick={() => handleOpenEdit(slide)}
                          className="relative w-28 aspect-[16/9] rounded-lg overflow-hidden bg-ink border border-border/80 shadow-2xs group-hover:border-royal-violet/60 transition-all cursor-pointer"
                          title="Click to edit & preview"
                        >
                          <img
                            src={slide.desktopImage}
                            alt={slide.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors" />
                        </div>
                      </td>

                      {/* Slide Reference / Title */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-0.5">
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(slide)}
                            className="font-bold text-sm text-foreground hover:text-royal-violet text-left transition-colors flex items-center gap-1.5"
                          >
                            <span>{slide.title}</span>
                          </button>
                          <div className="text-[11px] text-muted-foreground flex items-center gap-2">
                            <span>Slide #{idx + 1}</span>
                            <span>•</span>
                            <span>Added {formatDate(slide.createdAt)}</span>
                          </div>
                        </div>
                      </td>

                      {/* Overlay Design Type */}
                      <td className="py-3.5 px-4">
                        <div className="flex flex-col gap-1 items-start">
                          <Badge
                            variant="outline"
                            className="text-[10px] font-mono py-0.5 gap-1 text-royal-violet border-royal-violet/30 bg-royal-violet/5"
                          >
                            <CodeXml className="w-3 h-3 text-royal-violet" />
                            <span>Raw HTML &amp; CSS</span>
                          </Badge>
                          <span className="text-[11px] text-muted-foreground line-clamp-1 max-w-[260px]">
                            {slide.description
                              ? slide.description.replace(/<[^>]*>?/gm, "").slice(0, 45) + "..."
                              : "No overlay content"}
                          </span>
                        </div>
                      </td>

                      {/* Active / Inactive Toggle Switch */}
                      <td className="py-3.5 px-4 text-center">
                        <button
                          type="button"
                          onClick={() =>
                            toggleStatusMutation.mutate({
                              id: slide.id,
                              isActive: !slide.isActive,
                            })
                          }
                          disabled={toggleStatusMutation.isPending}
                          title={
                            slide.isActive
                              ? "Click to deactivate and hide from storefront"
                              : "Click to activate and show on storefront"
                          }
                          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all shadow-2xs border ${
                            slide.isActive
                              ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/25"
                              : "bg-muted text-muted-foreground border-border hover:bg-muted/80"
                          }`}
                        >
                          <span
                            className={`w-2 h-2 rounded-full ${
                              slide.isActive ? "bg-emerald-500 animate-pulse" : "bg-zinc-400"
                            }`}
                          />
                          <span>{slide.isActive ? "Active" : "Inactive"}</span>
                        </button>
                      </td>

                      {/* Row Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Edit & Preview Button */}
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => handleOpenEdit(slide)}
                            className="h-8 px-2.5 text-xs font-semibold rounded-lg flex items-center gap-1 hover:border-royal-violet hover:text-royal-violet"
                            title="Edit code & preview on devices"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                            <span>Edit</span>
                          </Button>

                          {/* Instant Status Switch Icon */}
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() =>
                              toggleStatusMutation.mutate({
                                id: slide.id,
                                isActive: !slide.isActive,
                              })
                            }
                            className={`h-8 w-8 p-0 rounded-lg ${
                              slide.isActive
                                ? "text-muted-foreground hover:text-amber-600 hover:bg-amber-500/10"
                                : "text-muted-foreground hover:text-emerald-600 hover:bg-emerald-500/10"
                            }`}
                            title={slide.isActive ? "Pause / Hide slide" : "Activate slide"}
                          >
                            {slide.isActive ? (
                              <EyeOff className="w-4 h-4" />
                            ) : (
                              <Eye className="w-4 h-4" />
                            )}
                          </Button>

                          {/* Delete Button */}
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSlideToDelete(slide);
                              setDeleteModalOpen(true);
                            }}
                            className="h-8 w-8 p-0 rounded-lg text-muted-foreground hover:text-vermilion hover:bg-rose-500/10"
                            title="Delete slide"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* DEDICATED SLIDE BUILDER & LIVE PREVIEW MODAL */}
      <HeroSlideBuilderModal
        open={isBuilderOpen}
        onOpenChange={setIsBuilderOpen}
        slide={editingSlide}
        onSave={handleSaveSlide}
      />

      {/* Delete Confirmation Modal */}
      <Dialog open={deleteModalOpen} onOpenChange={setDeleteModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="w-10 h-10 rounded-full bg-rose-50 dark:bg-rose-950/40 text-vermilion flex items-center justify-center mb-2">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <DialogTitle className="text-lg font-black text-ink dark:text-foreground">
              Delete Hero Slide?
            </DialogTitle>
            <DialogDescription className="text-xs">
              Are you sure you want to remove &ldquo;{slideToDelete?.title}&rdquo; from the hero rotation? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>

          <DialogFooter className="pt-2 gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setDeleteModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => slideToDelete && deleteMutation.mutate(slideToDelete.id)}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete Slide"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

"use client";

import { useState, useMemo, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ImageUploader, uploadImageFile } from "@/components/shared/image-uploader";
import { DEFAULT_SLIDE_HTML } from "@/components/admin/hero-slide-builder-modal";
import {
  ArrowLeft,
  Sparkles,
  Eye,
  Smartphone,
  Tablet,
  Monitor,
  Loader2,
  Check,
  AlertCircle,
  CodeXml,
  RotateCcw,
  Copy,
} from "lucide-react";
import { toast } from "sonner";

export default function DedicatedSlideBuilderPage() {
  const router = useRouter();
  const queryClient = useQueryClient();

  // Simple Form State: Reference Name, Image, Pure HTML Content
  const [title, setTitle] = useState("Summer Linen & Resort Atelier");
  const [sortOrder, setSortOrder] = useState<number>(1);
  const [htmlContent, setHtmlContent] = useState(DEFAULT_SLIDE_HTML);
  const [desktopImage, setDesktopImage] = useState(
    "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=1600&auto=format&fit=crop"
  );
  const [desktopImageFile, setDesktopImageFile] = useState<File | null>(null);
  const [isActive, setIsActive] = useState(true);

  // Bottom Preview Viewport State: Desktop, Tablet, Mobile
  const [previewDevice, setPreviewDevice] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Local object URL for staged file preview
  const previewImageUrl = useMemo(() => {
    if (desktopImageFile) {
      return URL.createObjectURL(desktopImageFile);
    }
    return desktopImage;
  }, [desktopImageFile, desktopImage]);

  useEffect(() => {
    return () => {
      if (desktopImageFile && previewImageUrl.startsWith("blob:")) {
        URL.revokeObjectURL(previewImageUrl);
      }
    };
  }, [desktopImageFile, previewImageUrl]);

  const createMutation = useMutation({
    mutationFn: (body: any) => apiClient.post("/hero-slides", body),
    onSuccess: () => {
      toast.success("Hero slide successfully created and published!");
      queryClient.invalidateQueries({ queryKey: queryKeys.heroSlides.all });
      router.push("/admin/hero-sliders");
    },
    onError: (err: any) => toast.error(err.message || "Failed to create slide"),
  });

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!title.trim()) errs.title = "Slide reference name is required.";
    if (!desktopImage.trim() && !desktopImageFile) {
      errs.desktopImage = "Background hero photograph is required.";
    }
    if (!htmlContent.trim()) {
      errs.htmlContent = "HTML content is required to render the slide.";
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      toast.error("Please provide a slide name, background image, and HTML content.");
      return;
    }

    setIsSubmitting(true);
    try {
      let finalImage = desktopImage;

      // Staged file upload through our system
      if (desktopImageFile) {
        const uploadRes = await uploadImageFile(desktopImageFile);
        finalImage = uploadRes.url;
      }

      await createMutation.mutateAsync({
        title: title.trim(),
        description: htmlContent.trim(), // Storing pure HTML code
        desktopImage: finalImage.trim(),
        mobileImage: finalImage.trim(),
        sortOrder: Number(sortOrder) || 1,
        isActive,
      });
    } catch (err: any) {
      toast.error(err.message || "Failed to publish hero slide");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetToDefaultTemplate = () => {
    setHtmlContent(DEFAULT_SLIDE_HTML);
    toast.success("Loaded default reference HTML template");
  };

  const handleInsertSnippet = (snippet: string, label: string) => {
    setHtmlContent((prev) => `${prev.trim()}\n\n${snippet}`);
    toast.success(`Inserted ${label}`);
  };

  const handleCopyCode = () => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(htmlContent);
      toast.success("HTML code copied to clipboard");
    }
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-24">
      {/* Top Navigation Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border">
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" asChild className="h-9 px-3 rounded-xl">
            <Link href="/admin/hero-sliders" className="flex items-center gap-1.5 text-xs">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Hero Sliders Table</span>
            </Link>
          </Button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-foreground flex items-center gap-2">
                <CodeXml className="w-6 h-6 text-royal-violet" />
                HTML Slide Studio
              </h1>
              <Badge variant="accent" className="text-[10px] uppercase font-bold tracking-wider">
                Pure HTML Overlay
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">
              Upload your background photo and design with raw HTML/CSS &amp; SVG icons. Live preview rendered below.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleResetToDefaultTemplate}
            className="h-9 text-xs font-semibold rounded-xl flex items-center gap-1.5 hover:border-royal-violet hover:text-royal-violet"
          >
            <RotateCcw className="w-3.5 h-3.5 text-royal-violet" />
            <span>Default Template</span>
          </Button>

          <Button
            type="submit"
            form="html-slide-builder-form"
            disabled={isSubmitting}
            className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold text-xs rounded-xl shadow-md h-9 px-4"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                <span>Publishing...</span>
              </>
            ) : (
              <>
                <Check className="w-3.5 h-3.5 mr-1.5" />
                <span>Publish Slide</span>
              </>
            )}
          </Button>
        </div>
      </div>

      {/* TOP SECTION: Form Controls & HTML Code Editor */}
      <form
        id="html-slide-builder-form"
        onSubmit={handlePublish}
        className="bg-card rounded-2xl border border-border shadow-2xs p-6 sm:p-8 space-y-6"
      >
        {/* Row 1: Name, Sort Order, Active Status */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="sm:col-span-2">
            <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
              Slide Reference Name <span className="text-vermilion">*</span>
            </label>
            <Input
              placeholder="e.g. Summer Linen Campaign 2026"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                if (e.target.value.trim()) {
                  setErrors((prev) => {
                    const c = { ...prev };
                    delete c.title;
                    return c;
                  });
                }
              }}
              className={`h-10 text-xs font-semibold ${errors.title ? "border-vermilion" : ""}`}
            />
            {errors.title && (
              <p className="text-[11px] text-vermilion font-medium mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {errors.title}
              </p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Sort Order
              </label>
              <Input
                type="number"
                min={1}
                value={sortOrder}
                onChange={(e) => setSortOrder(Number(e.target.value) || 1)}
                className="h-10 text-xs font-semibold text-center"
              />
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Status
              </label>
              <Button
                type="button"
                variant={isActive ? "default" : "outline"}
                size="sm"
                onClick={() => setIsActive(!isActive)}
                className={`w-full h-10 text-xs font-bold rounded-md ${
                  isActive
                    ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                    : "text-muted-foreground"
                }`}
              >
                {isActive ? "Active" : "Hidden"}
              </Button>
            </div>
          </div>
        </div>

        {/* Row 2: Background Hero Image (Uploaded through our system) */}
        <div className="p-4 rounded-xl border border-border bg-muted/15 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-foreground">
              Background Hero Photo <span className="text-vermilion">*</span>
            </span>
            <span className="text-[11px] text-muted-foreground">
              Staged upload · 16:9 ratio recommended
            </span>
          </div>

          <ImageUploader
            value={desktopImage}
            onChange={setDesktopImage}
            onFileSelect={setDesktopImageFile}
            label="Background Image File"
            required={true}
          />
          {errors.desktopImage && (
            <p className="text-[11px] text-vermilion font-medium mt-1 flex items-center gap-1">
              <AlertCircle className="w-3 h-3" />
              {errors.desktopImage}
            </p>
          )}
        </div>

        {/* Row 3: Pure HTML & CSS Code Editor */}
        <div className="space-y-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
              <CodeXml className="w-4 h-4 text-royal-violet" />
              <span>Slide HTML &amp; CSS Markup</span>
            </label>

            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] text-muted-foreground mr-1">Insert Helper:</span>
              <button
                type="button"
                onClick={() =>
                  handleInsertSnippet(
                    `<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold uppercase bg-[#191720]/80 text-[#C6F542] border border-[#C6F542]/30">\n  ★ Highlight Badge\n</span>`,
                    "Lime Badge"
                  )
                }
                className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-muted hover:bg-muted/80 text-foreground border border-border"
              >
                + Lime Badge
              </button>
              <button
                type="button"
                onClick={() =>
                  handleInsertSnippet(
                    `<a href="/men" class="inline-flex items-center gap-2 px-7 py-3 rounded-full bg-[#7137C8] hover:bg-[#7137C8]/90 text-white font-bold text-xs shadow-md transition">\n  Shop Now →\n</a>`,
                    "Violet Button"
                  )
                }
                className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-muted hover:bg-muted/80 text-foreground border border-border"
              >
                + CTA Button
              </button>
              <button
                type="button"
                onClick={() =>
                  handleInsertSnippet(
                    `<svg class="w-4 h-4 text-[#C6F542]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>`,
                    "SVG Star Icon"
                  )
                }
                className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-muted hover:bg-muted/80 text-foreground border border-border"
              >
                + SVG Icon
              </button>
              <button
                type="button"
                onClick={handleCopyCode}
                className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-muted hover:bg-muted/80 text-foreground border border-border flex items-center gap-1"
              >
                <Copy className="w-3 h-3" />
                <span>Copy</span>
              </button>
            </div>
          </div>

          <div className="rounded-xl border border-border overflow-hidden shadow-2xs">
            <div className="bg-[#191720] px-4 py-2 border-b border-border/40 flex items-center justify-between text-[11px] text-[#FCFAF4]/70 font-mono">
              <span className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#7137C8]" />
                <span>slide-overlay.html</span>
              </span>
              <span>Full control over markup, SVG icons &amp; typography</span>
            </div>
            <textarea
              rows={11}
              value={htmlContent}
              onChange={(e) => {
                setHtmlContent(e.target.value);
                if (e.target.value.trim()) {
                  setErrors((prev) => {
                    const c = { ...prev };
                    delete c.htmlContent;
                    return c;
                  });
                }
              }}
              placeholder="Enter HTML markup here..."
              className="w-full p-4 font-mono text-xs sm:text-sm leading-relaxed bg-[#121118] text-[#E6E1E5] focus:outline-none resize-y border-0 selection:bg-royal-violet selection:text-white"
            />
          </div>
          {errors.htmlContent && (
            <p className="text-[11px] text-vermilion font-medium mt-1 flex items-center gap-1">
              <AlertCircle className="w-3 h-3" />
              {errors.htmlContent}
            </p>
          )}
        </div>
      </form>

      {/* ========================================================================= */}
      {/* BOTTOM SECTION: LIVE STOREFRONT PREVIEW (DESKTOP / TABLET / MOBILE) */}
      {/* ========================================================================= */}
      <div className="bg-card rounded-2xl border border-border shadow-2xs p-6 sm:p-8 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-black text-foreground flex items-center gap-2">
              <Eye className="w-5 h-5 text-royal-violet" />
              <span>Live Storefront Preview (Bottom Preview)</span>
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Live responsive canvas showing your uploaded background photo and rendered HTML overlay.
            </p>
          </div>

          {/* Viewport Switcher Tabs */}
          <div className="flex items-center p-1 rounded-xl bg-muted border border-border self-start sm:self-auto">
            <button
              type="button"
              onClick={() => setPreviewDevice("desktop")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                previewDevice === "desktop"
                  ? "bg-card text-foreground shadow-xs border border-border/80"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Monitor className="w-3.5 h-3.5 text-royal-violet" />
              <span>Desktop (16:9)</span>
            </button>

            <button
              type="button"
              onClick={() => setPreviewDevice("tablet")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                previewDevice === "tablet"
                  ? "bg-card text-foreground shadow-xs border border-border/80"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Tablet className="w-3.5 h-3.5 text-royal-violet" />
              <span>Tablet (4:3)</span>
            </button>

            <button
              type="button"
              onClick={() => setPreviewDevice("mobile")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                previewDevice === "mobile"
                  ? "bg-card text-foreground shadow-xs border border-border/80"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 text-royal-violet" />
              <span>Mobile (9:16)</span>
            </button>
          </div>
        </div>

        {/* The Live Interactive Hero Slide Canvas */}
        <div className="flex justify-center bg-[#0B0A0F] p-4 sm:p-8 rounded-2xl border border-border/80 overflow-hidden shadow-inner">
          <div
            className={`relative overflow-hidden rounded-2xl shadow-2xl transition-all duration-300 border border-white/10 ${
              previewDevice === "desktop"
                ? "w-full aspect-[16/9] min-h-[380px] max-h-[520px]"
                : previewDevice === "tablet"
                ? "w-full max-w-[640px] aspect-[4/3] min-h-[440px]"
                : "w-[340px] aspect-[9/16] min-h-[540px]"
            }`}
            style={{ backgroundColor: "#15131C" }}
          >
            {/* Background Hero Image Asset */}
            {previewImageUrl ? (
              <img
                src={previewImageUrl}
                alt={title || "Slide Preview"}
                className="absolute inset-0 w-full h-full object-cover"
              />
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white/40 text-xs gap-2 p-6 text-center">
                <Sparkles className="w-8 h-8 text-royal-violet/50" />
                <span>Upload a background hero photo above to view the full composition</span>
              </div>
            )}

            {/* Dark Vignette Overlay Matching Storefront */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#15131C]/95 via-[#15131C]/65 to-transparent pointer-events-none" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#15131C]/80 via-transparent to-transparent pointer-events-none" />

            {/* Rendered Custom HTML Overlay */}
            <div className="relative h-full p-6 sm:p-10 md:p-12 flex flex-col justify-center text-[#FCFAF4] max-w-2xl overflow-y-auto">
              {htmlContent ? (
                <div
                  className="hero-html-preview leading-normal"
                  dangerouslySetInnerHTML={{ __html: htmlContent }}
                />
              ) : (
                <p className="text-white/40 text-xs italic">
                  Type HTML markup in the editor above to view the live preview...
                </p>
              )}
            </div>

            {/* Viewport Dimension Indicator Badge */}
            <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded-full bg-black/75 backdrop-blur-md text-[10px] font-mono text-white/70 border border-white/10 pointer-events-none">
              {previewDevice === "desktop"
                ? "Desktop 16:9 Canvas"
                : previewDevice === "tablet"
                ? "Tablet 4:3 Viewport"
                : "Mobile 9:16 Portrait"}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

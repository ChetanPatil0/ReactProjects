"use client";

import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { ImageUploader, uploadImageFile } from "@/components/shared/image-uploader";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import {
  Plus,
  FolderTree,
  CornerDownRight,
  MoreHorizontal,
  PackagePlus,
  Trash2,
  AlertTriangle,
  Check,
  Search,
  Pencil,
  GripVertical,
  ChevronUp,
  ChevronDown,
} from "lucide-react";
import { toast } from "sonner";

export default function AdminCategoriesPage() {
  const queryClient = useQueryClient();

  // Create Category Modal State
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [description, setDescription] = useState("");
  const [parentId, setParentId] = useState<string>("");
  const [imagePath, setImagePath] = useState("");
  const [isActive, setIsActive] = useState(true);
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  // Validation Errors state
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Edit Category Modal State
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<any>(null);
  const [editName, setEditName] = useState("");
  const [editSlug, setEditSlug] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editParentId, setEditParentId] = useState<string>("");
  const [editImagePath, setEditImagePath] = useState("");
  const [editIsActive, setEditIsActive] = useState(true);
  const [editImageFile, setEditImageFile] = useState<File | null>(null);
  const [editIsUploadingImage, setEditIsUploadingImage] = useState(false);
  const [editErrors, setEditErrors] = useState<{ [key: string]: string }>({});

  // Product Assignment Modal State
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [selectedCategoryForProducts, setSelectedCategoryForProducts] = useState<any>(null);
  const [allProducts, setAllProducts] = useState<any[]>([]);
  const [assignedProductIds, setAssignedProductIds] = useState<string[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(false);
  const [productSearch, setProductSearch] = useState("");

  // Delete Confirmation Modal State
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState<any>(null);

  // Drag and drop & ordering state
  const [orderedCategories, setOrderedCategories] = useState<any[]>([]);
  const [draggedCatId, setDraggedCatId] = useState<string | null>(null);
  const [dragOverCatId, setDragOverCatId] = useState<string | null>(null);

  const { data: categories = [], isLoading } = useQuery({
    queryKey: queryKeys.categories.all,
    queryFn: () => apiClient.get("/categories"),
  });

  useEffect(() => {
    if (categories && Array.isArray(categories)) {
      setOrderedCategories(categories);
    }
  }, [categories]);

  const toggleActiveMutation = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) =>
      apiClient.patch(`/categories/${id}`, { isActive }),
    onSuccess: () => {
      toast.success("Category status updated");
      queryClient.invalidateQueries({ queryKey: queryKeys.categories.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const reorderMutation = useMutation({
    mutationFn: (items: Array<{ id: string; displayOrder: number }>) =>
      apiClient.post("/categories/reorder", { items }),
    onSuccess: () => {
      toast.success("Category order saved successfully");
      queryClient.invalidateQueries({ queryKey: queryKeys.categories.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const createMutation = useMutation({
    mutationFn: (body: any) => apiClient.post("/categories", body),
    onSuccess: () => {
      toast.success("Category created successfully");
      setIsAddOpen(false);
      resetAddForm();
      queryClient.invalidateQueries({ queryKey: queryKeys.categories.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: any }) =>
      apiClient.patch(`/categories/${id}`, payload),
    onSuccess: () => {
      toast.success("Category updated successfully");
      setIsEditOpen(false);
      setEditingCategory(null);
      queryClient.invalidateQueries({ queryKey: queryKeys.categories.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiClient.delete(`/categories/${id}`),
    onSuccess: () => {
      toast.success("Category deleted successfully");
      setDeleteModalOpen(false);
      setCategoryToDelete(null);
      queryClient.invalidateQueries({ queryKey: queryKeys.categories.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const saveProductsMutation = useMutation({
    mutationFn: ({ id, productIds }: { id: string; productIds: string[] }) =>
      apiClient.post(`/categories/${id}/products`, { productIds }),
    onSuccess: (res: any) => {
      toast.success(res?.message || "Assigned products updated!");
      setAssignModalOpen(false);
      setSelectedCategoryForProducts(null);
      queryClient.invalidateQueries({ queryKey: queryKeys.categories.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const resetAddForm = () => {
    setName("");
    setSlug("");
    setDescription("");
    setParentId("");
    setImagePath("");
    setIsActive(true);
    setSelectedImageFile(null);
    setIsUploadingImage(false);
    setErrors({});
  };

  const handleNameChange = (val: string) => {
    setName(val);
    const generatedSlug = val
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)+/g, "");
    setSlug(generatedSlug);

    if (!val.trim()) {
      setErrors((prev) => ({ ...prev, name: "Category name is required" }));
    } else {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy.name;
        delete copy.slug;
        return copy;
      });
    }
  };

  const handleSlugBlur = () => {
    if (!slug.trim()) {
      setErrors((prev) => ({ ...prev, slug: "Slug is required" }));
    } else {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy.slug;
        return copy;
      });
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { [key: string]: string } = {};
    if (!name.trim()) newErrors.name = "Category name is required";
    if (!slug.trim()) newErrors.slug = "URL slug is required";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    let finalImagePath = imagePath;
    if (selectedImageFile) {
      setIsUploadingImage(true);
      try {
        const uploadResult = await uploadImageFile(selectedImageFile);
        finalImagePath = uploadResult.url;
      } catch (err: any) {
        setIsUploadingImage(false);
        toast.error(err.message || "Failed to upload category image");
        return;
      }
      setIsUploadingImage(false);
    }

    createMutation.mutate({
      name: name.trim(),
      slug: slug.trim(),
      description: description.trim() || null,
      parentId: parentId || null,
      imagePath: finalImagePath || null,
      isActive,
    });
  };

  // Open Edit Modal with prefilled category data
  const handleOpenEdit = (cat: any) => {
    setEditingCategory(cat);
    setEditName(cat.name || "");
    setEditSlug(cat.slug || "");
    setEditDescription(cat.description || "");
    setEditParentId(cat.parentId || "");
    setEditImagePath(cat.imagePath || "");
    setEditIsActive(cat.isActive !== false);
    setEditImageFile(null);
    setEditErrors({});
    setIsEditOpen(true);
  };

  const handleUpdateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory) return;

    const newErrors: { [key: string]: string } = {};
    if (!editName.trim()) newErrors.name = "Category name is required";
    if (!editSlug.trim()) newErrors.slug = "URL slug is required";

    if (Object.keys(newErrors).length > 0) {
      setEditErrors(newErrors);
      return;
    }

    let finalImagePath = editImagePath;
    if (editImageFile) {
      setEditIsUploadingImage(true);
      try {
        const uploadResult = await uploadImageFile(editImageFile);
        finalImagePath = uploadResult.url;
      } catch (err: any) {
        setEditIsUploadingImage(false);
        toast.error(err.message || "Failed to upload category image");
        return;
      }
      setEditIsUploadingImage(false);
    }

    updateMutation.mutate({
      id: editingCategory.id,
      payload: {
        name: editName.trim(),
        slug: editSlug.trim(),
        description: editDescription.trim() || null,
        parentId: editParentId || null,
        imagePath: finalImagePath || null,
        isActive: editIsActive,
      },
    });
  };

  // Drag and drop & manual move handlers
  const handleDragStart = (id: string) => {
    setDraggedCatId(id);
  };

  const handleDragOver = (e: React.DragEvent, id: string) => {
    e.preventDefault();
    if (dragOverCatId !== id) {
      setDragOverCatId(id);
    }
  };

  const handleDrop = (targetId: string) => {
    if (!draggedCatId || draggedCatId === targetId) {
      setDraggedCatId(null);
      setDragOverCatId(null);
      return;
    }

    const fromIndex = orderedCategories.findIndex((c) => c.id === draggedCatId);
    const toIndex = orderedCategories.findIndex((c) => c.id === targetId);

    if (fromIndex !== -1 && toIndex !== -1) {
      const newItems = [...orderedCategories];
      const [moved] = newItems.splice(fromIndex, 1);
      newItems.splice(toIndex, 0, moved);
      setOrderedCategories(newItems);

      const payload = newItems.map((c, idx) => ({
        id: c.id,
        displayOrder: idx + 1,
      }));
      reorderMutation.mutate(payload);
    }

    setDraggedCatId(null);
    setDragOverCatId(null);
  };

  const handleMove = (index: number, direction: "up" | "down") => {
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= orderedCategories.length) return;

    const newItems = [...orderedCategories];
    const [moved] = newItems.splice(index, 1);
    newItems.splice(targetIndex, 0, moved);
    setOrderedCategories(newItems);

    const payload = newItems.map((c, idx) => ({
      id: c.id,
      displayOrder: idx + 1,
    }));
    reorderMutation.mutate(payload);
  };

  const handleMoveSub = (parentId: string, subIndex: number, direction: "up" | "down") => {
    const parent = orderedCategories.find((c) => c.id === parentId);
    if (!parent || !parent.children) return;

    const targetSubIndex = direction === "up" ? subIndex - 1 : subIndex + 1;
    if (targetSubIndex < 0 || targetSubIndex >= parent.children.length) return;

    const newChildren = [...parent.children];
    const [moved] = newChildren.splice(subIndex, 1);
    newChildren.splice(targetSubIndex, 0, moved);

    const newCategories = orderedCategories.map((c) =>
      c.id === parentId ? { ...c, children: newChildren } : c
    );
    setOrderedCategories(newCategories);

    const payload = newChildren.map((sub, idx) => ({
      id: sub.id,
      displayOrder: idx + 1,
    }));
    reorderMutation.mutate(payload);
  };

  // Open Manage Products Modal
  const handleOpenAssignModal = async (cat: any) => {
    setSelectedCategoryForProducts(cat);
    setLoadingProducts(true);
    setAssignModalOpen(true);
    try {
      const data = await apiClient.get(`/categories/${cat.id}/products`);
      setAllProducts(data.allProducts || []);
      setAssignedProductIds(data.assignedProductIds || []);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoadingProducts(false);
    }
  };

  const toggleProductAssignment = (productId: string) => {
    setAssignedProductIds((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  const handleSaveAssignedProducts = () => {
    if (!selectedCategoryForProducts) return;
    saveProductsMutation.mutate({
      id: selectedCategoryForProducts.id,
      productIds: assignedProductIds,
    });
  };

  const filteredProducts = allProducts.filter((p) =>
    p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
    (p.sku && p.sku.toLowerCase().includes(productSearch.toLowerCase()))
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-ink">
            Category Taxonomy &amp; Catalog Hierarchy
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Organize main departments, unlimited nested subcategories, and associate products directly.
          </p>
        </div>

        <Button
          onClick={() => {
            resetAddForm();
            setIsAddOpen(true);
          }}
          size="sm"
          className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl text-xs"
        >
          <Plus className="w-4 h-4 mr-1.5" />
          Add Category
        </Button>
      </div>

      {/* Categories Table with Actions Dropdown */}
      <div className="bg-white rounded-2xl border border-border shadow-2xs overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-20">Order</TableHead>
              <TableHead>Category Hierarchy</TableHead>
              <TableHead>Slug</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Assigned Products</TableHead>
              <TableHead className="w-36">Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-xs text-muted-foreground">
                  Loading categories...
                </TableCell>
              </TableRow>
            ) : orderedCategories.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-xs text-muted-foreground">
                  No categories found. Click "Add Category" to create one.
                </TableCell>
              </TableRow>
            ) : (
              orderedCategories.map((cat: any, idx: number) => {
                const isDragTarget = dragOverCatId === cat.id && draggedCatId !== cat.id;
                return (
                  <div key={cat.id} className="contents">
                    {/* Top-Level Category Row */}
                    <TableRow
                      draggable
                      onDragStart={() => handleDragStart(cat.id)}
                      onDragOver={(e) => handleDragOver(e, cat.id)}
                      onDrop={() => handleDrop(cat.id)}
                      onDragEnd={() => {
                        setDraggedCatId(null);
                        setDragOverCatId(null);
                      }}
                      className={`bg-muted/15 font-semibold transition-colors duration-150 ${
                        isDragTarget
                          ? "border-t-2 border-royal-violet bg-royal-violet/10"
                          : ""
                      } ${draggedCatId === cat.id ? "opacity-50" : ""}`}
                    >
                      {/* Drag handle & Order Controls */}
                      <TableCell>
                        <div className="flex items-center gap-1.5 select-none">
                          <button
                            type="button"
                            className="cursor-grab active:cursor-grabbing p-1 text-muted-foreground hover:text-royal-violet rounded transition-colors"
                            title="Drag to change position"
                          >
                            <GripVertical className="w-4 h-4" />
                          </button>
                          <span className="font-mono text-[11px] font-bold text-muted-foreground">
                            #{idx + 1}
                          </span>
                          <div className="flex flex-col">
                            <button
                              type="button"
                              onClick={() => handleMove(idx, "up")}
                              disabled={idx === 0}
                              className="p-0.5 text-muted-foreground hover:text-royal-violet disabled:opacity-30 disabled:hover:text-muted-foreground"
                              title="Move up"
                            >
                              <ChevronUp className="w-3 h-3" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleMove(idx, "down")}
                              disabled={idx === orderedCategories.length - 1}
                              className="p-0.5 text-muted-foreground hover:text-royal-violet disabled:opacity-30 disabled:hover:text-muted-foreground"
                              title="Move down"
                            >
                              <ChevronDown className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </TableCell>

                      {/* Hierarchy Name */}
                      <TableCell>
                        <div className="flex items-center gap-2.5">
                          {cat.imagePath ? (
                            <img
                              src={cat.imagePath}
                              alt={cat.name}
                              className="w-8 h-8 rounded-lg object-cover border border-border shrink-0"
                            />
                          ) : (
                            <div className="w-8 h-8 rounded-lg bg-royal-violet/10 text-royal-violet flex items-center justify-center shrink-0">
                              <FolderTree className="w-4 h-4" />
                            </div>
                          )}
                          <div>
                            <span className="text-xs font-bold text-ink block">{cat.name}</span>
                            <span className="text-[10px] text-muted-foreground">
                              {cat.children?.length || 0} subcategories
                            </span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">
                        /{cat.slug}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground line-clamp-1 max-w-sm">
                        {cat.description || "-"}
                      </TableCell>
                      <TableCell className="text-xs font-bold text-ink">
                        {cat._count?.products || 0} styles
                      </TableCell>

                      {/* Interactive Active / Inactive Status Switch */}
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={cat.isActive !== false}
                            onCheckedChange={(checked) =>
                              toggleActiveMutation.mutate({ id: cat.id, isActive: checked })
                            }
                            aria-label={`Toggle active for ${cat.name}`}
                          />
                          <Badge variant={cat.isActive !== false ? "success" : "secondary"} className="text-[10px]">
                            {cat.isActive !== false ? "Active" : "Inactive"}
                          </Badge>
                        </div>
                      </TableCell>

                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-48 text-xs">
                            <DropdownMenuItem
                              onClick={() => handleOpenEdit(cat)}
                              className="cursor-pointer font-medium"
                            >
                              <Pencil className="w-3.5 h-3.5 mr-2 text-royal-violet" />
                              Edit Category
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleOpenAssignModal(cat)}
                              className="cursor-pointer font-medium"
                            >
                              <PackagePlus className="w-3.5 h-3.5 mr-2 text-royal-violet" />
                              Manage Products
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => {
                                resetAddForm();
                                setParentId(cat.id);
                                setIsAddOpen(true);
                              }}
                              className="cursor-pointer"
                            >
                              <Plus className="w-3.5 h-3.5 mr-2 text-royal-violet" />
                              Add Subcategory
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => {
                                setCategoryToDelete(cat);
                                setDeleteModalOpen(true);
                              }}
                              className="cursor-pointer text-vermilion focus:text-vermilion focus:bg-rose-50"
                            >
                              <Trash2 className="w-3.5 h-3.5 mr-2" />
                              Delete Category
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>

                    {/* Nested Subcategories */}
                    {cat.children?.map((sub: any, subIdx: number) => (
                      <TableRow key={sub.id} className="hover:bg-muted/10">
                        {/* Subcategory Move Up / Down */}
                        <TableCell className="pl-6">
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleMoveSub(cat.id, subIdx, "up")}
                              disabled={subIdx === 0}
                              className="p-0.5 text-muted-foreground hover:text-royal-violet disabled:opacity-30 disabled:hover:text-muted-foreground"
                              title="Move subcategory up"
                            >
                              <ChevronUp className="w-3 h-3" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleMoveSub(cat.id, subIdx, "down")}
                              disabled={subIdx === (cat.children?.length || 1) - 1}
                              className="p-0.5 text-muted-foreground hover:text-royal-violet disabled:opacity-30 disabled:hover:text-muted-foreground"
                              title="Move subcategory down"
                            >
                              <ChevronDown className="w-3 h-3" />
                            </button>
                          </div>
                        </TableCell>

                        <TableCell className="pl-8">
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-medium">
                            <CornerDownRight className="w-3.5 h-3.5 text-muted-foreground" />
                            <span>{sub.name}</span>
                          </div>
                        </TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground pl-8">
                          /{sub.slug}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground line-clamp-1">
                          {sub.description || "-"}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground font-semibold">
                          -
                        </TableCell>

                        {/* Subcategory Interactive Status Switch */}
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Switch
                              checked={sub.isActive !== false}
                              onCheckedChange={(checked) =>
                                toggleActiveMutation.mutate({ id: sub.id, isActive: checked })
                              }
                              aria-label={`Toggle active for ${sub.name}`}
                            />
                            <Badge variant={sub.isActive !== false ? "success" : "secondary"} className="text-[10px]">
                              {sub.isActive !== false ? "Active" : "Inactive"}
                            </Badge>
                          </div>
                        </TableCell>

                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-48 text-xs">
                              <DropdownMenuItem
                                onClick={() => handleOpenEdit(sub)}
                                className="cursor-pointer font-medium"
                              >
                                <Pencil className="w-3.5 h-3.5 mr-2 text-royal-violet" />
                                Edit Subcategory
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => handleOpenAssignModal(sub)}
                                className="cursor-pointer font-medium"
                              >
                                <PackagePlus className="w-3.5 h-3.5 mr-2 text-royal-violet" />
                                Manage Products
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => {
                                  setCategoryToDelete(sub);
                                  setDeleteModalOpen(true);
                                }}
                                className="cursor-pointer text-vermilion focus:text-vermilion focus:bg-rose-50"
                              >
                                <Trash2 className="w-3.5 h-3.5 mr-2" />
                                Delete Subcategory
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </div>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add / Create Category Modal */}
      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {parentId ? "Add Subcategory" : "Add New Category"}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleCreate} className="space-y-4 pt-2 text-xs">
            {/* Parent Category Selection */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Parent Hierarchy (Optional)
              </label>
              <select
                value={parentId}
                onChange={(e) => setParentId(e.target.value)}
                className="w-full h-10 text-xs rounded-md border border-border bg-white px-3 text-ink focus:outline-none focus:ring-1 focus:ring-royal-violet"
              >
                <option value="">None (Top-Level Parent Category)</option>
                {categories.map((c: any) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Category Name */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Category Name <span className="text-vermilion">*</span>
              </label>
              <Input
                placeholder="e.g. Resort & Linen Shirts"
                value={name}
                onChange={(e) => handleNameChange(e.target.value)}
                className={`h-10 text-xs ${errors.name ? "border-vermilion" : ""}`}
              />
              {errors.name && (
                <p className="text-[11px] text-vermilion font-medium mt-1">{errors.name}</p>
              )}
            </div>

            {/* URL Slug */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                URL Slug <span className="text-vermilion">*</span>
              </label>
              <Input
                placeholder="resort-linen-shirts"
                value={slug}
                onChange={(e) => setSlug(e.target.value)}
                onBlur={handleSlugBlur}
                className={`h-10 text-xs font-mono ${errors.slug ? "border-vermilion" : ""}`}
              />
              {errors.slug && (
                <p className="text-[11px] text-vermilion font-medium mt-1">{errors.slug}</p>
              )}
            </div>

            {/* Real Image Uploader with Validation and Deferred Upload */}
            <ImageUploader
              value={imagePath}
              onChange={setImagePath}
              onFileSelect={setSelectedImageFile}
              label="Category Header Image (Optional)"
              required={false}
            />

            {/* Description */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Description (Optional)
              </label>
              <Input
                placeholder="Atmospheric summary of garments in this category."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="h-10 text-xs"
              />
            </div>

            {/* Active Status Switch */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-muted/20 border border-border">
              <div>
                <label className="font-bold text-xs text-ink block">
                  Active on Storefront
                </label>
                <p className="text-[11px] text-muted-foreground">
                  When active, this category and its garments are visible to shoppers.
                </p>
              </div>
              <Switch
                checked={isActive}
                onCheckedChange={setIsActive}
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => { setIsAddOpen(false); resetAddForm(); }}>
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || isUploadingImage}
                className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold"
              >
                {isUploadingImage
                  ? "Uploading Image..."
                  : createMutation.isPending
                  ? "Creating..."
                  : "Save Category"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Category Modal */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="w-5 h-5 text-royal-violet" />
              Edit Category Details
            </DialogTitle>
            <DialogDescription className="text-xs">
              Update category title, taxonomy URL slug, parent hierarchy, and header visual.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleUpdateCategory} className="space-y-4 pt-2 text-xs">
            {/* Parent Category Hierarchy Selector */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Parent Hierarchy
              </label>
              <select
                value={editParentId}
                onChange={(e) => setEditParentId(e.target.value)}
                className="w-full h-10 rounded-md border border-border bg-card px-3 text-xs focus:ring-2 focus:ring-royal-violet"
              >
                <option value="">Top-Level Department (No Parent)</option>
                {categories
                  .filter((c: any) => c.id !== editingCategory?.id)
                  .map((c: any) => (
                    <option key={c.id} value={c.id}>
                      {c.name} (Parent)
                    </option>
                  ))}
              </select>
            </div>

            {/* Name */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Category Name <span className="text-vermilion">*</span>
              </label>
              <Input
                placeholder="e.g. Resort &amp; Linen Wear"
                value={editName}
                onChange={(e) => {
                  setEditName(e.target.value);
                  if (e.target.value.trim()) {
                    setEditErrors((prev) => {
                      const copy = { ...prev };
                      delete copy.name;
                      return copy;
                    });
                  }
                }}
                className={`h-10 text-xs ${editErrors.name ? "border-vermilion" : ""}`}
              />
              {editErrors.name && (
                <p className="text-[11px] text-vermilion font-medium mt-1">{editErrors.name}</p>
              )}
            </div>

            {/* URL Slug */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                URL Slug <span className="text-vermilion">*</span>
              </label>
              <Input
                placeholder="resort-linen-shirts"
                value={editSlug}
                onChange={(e) => {
                  setEditSlug(e.target.value);
                  if (e.target.value.trim()) {
                    setEditErrors((prev) => {
                      const copy = { ...prev };
                      delete copy.slug;
                      return copy;
                    });
                  }
                }}
                className={`h-10 text-xs font-mono ${editErrors.slug ? "border-vermilion" : ""}`}
              />
              {editErrors.slug && (
                <p className="text-[11px] text-vermilion font-medium mt-1">{editErrors.slug}</p>
              )}
            </div>

            {/* Real Image Uploader with Validation and Deferred Upload */}
            <ImageUploader
              value={editImagePath}
              onChange={setEditImagePath}
              onFileSelect={setEditImageFile}
              label="Category Header Image (Optional)"
              required={false}
            />

            {/* Description */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Description (Optional)
              </label>
              <Input
                placeholder="Atmospheric summary of garments in this category."
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                className="h-10 text-xs"
              />
            </div>

            {/* Active Status Switch */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-muted/20 border border-border">
              <div>
                <label className="font-bold text-xs text-ink block">
                  Active on Storefront
                </label>
                <p className="text-[11px] text-muted-foreground">
                  Control category visibility in navigation menus and catalogue pages.
                </p>
              </div>
              <Switch
                checked={editIsActive}
                onCheckedChange={setEditIsActive}
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setIsEditOpen(false)}>
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={updateMutation.isPending || editIsUploadingImage}
                className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold"
              >
                {editIsUploadingImage
                  ? "Uploading Image..."
                  : updateMutation.isPending
                  ? "Saving Changes..."
                  : "Save Changes"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Modal: Attach / Manage Products for Category */}
      <Dialog open={assignModalOpen} onOpenChange={setAssignModalOpen}>
        <DialogContent className="max-w-xl max-h-[85vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>
              Manage Products in "{selectedCategoryForProducts?.name}"
            </DialogTitle>
            <DialogDescription className="text-xs">
              Select products to assign to this category, or uncheck to remove them.
            </DialogDescription>
          </DialogHeader>

          <div className="py-2">
            <div className="relative mb-3">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Filter products by name or SKU..."
                value={productSearch}
                onChange={(e) => setProductSearch(e.target.value)}
                className="pl-9 h-9 text-xs"
              />
            </div>

            <div className="max-h-72 overflow-y-auto divide-y divide-border/60 border border-border rounded-xl">
              {loadingProducts ? (
                <p className="text-xs text-muted-foreground p-6 text-center">Loading catalogue products...</p>
              ) : filteredProducts.length === 0 ? (
                <p className="text-xs text-muted-foreground p-6 text-center">No matching products found.</p>
              ) : (
                filteredProducts.map((p) => {
                  const isChecked = assignedProductIds.includes(p.id);
                  return (
                    <div
                      key={p.id}
                      onClick={() => toggleProductAssignment(p.id)}
                      className={`p-3 flex items-center justify-between text-xs cursor-pointer transition ${
                        isChecked ? "bg-violet-50/60" : "hover:bg-muted/40"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}} // handled by parent div
                          className="rounded text-royal-violet focus:ring-royal-violet cursor-pointer"
                        />
                        <div>
                          <span className="font-bold text-ink block">{p.name}</span>
                          <span className="text-[11px] text-muted-foreground font-mono">
                            {p.sku || "No SKU"}
                          </span>
                        </div>
                      </div>
                      <span className="font-semibold text-ink">₹{Number(p.regularPrice)}</span>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <DialogFooter className="pt-2">
            <Button variant="outline" size="sm" onClick={() => setAssignModalOpen(false)}>
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleSaveAssignedProducts}
              disabled={saveProductsMutation.isPending}
              className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold"
            >
              {saveProductsMutation.isPending ? "Saving..." : `Save Assigned (${assignedProductIds.length})`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Modal (Pop Modal) */}
      <Dialog open={deleteModalOpen} onOpenChange={setDeleteModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="w-10 h-10 rounded-full bg-rose-50 text-vermilion flex items-center justify-center mb-2">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <DialogTitle>Delete Category</DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground">
              Are you sure you want to delete category <strong>"{categoryToDelete?.name}"</strong>? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="pt-2">
            <Button variant="outline" size="sm" onClick={() => setDeleteModalOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              size="sm"
              disabled={deleteMutation.isPending}
              onClick={() => categoryToDelete && deleteMutation.mutate(categoryToDelete.id)}
            >
              {deleteMutation.isPending ? "Deleting..." : "Confirm Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

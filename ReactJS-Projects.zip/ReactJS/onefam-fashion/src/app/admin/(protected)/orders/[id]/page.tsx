"use client";

import { use, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  ArrowLeft,
  CheckCircle2,
  Clock,
  Package,
  Truck,
  CreditCard,
  FileText,
  PlusCircle,
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
  Receipt,
  Download,
  Share2,
  MessageSquare,
  Copy,
  Eye,
} from "lucide-react";
import { toast } from "sonner";

export default function AdminOrderDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const queryClient = useQueryClient();

  // Payment recording dialog state
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("UPI");
  const [paymentRef, setPaymentRef] = useState("");
  const [paymentNotes, setPaymentNotes] = useState("");

  const { data: order, isLoading } = useQuery({
    queryKey: queryKeys.orders.detail(id),
    queryFn: () => apiClient.get(`/orders/${id}`),
  });

  // Status update mutation
  const statusMutation = useMutation({
    mutationFn: (payload: { status: string; note?: string }) =>
      apiClient.patch(`/orders/${id}`, payload),
    onSuccess: () => {
      toast.success("Order status updated");
      queryClient.invalidateQueries({ queryKey: queryKeys.orders.detail(id) });
      queryClient.invalidateQueries({ queryKey: queryKeys.orders.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  // Record payment mutation
  const paymentMutation = useMutation({
    mutationFn: (payload: any) => apiClient.post("/payments", payload),
    onSuccess: () => {
      toast.success("Payment recorded successfully");
      setIsPaymentOpen(false);
      setPaymentAmount("");
      setPaymentRef("");
      setPaymentNotes("");
      queryClient.invalidateQueries({ queryKey: queryKeys.orders.detail(id) });
      queryClient.invalidateQueries({ queryKey: queryKeys.orders.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  // Invoice generation mutation
  const invoiceMutation = useMutation({
    mutationFn: () => apiClient.post("/invoices", { orderId: id }),
    onSuccess: (inv: any) => {
      toast.success(`Invoice ${inv.invoiceNumber} generated!`);
      queryClient.invalidateQueries({ queryKey: queryKeys.orders.detail(id) });
    },
    onError: (err: any) => toast.error(err.message),
  });

  if (isLoading || !order) {
    return <div className="p-8 text-xs text-muted-foreground animate-pulse">Loading order details...</div>;
  }

  const handleRecordPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(paymentAmount);
    if (!amt || amt <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }
    paymentMutation.mutate({
      orderId: id,
      amount: amt,
      method: paymentMethod,
      reference: paymentRef,
      notes: paymentNotes || "Staff recorded payment",
    });
  };

  const isFullyPaid = order.paymentStatus === "PAID";
  const balanceDue = Number(order.balanceDue);

  // Invoice helper links and sharing
  const primaryInvoice = order.invoices?.[0];
  const invoicePreviewUrl = typeof window !== "undefined"
    ? `${window.location.origin}/api/invoices/${primaryInvoice?.id || order.id}/preview`
    : `/api/invoices/${primaryInvoice?.id || order.id}/preview`;

  const shareText = `✨ *OneFam Fashion - Order & Invoice Confirmation*
Hello ${order.customer?.name || "Customer"},
Thank you for shopping with OneFam Fashion! Here are your order details:

• *Order Reference:* ${order.orderRef}
• *Status:* ${order.status?.replace(/_/g, " ")}
• *Total Payable:* ${formatCurrency(order.total)}
• *Amount Paid:* ${formatCurrency(order.amountPaid)}
• *Balance Due:* ${formatCurrency(order.balanceDue)}

📄 *View & Download Official Invoice:*
${invoicePreviewUrl}

For bespoke inquiries or size adjustments, feel free to reply directly to this chat.`;

  const rawPhone = (order.customer?.phone || "").replace(/[^0-9]/g, "");
  const whatsappPhone = rawPhone.startsWith("91") ? rawPhone : rawPhone.length === 10 ? `91${rawPhone}` : rawPhone;
  const whatsappShareUrl = `https://wa.me/${whatsappPhone}?text=${encodeURIComponent(shareText)}`;

  const handleCopyInvoiceLink = () => {
    if (typeof window !== "undefined") {
      navigator.clipboard.writeText(invoicePreviewUrl);
      toast.success("Invoice link copied to clipboard!");
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-16">
      {/* Top Header & Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <Link
            href="/admin/orders"
            className="text-xs font-bold text-muted-foreground hover:text-royal-violet flex items-center gap-1 mb-2"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Orders
          </Link>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-foreground">
              {order.orderRef}
            </h1>
            <Badge
              variant={
                order.status === "DELIVERED"
                  ? "success"
                  : order.status === "CANCELLED"
                  ? "destructive"
                  : "default"
              }
            >
              {order.status.replace(/_/g, " ")}
            </Badge>
            <Badge
              variant={
                order.paymentStatus === "PAID"
                  ? "success"
                  : order.paymentStatus === "PARTIALLY_PAID"
                  ? "warning"
                  : "destructive"
              }
            >
              {order.paymentStatus.replace(/_/g, " ")}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Registered on {formatDate(order.createdAt)} · Customer: {order.customer?.name}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Record Payment Dialog */}
          <Dialog open={isPaymentOpen} onOpenChange={setIsPaymentOpen}>
            <DialogTrigger asChild>
              <Button
                size="sm"
                variant="outline"
                className="rounded-xl font-bold text-xs h-9"
              >
                <CreditCard className="w-3.5 h-3.5 mr-1.5 text-royal-violet" />
                Record Payment
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Record Payment for {order.orderRef}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleRecordPayment} className="space-y-4 pt-2 text-xs">
                <div className="p-3 bg-muted/40 rounded-xl flex items-center justify-between">
                  <span>Balance Outstanding:</span>
                  <strong className="text-sm font-bold text-vermilion">
                    {formatCurrency(balanceDue)}
                  </strong>
                </div>

                <div>
                  <label className="font-bold text-muted-foreground block mb-1">
                    Payment Amount (₹) *
                  </label>
                  <Input
                    type="number"
                    placeholder={balanceDue.toString()}
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                    required
                    className="h-10 text-sm font-bold"
                  />
                </div>

                <div>
                  <label className="font-bold text-muted-foreground block mb-1">
                    Method *
                  </label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full h-10 text-xs rounded-md border border-border bg-card px-3 text-foreground focus:outline-none"
                  >
                    <option value="UPI">UPI (GPay, PhonePe, Paytm, QR)</option>
                    <option value="BANK_TRANSFER">Bank IMPS / NEFT</option>
                    <option value="CASH">Cash</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-muted-foreground block mb-1">
                    Transaction / UTR Reference
                  </label>
                  <Input
                    placeholder="e.g. UPI/3948291048"
                    value={paymentRef}
                    onChange={(e) => setPaymentRef(e.target.value)}
                    className="h-10 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="font-bold text-muted-foreground block mb-1">Notes</label>
                  <Input
                    placeholder="e.g. Balance settlement"
                    value={paymentNotes}
                    onChange={(e) => setPaymentNotes(e.target.value)}
                    className="h-10 text-xs"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setIsPaymentOpen(false)}>
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={paymentMutation.isPending}
                    className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold"
                  >
                    {paymentMutation.isPending ? "Recording..." : "Save Payment"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>

          {/* Invoice Actions: View, Download & Share */}
          {order.invoices && order.invoices.length > 0 ? (
            <div className="flex items-center gap-1.5 flex-wrap">
              <Button
                asChild
                size="sm"
                variant="outline"
                className="rounded-xl font-bold text-xs h-9"
              >
                <a
                  href={`/api/invoices/${order.invoices[0].id}/preview`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5 text-royal-violet" />
                  <span>View Invoice</span>
                </a>
              </Button>

              <Button
                asChild
                size="sm"
                variant="outline"
                className="rounded-xl font-bold text-xs h-9"
              >
                <a
                  href={`/api/invoices/${order.invoices[0].id}/preview?download=true`}
                  className="flex items-center gap-1.5"
                  title="Download official PDF invoice"
                >
                  <Download className="w-3.5 h-3.5 text-royal-violet" />
                  <span>Download PDF</span>
                </a>
              </Button>

              <Button
                asChild
                size="sm"
                variant="outline"
                className="rounded-xl font-bold text-xs h-9 border-emerald-500/40 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/10"
              >
                <a
                  href={whatsappShareUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>Share on WhatsApp</span>
                </a>
              </Button>

              <Button
                type="button"
                size="sm"
                variant="ghost"
                onClick={handleCopyInvoiceLink}
                className="h-9 px-2 text-xs text-muted-foreground hover:text-foreground"
                title="Copy invoice link to clipboard"
              >
                <Copy className="w-3.5 h-3.5 mr-1" />
                <span>Copy Link</span>
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                onClick={() => invoiceMutation.mutate()}
                disabled={invoiceMutation.isPending}
                className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl text-xs h-9 shadow-sm"
              >
                <Receipt className="w-3.5 h-3.5 mr-1.5" />
                {invoiceMutation.isPending ? "Generating..." : "Generate Invoice"}
              </Button>
              <Button
                asChild
                size="sm"
                variant="outline"
                className="rounded-xl font-bold text-xs h-9 border-emerald-500/40 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/10"
              >
                <a
                  href={whatsappShareUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>Share Order</span>
                </a>
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Status Lifecycle Transition Buttons */}
      <div className="p-4 bg-card rounded-2xl border border-border shadow-2xs space-y-2">
        <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground block">
          Update Order Status
        </span>
        <div className="flex flex-wrap items-center gap-2">
          {["CONFIRMED", "PROCESSING", "PACKED", "SHIPPED", "DELIVERED", "CANCELLED"].map(
            (status) => (
              <Button
                key={status}
                size="sm"
                variant={order.status === status ? "default" : "outline"}
                disabled={statusMutation.isPending || order.status === status}
                onClick={() => statusMutation.mutate({ status })}
                className="h-8 text-xs font-bold rounded-lg"
              >
                {status.replace(/_/g, " ")}
              </Button>
            )
          )}
        </div>
      </div>

      {/* Main Grid: Details & Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Ordered Items & Timeline */}
        <div className="lg:col-span-2 space-y-6">
          {/* Order Items Table */}
          <div className="p-6 bg-card rounded-2xl border border-border shadow-2xs space-y-4">
            <h2 className="font-bold text-base text-foreground">Ordered Items</h2>
            <div className="divide-y divide-border/60">
              {order.items?.map((item: any) => (
                <div key={item.id} className="py-3.5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-foreground block">{item.productName}</span>
                    <span className="text-muted-foreground">
                      Variant: {[item.size, item.color].filter(Boolean).join(" / ") || "Standard"} · SKU:{" "}
                      {item.sku || "-"}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-foreground block">
                      {formatCurrency(Number(item.unitPrice) * item.quantity)}
                    </span>
                    <span className="text-muted-foreground text-[11px]">
                      {item.quantity} × {formatCurrency(item.unitPrice)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Payment Transactions Log */}
          <div className="p-6 bg-card rounded-2xl border border-border shadow-2xs space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-base text-foreground">Payment History &amp; Ledger</h2>
              <span className="text-xs text-muted-foreground font-semibold">
                {order.payments?.length || 0} transaction(s)
              </span>
            </div>

            <div className="divide-y divide-border/60">
              {order.payments?.length === 0 ? (
                <p className="text-xs text-muted-foreground py-4 text-center">
                  No payments recorded yet. Click &quot;Record Payment&quot; above.
                </p>
              ) : (
                order.payments?.map((pm: any) => (
                  <div key={pm.id} className="py-3 flex items-center justify-between text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-emerald-700 dark:text-emerald-400">
                          {formatCurrency(pm.amount)}
                        </span>
                        <Badge variant="outline" className="text-[10px] py-0">
                          {pm.method}
                        </Badge>
                      </div>
                      <span className="text-muted-foreground text-[11px] mt-0.5 block">
                        {formatDate(pm.paymentDate)} {pm.reference ? `· Ref: ${pm.reference}` : ""}
                      </span>
                    </div>
                    {pm.notes && (
                      <span className="text-[11px] text-muted-foreground italic max-w-xs truncate">
                        {pm.notes}
                      </span>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Order Lifecycle History Timeline */}
          <div className="p-6 bg-card rounded-2xl border border-border shadow-2xs space-y-4">
            <h2 className="font-bold text-base text-foreground">Status Activity Trail</h2>
            <div className="space-y-3">
              {order.statusHistory?.map((hist: any) => (
                <div key={hist.id} className="flex items-start gap-3 text-xs">
                  <div className="w-2 h-2 rounded-full bg-royal-violet mt-1.5 shrink-0" />
                  <div>
                    <span className="font-bold text-foreground">
                      {hist.status.replace(/_/g, " ")}
                    </span>
                    <span className="text-muted-foreground ml-2 text-[11px]">
                      {formatDate(hist.createdAt)} {hist.changedBy ? `by ${hist.changedBy}` : ""}
                    </span>
                    {hist.note && (
                      <p className="text-muted-foreground text-[11px] mt-0.5">{hist.note}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Customer Info & Financial Totals */}
        <div className="space-y-6">
          {/* Customer Card */}
          <div className="p-6 bg-card rounded-2xl border border-border shadow-2xs space-y-3 text-xs">
            <h3 className="font-bold text-sm text-foreground pb-2 border-b border-border">
              Customer Information
            </h3>
            <div>
              <span className="text-muted-foreground block text-[11px] uppercase tracking-wider font-semibold">
                Name
              </span>
              <span className="font-bold text-foreground text-sm">{order.customer?.name}</span>
            </div>
            <div>
              <span className="text-muted-foreground block text-[11px] uppercase tracking-wider font-semibold">
                Email
              </span>
              <span className="font-medium text-foreground">{order.customer?.email}</span>
            </div>
            <div>
              <span className="text-muted-foreground block text-[11px] uppercase tracking-wider font-semibold">
                Phone
              </span>
              <span className="font-medium text-foreground">{order.customer?.phone}</span>
            </div>
            <div>
              <span className="text-muted-foreground block text-[11px] uppercase tracking-wider font-semibold">
                Shipping Destination
              </span>
              <p className="text-foreground mt-1 leading-relaxed bg-muted/40 p-2.5 rounded-lg border border-border font-medium">
                {order.customer?.shippingAddress}
              </p>
            </div>
          </div>

          {/* Financial Breakdown */}
          <div className="p-6 bg-card rounded-2xl border border-border shadow-2xs space-y-3 text-xs">
            <h3 className="font-bold text-sm text-foreground pb-2 border-b border-border">
              Financial Summary
            </h3>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Subtotal:</span>
              <span className="font-semibold text-foreground">{formatCurrency(order.subtotal)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Discount:</span>
              <span className="font-semibold text-vermilion">-{formatCurrency(order.discount)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Shipping:</span>
              <span className="font-semibold text-foreground">{formatCurrency(order.shipping)}</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-border font-bold text-sm">
              <span>Total Payable:</span>
              <span className="text-royal-violet">{formatCurrency(order.total)}</span>
            </div>
            <div className="flex justify-between text-emerald-700 dark:text-emerald-400 font-bold">
              <span>Amount Paid:</span>
              <span>{formatCurrency(order.amountPaid)}</span>
            </div>
            <div className="flex justify-between text-vermilion font-bold">
              <span>Outstanding Balance:</span>
              <span>{formatCurrency(order.balanceDue)}</span>
            </div>
          </div>

          {/* Internal Admin Notes */}
          {order.adminNotes && (
            <div className="p-4 bg-muted/40 rounded-xl border border-border text-xs space-y-1.5">
              <span className="font-bold text-royal-violet dark:text-[#C6F542] uppercase text-[10px] tracking-wider flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5" />
                Internal Staff Notes
              </span>
              <p className="text-foreground leading-relaxed font-medium">
                {order.adminNotes}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}


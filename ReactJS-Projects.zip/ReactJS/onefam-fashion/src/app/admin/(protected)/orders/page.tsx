"use client";

import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import {
  Plus,
  Search,
  ShoppingBag,
  ExternalLink,
  PlusCircle,
  Trash2,
  Receipt,
  Shirt,
  Sparkles,
  Filter,
  Check,
  X,
  Tag,
  ChevronDown,
  Download,
  MessageSquare,
  Copy,
  FileText,
} from "lucide-react";
import { toast } from "sonner";

export interface OrderItemFormState {
  productId?: string;
  variantId?: string;
  productName: string;
  sku?: string;
  size?: string;
  color?: string;
  unitPrice: number;
  quantity: number;
  image?: string;
}

export default function AdminOrdersPage() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [paymentStatusFilter, setPaymentStatusFilter] = useState("");
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);

  // Register Order Form State
  const [customerName, setCustomerName] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [shippingAddress, setShippingAddress] = useState("");
  const [adminNotes, setAdminNotes] = useState("");

  // Items in Order
  const [items, setItems] = useState<OrderItemFormState[]>([
    {
      productName: "Oversized Heavyweight Cotton Tee",
      sku: "OFF-M-TEE-001-BLK-M",
      size: "M",
      color: "Obsidian Black",
      unitPrice: 1499,
      quantity: 1,
    },
  ]);

  // Product Picker in Order State
  const [isPickerOpen, setIsPickerOpen] = useState(false);
  const [pickerSearch, setPickerSearch] = useState("");
  const [pickerCategory, setPickerCategory] = useState("");
  const [pickerInStockOnly, setPickerInStockOnly] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<any | null>(null);
  const [selectedVariantId, setSelectedVariantId] = useState<string>("");
  const [pickerQty, setPickerQty] = useState<number>(1);

  // Catalogue Queries for Product Picker
  const { data: catalogueProductsData } = useQuery({
    queryKey: ["catalogue", "order-picker"],
    queryFn: async () => {
      const res = await apiClient.get<{ products: any[] }>("/products?limit=100");
      return res?.products || [];
    },
    enabled: isRegisterOpen,
  });

  const { data: catalogueCategoriesData } = useQuery({
    queryKey: ["categories", "order-picker"],
    queryFn: async () => {
      const res = await apiClient.get<any[]>("/categories");
      return res || [];
    },
    enabled: isRegisterOpen,
  });

  const catalogueProducts = catalogueProductsData || [];
  const catalogueCategories = catalogueCategoriesData || [];

  // Super Filter & Search for Product Picker
  const filteredCatalogueProducts = useMemo(() => {
    return catalogueProducts.filter((p: any) => {
      const q = pickerSearch.trim().toLowerCase();
      const matchSearch =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.slug.toLowerCase().includes(q) ||
        (p.sku && p.sku.toLowerCase().includes(q));

      const matchCategory =
        !pickerCategory ||
        p.categoryId === pickerCategory ||
        p.category?.slug === pickerCategory;

      const hasStock =
        !pickerInStockOnly ||
        (p.variants &&
          p.variants.some((v: any) => v.isAvailable !== false && (v.stock === null || v.stock > 0)));

      return matchSearch && matchCategory && hasStock;
    });
  }, [catalogueProducts, pickerSearch, pickerCategory, pickerInStockOnly]);

  // Pricing & Negotiation State
  const [discountMode, setDiscountMode] = useState<"amount" | "percent">("amount");
  const [discountAmount, setDiscountAmount] = useState("0");
  const [discountPercent, setDiscountPercent] = useState("0");
  const [shippingCharge, setShippingCharge] = useState("0");
  const [initialPaymentAmount, setInitialPaymentAmount] = useState("0");
  const [paymentMethod, setPaymentMethod] = useState("UPI");
  const [paymentRef, setPaymentRef] = useState("");

  // Form Validation Errors
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const { data, isLoading } = useQuery({
    queryKey: queryKeys.orders.list({
      search,
      status: statusFilter,
      paymentStatus: paymentStatusFilter,
    }),
    queryFn: () =>
      apiClient.get(
        `/orders?${new URLSearchParams({
          ...(search ? { search } : {}),
          ...(statusFilter ? { status: statusFilter } : {}),
          ...(paymentStatusFilter ? { paymentStatus: paymentStatusFilter } : {}),
          limit: "50",
        }).toString()}`
      ),
  });

  const orders = data?.orders || [];

  const subtotal = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);

  // Compute calculated discount based on mode
  const calculatedDiscount =
    discountMode === "percent"
      ? Math.round((subtotal * (parseFloat(discountPercent || "0") || 0)) / 100)
      : Math.min(subtotal, parseFloat(discountAmount || "0") || 0);

  const effectivePercent =
    subtotal > 0 ? Math.round((calculatedDiscount / subtotal) * 100) : 0;

  const total = Math.max(0, subtotal - calculatedDiscount + (parseFloat(shippingCharge || "0") || 0));
  const paidNow = parseFloat(initialPaymentAmount || "0") || 0;
  const balanceDue = Math.max(0, total - paidNow);

  const registerMutation = useMutation({
    mutationFn: (body: any) => apiClient.post("/orders", body),
    onSuccess: (order: any) => {
      toast.success(`Order ${order.orderRef} registered successfully!`);
      setIsRegisterOpen(false);
      // Reset form
      setCustomerName("");
      setCustomerEmail("");
      setCustomerPhone("");
      setShippingAddress("");
      setInitialPaymentAmount("0");
      setPaymentRef("");
      queryClient.invalidateQueries({ queryKey: queryKeys.orders.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const handleAddItem = () => {
    setItems((prev) => [
      ...prev,
      {
        productName: "Bespoke Custom Garment",
        sku: "OFF-CUSTOM-01",
        size: "M",
        color: "Custom",
        unitPrice: 1999,
        quantity: 1,
      },
    ]);
  };

  const handleAddProductFromPicker = (product: any, variant?: any, qty: number = 1) => {
    const chosenVariant = variant || product.variants?.[0];
    const effectiveUnitPrice =
      chosenVariant?.priceOverride !== null && chosenVariant?.priceOverride !== undefined
        ? Number(chosenVariant.priceOverride)
        : product.discountPrice !== null && product.discountPrice !== undefined
        ? Number(product.discountPrice)
        : Number(product.regularPrice) || 0;

    const newItem: OrderItemFormState = {
      productId: product.id,
      variantId: chosenVariant?.id,
      productName: product.name,
      sku: chosenVariant?.sku || product.sku || "",
      size: chosenVariant?.size || "One Size",
      color: chosenVariant?.color || "Standard",
      unitPrice: effectiveUnitPrice,
      quantity: Math.max(1, qty),
      image: chosenVariant?.imagePath || product.images?.[0]?.path,
    };

    setItems((prev) => {
      // If the only item in order is the default placeholder without an ID, replace it
      if (
        prev.length === 1 &&
        !prev[0].productId &&
        prev[0].productName === "Oversized Heavyweight Cotton Tee"
      ) {
        return [newItem];
      }
      return [...prev, newItem];
    });

    toast.success(
      `Added "${product.name}" (${chosenVariant?.size || "Std"} / ${chosenVariant?.color || "Std"}) to order`
    );
  };

  const handleRemoveItem = (index: number) => {
    if (items.length <= 1) return;
    setItems((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { [key: string]: string } = {};

    if (!customerName.trim()) newErrors.customerName = "Customer name is required";
    if (!customerEmail.trim()) newErrors.customerEmail = "Customer email is required";
    if (!customerPhone.trim()) newErrors.customerPhone = "Customer phone number is required";
    if (!shippingAddress.trim()) newErrors.shippingAddress = "Full shipping address is required";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    setErrors({});

    registerMutation.mutate({
      customer: {
        name: customerName.trim(),
        email: customerEmail.trim(),
        phone: customerPhone.trim(),
        shippingAddress: shippingAddress.trim(),
      },
      items,
      pricing: {
        subtotal,
        discount: calculatedDiscount,
        shipping: parseFloat(shippingCharge || "0") || 0,
      },
      payment:
        paidNow > 0
          ? {
              amount: paidNow,
              method: paymentMethod,
              reference: paymentRef,
              notes: "Advance payment at order confirmation",
            }
          : undefined,
      notes: {
        adminNotes: adminNotes || "Confirmed order via WhatsApp Concierge",
      },
    });
  };

  const getInvoiceUrl = (orderId: string, invoiceId?: string, download?: boolean) => {
    const id = invoiceId || orderId;
    const base = typeof window !== "undefined" ? window.location.origin : "";
    return `${base}/api/invoices/${id}/preview${download ? "?download=true" : ""}`;
  };

  const getOrderWhatsAppUrl = (o: any) => {
    const primaryInvoice = o.invoices?.[0];
    const invoiceUrl = getInvoiceUrl(o.id, primaryInvoice?.id);
    const text = `✨ *OneFam Fashion - Order & Invoice Confirmation*
Hello ${o.customer?.name || "Customer"},
Thank you for shopping with OneFam Fashion! Here are your order details:

• *Order Reference:* ${o.orderRef}
• *Status:* ${o.status?.replace(/_/g, " ")}
• *Total Payable:* ${formatCurrency(o.total)}
• *Amount Paid:* ${formatCurrency(o.amountPaid)}
• *Balance Due:* ${formatCurrency(o.balanceDue)}

📄 *View & Download Official Invoice:*
${invoiceUrl}

For bespoke inquiries or size adjustments, feel free to reply directly to this chat.`;

    const rawPhone = (o.customer?.phone || "").replace(/[^0-9]/g, "");
    const whatsappPhone = rawPhone.startsWith("91") ? rawPhone : rawPhone.length === 10 ? `91${rawPhone}` : rawPhone;
    return `https://wa.me/${whatsappPhone}?text=${encodeURIComponent(text)}`;
  };

  const handleCopyOrderInvoice = (o: any) => {
    const primaryInvoice = o.invoices?.[0];
    const url = getInvoiceUrl(o.id, primaryInvoice?.id);
    if (typeof window !== "undefined") {
      navigator.clipboard.writeText(url);
      toast.success(`Invoice link for ${o.orderRef} copied to clipboard!`);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Header & Register Order Dialog */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-foreground">
            Order Fulfillment &amp; Operations
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Register confirmed WhatsApp orders, record partial/full payments and trigger official invoices.
          </p>
        </div>

        <Dialog open={isRegisterOpen} onOpenChange={setIsRegisterOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl text-xs">
              <Plus className="w-4 h-4 mr-1.5" />
              Register Order (Staff)
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[92vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Register Customer Order</DialogTitle>
            </DialogHeader>

            <form onSubmit={handleRegisterSubmit} className="space-y-6 pt-2">
              {/* Customer Information */}
              <div className="space-y-3 p-4 bg-muted/40 rounded-xl border border-border">
                <span className="text-xs font-bold uppercase tracking-wider text-royal-violet block">
                  1. Customer Details
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-muted-foreground block mb-1">
                      Customer Full Name <span className="text-vermilion">*</span>
                    </label>
                    <Input
                      placeholder="e.g. Aarav Sharma"
                      value={customerName}
                      onChange={(e) => {
                        setCustomerName(e.target.value);
                        if (e.target.value.trim()) {
                          setErrors((prev) => {
                            const c = { ...prev };
                            delete c.customerName;
                            return c;
                          });
                        }
                      }}
                      className={`h-9 text-xs ${errors.customerName ? "border-vermilion" : ""}`}
                    />
                    {errors.customerName && (
                      <p className="text-[10px] text-vermilion font-medium mt-1">{errors.customerName}</p>
                    )}
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-muted-foreground block mb-1">
                      Customer Email <span className="text-vermilion">*</span>
                    </label>
                    <Input
                      type="email"
                      placeholder="aarav@example.com"
                      value={customerEmail}
                      onChange={(e) => {
                        setCustomerEmail(e.target.value);
                        if (e.target.value.trim()) {
                          setErrors((prev) => {
                            const c = { ...prev };
                            delete c.customerEmail;
                            return c;
                          });
                        }
                      }}
                      className={`h-9 text-xs ${errors.customerEmail ? "border-vermilion" : ""}`}
                    />
                    {errors.customerEmail && (
                      <p className="text-[10px] text-vermilion font-medium mt-1">{errors.customerEmail}</p>
                    )}
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-muted-foreground block mb-1">
                      Phone Number <span className="text-vermilion">*</span>
                    </label>
                    <Input
                      placeholder="+91 98765 43210"
                      value={customerPhone}
                      onChange={(e) => {
                        setCustomerPhone(e.target.value);
                        if (e.target.value.trim()) {
                          setErrors((prev) => {
                            const c = { ...prev };
                            delete c.customerPhone;
                            return c;
                          });
                        }
                      }}
                      className={`h-9 text-xs ${errors.customerPhone ? "border-vermilion" : ""}`}
                    />
                    {errors.customerPhone && (
                      <p className="text-[10px] text-vermilion font-medium mt-1">{errors.customerPhone}</p>
                    )}
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-muted-foreground block mb-1">
                    Shipping Address (with Landmark &amp; Pincode) <span className="text-vermilion">*</span>
                  </label>
                  <Input
                    placeholder="Flat 402, Royal Palms, 100ft Road, Indiranagar, Bengaluru, KA 560038"
                    value={shippingAddress}
                    onChange={(e) => {
                      setShippingAddress(e.target.value);
                      if (e.target.value.trim()) {
                        setErrors((prev) => {
                          const c = { ...prev };
                          delete c.shippingAddress;
                          return c;
                        });
                      }
                    }}
                    className={`h-9 text-xs ${errors.shippingAddress ? "border-vermilion" : ""}`}
                  />
                  {errors.shippingAddress && (
                    <p className="text-[10px] text-vermilion font-medium mt-1">{errors.shippingAddress}</p>
                  )}
                </div>
              </div>

              {/* Order Items with Super Search & Filter Product Picker */}
              <div className="space-y-3 p-4 bg-white dark:bg-card rounded-xl border border-border">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-royal-violet flex items-center gap-1.5">
                      <Shirt className="w-3.5 h-3.5" />
                      2. Ordered Items ({items.length})
                    </span>
                    <span className="text-[11px] text-muted-foreground block">
                      Search and pick from store catalogue or add custom items.
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      size="sm"
                      onClick={() => setIsPickerOpen(!isPickerOpen)}
                      className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold text-xs h-8 px-3 rounded-lg flex items-center gap-1.5 shadow-2xs"
                    >
                      <Search className="w-3.5 h-3.5" />
                      <span>{isPickerOpen ? "Close Catalogue Picker" : "Browse & Pick Product"}</span>
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={handleAddItem}
                      className="h-8 text-xs font-semibold"
                    >
                      <PlusCircle className="w-3.5 h-3.5 mr-1 text-royal-violet" />
                      <span>Custom Blank</span>
                    </Button>
                  </div>
                </div>

                {/* Super Filter & Search Product Picker Drawer/Panel */}
                {isPickerOpen && (
                  <div className="p-4 rounded-xl border border-royal-violet/30 bg-royal-violet/5 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black uppercase tracking-wider text-royal-violet flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5" />
                        Catalogue Super Search &amp; Filter
                      </span>
                      <button
                        type="button"
                        onClick={() => setIsPickerOpen(false)}
                        className="text-xs text-muted-foreground hover:text-foreground"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Filter bar: Search input + Category dropdown + In-stock toggle */}
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                      <div className="sm:col-span-6 relative">
                        <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                        <Input
                          placeholder="Search products by title, SKU, or slug..."
                          value={pickerSearch}
                          onChange={(e) => setPickerSearch(e.target.value)}
                          className="h-8 pl-8 text-xs bg-background"
                        />
                      </div>

                      <div className="sm:col-span-4">
                        <select
                          value={pickerCategory}
                          onChange={(e) => setPickerCategory(e.target.value)}
                          className="w-full h-8 px-2.5 rounded-lg border border-border bg-background text-xs font-medium focus:outline-none focus:ring-1 focus:ring-royal-violet"
                        >
                          <option value="">All Categories ({catalogueProducts.length})</option>
                          {catalogueCategories.map((c: any) => (
                            <option key={c.id} value={c.id}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="sm:col-span-2 flex items-center justify-end">
                        <label className="flex items-center gap-1.5 text-[11px] text-muted-foreground cursor-pointer select-none">
                          <input
                            type="checkbox"
                            checked={pickerInStockOnly}
                            onChange={(e) => setPickerInStockOnly(e.target.checked)}
                            className="rounded border-border text-royal-violet focus:ring-royal-violet"
                          />
                          <span>In Stock</span>
                        </label>
                      </div>
                    </div>

                    {/* Filtered Products List */}
                    <div className="max-h-64 overflow-y-auto rounded-lg border border-border bg-background divide-y divide-border">
                      {filteredCatalogueProducts.length === 0 ? (
                        <div className="p-6 text-center text-xs text-muted-foreground">
                          No matching products found. Try a different keyword or category.
                        </div>
                      ) : (
                        filteredCatalogueProducts.map((p: any) => {
                          const variants = p.variants || [];
                          const hasVariants = variants.length > 0;
                          const regPrice = Number(p.regularPrice) || 0;
                          const discPrice =
                            p.discountPrice !== null && p.discountPrice !== undefined
                              ? Number(p.discountPrice)
                              : null;
                          const displayPrice = discPrice ?? regPrice;

                          return (
                            <div
                              key={p.id}
                              className="p-3 hover:bg-muted/30 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                {p.images?.[0]?.path ? (
                                  <img
                                    src={p.images[0].path}
                                    alt={p.name}
                                    className="w-10 h-12 object-cover rounded-md border border-border shrink-0"
                                  />
                                ) : (
                                  <div className="w-10 h-12 bg-muted rounded-md flex items-center justify-center text-[10px] text-muted-foreground shrink-0">
                                    No Pic
                                  </div>
                                )}

                                <div className="min-w-0">
                                  <span className="font-bold text-foreground text-xs block truncate">
                                    {p.name}
                                  </span>
                                  <div className="flex items-center gap-2 text-[10px] text-muted-foreground mt-0.5">
                                    {p.sku && <span>SKU: {p.sku}</span>}
                                    {p.category?.name && <span>&bull; {p.category.name}</span>}
                                    {p.activeOffer && (
                                      <Badge
                                        variant="destructive"
                                        className="text-[9px] py-0 px-1.5 bg-vermilion text-white uppercase"
                                      >
                                        {p.activeOffer.name}
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                              </div>

                              {/* Price & Variant Selection & Add Button */}
                              <div className="flex flex-wrap items-center gap-3 shrink-0 sm:justify-end">
                                <div className="text-right">
                                  <span className="text-xs font-black text-foreground block">
                                    {formatCurrency(displayPrice)}
                                  </span>
                                  {discPrice !== null && (
                                    <span className="text-[10px] text-muted-foreground line-through block">
                                      {formatCurrency(regPrice)}
                                    </span>
                                  )}
                                </div>

                                {hasVariants ? (
                                  <select
                                    id={`var-select-${p.id}`}
                                    defaultValue={variants[0]?.id}
                                    className="h-8 px-2 rounded-lg border border-border bg-card text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-royal-violet max-w-[150px]"
                                  >
                                    {variants.map((v: any) => (
                                      <option key={v.id} value={v.id}>
                                        {v.size || "Std"} / {v.color || "Std"}{" "}
                                        {v.stock !== null ? `(${v.stock} in stock)` : ""}
                                      </option>
                                    ))}
                                  </select>
                                ) : (
                                  <span className="text-[11px] text-muted-foreground">Standard</span>
                                )}

                                <Button
                                  type="button"
                                  size="sm"
                                  onClick={() => {
                                    const selectElem = document.getElementById(
                                      `var-select-${p.id}`
                                    ) as HTMLSelectElement | null;
                                    const chosenVarId = selectElem ? selectElem.value : variants[0]?.id;
                                    const chosenVar =
                                      variants.find((v: any) => v.id === chosenVarId) || variants[0];
                                    handleAddProductFromPicker(p, chosenVar, 1);
                                  }}
                                  className="h-8 text-xs font-bold bg-royal-violet hover:bg-royal-violet/90 text-white rounded-lg px-3 shadow-2xs flex items-center gap-1"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                  <span>Add</span>
                                </Button>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                )}

                {/* Items List */}
                <div className="space-y-3">
                  {items.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-lg border border-border/80 bg-paper/50 flex flex-wrap items-center gap-3 text-xs"
                    >
                      {item.image && (
                        <img
                          src={item.image}
                          alt={item.productName}
                          className="w-9 h-11 object-cover rounded border border-border shrink-0"
                        />
                      )}
                      <div className="flex-1 min-w-[180px]">
                        <label className="text-[10px] text-muted-foreground block">Product</label>
                        <Input
                          value={item.productName}
                          onChange={(e) => {
                            const val = e.target.value;
                            setItems((prev) =>
                              prev.map((it, i) => (i === idx ? { ...it, productName: val } : it))
                            );
                          }}
                          className="h-8 text-xs font-semibold"
                        />
                      </div>
                      <div className="w-20">
                        <label className="text-[10px] text-muted-foreground block">Size</label>
                        <Input
                          value={item.size || ""}
                          onChange={(e) => {
                            const val = e.target.value;
                            setItems((prev) =>
                              prev.map((it, i) => (i === idx ? { ...it, size: val } : it))
                            );
                          }}
                          className="h-8 text-xs font-bold"
                        />
                      </div>
                      <div className="w-24">
                        <label className="text-[10px] text-muted-foreground block">Colour</label>
                        <Input
                          value={item.color || ""}
                          onChange={(e) => {
                            const val = e.target.value;
                            setItems((prev) =>
                              prev.map((it, i) => (i === idx ? { ...it, color: val } : it))
                            );
                          }}
                          className="h-8 text-xs"
                        />
                      </div>
                      <div className="w-16">
                        <label className="text-[10px] text-muted-foreground block">Qty</label>
                        <Input
                          type="number"
                          min={1}
                          value={item.quantity}
                          onChange={(e) => {
                            const val = parseInt(e.target.value, 10) || 1;
                            setItems((prev) =>
                              prev.map((it, i) => (i === idx ? { ...it, quantity: val } : it))
                            );
                          }}
                          className="h-8 text-xs font-bold"
                        />
                      </div>
                      <div className="w-24">
                        <label className="text-[10px] text-muted-foreground block">Price (₹)</label>
                        <Input
                          type="number"
                          value={item.unitPrice}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            setItems((prev) =>
                              prev.map((it, i) => (i === idx ? { ...it, unitPrice: val } : it))
                            );
                          }}
                          className="h-8 text-xs font-bold"
                        />
                      </div>
                      <div className="text-right w-20 pt-3">
                        <span className="text-[10px] text-muted-foreground block">Line Total</span>
                        <span className="text-xs font-black text-foreground">
                          {formatCurrency(item.unitPrice * item.quantity)}
                        </span>
                      </div>
                      {items.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(idx)}
                          className="text-vermilion hover:text-vermilion/80 p-1 mt-4"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Payment Details & Negotiation Calculator */}
              <div className="space-y-4 p-4 bg-muted/40 rounded-xl border border-border">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-royal-violet">
                    3. Pricing, Negotiation &amp; Payment
                  </span>
                  <div className="flex items-center gap-1 bg-background p-0.5 rounded-lg border border-border text-[11px] font-bold">
                    <button
                      type="button"
                      onClick={() => setDiscountMode("amount")}
                      className={`px-2.5 py-1 rounded-md transition ${
                        discountMode === "amount"
                          ? "bg-royal-violet text-white"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      Flat Discount (₹)
                    </button>
                    <button
                      type="button"
                      onClick={() => setDiscountMode("percent")}
                      className={`px-2.5 py-1 rounded-md transition ${
                        discountMode === "percent"
                          ? "bg-royal-violet text-white"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      Percent Discount (%)
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="text-[11px] font-bold text-muted-foreground block mb-1">
                      Gross Subtotal
                    </label>
                    <div className="font-bold text-sm text-foreground">{formatCurrency(subtotal)}</div>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-muted-foreground block mb-1">
                      {discountMode === "percent" ? "Negotiated Discount (%)" : "Negotiated Discount (₹)"}
                    </label>
                    {discountMode === "percent" ? (
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="e.g. 10"
                          value={discountPercent}
                          onChange={(e) => setDiscountPercent(e.target.value)}
                          className="h-8 text-xs pr-6"
                        />
                        <span className="absolute right-2 top-2 text-[10px] text-muted-foreground">%</span>
                      </div>
                    ) : (
                      <div className="relative">
                        <Input
                          type="number"
                          placeholder="e.g. 300"
                          value={discountAmount}
                          onChange={(e) => setDiscountAmount(e.target.value)}
                          className="h-8 text-xs pl-5"
                        />
                        <span className="absolute left-2 top-2 text-[10px] text-muted-foreground">₹</span>
                      </div>
                    )}
                    <span className="text-[10px] text-vermilion font-semibold block mt-0.5">
                      -{formatCurrency(calculatedDiscount)} ({effectivePercent}%)
                    </span>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-muted-foreground block mb-1">
                      Shipping Charge (₹)
                    </label>
                    <Input
                      type="number"
                      value={shippingCharge}
                      onChange={(e) => setShippingCharge(e.target.value)}
                      className="h-8 text-xs"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-muted-foreground block mb-1">
                      Net Total Payable
                    </label>
                    <div className="font-extrabold text-base text-royal-violet">
                      {formatCurrency(total)}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-border/60">
                  <div>
                    <label className="text-[11px] font-bold text-muted-foreground block mb-1">
                      Advance Amount Received Now (₹)
                    </label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={initialPaymentAmount}
                      onChange={(e) => setInitialPaymentAmount(e.target.value)}
                      className="h-9 text-xs font-bold"
                    />
                    <span
                      className={`text-[10px] font-semibold block mt-1 ${
                        balanceDue === 0 ? "text-emerald-700 font-bold" : "text-vermilion"
                      }`}
                    >
                      {balanceDue === 0
                        ? "✓ Fully Settled"
                        : `Balance Due: ${formatCurrency(balanceDue)}`}
                    </span>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-muted-foreground block mb-1">
                      Payment Mode
                    </label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="w-full h-9 text-xs rounded-md border border-border bg-card px-2 text-foreground focus:outline-none"
                    >
                      <option value="UPI">UPI (GPay / PhonePe / Paytm)</option>
                      <option value="BANK_TRANSFER">Bank IMPS / NEFT</option>
                      <option value="CASH">Cash on Delivery</option>
                      <option value="OTHER">Other / QR</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-muted-foreground block mb-1">
                      UTR / Transaction Reference
                    </label>
                    <Input
                      placeholder="e.g. UPI/3948291048"
                      value={paymentRef}
                      onChange={(e) => setPaymentRef(e.target.value)}
                      className="h-9 text-xs font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsRegisterOpen(false)}>
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={registerMutation.isPending}
                  className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold"
                >
                  {registerMutation.isPending ? "Registering..." : "Confirm & Register Order"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filter Bar */}
      <div className="p-4 bg-card rounded-2xl border border-border shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search order ref, customer name, phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 h-9 text-xs"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs rounded-md border border-border bg-card px-3 py-1.5 text-foreground focus:outline-none"
          >
            <option value="">All Order Statuses</option>
            <option value="CONFIRMED">Confirmed</option>
            <option value="PROCESSING">Processing</option>
            <option value="PACKED">Packed</option>
            <option value="SHIPPED">Shipped</option>
            <option value="DELIVERED">Delivered</option>
            <option value="CANCELLED">Cancelled</option>
          </select>

          <select
            value={paymentStatusFilter}
            onChange={(e) => setPaymentStatusFilter(e.target.value)}
            className="text-xs rounded-md border border-border bg-card px-3 py-1.5 text-foreground focus:outline-none"
          >
            <option value="">All Payment Statuses</option>
            <option value="PAID">Paid</option>
            <option value="PARTIALLY_PAID">Partially Paid</option>
            <option value="UNPAID">Unpaid</option>
          </select>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-card rounded-2xl border border-border shadow-2xs overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order Reference</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Items</TableHead>
              <TableHead>Total Amount</TableHead>
              <TableHead>Paid / Balance</TableHead>
              <TableHead>Payment</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center py-8 text-xs text-muted-foreground">
                  Loading orders...
                </TableCell>
              </TableRow>
            ) : orders.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center py-8 text-xs text-muted-foreground">
                  No orders found. Click "Register Order" to add one.
                </TableCell>
              </TableRow>
            ) : (
              orders.map((o: any) => (
                <TableRow key={o.id}>
                  <TableCell>
                    <Link
                      href={`/admin/orders/${o.id}`}
                      className="font-mono font-bold text-xs text-royal-violet dark:text-[#C6F542] hover:underline"
                    >
                      {o.orderRef}
                    </Link>
                  </TableCell>
                  <TableCell className="text-xs">
                    <span className="font-bold text-foreground block">{o.customer?.name}</span>
                    <span className="text-muted-foreground text-[11px]">{o.customer?.phone}</span>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {formatDate(o.createdAt)}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground font-semibold">
                    {o.items?.length || 0} item(s)
                  </TableCell>
                  <TableCell className="text-xs font-bold text-foreground">
                    {formatCurrency(o.total)}
                  </TableCell>
                  <TableCell className="text-xs">
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold block">
                      {formatCurrency(o.amountPaid)}
                    </span>
                    {Number(o.balanceDue) > 0 && (
                      <span className="text-vermilion dark:text-rose-400 text-[10px] font-semibold">
                        Due: {formatCurrency(o.balanceDue)}
                      </span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        o.paymentStatus === "PAID"
                          ? "success"
                          : o.paymentStatus === "PARTIALLY_PAID"
                          ? "warning"
                          : "destructive"
                      }
                    >
                      {o.paymentStatus.replace(/_/g, " ")}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        o.status === "DELIVERED"
                          ? "success"
                          : o.status === "CANCELLED"
                          ? "destructive"
                          : "default"
                      }
                    >
                      {o.status.replace(/_/g, " ")}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <a
                        href={getInvoiceUrl(o.id, o.invoices?.[0]?.id, true)}
                        download
                        title="Download Invoice"
                        className="p-1.5 rounded-lg border border-border bg-card hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </a>
                      <a
                        href={getOrderWhatsAppUrl(o)}
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Share on WhatsApp"
                        className="p-1.5 rounded-lg border border-border bg-card hover:bg-emerald-50 dark:hover:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 transition-colors"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                      </a>
                      <button
                        type="button"
                        onClick={() => handleCopyOrderInvoice(o)}
                        title="Copy Invoice Link"
                        className="p-1.5 rounded-lg border border-border bg-card hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <Link
                        href={`/admin/orders/${o.id}`}
                        className="text-xs font-bold text-royal-violet dark:text-[#C6F542] hover:underline inline-flex items-center gap-1 pl-1"
                      >
                        Manage <ExternalLink className="w-3 h-3" />
                      </Link>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}


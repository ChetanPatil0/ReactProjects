"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import {
  LayoutDashboard,
  Shirt,
  FolderTree,
  Sparkles,
  ShoppingBag,
  CreditCard,
  FileText,
  Sliders,
  Tag,
  Settings,
  LogOut,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  User,
  BarChart3,
  HelpCircle,
} from "lucide-react";
import { ToastProvider } from "@/components/providers/toast-provider";
import { QueryProvider } from "@/components/providers/query-provider";
import { toast } from "sonner";
import { OneFamLogo } from "@/components/brand/onefam-logo";
import { ThemeToggle } from "@/components/theme/theme-toggle";

export default function AdminProtectedLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [collapsed, setCollapsed] = useState(false);
  const [adminUser, setAdminUser] = useState<{ name?: string; email?: string } | null>(null);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((res) => {
        if (!res.ok) {
          router.push("/admin/login");
          return null;
        }
        return res.json();
      })
      .then((data) => {
        if (data?.data) setAdminUser(data.data);
      })
      .catch(() => {
        router.push("/admin/login");
      });
  }, [router]);

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    toast.success("Logged out successfully");
    router.push("/admin/login");
  };

  const navSections = [
    {
      group: "WORKSPACE",
      items: [
        { label: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },
        { label: "Reports & Analytics", href: "/admin/reports", icon: BarChart3 },
        { label: "Products", href: "/admin/products", icon: Shirt },
        { label: "Categories", href: "/admin/categories", icon: FolderTree },
        { label: "Collections", href: "/admin/collections", icon: Sparkles },
      ],
    },
    {
      group: "OPERATIONS",
      items: [
        { label: "Orders", href: "/admin/orders", icon: ShoppingBag },
        { label: "Payments", href: "/admin/payments", icon: CreditCard },
        { label: "Invoices", href: "/admin/invoices", icon: FileText },
        { label: "Help & Inquiries", href: "/admin/inquiries", icon: HelpCircle },
      ],
    },
    {
      group: "MARKETING",
      items: [
        { label: "Hero Sliders", href: "/admin/hero-sliders", icon: Sliders },
        { label: "Offers & Discounts", href: "/admin/offers", icon: Tag },
      ],
    },
    {
      group: "CONFIGURATION",
      items: [
        { label: "Store Settings", href: "/admin/settings", icon: Settings },
        { label: "Invoice Templates", href: "/admin/invoice-templates", icon: FileText },
      ],
    },
  ];

  return (
    <QueryProvider>
      <div className="min-h-screen flex bg-background text-foreground selection:bg-royal-violet selection:text-white">
        {/* Compact Admin Sidebar */}
        <aside
          className={`sticky top-0 h-screen bg-ink text-paper flex flex-col justify-between transition-all duration-300 z-30 ${
            collapsed ? "w-20" : "w-64"
          } shrink-0 border-r border-ink/40`}
        >
          {/* Sidebar Top: Logo & Collapse Toggle */}
          <div>
            <div className="h-16 px-4 flex items-center justify-between border-b border-paper/10">
              {!collapsed ? (
                <div className="flex items-center gap-2">
                  <OneFamLogo variant="dark" size="sm" />
                </div>
              ) : (
                <div className="mx-auto">
                  <OneFamLogo variant="symbol-dark" size="sm" />
                </div>
              )}

              <button
                onClick={() => setCollapsed(!collapsed)}
                className="text-paper/60 hover:text-white p-1 rounded-md transition"
                aria-label="Toggle Sidebar"
              >
                {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
              </button>
            </div>

            {/* Navigation Sections */}
            <div className="p-3 space-y-6 overflow-y-auto max-h-[calc(100vh-140px)]">
              {navSections.map((section) => (
                <div key={section.group} className="space-y-1">
                  {!collapsed && (
                    <span className="px-3 text-[10px] font-extrabold tracking-widest text-paper/40 uppercase block mb-1">
                      {section.group}
                    </span>
                  )}
                  {section.items.map((item) => {
                    const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
                    const Icon = item.icon;
                    return (
                      <Link
                        key={item.href}
                        href={item.href}
                        title={collapsed ? item.label : undefined}
                        className={`flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                          isActive
                            ? "bg-royal-violet text-white shadow-xs"
                            : "text-paper/70 hover:bg-paper/10 hover:text-white"
                        }`}
                      >
                        <Icon className={`w-4 h-4 shrink-0 ${isActive ? "text-white" : "text-paper/60"}`} />
                        {!collapsed && <span>{item.label}</span>}
                      </Link>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>

          {/* Sidebar Bottom: User Profile & Actions */}
          <div className="p-3 border-t border-paper/10 space-y-2">
            <Link
              href="/"
              target="_blank"
              title="View Customer Storefront"
              className="flex items-center gap-2 px-3 py-2 text-xs font-medium text-paper/70 hover:text-electric-lime transition"
            >
              <ExternalLink className="w-4 h-4 shrink-0" />
              {!collapsed && <span>Storefront</span>}
            </Link>

            <div className="pt-1 flex items-center justify-between px-2">
              <div className="flex items-center gap-2 overflow-hidden">
                <div className="w-7 h-7 rounded-full bg-paper/20 flex items-center justify-center shrink-0">
                  <User className="w-3.5 h-3.5 text-paper" />
                </div>
                {!collapsed && (
                  <div className="overflow-hidden">
                    <span className="text-xs font-bold text-paper block truncate">
                      {adminUser?.name || "Administrator"}
                    </span>
                    <span className="text-[10px] text-paper/50 block truncate">
                      {adminUser?.email || "Staff"}
                    </span>
                  </div>
                )}
              </div>

              <button
                onClick={handleLogout}
                title="Sign out"
                className="text-paper/60 hover:text-vermilion p-1.5 rounded-md transition"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </aside>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
          {/* Top Admin Bar */}
          <header className="h-16 bg-card border-b border-border px-6 flex items-center justify-between sticky top-0 z-20 shadow-2xs">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold tracking-wider uppercase text-royal-violet">
                Atelier System
              </span>
              <span className="text-muted-foreground text-xs">/</span>
              <span className="text-xs font-semibold text-ink capitalize">
                {pathname.split("/").pop()?.replace(/-/g, " ") || "Dashboard"}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <ThemeToggle variant="dropdown" />
              <Link
                href="/admin/orders"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-royal-violet/10 text-royal-violet hover:bg-royal-violet/20 font-bold text-xs transition"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                Orders
              </Link>
            </div>
          </header>

          {/* Page Body */}
          <main className="p-6 sm:p-8 flex-1">{children}</main>
        </div>

        <ToastProvider />
      </div>
    </QueryProvider>
  );
}


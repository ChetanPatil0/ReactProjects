export default function AdminLoading() {
  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16 animate-pulse">
      {/* Top Bar Skeleton */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-2">
          <div className="h-7 w-48 bg-muted rounded-xl" />
          <div className="h-3 w-80 bg-muted/60 rounded-md" />
        </div>
        <div className="h-9 w-32 bg-muted rounded-xl" />
      </div>

      {/* Table Skeleton */}
      <div className="bg-card rounded-2xl border border-border/80 shadow-2xs overflow-hidden p-6 space-y-4">
        <div className="flex items-center justify-between pb-4 border-b border-border/40">
          <div className="h-8 w-60 bg-muted rounded-lg" />
          <div className="h-8 w-28 bg-muted rounded-lg" />
        </div>

        <div className="space-y-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-12 w-full bg-muted/40 rounded-xl flex items-center px-4 gap-4">
              <div className="w-8 h-8 rounded-lg bg-muted/70" />
              <div className="h-4 w-40 bg-muted/70 rounded-md" />
              <div className="h-4 w-24 bg-muted/50 rounded-md ml-auto" />
              <div className="h-6 w-16 bg-muted/60 rounded-full" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


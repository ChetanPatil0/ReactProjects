"use client";

import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { ImageUploader, uploadImageFile } from "@/components/shared/image-uploader";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import {
  Plus,
  Sparkles,
  ExternalLink,
  MoreHorizontal,
  PackagePlus,
  Trash2,
  AlertTriangle,
  Search,
  Pencil,
  GripVertical,
  ChevronUp,
  ChevronDown,
  Copy,
} from "lucide-react";
import { toast } from "sonner";

export default function AdminCollectionsPage() {
  const queryClient = useQueryClient();

  // Create Modal State
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [slug, setSlug] = useState("");
  const [description, setDescription] = useState("");
  const [coverImage, setCoverImage] = useState("");
  const [coverImageFile, setCoverImageFile] = useState<File | null>(null);
  const [isActive, setIsActive] = useState(true);
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  // Validation Errors state
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Edit Collection Modal State
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingCollection, setEditingCollection] = useState<any>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editSlug, setEditSlug] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editCoverImage, setEditCoverImage] = useState("");
  const [editCoverImageFile, setEditCoverImageFile] = useState<File | null>(null);
  const [editIsActive, setEditIsActive] = useState(true);
  const [editIsUploadingImage, setEditIsUploadingImage] = useState(false);
  const [editErrors, setEditErrors] = useState<{ [key: string]: string }>({});

  // Product Assignment Modal State
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [selectedCollectionForProducts, setSelectedCollectionForProducts] = useState<any>(null);
  const [allProducts, setAllProducts] = useState<any[]>([]);
  const [assignedProductIds, setAssignedProductIds] = useState<string[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(false);
  const [productSearch, setProductSearch] = useState("");

  // Delete Confirmation Modal State (Pop Modal)
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [collectionToDelete, setCollectionToDelete] = useState<any>(null);

  // Drag and drop & ordering state
  const [orderedCollections, setOrderedCollections] = useState<any[]>([]);
  const [draggedColId, setDraggedColId] = useState<string | null>(null);
  const [dragOverColId, setDragOverColId] = useState<string | null>(null);

  const { data: collections = [], isLoading } = useQuery({
    queryKey: queryKeys.collections.all,
    queryFn: () => apiClient.get("/collections"),
  });

  useEffect(() => {
    if (collections && Array.isArray(collections)) {
      setOrderedCollections(collections);
    }
  }, [collections]);

  const toggleActiveMutation = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) =>
      apiClient.patch(`/collections/${id}`, { isActive }),
    onSuccess: () => {
      toast.success("Collection status updated");
      queryClient.invalidateQueries({ queryKey: queryKeys.collections.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const reorderMutation = useMutation({
    mutationFn: (items: Array<{ id: string; order: number }>) =>
      apiClient.post("/collections/reorder", { items }),
    onSuccess: () => {
      toast.success("Collection display order saved");
      queryClient.invalidateQueries({ queryKey: queryKeys.collections.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const createMutation = useMutation({
    mutationFn: (body: any) => apiClient.post("/collections", body),
    onSuccess: () => {
      toast.success("Collection created successfully");
      setIsAddOpen(false);
      resetAddForm();
      queryClient.invalidateQueries({ queryKey: queryKeys.collections.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: any }) =>
      apiClient.patch(`/collections/${id}`, payload),
    onSuccess: () => {
      toast.success("Collection updated successfully");
      setIsEditOpen(false);
      setEditingCollection(null);
      queryClient.invalidateQueries({ queryKey: queryKeys.collections.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiClient.delete(`/collections/${id}`),
    onSuccess: () => {
      toast.success("Collection deleted successfully");
      setDeleteModalOpen(false);
      setCollectionToDelete(null);
      queryClient.invalidateQueries({ queryKey: queryKeys.collections.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const saveProductsMutation = useMutation({
    mutationFn: ({ id, productIds }: { id: string; productIds: string[] }) =>
      apiClient.post(`/collections/${id}/products`, { productIds }),
    onSuccess: (res: any) => {
      toast.success(res?.message || "Assigned products updated!");
      setAssignModalOpen(false);
      setSelectedCollectionForProducts(null);
      queryClient.invalidateQueries({ queryKey: queryKeys.collections.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const resetAddForm = () => {
    setTitle("");
    setSlug("");
    setDescription("");
    setCoverImage("");
    setCoverImageFile(null);
    setIsActive(true);
    setIsUploadingImage(false);
    setErrors({});
  };

  const handleTitleChange = (val: string) => {
    setTitle(val);
    const generatedSlug = val
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)+/g, "");
    setSlug(generatedSlug);

    if (!val.trim()) {
      setErrors((prev) => ({ ...prev, title: "Collection title is required" }));
    } else {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy.title;
        delete copy.slug;
        return copy;
      });
    }
  };

  const handleSlugBlur = () => {
    if (!slug.trim()) {
      setErrors((prev) => ({ ...prev, slug: "Slug is required" }));
    } else {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy.slug;
        return copy;
      });
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { [key: string]: string } = {};
    if (!title.trim()) newErrors.title = "Collection title is required";
    if (!slug.trim()) newErrors.slug = "URL slug is required";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    let finalCover = coverImage;
    if (coverImageFile) {
      setIsUploadingImage(true);
      try {
        const uploadResult = await uploadImageFile(coverImageFile);
        finalCover = uploadResult.url;
      } catch (err: any) {
        setIsUploadingImage(false);
        toast.error(err.message || "Failed to upload collection cover image");
        return;
      }
      setIsUploadingImage(false);
    }

    createMutation.mutate({
      title: title.trim(),
      slug: slug.trim(),
      description: description.trim() || null,
      coverImage: finalCover.trim() || null, // Image NOT required!
      isActive,
    });
  };

  // Drag and drop & manual move handlers
  const handleDragStart = (id: string) => {
    setDraggedColId(id);
  };

  const handleDragOver = (e: React.DragEvent, id: string) => {
    e.preventDefault();
    if (dragOverColId !== id) {
      setDragOverColId(id);
    }
  };

  const handleDrop = (targetId: string) => {
    if (!draggedColId || draggedColId === targetId) {
      setDraggedColId(null);
      setDragOverColId(null);
      return;
    }

    const fromIndex = orderedCollections.findIndex((c) => c.id === draggedColId);
    const toIndex = orderedCollections.findIndex((c) => c.id === targetId);

    if (fromIndex !== -1 && toIndex !== -1) {
      const newItems = [...orderedCollections];
      const [moved] = newItems.splice(fromIndex, 1);
      newItems.splice(toIndex, 0, moved);
      setOrderedCollections(newItems);

      const payload = newItems.map((c, idx) => ({
        id: c.id,
        order: idx + 1,
      }));
      reorderMutation.mutate(payload);
    }

    setDraggedColId(null);
    setDragOverColId(null);
  };

  const handleMove = (index: number, direction: "up" | "down") => {
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= orderedCollections.length) return;

    const newItems = [...orderedCollections];
    const [moved] = newItems.splice(index, 1);
    newItems.splice(targetIndex, 0, moved);
    setOrderedCollections(newItems);

    const payload = newItems.map((c, idx) => ({
      id: c.id,
      order: idx + 1,
    }));
    reorderMutation.mutate(payload);
  };

  // Open Edit Modal with prefilled collection data
  const handleOpenEdit = (col: any) => {
    setEditingCollection(col);
    setEditTitle(col.title || "");
    setEditSlug(col.slug || "");
    setEditDescription(col.description || "");
    setEditCoverImage(col.coverImage || "");
    setEditCoverImageFile(null);
    setEditIsActive(col.isActive !== false);
    setEditErrors({});
    setIsEditOpen(true);
  };

  const handleUpdateCollection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCollection) return;

    const newErrors: { [key: string]: string } = {};
    if (!editTitle.trim()) newErrors.title = "Collection title is required";
    if (!editSlug.trim()) newErrors.slug = "URL slug is required";

    if (Object.keys(newErrors).length > 0) {
      setEditErrors(newErrors);
      return;
    }

    let finalCover = editCoverImage;
    if (editCoverImageFile) {
      setEditIsUploadingImage(true);
      try {
        const uploadResult = await uploadImageFile(editCoverImageFile);
        finalCover = uploadResult.url;
      } catch (err: any) {
        setEditIsUploadingImage(false);
        toast.error(err.message || "Failed to upload collection cover image");
        return;
      }
      setEditIsUploadingImage(false);
    }

    updateMutation.mutate({
      id: editingCollection.id,
      payload: {
        title: editTitle.trim(),
        slug: editSlug.trim(),
        description: editDescription.trim() || null,
        coverImage: finalCover.trim() || null,
        isActive: editIsActive,
      },
    });
  };

  // Open Manage Products Modal
  const handleOpenAssignModal = async (col: any) => {
    setSelectedCollectionForProducts(col);
    setLoadingProducts(true);
    setAssignModalOpen(true);
    try {
      const data = await apiClient.get(`/collections/${col.id}/products`);
      setAllProducts(data.allProducts || []);
      setAssignedProductIds(data.assignedProductIds || []);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoadingProducts(false);
    }
  };

  const toggleProductAssignment = (productId: string) => {
    setAssignedProductIds((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  const handleSaveAssignedProducts = () => {
    if (!selectedCollectionForProducts) return;
    saveProductsMutation.mutate({
      id: selectedCollectionForProducts.id,
      productIds: assignedProductIds,
    });
  };

  const filteredProducts = allProducts.filter((p) =>
    p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
    (p.sku && p.sku.toLowerCase().includes(productSearch.toLowerCase()))
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-ink">
            Signature Collections &amp; Lookbooks
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Curate thematic capsules (e.g. Urban Minimalist, Festive Bloom). Attach or remove styles easily.
          </p>
        </div>

        <Button
          onClick={() => {
            resetAddForm();
            setIsAddOpen(true);
          }}
          size="sm"
          className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl text-xs"
        >
          <Plus className="w-4 h-4 mr-1.5" />
          New Collection
        </Button>
      </div>

      {/* Collections Table with Actions Dropdown */}
      <div className="bg-white rounded-2xl border border-border shadow-2xs overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-20">Order</TableHead>
              <TableHead>Collection</TableHead>
              <TableHead>Slug</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Assigned Products</TableHead>
              <TableHead className="w-36">Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-xs text-muted-foreground">
                  Loading collections...
                </TableCell>
              </TableRow>
            ) : orderedCollections.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-xs text-muted-foreground">
                  No collections created yet. Click "New Collection" to create one.
                </TableCell>
              </TableRow>
            ) : (
              orderedCollections.map((col: any, idx: number) => {
                const isDragTarget = dragOverColId === col.id && draggedColId !== col.id;
                return (
                  <TableRow
                    key={col.id}
                    draggable
                    onDragStart={() => handleDragStart(col.id)}
                    onDragOver={(e) => handleDragOver(e, col.id)}
                    onDrop={() => handleDrop(col.id)}
                    onDragEnd={() => {
                      setDraggedColId(null);
                      setDragOverColId(null);
                    }}
                    className={`transition-colors duration-150 ${
                      isDragTarget
                        ? "border-t-2 border-royal-violet bg-royal-violet/10"
                        : ""
                    } ${draggedColId === col.id ? "opacity-50" : ""}`}
                  >
                    {/* Drag Handle & Order Controls */}
                    <TableCell>
                      <div className="flex items-center gap-1.5 select-none">
                        <button
                          type="button"
                          className="cursor-grab active:cursor-grabbing p-1 text-muted-foreground hover:text-royal-violet rounded transition-colors"
                          title="Drag to change collection display position"
                        >
                          <GripVertical className="w-4 h-4" />
                        </button>
                        <span className="font-mono text-[11px] font-bold text-muted-foreground">
                          #{idx + 1}
                        </span>
                        <div className="flex flex-col">
                          <button
                            type="button"
                            onClick={() => handleMove(idx, "up")}
                            disabled={idx === 0}
                            className="p-0.5 text-muted-foreground hover:text-royal-violet disabled:opacity-30 disabled:hover:text-muted-foreground"
                            title="Move collection up"
                          >
                            <ChevronUp className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleMove(idx, "down")}
                            disabled={idx === orderedCollections.length - 1}
                            className="p-0.5 text-muted-foreground hover:text-royal-violet disabled:opacity-30 disabled:hover:text-muted-foreground"
                            title="Move collection down"
                          >
                            <ChevronDown className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </TableCell>

                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-10 rounded-lg bg-muted overflow-hidden shrink-0 border border-border">
                          {col.coverImage ? (
                            <img
                              src={col.coverImage}
                              alt={col.title}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-muted-foreground text-[10px]">
                              No Img
                            </div>
                          )}
                        </div>
                        <div>
                          <span className="font-bold text-xs text-ink block">{col.title}</span>
                          <span className="text-[10px] text-muted-foreground">
                            {col._count?.products || 0} styles assigned
                          </span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      /collections/{col.slug}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground max-w-sm line-clamp-1">
                      {col.description || "-"}
                    </TableCell>
                    <TableCell className="text-xs font-bold text-ink">
                      {col._count?.products || 0} styles
                    </TableCell>

                    {/* Active Status 1-Click Toggle Switch */}
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={col.isActive !== false}
                          onCheckedChange={(checked) =>
                            toggleActiveMutation.mutate({ id: col.id, isActive: checked })
                          }
                          aria-label={`Toggle active for ${col.title}`}
                        />
                        <Badge variant={col.isActive !== false ? "success" : "secondary"} className="text-[10px]">
                          {col.isActive !== false ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                    </TableCell>

                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48 text-xs">
                          <DropdownMenuItem
                            onClick={() => handleOpenEdit(col)}
                            className="cursor-pointer font-medium"
                          >
                            <Pencil className="w-3.5 h-3.5 mr-2 text-royal-violet" />
                            Edit Collection
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => handleOpenAssignModal(col)}
                            className="cursor-pointer font-medium"
                          >
                            <PackagePlus className="w-3.5 h-3.5 mr-2 text-royal-violet" />
                            Manage Products
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => {
                              navigator.clipboard.writeText(col.id);
                              toast.success("Collection ID copied to clipboard");
                            }}
                            className="cursor-pointer font-medium"
                          >
                            <Copy className="w-3.5 h-3.5 mr-2 text-muted-foreground" />
                            Copy ID
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild className="cursor-pointer">
                            <a href={`/collections/${col.slug}`} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="w-3.5 h-3.5 mr-2" />
                              Preview on Store
                            </a>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => {
                              setCollectionToDelete(col);
                              setDeleteModalOpen(true);
                            }}
                            className="cursor-pointer text-vermilion focus:text-vermilion focus:bg-rose-50"
                          >
                            <Trash2 className="w-3.5 h-3.5 mr-2" />
                            Delete Collection
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add Collection Dialog */}
      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Create New Fashion Collection</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleCreate} className="space-y-4 pt-2 text-xs">
            {/* Title */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Collection Title <span className="text-vermilion">*</span>
              </label>
              <Input
                placeholder="e.g. Resort & Linen Edit"
                value={title}
                onChange={(e) => handleTitleChange(e.target.value)}
                className={`h-10 text-xs ${errors.title ? "border-vermilion" : ""}`}
              />
              {errors.title && (
                <p className="text-[11px] text-vermilion font-medium mt-1">{errors.title}</p>
              )}
            </div>

            {/* Slug */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                URL Slug <span className="text-vermilion">*</span>
              </label>
              <Input
                placeholder="resort-linen-edit"
                value={slug}
                onChange={(e) => setSlug(e.target.value)}
                onBlur={handleSlugBlur}
                className={`h-10 text-xs font-mono ${errors.slug ? "border-vermilion" : ""}`}
              />
              {errors.slug && (
                <p className="text-[11px] text-vermilion font-medium mt-1">{errors.slug}</p>
              )}
            </div>

            {/* Image is NOT required as user instructed */}
            <ImageUploader
              value={coverImage}
              onChange={setCoverImage}
              onFileSelect={setCoverImageFile}
              label="Cover Image (Optional — Not Required)"
              required={false}
            />

            {/* Description */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Description (Optional)
              </label>
              <Input
                placeholder="Atmospheric summary of the collection mood."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="h-10 text-xs"
              />
            </div>

            {/* Active Status Switch */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-muted/20 border border-border">
              <div>
                <label className="font-bold text-xs text-ink block">
                  Active on Storefront
                </label>
                <p className="text-[11px] text-muted-foreground">
                  When active, this collection is visible to shoppers and featured on homepage.
                </p>
              </div>
              <Switch
                checked={isActive}
                onCheckedChange={setIsActive}
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => { setIsAddOpen(false); resetAddForm(); }}>
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || isUploadingImage}
                className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold"
              >
                {isUploadingImage
                  ? "Uploading Image..."
                  : createMutation.isPending
                  ? "Creating..."
                  : "Save Collection"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* EDIT Collection Modal */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="w-5 h-5 text-royal-violet" />
              Edit Collection
            </DialogTitle>
            <DialogDescription className="text-xs">
              Update collection title, slug, atmosphere description, cover photo, and status.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleUpdateCollection} className="space-y-4 pt-2 text-xs">
            {/* Title */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Collection Title <span className="text-vermilion">*</span>
              </label>
              <Input
                placeholder="e.g. Resort Linen &amp; Silk Edit"
                value={editTitle}
                onChange={(e) => {
                  setEditTitle(e.target.value);
                  if (e.target.value.trim()) {
                    setEditErrors((prev) => {
                      const copy = { ...prev };
                      delete copy.title;
                      return copy;
                    });
                  }
                }}
                className={`h-10 text-xs ${editErrors.title ? "border-vermilion" : ""}`}
              />
              {editErrors.title && (
                <p className="text-[11px] text-vermilion font-medium mt-1">{editErrors.title}</p>
              )}
            </div>

            {/* URL Slug */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                URL Slug <span className="text-vermilion">*</span>
              </label>
              <Input
                placeholder="resort-linen-edit"
                value={editSlug}
                onChange={(e) => {
                  setEditSlug(e.target.value);
                  if (e.target.value.trim()) {
                    setEditErrors((prev) => {
                      const copy = { ...prev };
                      delete copy.slug;
                      return copy;
                    });
                  }
                }}
                className={`h-10 text-xs font-mono ${editErrors.slug ? "border-vermilion" : ""}`}
              />
              {editErrors.slug && (
                <p className="text-[11px] text-vermilion font-medium mt-1">{editErrors.slug}</p>
              )}
            </div>

            {/* Cover Image */}
            <ImageUploader
              value={editCoverImage}
              onChange={setEditCoverImage}
              onFileSelect={setEditCoverImageFile}
              label="Cover Image (Optional)"
              required={false}
            />

            {/* Description */}
            <div>
              <label className="font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Description (Optional)
              </label>
              <Input
                placeholder="Atmospheric summary of the collection mood."
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                className="h-10 text-xs"
              />
            </div>

            {/* Active Status Toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl border border-border bg-muted/20">
              <div>
                <span className="text-xs font-bold text-ink block">Collection Visibility</span>
                <span className="text-[11px] text-muted-foreground">
                  {editIsActive ? "Visible on customer storefront" : "Hidden from customer storefront"}
                </span>
              </div>
              <Button
                type="button"
                variant={editIsActive ? "default" : "outline"}
                size="sm"
                onClick={() => setEditIsActive(!editIsActive)}
                className={editIsActive ? "bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold" : "text-xs"}
              >
                {editIsActive ? "Active" : "Hidden"}
              </Button>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setIsEditOpen(false)}>
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={updateMutation.isPending || editIsUploadingImage}
                className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold"
              >
                {editIsUploadingImage
                  ? "Uploading Image..."
                  : updateMutation.isPending
                  ? "Saving Changes..."
                  : "Save Changes"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Modal: Attach / Manage Products for Collection */}
      <Dialog open={assignModalOpen} onOpenChange={setAssignModalOpen}>
        <DialogContent className="max-w-xl max-h-[85vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>
              Manage Products in "{selectedCollectionForProducts?.title}"
            </DialogTitle>
            <DialogDescription className="text-xs">
              Check products to add them to this signature lookbook collection, or uncheck to remove them.
            </DialogDescription>
          </DialogHeader>

          <div className="py-2">
            <div className="relative mb-3">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search products by title or SKU..."
                value={productSearch}
                onChange={(e) => setProductSearch(e.target.value)}
                className="pl-9 h-9 text-xs"
              />
            </div>

            <div className="max-h-72 overflow-y-auto divide-y divide-border/60 border border-border rounded-xl">
              {loadingProducts ? (
                <p className="text-xs text-muted-foreground p-6 text-center">Loading catalogue products...</p>
              ) : filteredProducts.length === 0 ? (
                <p className="text-xs text-muted-foreground p-6 text-center">No matching products found.</p>
              ) : (
                filteredProducts.map((p) => {
                  const isChecked = assignedProductIds.includes(p.id);
                  return (
                    <div
                      key={p.id}
                      onClick={() => toggleProductAssignment(p.id)}
                      className={`p-3 flex items-center justify-between text-xs cursor-pointer transition ${
                        isChecked ? "bg-violet-50/60" : "hover:bg-muted/40"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}} // handled by parent div
                          className="rounded text-royal-violet focus:ring-royal-violet cursor-pointer"
                        />
                        <div>
                          <span className="font-bold text-ink block">{p.name}</span>
                          <span className="text-[11px] text-muted-foreground font-mono">
                            {p.sku || "No SKU"}
                          </span>
                        </div>
                      </div>
                      <span className="font-semibold text-ink">₹{Number(p.regularPrice)}</span>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <DialogFooter className="pt-2">
            <Button variant="outline" size="sm" onClick={() => setAssignModalOpen(false)}>
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleSaveAssignedProducts}
              disabled={saveProductsMutation.isPending}
              className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold"
            >
              {saveProductsMutation.isPending ? "Saving..." : `Save Assigned (${assignedProductIds.length})`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Modal (Pop Modal) */}
      <Dialog open={deleteModalOpen} onOpenChange={setDeleteModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="w-10 h-10 rounded-full bg-rose-50 text-vermilion flex items-center justify-center mb-2">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <DialogTitle>Delete Collection</DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground">
              Are you sure you want to delete collection <strong>"{collectionToDelete?.title}"</strong>? The products themselves will remain in your catalogue.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="pt-2">
            <Button variant="outline" size="sm" onClick={() => setDeleteModalOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              size="sm"
              disabled={deleteMutation.isPending}
              onClick={() => collectionToDelete && deleteMutation.mutate(collectionToDelete.id)}
            >
              {deleteMutation.isPending ? "Deleting..." : "Confirm Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

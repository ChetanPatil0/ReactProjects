"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { formatCurrency } from "@/lib/formatters";
import { apiClient } from "@/lib/api-client";
import { Button } from "@/components/ui/button";
import {
  BarChart3,
  TrendingUp,
  DollarSign,
  ShoppingBag,
  CreditCard,
  Download,
  Calendar,
  Layers,
  Sparkles,
} from "lucide-react";
import {
  RevenueTrendChart,
  OrderStatusDonutChart,
  PaymentMethodsChart,
  TopProductsTable,
} from "@/components/admin/charts/analytics-charts";
import { toast } from "sonner";

export default function AdminReportsPage() {
  const [range, setRange] = useState<"7d" | "30d" | "90d" | "all">("30d");

  const { data, isLoading } = useQuery({
    queryKey: ["admin-reports", range],
    queryFn: () => apiClient.get(`/reports?range=${range}`),
  });

  const analytics = data || {
    kpis: {
      totalRevenue: 0,
      totalPaid: 0,
      totalBalance: 0,
      totalOrders: 0,
      averageOrderValue: 0,
      totalUnitsSold: 0,
    },
    revenueTrend: [],
    statusBreakdown: [],
    paymentMethods: [],
    topSellingProducts: [],
  };

  const handleExportReport = () => {
    try {
      const exportData = {
        generatedAt: new Date().toISOString(),
        reportingPeriod: range,
        kpiSummary: analytics.kpis,
        revenueTrend: analytics.revenueTrend,
        fulfillmentStatus: analytics.statusBreakdown,
        paymentDistribution: analytics.paymentMethods,
        topSellingGarments: analytics.topSellingProducts,
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `OneFam-Analytics-Report-${range}-${new Date().toISOString().split("T")[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Analytics executive report downloaded successfully!");
    } catch {
      toast.error("Failed to generate export report.");
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      {/* Top Header & Range Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-widest text-royal-violet dark:text-[#C6F542] flex items-center gap-1.5">
              <BarChart3 className="w-3.5 h-3.5" />
              Intelligence &amp; Metrics
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-foreground mt-0.5">
            Reports &amp; Sales Analytics
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            Financial revenue velocity, workshop fulfillment metrics and best-performing designs.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Time Range Pills */}
          <div className="flex items-center bg-card p-1 rounded-xl border border-border text-xs font-bold">
            {(
              [
                { key: "7d", label: "Last 7 Days" },
                { key: "30d", label: "Last 30 Days" },
                { key: "90d", label: "Last 90 Days" },
                { key: "all", label: "All Time" },
              ] as const
            ).map((tab) => (
              <button
                key={tab.key}
                onClick={() => setRange(tab.key)}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  range === tab.key
                    ? "bg-royal-violet text-white shadow-xs"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <Button
            size="sm"
            variant="outline"
            onClick={handleExportReport}
            className="rounded-xl font-bold text-xs border-border bg-card hover:bg-muted"
          >
            <Download className="w-3.5 h-3.5 mr-1.5" />
            Export JSON
          </Button>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* KPI 1: Gross Sales */}
        <div className="p-5 rounded-2xl bg-card border border-border shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-muted-foreground">
            <span className="text-[11px] font-bold uppercase tracking-wider">Gross Turnover</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-foreground">
            {formatCurrency(analytics.kpis.totalRevenue)}
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">
            Collected: {formatCurrency(analytics.kpis.totalPaid)}
          </div>
        </div>

        {/* KPI 2: Outstanding Balance */}
        <div className="p-5 rounded-2xl bg-card border border-border shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-muted-foreground">
            <span className="text-[11px] font-bold uppercase tracking-wider">Outstanding Due</span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-vermilion dark:text-rose-400">
            {formatCurrency(analytics.kpis.totalBalance)}
          </div>
          <div className="text-[11px] text-muted-foreground">
            Pending balance reconciliation
          </div>
        </div>

        {/* KPI 3: Orders Count & AOV */}
        <div className="p-5 rounded-2xl bg-card border border-border shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-muted-foreground">
            <span className="text-[11px] font-bold uppercase tracking-wider">Total Orders</span>
            <div className="w-8 h-8 rounded-lg bg-violet-500/10 text-royal-violet dark:text-[#C6F542] flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-foreground">
            {analytics.kpis.totalOrders}
          </div>
          <div className="text-[11px] text-muted-foreground font-semibold">
            AOV: {formatCurrency(analytics.kpis.averageOrderValue)}
          </div>
        </div>

        {/* KPI 4: Units Sold */}
        <div className="p-5 rounded-2xl bg-card border border-border shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-muted-foreground">
            <span className="text-[11px] font-bold uppercase tracking-wider">Garments Dispatched</span>
            <div className="w-8 h-8 rounded-lg bg-lime-500/10 text-emerald-600 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-foreground">
            {analytics.kpis.totalUnitsSold}
          </div>
          <div className="text-[11px] text-muted-foreground">
            Individual items across orders
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="h-64 rounded-2xl bg-card border border-border animate-pulse flex items-center justify-center text-xs text-muted-foreground">
          Aggregating financial reports...
        </div>
      ) : (
        <>
          {/* Main Revenue Trend Chart */}
          <RevenueTrendChart
            data={analytics.revenueTrend}
            title={`Sales Velocity (${range.toUpperCase()})`}
            subtitle="Gross daily turnover and order volume over the selected window"
          />

          {/* 2-Column Split: Fulfillment Status & Payment Methods */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <OrderStatusDonutChart data={analytics.statusBreakdown} />
            <PaymentMethodsChart data={analytics.paymentMethods} />
          </div>

          {/* Top Selling Garments Leaderboard */}
          <TopProductsTable data={analytics.topSellingProducts} />
        </>
      )}
    </div>
  );
}


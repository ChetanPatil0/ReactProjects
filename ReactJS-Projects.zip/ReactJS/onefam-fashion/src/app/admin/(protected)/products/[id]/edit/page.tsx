"use client";

import { use } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { ProductForm } from "@/components/admin/product-form";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function EditProductPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const queryClient = useQueryClient();

  const { data: product, isLoading, error } = useQuery({
    queryKey: ["products", id],
    queryFn: () => apiClient.get(`/products/${id}`),
  });

  const updateMutation = useMutation({
    mutationFn: (body: any) => apiClient.patch(`/products/${id}`, body),
    onSuccess: () => {
      toast.success("Product updated successfully!");
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
      queryClient.invalidateQueries({ queryKey: ["products", id] });
    },
    onError: (err: any) => toast.error(err.message || "Failed to update product"),
  });

  const handleSave = async (data: any) => {
    await updateMutation.mutateAsync(data);
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] text-muted-foreground gap-2">
        <Loader2 className="w-8 h-8 animate-spin text-royal-violet" />
        <span className="text-xs font-semibold">Loading product details...</span>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="py-12 text-center text-muted-foreground">
        <p className="text-sm font-bold text-vermilion">Failed to load product.</p>
      </div>
    );
  }

  return (
    <div className="py-2">
      <ProductForm initialData={product} isEditing={true} onSave={handleSave} />
    </div>
  );
}


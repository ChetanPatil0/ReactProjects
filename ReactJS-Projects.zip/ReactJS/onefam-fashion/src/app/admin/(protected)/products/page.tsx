"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import {
  Plus,
  Search,
  Trash2,
  CheckCircle,
  EyeOff,
  Shirt,
  AlertTriangle,
  Pencil,
  Sparkles,
  FileCode2,
  Download,
} from "lucide-react";
import { toast } from "sonner";

export default function AdminProductsPage() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Delete modal state
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState<any>(null);

  // Dedicated Separate Page Navigation for Edit Fashion Product
  const handleOpenEdit = (product: any) => {
    router.push(`/admin/products/${product.id}/edit`);
  };

  const handleUpdateProduct = async (id: string, data: any) => {
    return apiClient.patch(`/products/${id}`, data);
  };

  // Fetch products
  const { data, isLoading } = useQuery({
    queryKey: queryKeys.products.list({ search, status: statusFilter }),
    queryFn: () =>
      apiClient.get(
        `/products?${new URLSearchParams({
          ...(search ? { search } : {}),
          ...(statusFilter ? { status: statusFilter } : {}),
          limit: "50",
        }).toString()}`
      ),
  });

  const products = data?.products || [];

  // Bulk mutation
  const bulkMutation = useMutation({
    mutationFn: (payload: { action: string; productIds: string[]; status?: string }) =>
      apiClient.post("/products/bulk", payload),
    onSuccess: (res: any) => {
      toast.success(res?.message || "Bulk action completed");
      setSelectedIds([]);
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  // Single Delete Mutation
  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiClient.delete(`/products/${id}`),
    onSuccess: () => {
      toast.success("Product deleted successfully");
      setDeleteModalOpen(false);
      setProductToDelete(null);
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
    onError: (err: any) => toast.error(err.message),
  });

  // Toggle selection
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedIds(products.map((p: any) => p.id));
    } else {
      setSelectedIds([]);
    }
  };

  const handleSelectOne = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedIds((prev) => [...prev, id]);
    } else {
      setSelectedIds((prev) => prev.filter((item) => item !== id));
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-ink dark:text-foreground flex items-center gap-2">
            <Shirt className="w-6 h-6 text-royal-violet" />
            Products Catalogue
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Manage your fashion pieces, multi-variant combinations, pricing, and merchandising flags.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <Button
            asChild
            variant="outline"
            size="sm"
            className="text-xs font-semibold rounded-xl"
            title="Export full catalogue in JSON format"
          >
            <a href="/api/products/export" download>
              <Download className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
              Export JSON
            </a>
          </Button>

          <Button
            asChild
            variant="outline"
            size="sm"
            className="text-xs font-bold rounded-xl border-royal-violet/30 text-royal-violet hover:bg-royal-violet/10"
          >
            <Link href="/admin/products/bulk">
              <FileCode2 className="w-4 h-4 mr-1.5" />
              Bulk Setup (JSON)
            </Link>
          </Button>

          {/* Separate Page Link for Creating Product (No Modal!) */}
          <Button
            asChild
            size="sm"
            className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl text-xs shadow-md"
          >
            <Link href="/admin/products/new">
              <Plus className="w-4 h-4 mr-1.5" />
              Add New Product
            </Link>
          </Button>
        </div>
      </div>

      {/* Filter and Bulk Bar */}
      <div className="bg-card p-4 rounded-2xl border border-border flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search & Filter */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by title, SKU, or tag..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 text-xs h-9"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="h-9 px-3 rounded-lg border border-border bg-background text-xs text-foreground focus:outline-none focus:ring-1 focus:ring-royal-violet"
          >
            <option value="">All Statuses</option>
            <option value="PUBLISHED">Published Only</option>
            <option value="DRAFT">Draft Only</option>
            <option value="UNPUBLISHED">Unpublished</option>
          </select>
        </div>

        {/* Bulk Action Controls */}
        {selectedIds.length > 0 && (
          <div className="flex items-center gap-2 self-start md:self-auto bg-royal-violet/10 p-1.5 px-3 rounded-xl border border-royal-violet/20">
            <span className="text-xs font-bold text-royal-violet">
              {selectedIds.length} Selected:
            </span>
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-[11px] gap-1"
              onClick={() =>
                bulkMutation.mutate({
                  action: "status",
                  productIds: selectedIds,
                  status: "PUBLISHED",
                })
              }
              disabled={bulkMutation.isPending}
            >
              <CheckCircle className="w-3 h-3 text-emerald-600" /> Publish
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-[11px] gap-1"
              onClick={() =>
                bulkMutation.mutate({
                  action: "status",
                  productIds: selectedIds,
                  status: "UNPUBLISHED",
                })
              }
              disabled={bulkMutation.isPending}
            >
              <EyeOff className="w-3 h-3 text-muted-foreground" /> Unpublish
            </Button>
            <Button
              variant="destructive"
              size="sm"
              className="h-7 text-[11px] gap-1"
              onClick={() =>
                bulkMutation.mutate({
                  action: "delete",
                  productIds: selectedIds,
                })
              }
              disabled={bulkMutation.isPending}
            >
              <Trash2 className="w-3 h-3" /> Delete
            </Button>
          </div>
        )}
      </div>

      {/* Products Table */}
      <div className="bg-card rounded-2xl border border-border shadow-2xs overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/30">
              <TableHead className="w-12 text-center">
                <input
                  type="checkbox"
                  checked={products.length > 0 && selectedIds.length === products.length}
                  onChange={(e) => handleSelectAll(e.target.checked)}
                  className="rounded border-border text-royal-violet focus:ring-royal-violet cursor-pointer"
                />
              </TableHead>
              <TableHead className="w-20">Image</TableHead>
              <TableHead>Product Title &amp; SKU</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Variants</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-12 text-xs text-muted-foreground">
                  Loading catalogue...
                </TableCell>
              </TableRow>
            ) : products.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-16 text-muted-foreground">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <Shirt className="w-8 h-8 text-muted-foreground/50" />
                    <p className="text-sm font-semibold">No products found</p>
                    <p className="text-xs text-muted-foreground">
                      Try adjusting your search criteria or add a new piece to your boutique.
                    </p>
                    <Button
                      asChild
                      size="sm"
                      className="mt-3 bg-royal-violet hover:bg-royal-violet/90 text-white font-bold text-xs rounded-xl"
                    >
                      <Link href="/admin/products/new">
                        <Plus className="w-4 h-4 mr-1.5" />
                        Create First Product
                      </Link>
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              products.map((product: any) => {
                const primaryImage = product.images?.find((img: any) => img.isPrimary) || product.images?.[0];
                const totalStock = product.variants?.reduce(
                  (acc: number, v: any) => acc + (v.stock || 0),
                  0
                ) || 0;

                return (
                  <TableRow key={product.id} className="hover:bg-muted/30 transition-colors">
                    {/* Checkbox */}
                    <TableCell className="text-center">
                      <input
                        type="checkbox"
                        checked={selectedIds.includes(product.id)}
                        onChange={(e) => handleSelectOne(product.id, e.target.checked)}
                        className="rounded border-border text-royal-violet focus:ring-royal-violet cursor-pointer"
                      />
                    </TableCell>

                    {/* Image */}
                    <TableCell>
                      <Link
                        href={`/admin/products/${product.id}/edit`}
                        className="block w-12 h-14 rounded-lg overflow-hidden bg-muted relative border border-border group"
                      >
                        {primaryImage ? (
                          <img
                            src={primaryImage.path}
                            alt={product.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-[10px] text-muted-foreground">
                            No Img
                          </div>
                        )}
                      </Link>
                    </TableCell>

                    {/* Title & SKU */}
                    <TableCell>
                      <div className="space-y-0.5">
                        <Link
                          href={`/admin/products/${product.id}/edit`}
                          className="font-bold text-sm text-foreground hover:text-royal-violet line-clamp-1 transition-colors"
                        >
                          {product.name}
                        </Link>
                        <div className="text-[11px] text-muted-foreground flex items-center gap-1.5">
                          <span className="font-mono">{product.sku || "NO-SKU"}</span>
                          {product.isNewArrival && (
                            <Badge variant="accent" className="text-[9px] py-0 px-1.5 font-bold uppercase">
                              New
                            </Badge>
                          )}
                          {product.isTrending && (
                            <Badge variant="destructive" className="text-[9px] py-0 px-1.5 font-black uppercase bg-vermilion">
                              Trending
                            </Badge>
                          )}
                        </div>
                      </div>
                    </TableCell>

                    {/* Category */}
                    <TableCell>
                      <span className="text-xs text-muted-foreground font-medium">
                        {product.category?.name || "Uncategorized"}
                      </span>
                    </TableCell>

                    {/* Price */}
                    <TableCell>
                      <div className="text-xs">
                        <span className="font-black text-foreground">
                          {formatCurrency(product.discountPrice || product.regularPrice)}
                        </span>
                        {product.discountPrice && (
                          <span className="text-[10px] text-muted-foreground line-through ml-1.5">
                            {formatCurrency(product.regularPrice)}
                          </span>
                        )}
                      </div>
                    </TableCell>

                    {/* Variants info */}
                    <TableCell>
                      <div className="text-xs space-y-0.5">
                        <span className="font-semibold text-foreground">
                          {product.variants?.length || 0} variants
                        </span>
                        <div className="text-[11px] text-muted-foreground">
                          {totalStock > 0 ? (
                            <span>{totalStock} in stock</span>
                          ) : (
                            <span className="text-vermilion font-bold">Out of stock</span>
                          )}
                        </div>
                      </div>
                    </TableCell>

                    {/* Status */}
                    <TableCell>
                      <Badge
                        variant={
                          product.status === "PUBLISHED"
                            ? "success"
                            : product.status === "DRAFT"
                            ? "secondary"
                            : "outline"
                        }
                        className="text-[10px] uppercase font-bold"
                      >
                        {product.status}
                      </Badge>
                    </TableCell>

                    {/* Actions: Dedicated Separate Page Link (No Modal!) */}
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <Button
                          asChild
                          variant="outline"
                          size="sm"
                          className="h-8 px-2.5 text-xs font-semibold rounded-lg flex items-center gap-1 hover:border-royal-violet hover:text-royal-violet"
                          title="Edit Fashion Product (Separate Page)"
                        >
                          <Link href={`/admin/products/${product.id}/edit`}>
                            <Pencil className="w-3.5 h-3.5 mr-1" />
                            Edit
                          </Link>
                        </Button>

                        <button
                          type="button"
                          onClick={() => {
                            setProductToDelete(product);
                            setDeleteModalOpen(true);
                          }}
                          className="text-muted-foreground hover:text-vermilion p-1.5 transition-colors"
                          title="Delete product"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Delete Confirmation Modal */}
      <Dialog open={deleteModalOpen} onOpenChange={setDeleteModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="w-10 h-10 rounded-full bg-rose-50 dark:bg-rose-950/40 text-vermilion flex items-center justify-center mb-2">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <DialogTitle className="text-lg font-black text-ink dark:text-foreground">
              Delete Product?
            </DialogTitle>
            <DialogDescription className="text-xs">
              Are you sure you want to remove &ldquo;{productToDelete?.name}&rdquo;? All variant stock records and product associations will be permanently removed.
            </DialogDescription>
          </DialogHeader>

          <DialogFooter className="pt-2 gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setDeleteModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => productToDelete && deleteMutation.mutate(productToDelete.id)}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete Product"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

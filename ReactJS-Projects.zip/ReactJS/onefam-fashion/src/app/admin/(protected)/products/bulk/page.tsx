"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import {
  FileCode2,
  Upload,
  Download,
  ArrowLeft,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  FileJson,
  Layers,
  Image as ImageIcon,
  Check,
  RefreshCw,
  FolderDown,
} from "lucide-react";
import { toast } from "sonner";

// Sample template data for download and live testing
const SAMPLE_JSON_DATA = [
  {
    name: "Architectural Oversized Poplin Shirt",
    slug: "architectural-oversized-poplin-shirt",
    sku: "OFF-M-SHT-101",
    categorySlug: "men-shirts",
    shortDescription: "Drop-shoulder relaxed tailored shirt crafted from 100% Giza Egyptian cotton.",
    description: "Engineered with subtle architectural pleating across the back yoke, Mother-of-Pearl buttons, and structured French cuffs. Breathable, crisp, and timeless.",
    regularPrice: 2899,
    discountPrice: 2399,
    status: "PUBLISHED",
    isFeatured: true,
    isTrending: true,
    isNewArrival: true,
    collections: ["urban-minimalist", "new-arrivals"],
    images: [
      {
        path: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=1200&auto=format&fit=crop",
        altText: "Oversized Poplin Shirt - Front View",
        isPrimary: true,
        sortOrder: 0,
      },
      {
        path: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=1200&auto=format&fit=crop",
        altText: "Oversized Poplin Shirt - Detail View",
        isPrimary: false,
        sortOrder: 1,
      },
    ],
    variants: [
      { size: "S", color: "Paper White", colorHex: "#FCFAF4", sku: "OFF-M-SHT-101-WHT-S", stock: 15, isAvailable: true, image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=1200&auto=format&fit=crop" },
      { size: "M", color: "Paper White", colorHex: "#FCFAF4", sku: "OFF-M-SHT-101-WHT-M", stock: 25, isAvailable: true, image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=1200&auto=format&fit=crop" },
      { size: "L", color: "Paper White", colorHex: "#FCFAF4", sku: "OFF-M-SHT-101-WHT-L", stock: 18, isAvailable: true, image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=1200&auto=format&fit=crop" },
      { size: "M", color: "Slate Navy", colorHex: "#1E2A38", sku: "OFF-M-SHT-101-NVY-M", stock: 20, isAvailable: true, image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=1200&auto=format&fit=crop" },
    ],
  },
  {
    name: "Fluid Bias-Cut Mulberry Silk Dress",
    slug: "fluid-bias-cut-mulberry-silk-dress",
    sku: "OFF-W-DRS-102",
    categorySlug: "women-dresses",
    shortDescription: "19mm pure mulberry silk slip dress with delicate French-rolled hems.",
    description: "Cut on the bias for an effortless liquid contour that hugs gracefully. Features adjustable delicate straps and seamless hand-stitched side finishing.",
    regularPrice: 5499,
    discountPrice: 4699,
    status: "PUBLISHED",
    isFeatured: true,
    isTrending: true,
    isNewArrival: false,
    collections: ["new-arrivals"],
    images: [
      {
        path: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?q=80&w=1200&auto=format&fit=crop",
        altText: "Mulberry Silk Slip Dress",
        isPrimary: true,
        sortOrder: 0,
      },
    ],
    variants: [
      { size: "XS", color: "Champagne Gold", colorHex: "#F7E7CE", sku: "OFF-W-DRS-102-GLD-XS", stock: 8, isAvailable: true },
      { size: "S", color: "Champagne Gold", colorHex: "#F7E7CE", sku: "OFF-W-DRS-102-GLD-S", stock: 14, isAvailable: true },
      { size: "M", color: "Champagne Gold", colorHex: "#F7E7CE", sku: "OFF-W-DRS-102-GLD-M", stock: 10, isAvailable: true },
      { size: "S", color: "Noir Black", colorHex: "#191720", sku: "OFF-W-DRS-102-BLK-S", stock: 12, isAvailable: true },
    ],
  },
  {
    name: "Artisanal Linen Camp Collar Shirt",
    slug: "artisanal-linen-camp-collar-shirt",
    sku: "OFF-M-SHT-103",
    categorySlug: "men-shirts",
    shortDescription: "100% French flax pure linen shirt with breezy cuban camp collar.",
    description: "Garment-washed for ultra-soft lived-in handfeel. Naturally thermoregulating for humid and warm climates.",
    regularPrice: 2499,
    discountPrice: 1999,
    status: "PUBLISHED",
    isFeatured: false,
    isTrending: true,
    isNewArrival: true,
    collections: ["urban-minimalist"],
    images: [
      {
        path: "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?q=80&w=1200&auto=format&fit=crop",
        altText: "Camp Collar Linen Shirt",
        isPrimary: true,
        sortOrder: 0,
      },
    ],
    variants: [
      { size: "M", color: "Terracotta Clay", colorHex: "#E2725B", sku: "OFF-M-SHT-103-TER-M", stock: 16, isAvailable: true },
      { size: "L", color: "Terracotta Clay", colorHex: "#E2725B", sku: "OFF-M-SHT-103-TER-L", stock: 12, isAvailable: true },
      { size: "XL", color: "Terracotta Clay", colorHex: "#E2725B", sku: "OFF-M-SHT-103-TER-XL", stock: 8, isAvailable: true },
    ],
  },
];

export default function AdminBulkProductsPage() {
  const router = useRouter();
  const queryClient = useQueryClient();

  // Active tab: "upload" | "editor"
  const [activeTab, setActiveTab] = useState<"upload" | "editor">("upload");

  // Raw JSON string in editor or loaded from file
  const [rawJson, setRawJson] = useState("");
  const [fileName, setFileName] = useState<string | null>(null);

  // Parsing & validation state
  const [parsedProducts, setParsedProducts] = useState<any[]>([]);
  const [parseError, setParseError] = useState<string | null>(null);
  const [validationWarnings, setValidationWarnings] = useState<string[]>([]);

  // Import options
  const [updateExisting, setUpdateExisting] = useState(true);

  // Import Execution Result
  const [importResult, setImportResult] = useState<any | null>(null);

  // Bulk import mutation
  const importMutation = useMutation({
    mutationFn: (payload: { products: any[]; updateExisting: boolean }) =>
      apiClient.post("/products/bulk-import", payload),
    onSuccess: (res: any) => {
      setImportResult(res.data);
      toast.success(res.message || "Bulk import completed successfully!");
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
    onError: (err: any) => {
      toast.error(err.message || "Bulk import failed");
    },
  });

  // Parse and validate JSON string
  const handleValidateJson = (jsonStr: string, name?: string) => {
    setParseError(null);
    setValidationWarnings([]);
    setImportResult(null);

    if (!jsonStr.trim()) {
      setParsedProducts([]);
      return;
    }

    try {
      const data = JSON.parse(jsonStr);
      let items: any[] = [];

      if (Array.isArray(data)) {
        items = data;
      } else if (data && Array.isArray(data.products)) {
        items = data.products;
      } else {
        setParseError("JSON must be an array of products: [ { ... }, { ... } ]");
        setParsedProducts([]);
        return;
      }

      if (items.length === 0) {
        setParseError("The JSON array contains no products (length 0).");
        setParsedProducts([]);
        return;
      }

      const warnings: string[] = [];
      items.forEach((p, idx) => {
        const row = idx + 1;
        if (!p.name) warnings.push(`Item #${row}: Missing 'name' property.`);
        if (p.regularPrice === undefined || isNaN(Number(p.regularPrice))) {
          warnings.push(`Item #${row} (${p.name || "Untitled"}): Missing or invalid 'regularPrice'.`);
        }
        if (!p.categorySlug && !p.categoryName && !p.categoryId) {
          warnings.push(`Item #${row} (${p.name || "Untitled"}): No category specified (will default to uncategorized).`);
        }
      });

      setParsedProducts(items);
      setValidationWarnings(warnings);
      if (name) setFileName(name);
    } catch (err: any) {
      setParseError(`JSON Syntax Error: ${err.message}`);
      setParsedProducts([]);
    }
  };

  // Handle file drop or selection
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith(".json")) {
      toast.error("Please upload a .json file. CSV and Excel files are not supported.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setRawJson(content);
      handleValidateJson(content, file.name);
      toast.success(`Loaded "${file.name}" (${file.size} bytes)`);
    };
    reader.readAsText(file);
  };

  // Download sample JSON template
  const handleDownloadSample = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(SAMPLE_JSON_DATA, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "onefam-products-sample.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    toast.success("Sample JSON template downloaded");
  };

  // Load demo batch into editor
  const handleLoadDemoBatch = () => {
    const jsonStr = JSON.stringify(SAMPLE_JSON_DATA, null, 2);
    setRawJson(jsonStr);
    setFileName("demo-batch.json");
    handleValidateJson(jsonStr, "demo-batch.json");
    setActiveTab("editor");
    toast.success("Loaded 3 demo fashion products into JSON editor");
  };

  // Prettify / Format JSON in editor
  const handleFormatJson = () => {
    try {
      const parsed = JSON.parse(rawJson);
      const formatted = JSON.stringify(parsed, null, 2);
      setRawJson(formatted);
      handleValidateJson(formatted);
      toast.success("JSON formatted successfully");
    } catch (err: any) {
      toast.error("Cannot format invalid JSON. Check syntax.");
    }
  };

  // Submit bulk import
  const handleRunImport = () => {
    if (parsedProducts.length === 0) {
      toast.error("No valid products to import. Please check your JSON.");
      return;
    }

    importMutation.mutate({
      products: parsedProducts,
      updateExisting,
    });
  };

  // Calculate detected totals
  const totalVariants = parsedProducts.reduce(
    (acc, p) => acc + (Array.isArray(p.variants) ? p.variants.length : 0),
    0
  );
  const totalImages = parsedProducts.reduce(
    (acc, p) => acc + (Array.isArray(p.images) ? p.images.length : 0),
    0
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-20">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <Link
            href="/admin/products"
            className="inline-flex items-center gap-1.5 text-xs font-bold text-muted-foreground hover:text-royal-violet mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Products
          </Link>
          <h1 className="text-2xl font-black tracking-tight text-ink dark:text-foreground flex items-center gap-2">
            <FileCode2 className="w-6 h-6 text-royal-violet" />
            JSON Bulk Product Setup &amp; Onboarding
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Import, onboard, and synchronize multiple fashion pieces in pure structured JSON format. No CSV or Excel conversion needed.
          </p>
        </div>

        {/* Global Action Tools */}
        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleDownloadSample}
            className="text-xs font-semibold rounded-xl"
            title="Download sample JSON schema"
          >
            <Download className="w-3.5 h-3.5 mr-1.5 text-royal-violet" />
            Download Sample JSON
          </Button>

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleLoadDemoBatch}
            className="text-xs font-semibold rounded-xl"
          >
            <Sparkles className="w-3.5 h-3.5 mr-1.5 text-royal-violet" />
            Load Sample Demo
          </Button>

          <Button
            asChild
            variant="outline"
            size="sm"
            className="text-xs font-semibold rounded-xl"
          >
            <a href="/api/products/export" download>
              <FolderDown className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
              Export All as JSON
            </a>
          </Button>
        </div>
      </div>

      {/* Main Setup Card */}
      <div className="bg-card rounded-2xl border border-border shadow-xs overflow-hidden">
        {/* Navigation Tabs */}
        <div className="border-b border-border bg-muted/20 px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab("upload")}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === "upload"
                  ? "bg-royal-violet text-white shadow-xs"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              Upload JSON File (.json)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("editor")}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === "editor"
                  ? "bg-royal-violet text-white shadow-xs"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
              }`}
            >
              <FileJson className="w-3.5 h-3.5" />
              Paste &amp; Edit Raw JSON
            </button>
          </div>

          {activeTab === "editor" && rawJson && (
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleFormatJson}
                className="text-xs h-7 px-2.5 font-semibold text-royal-violet hover:bg-royal-violet/10"
              >
                Format / Prettify
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => {
                  setRawJson("");
                  setParsedProducts([]);
                  setParseError(null);
                  setValidationWarnings([]);
                  setFileName(null);
                }}
                className="text-xs h-7 px-2.5 text-muted-foreground hover:text-vermilion"
              >
                Clear
              </Button>
            </div>
          )}
        </div>

        {/* Tab Content 1: Upload JSON */}
        {activeTab === "upload" && (
          <div className="p-8">
            <label className="border-2 border-dashed border-border hover:border-royal-violet rounded-2xl p-10 flex flex-col items-center justify-center cursor-pointer transition-colors bg-muted/10 hover:bg-royal-violet/5 block">
              <div className="w-14 h-14 rounded-full bg-royal-violet/10 text-royal-violet flex items-center justify-center mb-4">
                <FileJson className="w-7 h-7" />
              </div>
              <span className="text-sm font-bold text-ink dark:text-foreground block mb-1">
                {fileName ? `Selected: ${fileName}` : "Click to select or drag & drop a .json product catalogue file"}
              </span>
              <p className="text-xs text-muted-foreground max-w-md text-center">
                Supports single or multiple product definitions with full multi-variant combinations and image arrays. CSV/Excel are not accepted.
              </p>
              <input
                type="file"
                accept=".json,application/json"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>
        )}

        {/* Tab Content 2: Raw JSON Editor */}
        {activeTab === "editor" && (
          <div className="p-6">
            <textarea
              value={rawJson}
              onChange={(e) => {
                setRawJson(e.target.value);
                handleValidateJson(e.target.value);
              }}
              placeholder={`[\n  {\n    "name": "Heavyweight Cotton Tee",\n    "regularPrice": 1499,\n    "categorySlug": "men-t-shirts",\n    "variants": [\n      { "size": "M", "color": "Black", "sku": "OFF-TEE-BLK-M", "stock": 20 }\n    ]\n  }\n]`}
              rows={14}
              className="w-full font-mono text-xs p-4 rounded-xl bg-[#191720] text-[#FCFAF4] border border-border focus:outline-none focus:ring-2 focus:ring-royal-violet placeholder:text-muted-foreground/50 leading-relaxed resize-y"
            />
          </div>
        )}

        {/* Error / Warning Alerts */}
        {parseError && (
          <div className="mx-6 mb-6 p-4 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-vermilion/30 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-vermilion shrink-0 mt-0.5" />
            <div>
              <span className="text-xs font-bold text-vermilion block">JSON Error Detected</span>
              <p className="text-xs text-rose-800 dark:text-rose-200 mt-0.5 font-mono">{parseError}</p>
            </div>
          </div>
        )}

        {validationWarnings.length > 0 && !parseError && (
          <div className="mx-6 mb-6 p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-300/40 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="text-xs font-bold text-amber-900 dark:text-amber-200 block">
                {validationWarnings.length} Warnings Detected (Import will still proceed):
              </span>
              <ul className="text-xs text-amber-800 dark:text-amber-300 list-disc list-inside mt-1 space-y-0.5">
                {validationWarnings.slice(0, 5).map((w, idx) => (
                  <li key={idx}>{w}</li>
                ))}
                {validationWarnings.length > 5 && (
                  <li>...and {validationWarnings.length - 5} more warnings</li>
                )}
              </ul>
            </div>
          </div>
        )}
      </div>

      {/* Live Pre-Import Inspection Summary & Action Bar */}
      {parsedProducts.length > 0 && !parseError && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-card p-4 rounded-2xl border border-border shadow-2xs">
              <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider block">
                Products to Process
              </span>
              <span className="text-2xl font-black text-ink dark:text-foreground mt-1 block">
                {parsedProducts.length}
              </span>
            </div>

            <div className="bg-card p-4 rounded-2xl border border-border shadow-2xs">
              <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider block flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-royal-violet" /> Variants Detected
              </span>
              <span className="text-2xl font-black text-royal-violet mt-1 block">
                {totalVariants}
              </span>
            </div>

            <div className="bg-card p-4 rounded-2xl border border-border shadow-2xs">
              <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider block flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-emerald-600" /> Image Assets
              </span>
              <span className="text-2xl font-black text-emerald-600 mt-1 block">
                {totalImages}
              </span>
            </div>

            <div className="bg-card p-4 rounded-2xl border border-border shadow-2xs flex flex-col justify-between">
              <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider block">
                Update If Exists
              </span>
              <div className="flex items-center justify-between pt-1">
                <span className="text-xs font-medium text-foreground">
                  {updateExisting ? "Enabled" : "Skip"}
                </span>
                <Switch checked={updateExisting} onCheckedChange={setUpdateExisting} />
              </div>
            </div>
          </div>

          {/* Pre-Import Data Preview Table */}
          <div className="bg-card rounded-2xl border border-border shadow-2xs overflow-hidden">
            <div className="p-4 border-b border-border bg-muted/15 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-ink dark:text-foreground">
                  Pre-Import Verification Table
                </h3>
                <p className="text-xs text-muted-foreground">
                  Inspect parsed properties and verified structures before writing to database.
                </p>
              </div>

              <Button
                type="button"
                onClick={handleRunImport}
                disabled={importMutation.isPending}
                className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl text-xs px-6 shadow-md"
              >
                {importMutation.isPending ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Importing {parsedProducts.length} Products...
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Execute Import ({parsedProducts.length} Items)
                  </>
                )}
              </Button>
            </div>

            <div className="overflow-x-auto max-h-[400px]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">#</TableHead>
                    <TableHead>Product Name</TableHead>
                    <TableHead>Slug / SKU</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Pricing (INR)</TableHead>
                    <TableHead>Variants</TableHead>
                    <TableHead>Images</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {parsedProducts.map((p, idx) => (
                    <TableRow key={idx}>
                      <TableCell className="font-mono text-xs text-muted-foreground">
                        {idx + 1}
                      </TableCell>
                      <TableCell className="text-xs font-bold text-ink dark:text-foreground">
                        {p.name || <span className="text-vermilion">Unnamed</span>}
                      </TableCell>
                      <TableCell className="font-mono text-[11px] text-muted-foreground">
                        {p.slug || "-"}
                        {p.sku && <span className="block text-[10px] text-foreground/70 font-semibold">{p.sku}</span>}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {p.categorySlug || p.categoryName || p.categoryId || (
                          <span className="text-amber-600 dark:text-amber-400 font-medium">None</span>
                        )}
                      </TableCell>
                      <TableCell className="text-xs font-mono">
                        <span className="font-bold text-foreground">₹{p.regularPrice || 0}</span>
                        {p.discountPrice && (
                          <span className="text-emerald-600 block text-[11px]">₹{p.discountPrice}</span>
                        )}
                      </TableCell>
                      <TableCell className="text-xs font-medium">
                        {Array.isArray(p.variants) && p.variants.length > 0 ? (
                          <span className="px-2 py-0.5 rounded-full bg-royal-violet/10 text-royal-violet text-[11px] font-bold">
                            {p.variants.length} combinations
                          </span>
                        ) : (
                          <span className="text-muted-foreground text-[11px]">0</span>
                        )}
                      </TableCell>
                      <TableCell className="text-xs font-medium">
                        {Array.isArray(p.images) && p.images.length > 0 ? (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 text-[11px] font-bold">
                            {p.images.length} assets
                          </span>
                        ) : (
                          <span className="text-muted-foreground text-[11px]">0</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={p.status === "PUBLISHED" ? "success" : "secondary"}>
                          {p.status || "DRAFT"}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </div>
      )}

      {/* Post-Import Execution Summary Card */}
      {importResult && (
        <div className="bg-card rounded-2xl border border-emerald-500/30 p-6 shadow-md space-y-4 animate-in fade-in duration-300">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 text-emerald-600 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-ink dark:text-foreground">
                Bulk Import Execution Complete
              </h3>
              <p className="text-xs text-muted-foreground">
                {importResult.createdCount} products created, {importResult.updatedCount} products updated, and {importResult.errorsCount} errors encountered.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-3 pt-2">
            <Button
              asChild
              className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl text-xs"
            >
              <Link href="/admin/products">
                View All Products in Catalogue
              </Link>
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setImportResult(null);
                setParsedProducts([]);
                setRawJson("");
                setFileName(null);
              }}
              className="text-xs rounded-xl"
            >
              Import Another JSON File
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}


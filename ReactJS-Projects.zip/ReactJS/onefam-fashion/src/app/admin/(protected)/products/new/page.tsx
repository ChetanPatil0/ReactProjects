"use client";

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { ProductForm } from "@/components/admin/product-form";
import { toast } from "sonner";

export default function CreateProductPage() {
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (body: any) => apiClient.post("/products", body),
    onSuccess: () => {
      toast.success("Product created & published successfully!");
      queryClient.invalidateQueries({ queryKey: queryKeys.products.all });
    },
    onError: (err: any) => toast.error(err.message || "Failed to create product"),
  });

  const handleSave = async (data: any) => {
    await createMutation.mutateAsync(data);
  };

  return (
    <div className="py-2">
      <ProductForm isEditing={false} onSave={handleSave} />
    </div>
  );
}


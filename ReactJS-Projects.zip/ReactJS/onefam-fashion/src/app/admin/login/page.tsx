"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Lock, Mail, ArrowRight, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { OneFamLogo } from "@/components/brand/onefam-logo";

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("admin@onefamfashion.com");
  const [password, setPassword] = useState("Admin@OneFam2026!");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Login failed");
      }

      toast.success("Welcome back! Signed in as administrator.");
      router.push("/admin/dashboard");
      router.refresh();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-paper px-4 py-12 selection:bg-royal-violet selection:text-white">
      <div className="w-full max-w-md space-y-8">
        {/* Brand Header */}
        <div className="text-center space-y-3 flex flex-col items-center">
          <OneFamLogo variant="light" size="lg" />
          <p className="text-xs text-muted-foreground font-medium">
            Authorized Store Staff &amp; Order Management Console
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-white p-8 rounded-2xl border border-border shadow-sm space-y-6">
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1.5">
                Staff Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="admin@onefamfashion.com"
                  className="pl-9 h-11 text-sm bg-paper/40"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1.5">
                Staff Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  placeholder="••••••••••••"
                  className="pl-9 h-11 text-sm bg-paper/40"
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-11 bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl mt-2 shadow-xs cursor-pointer"
            >
              {loading ? "Authenticating..." : "Sign In to Management"}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </form>

          <div className="p-3 rounded-lg bg-muted/60 text-xs text-muted-foreground text-center">
            Default credentials prefilled for demonstration:
            <br />
            <span className="font-mono text-[11px] text-ink font-semibold">
              admin@onefamfashion.com / Admin@OneFam2026!
            </span>
          </div>
        </div>

        <div className="text-center">
          <a
            href="/"
            className="text-xs text-muted-foreground hover:text-royal-violet font-semibold transition"
          >
            ← Back to Customer Storefront
          </a>
        </div>
      </div>
    </div>
  );
}


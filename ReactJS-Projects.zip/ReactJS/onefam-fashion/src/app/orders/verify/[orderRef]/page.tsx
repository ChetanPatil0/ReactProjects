import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { siteConfig } from "@/config/site";
import { OneFamLogo } from "@/components/brand/onefam-logo";
import {
  ShieldCheck,
  Package,
  Calendar,
  CheckCircle2,
  Clock,
  Printer,
  HelpCircle,
  Home,
  ArrowLeft,
  ExternalLink,
  Store,
  BadgeCheck,
} from "lucide-react";
import type { Metadata } from "next";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ orderRef: string }>;
}): Promise<Metadata> {
  const { orderRef } = await params;
  const cleanRef = decodeURIComponent(orderRef || "").trim();
  return {
    title: `Order Verification - ${cleanRef} | ${siteConfig.brand.name}`,
    description: `Official digital verification of order ${cleanRef} for ${siteConfig.brand.name}.`,
    robots: { index: false, follow: false },
  };
}

export default async function OrderVerifyPage({
  params,
}: {
  params: Promise<{ orderRef: string }>;
}) {
  const { orderRef } = await params;
  const cleanRef = decodeURIComponent(orderRef || "").trim();

  // Validate if parameter is a valid UUID to safely query the PostgreSQL UUID `id` column without crashing
  const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(cleanRef);

  // Build exact and case-insensitive order reference lookup variations
  const variations: Array<string> = [cleanRef];
  const unhyphenated = cleanRef.replace(/[^A-Za-z0-9]/g, "");
  if (unhyphenated && unhyphenated !== cleanRef) {
    variations.push(unhyphenated);
  }
  if (unhyphenated.length >= 7) {
    const prefix = unhyphenated.slice(0, 3).toUpperCase();
    const rest = unhyphenated.slice(3).toUpperCase();
    variations.push(`${prefix}-${rest}`);
    if (rest.length === 8) {
      variations.push(`${prefix}-${rest.slice(0, 4)}-${rest.slice(4)}`);
    }
  }

  const queryConditions: Array<Record<string, any>> = Array.from(new Set(variations)).map((ref) => ({
    orderRef: { equals: ref, mode: "insensitive" as const },
  }));

  // Only query `id` if the input is genuinely a UUID, preventing PostgreSQL UUID syntax errors
  if (isUuid) {
    queryConditions.push({ id: cleanRef });
  }

  const [settings, order] = await Promise.all([
    prisma.storeSettings.findFirst().catch(() => null),
    prisma.order.findFirst({
      where: {
        OR: queryConditions,
      },
      include: {
        customer: true,
        items: true,
        invoices: { take: 1, orderBy: { createdAt: "desc" } },
      },
    }),
  ]);

  const brandName = settings?.storeName || siteConfig.brand.name;
  const logoUrl = settings?.logoUrl;

  if (!order) {
    return (
      <div className="min-h-screen bg-[#FDFCFB] dark:bg-background flex flex-col">
        {/* Minimal Clean Header */}
        <header className="border-b border-border bg-white/80 dark:bg-card/80 backdrop-blur sticky top-0 z-50 px-4 sm:px-6 py-3.5">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2 hover:opacity-85 transition">
              {logoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={logoUrl}
                  alt={brandName}
                  className="h-8 max-w-[140px] object-contain"
                />
              ) : (
                <OneFamLogo className="h-7 w-auto text-ink dark:text-foreground" />
              )}
            </Link>
            <div className="flex items-center gap-2">
              <Link
                href="/contact"
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-full border border-border bg-background hover:bg-muted text-foreground transition"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Contact Us</span>
              </Link>
              <Link
                href="/"
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded-full bg-ink text-paper hover:bg-ink/90 dark:bg-foreground dark:text-background transition"
              >
                <Home className="w-3.5 h-3.5" />
                <span>Go to Home</span>
              </Link>
            </div>
          </div>
        </header>

        {/* Not Found Body */}
        <main className="flex-1 flex items-center justify-center p-4">
          <div className="max-w-md w-full p-8 rounded-2xl bg-white dark:bg-card border border-border shadow-sm text-center">
            <div className="w-14 h-14 rounded-full bg-vermilion/10 text-vermilion flex items-center justify-center mx-auto mb-4">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <h1 className="text-xl font-black text-ink dark:text-foreground">
              Order Record Not Found
            </h1>
            <p className="text-xs text-muted-foreground mt-2 leading-relaxed">
              We could not locate an official order with reference{" "}
              <span className="font-mono font-bold text-foreground">{orderRef}</span>. Please verify
              your order ID or contact our customer support team for help.
            </p>
            <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-2.5">
              <Link
                href="/"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-5 py-2 text-xs font-bold rounded-full bg-ink text-paper hover:bg-ink/90 dark:bg-foreground dark:text-background transition"
              >
                <Home className="w-3.5 h-3.5" />
                <span>Go to Home</span>
              </Link>
              <Link
                href="/contact"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-5 py-2 text-xs font-bold rounded-full border border-border bg-background hover:bg-muted text-foreground transition"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Contact Support</span>
              </Link>
            </div>
          </div>
        </main>
      </div>
    );
  }

  const invoice = order.invoices[0];
  const invoiceNumber = invoice?.invoiceNumber || `INV-${order.orderRef}`;
  const invoiceDate = invoice?.invoiceDate || order.createdAt;

  // Mask sensitive customer phone for privacy
  const maskedPhone = order.customer.phone
    ? order.customer.phone.replace(/(\d{2})\d{4}(\d{4})/, "$1****$2")
    : null;

  return (
    <div className="min-h-screen bg-[#FDFCFB] dark:bg-background flex flex-col">
      {/* Minimal Standalone Header with Store Logo & Go to Home */}
      <header className="border-b border-border bg-white/80 dark:bg-card/80 backdrop-blur sticky top-0 z-50 px-4 sm:px-6 py-3.5">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-2 hover:opacity-85 transition"
            title={`${brandName} Home`}
          >
            {logoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={logoUrl}
                alt={brandName}
                className="h-8 max-w-[140px] object-contain"
              />
            ) : (
              <OneFamLogo className="h-7 w-auto text-ink dark:text-foreground" />
            )}
          </Link>

          <div className="flex items-center gap-2">
            <Link
              href="/contact"
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-full border border-border bg-background hover:bg-muted text-foreground transition"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Contact Us</span>
            </Link>
            <Link
              href="/"
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded-full bg-ink text-paper hover:bg-ink/90 dark:bg-foreground dark:text-background transition"
            >
              <Home className="w-3.5 h-3.5" />
              <span>Go to Home</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Order Certificate Content */}
      <main className="flex-1 py-8 sm:py-12 px-4 sm:px-6">
        <div className="max-w-3xl mx-auto space-y-6">
          {/* Back Link */}
          <div className="flex items-center justify-between">
            <Link
              href="/"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground transition"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Store</span>
            </Link>

            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
              <BadgeCheck className="w-3.5 h-3.5" />
              Official Verification Certificate
            </span>
          </div>

          {/* Verification Container Card */}
          <div className="rounded-2xl bg-white dark:bg-card border border-border shadow-sm p-6 sm:p-8 space-y-6">
            {/* Header Badge & Action */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-border">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-7 h-7" />
                </div>
                <div>
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-[11px] font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Officially Verified Order</span>
                  </div>
                  <h1 className="text-xl sm:text-2xl font-black tracking-tight text-ink dark:text-foreground mt-1">
                    Order {order.orderRef}
                  </h1>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {invoice && (
                  <a
                    href={`/api/invoices/${invoice.id}/preview?format=pdf`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-royal-violet hover:bg-royal-violet/90 text-white text-xs font-bold shadow-sm transition"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Official PDF Invoice</span>
                  </a>
                )}
              </div>
            </div>

            {/* Key Metadata Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-muted/40 rounded-xl">
                <span className="text-[11px] text-muted-foreground block font-medium">Invoice No.</span>
                <span className="font-mono font-bold text-foreground mt-0.5 block">{invoiceNumber}</span>
              </div>

              <div className="p-3 bg-muted/40 rounded-xl">
                <span className="text-[11px] text-muted-foreground block font-medium">Date Issued</span>
                <span className="font-bold text-foreground mt-0.5 block">{formatDate(invoiceDate)}</span>
              </div>

              <div className="p-3 bg-muted/40 rounded-xl">
                <span className="text-[11px] text-muted-foreground block font-medium">Order Status</span>
                <span className="font-bold uppercase tracking-wider text-royal-violet mt-0.5 block">
                  {order.status}
                </span>
              </div>

              <div className="p-3 bg-muted/40 rounded-xl">
                <span className="text-[11px] text-muted-foreground block font-medium">Payment</span>
                <span
                  className={`font-bold uppercase tracking-wider mt-0.5 block ${
                    order.paymentStatus === "PAID"
                      ? "text-emerald-600"
                      : order.paymentStatus === "PARTIALLY_PAID"
                        ? "text-amber-600"
                        : "text-muted-foreground"
                  }`}
                >
                  {order.paymentStatus}
                </span>
              </div>
            </div>

            {/* Customer & Shipping Information (Privacy Masked) */}
            <div className="p-4 bg-[#FCFAF4] dark:bg-muted/20 border border-[#E8E6E1] dark:border-border rounded-xl text-xs space-y-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground block">
                Customer &amp; Shipping Delivery
              </span>
              <p className="font-bold text-ink dark:text-foreground text-sm">{order.customer.name}</p>
              <p className="text-muted-foreground">
                {maskedPhone && <span>Phone: {maskedPhone} • </span>}
                <span>{order.customer.shippingAddress || "Online Order Delivery"}</span>
              </p>
            </div>

            {/* Itemized Order Products */}
            <div className="space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground block">
                Order Items ({order.items.length})
              </span>

              <div className="border border-border rounded-xl overflow-hidden divide-y divide-border text-xs">
                {order.items.map((item) => (
                  <div key={item.id} className="p-3.5 flex items-center justify-between gap-3">
                    <div className="space-y-0.5">
                      <p className="font-bold text-foreground">{item.productName}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {[item.size, item.color].filter(Boolean).join(" / ") || "Standard"} • Qty:{" "}
                        {item.quantity}
                      </p>
                    </div>
                    <div className="text-right font-bold text-foreground">
                      {formatCurrency(item.totalPrice)}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Financial Totals */}
            <div className="p-4 bg-muted/30 rounded-xl space-y-2 text-xs max-w-sm ml-auto">
              <div className="flex justify-between text-muted-foreground">
                <span>Subtotal:</span>
                <span>{formatCurrency(order.subtotal)}</span>
              </div>
              {Number(order.discount) > 0 && (
                <div className="flex justify-between text-vermilion">
                  <span>Special Offer Discount:</span>
                  <span>-{formatCurrency(order.discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-muted-foreground">
                <span>Shipping:</span>
                <span>{Number(order.shipping) > 0 ? formatCurrency(order.shipping) : "FREE"}</span>
              </div>
              <div className="flex justify-between font-black text-sm text-foreground pt-2 border-t border-border">
                <span>Total Value:</span>
                <span className="text-royal-violet dark:text-[#C6F542]">{formatCurrency(order.total)}</span>
              </div>
              <div className="flex justify-between font-bold text-emerald-600 text-xs">
                <span>Amount Paid:</span>
                <span>{formatCurrency(order.amountPaid)}</span>
              </div>
              {Number(order.balanceDue) > 0 && (
                <div className="flex justify-between font-bold text-vermilion text-xs">
                  <span>Balance Due (COD):</span>
                  <span>{formatCurrency(order.balanceDue)}</span>
                </div>
              )}
            </div>

            {/* Bottom Action / Home & Contact Us Banner */}
            <div className="pt-6 border-t border-border flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <Link
                href="/"
                className="inline-flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-full bg-ink text-paper hover:bg-ink/90 dark:bg-foreground dark:text-background text-xs font-bold transition shadow-sm"
              >
                <Home className="w-3.5 h-3.5" />
                <span>Go to Home / Continue Shopping</span>
              </Link>

              <Link
                href="/contact"
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-full border border-border bg-background hover:bg-muted text-foreground text-xs font-bold transition shrink-0 shadow-sm"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Contact Us &amp; Help Section</span>
              </Link>
            </div>
          </div>
        </div>
      </main>

      {/* Minimal Footer */}
      <footer className="border-t border-border py-6 px-4 text-center text-[11px] text-muted-foreground">
        <p>© {new Date().getFullYear()} {brandName} • Official Digital Order Verification Record</p>
      </footer>
    </div>
  );
}


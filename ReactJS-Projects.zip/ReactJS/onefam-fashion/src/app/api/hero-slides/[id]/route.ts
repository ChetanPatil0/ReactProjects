import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/server/auth/session";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const slide = await prisma.heroSlide.findUnique({
      where: { id },
    });
    if (!slide) {
      return NextResponse.json({ success: false, error: "Hero slide not found" }, { status: 404 });
    }
    return NextResponse.json({ success: true, data: slide });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const body = await request.json();

    const slide = await prisma.heroSlide.update({
      where: { id },
      data: {
        title: body.title,
        subtitle: body.subtitle !== undefined ? body.subtitle : undefined,
        description: body.description !== undefined ? body.description : undefined,
        primaryCtaText: body.primaryCtaText !== undefined ? body.primaryCtaText : undefined,
        primaryCtaUrl: body.primaryCtaUrl !== undefined ? body.primaryCtaUrl : undefined,
        secondaryCtaText: body.secondaryCtaText !== undefined ? body.secondaryCtaText : undefined,
        secondaryCtaUrl: body.secondaryCtaUrl !== undefined ? body.secondaryCtaUrl : undefined,
        desktopImage: body.desktopImage !== undefined ? body.desktopImage : undefined,
        mobileImage: body.mobileImage !== undefined ? body.mobileImage : undefined,
        sortOrder: body.sortOrder !== undefined ? body.sortOrder : undefined,
        isActive: body.isActive !== undefined ? body.isActive : undefined,
      },
    });

    return NextResponse.json({ success: true, data: slide });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 400 });
  }
}

export { PATCH as PUT };

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    await prisma.heroSlide.delete({ where: { id } });

    return NextResponse.json({ success: true, message: "Slide deleted successfully" });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 400 });
  }
}


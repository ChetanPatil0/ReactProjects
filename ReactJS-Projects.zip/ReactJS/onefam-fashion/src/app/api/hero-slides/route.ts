import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/server/auth/session";

export async function GET() {
  try {
    const slides = await prisma.heroSlide.findMany({
      orderBy: { sortOrder: "asc" },
    });
    return NextResponse.json({ success: true, data: slides });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const count = await prisma.heroSlide.count();

    const slide = await prisma.heroSlide.create({
      data: {
        title: body.title,
        subtitle: body.subtitle || null,
        description: body.description || null,
        primaryCtaText: body.primaryCtaText || null,
        primaryCtaUrl: body.primaryCtaUrl || null,
        secondaryCtaText: body.secondaryCtaText || null,
        secondaryCtaUrl: body.secondaryCtaUrl || null,
        desktopImage: body.desktopImage,
        mobileImage: body.mobileImage || body.desktopImage,
        sortOrder: body.sortOrder ?? count + 1,
        isActive: body.isActive ?? true,
      },
    });

    return NextResponse.json({ success: true, data: slide }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 400 });
  }
}


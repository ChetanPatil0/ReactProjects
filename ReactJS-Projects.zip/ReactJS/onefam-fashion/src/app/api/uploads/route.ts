import { NextResponse } from "next/server";
import { getAdminSession } from "@/server/auth/session";
import { PRODUCT_IMAGE } from "@/lib/constants";
import { createClient } from "@supabase/supabase-js";
import sharp from "sharp";
import crypto from "crypto";
import fs from "fs/promises";
import path from "path";

export async function POST(request: Request) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json({ success: false, error: "No image file provided." }, { status: 400 });
    }

    // 1. File size validation (Max 2MB per spec)
    if (file.size > PRODUCT_IMAGE.maxUploadBytes) {
      return NextResponse.json(
        {
          success: false,
          error: `File size exceeds 2MB limit. (Uploaded: ${(file.size / (1024 * 1024)).toFixed(2)} MB)`,
        },
        { status: 400 }
      );
    }

    // 2. MIME type validation
    const allowedFormats = ["image/jpeg", "image/png", "image/webp", "image/jpg"];
    if (!allowedFormats.includes(file.type.toLowerCase())) {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid file format. Allowed formats: JPEG, PNG, WebP.",
        },
        { status: 400 }
      );
    }

    // 3. Process image with Sharp: convert to WebP, resize if exceeding 1600px width
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    const processedBuffer = await sharp(buffer)
      .resize({ width: 1600, height: 2000, fit: "inside", withoutEnlargement: true })
      .webp({ quality: 85 })
      .toBuffer();

    const uniqueId = crypto.randomUUID();
    const filename = `${uniqueId}.webp`;

    // 4. Try Supabase Storage if configured
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const bucket = process.env.SUPABASE_STORAGE_BUCKET || "product-images";

    if (supabaseUrl && supabaseKey && !supabaseUrl.includes("your-project")) {
      try {
        const supabase = createClient(supabaseUrl, supabaseKey);
        const { error: uploadError } = await supabase.storage
          .from(bucket)
          .upload(`products/${filename}`, processedBuffer, {
            contentType: "image/webp",
            upsert: false,
          });

        if (!uploadError) {
          const { data: publicData } = supabase.storage
            .from(bucket)
            .getPublicUrl(`products/${filename}`);

          return NextResponse.json({
            success: true,
            data: {
              url: publicData.publicUrl,
              filename,
              sizeBytes: processedBuffer.length,
            },
          });
        }
      } catch (sbErr) {
        console.warn("Supabase upload failed, falling back to local public storage", sbErr);
      }
    }

    // 5. Fallback to public/uploads directory for robust local operation
    const uploadDir = path.join(process.cwd(), "public", "uploads");
    await fs.mkdir(uploadDir, { recursive: true });
    const localFilePath = path.join(uploadDir, filename);
    await fs.writeFile(localFilePath, processedBuffer);

    const publicUrl = `/uploads/${filename}`;

    return NextResponse.json({
      success: true,
      data: {
        url: publicUrl,
        filename,
        sizeBytes: processedBuffer.length,
      },
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message || "Failed to process image upload." },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { url } = await request.json();
    if (!url || typeof url !== "string") {
      return NextResponse.json({ success: false, error: "Image URL required" }, { status: 400 });
    }

    if (url.startsWith("/uploads/")) {
      const filename = path.basename(url);
      const filePath = path.join(process.cwd(), "public", "uploads", filename);
      try {
        await fs.unlink(filePath);
      } catch {
        // file already deleted or doesn't exist
      }
    }

    return NextResponse.json({ success: true, message: "File removed" });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message || "Failed to delete file" },
      { status: 500 }
    );
  }
}

import { NextResponse } from "next/server";
import { inquiryService } from "@/server/services/inquiry-service";
import { getAdminSession } from "@/server/auth/session";
import { validateContactInquiry } from "@/lib/validations";

// Public POST: Customers submit a Help / Contact Inquiry
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, email, phone, subject, orderNumber, message } = body;

    const validation = validateContactInquiry({
      name: typeof name === "string" ? name : "",
      email: typeof email === "string" ? email : "",
      phone: typeof phone === "string" ? phone : "",
      subject: typeof subject === "string" ? subject : undefined,
      orderNumber: typeof orderNumber === "string" ? orderNumber : undefined,
      message: typeof message === "string" ? message : "",
    });

    if (!validation.valid) {
      const firstErrorMessage =
        validation.errors.general ||
        validation.errors.name ||
        validation.errors.email ||
        validation.errors.phone ||
        validation.errors.orderNumber ||
        validation.errors.message ||
        "Invalid submission data.";

      return NextResponse.json(
        { success: false, error: firstErrorMessage, errors: validation.errors },
        { status: 400 }
      );
    }

    const inquiry = await inquiryService.createInquiry({
      name: validation.sanitized.name,
      email: validation.sanitized.email,
      phone: validation.sanitized.phone,
      subject: validation.sanitized.subject,
      orderNumber: validation.sanitized.orderNumber,
      message: validation.sanitized.message,
    });

    return NextResponse.json({
      success: true,
      message: "Your inquiry has been received. Our customer support team will reach out shortly.",
      data: inquiry,
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message || "Failed to submit inquiry" },
      { status: 500 }
    );
  }
}

// Protected GET: Admin lists inquiries
export async function GET(request: Request) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status") || undefined;
    const subject = searchParams.get("subject") || undefined;
    const search = searchParams.get("search") || undefined;

    const result = await inquiryService.getInquiries({ status, subject, search });
    return NextResponse.json({ success: true, data: result.inquiries, stats: result.stats });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch inquiries" },
      { status: 500 }
    );
  }
}


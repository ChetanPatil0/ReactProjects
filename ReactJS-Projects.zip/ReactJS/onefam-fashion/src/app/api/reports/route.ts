import { NextResponse } from "next/server";
import { reportService } from "@/server/services/report-service";
import { getAdminSession } from "@/server/auth/session";

export async function GET(request: Request) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const range = (searchParams.get("range") || "30d") as "7d" | "30d" | "90d" | "all";

    const data = await reportService.getAnalytics(range);
    return NextResponse.json({ success: true, data });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}


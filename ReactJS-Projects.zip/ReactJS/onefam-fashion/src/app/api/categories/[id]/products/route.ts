import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/server/auth/session";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const category = await prisma.category.findUnique({
      where: { id },
      include: {
        products: {
          select: { id: true, name: true, sku: true, regularPrice: true },
        },
      },
    });

    if (!category) {
      return NextResponse.json({ success: false, error: "Category not found" }, { status: 404 });
    }

    const allProducts = await prisma.product.findMany({
      select: { id: true, name: true, sku: true, regularPrice: true, categoryId: true },
      orderBy: { name: "asc" },
    });

    return NextResponse.json({
      success: true,
      data: {
        category,
        assignedProductIds: category.products.map((p) => p.id),
        allProducts,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const { productIds } = await request.json();

    if (!Array.isArray(productIds)) {
      return NextResponse.json({ success: false, error: "Invalid productIds array" }, { status: 400 });
    }

    await prisma.$transaction([
      // Unassign products currently in this category but not in the new list
      prisma.product.updateMany({
        where: {
          categoryId: id,
          id: { notIn: productIds },
        },
        data: { categoryId: null },
      }),
      // Assign products in the list to this category
      prisma.product.updateMany({
        where: { id: { in: productIds } },
        data: { categoryId: id },
      }),
    ]);

    return NextResponse.json({
      success: true,
      message: `Updated assigned products for category.`,
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}


import { NextResponse } from "next/server";
import { productService } from "@/server/services/product-service";
import { getAdminSession } from "@/server/auth/session";

export async function POST(request: Request) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { action, productIds, status } = await request.json();

    if (!Array.isArray(productIds) || productIds.length === 0) {
      return NextResponse.json({ success: false, error: "No products selected" }, { status: 400 });
    }

    if (action === "update_status" && status) {
      await productService.bulkUpdateStatus(productIds, status);
      return NextResponse.json({ success: true, message: `Updated ${productIds.length} products to ${status}` });
    }

    if (action === "delete") {
      await productService.bulkDelete(productIds);
      return NextResponse.json({ success: true, message: `Deleted ${productIds.length} products` });
    }

    return NextResponse.json({ success: false, error: "Invalid bulk action" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}


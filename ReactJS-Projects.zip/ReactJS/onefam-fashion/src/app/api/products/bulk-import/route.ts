import { NextResponse } from "next/server";
import { productService } from "@/server/services/product-service";
import { getAdminSession } from "@/server/auth/session";

export async function POST(request: Request) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { products, updateExisting = true } = body;

    if (!Array.isArray(products) || products.length === 0) {
      return NextResponse.json(
        { success: false, error: "No products array provided in JSON payload" },
        { status: 400 }
      );
    }

    const result = await productService.bulkImportJson(products, updateExisting);

    return NextResponse.json({
      success: true,
      message: `Successfully processed ${result.totalProcessed} products (${result.createdCount} created, ${result.updatedCount} updated)`,
      data: result,
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message || "Failed to process bulk import" },
      { status: 500 }
    );
  }
}


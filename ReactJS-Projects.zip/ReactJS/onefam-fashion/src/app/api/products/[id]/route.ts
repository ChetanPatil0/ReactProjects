import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/server/auth/session";
import { serializeProduct } from "@/lib/serializers";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const product = await prisma.product.findUnique({
      where: { id },
      include: {
        category: true,
        images: true,
        variants: true,
        collectionProducts: { include: { collection: true } },
        promotionProducts: { include: { promotion: true } },
      },
    });

    if (!product) {
      return NextResponse.json({ success: false, error: "Product not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: serializeProduct(product) });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const body = await request.json();

    const product = await prisma.product.update({
      where: { id },
      data: {
        name: body.name,
        slug: body.slug,
        sku: body.sku !== undefined ? (body.sku || null) : undefined,
        shortDescription: body.shortDescription !== undefined ? body.shortDescription : undefined,
        description: body.description !== undefined ? body.description : undefined,
        regularPrice: body.regularPrice !== undefined ? body.regularPrice : undefined,
        discountPrice: body.discountPrice !== undefined ? (body.discountPrice ? body.discountPrice : null) : undefined,
        categoryId: body.categoryId !== undefined ? (body.categoryId || null) : undefined,
        status: body.status !== undefined ? body.status : undefined,
        isFeatured: body.isFeatured !== undefined ? body.isFeatured : undefined,
        isTrending: body.isTrending !== undefined ? body.isTrending : undefined,
        isNewArrival: body.isNewArrival !== undefined ? body.isNewArrival : undefined,
      },
    });

    // If images array was passed
    if (Array.isArray(body.images) && body.images.length > 0) {
      await prisma.productImage.deleteMany({ where: { productId: id } });
      await prisma.productImage.createMany({
        data: body.images.map((img: any, idx: number) => ({
          productId: id,
          path: typeof img === "string" ? img : img.path,
          altText: (typeof img === "object" && img.altText) ? img.altText : (body.name || "Product Image"),
          isPrimary: (typeof img === "object" && img.isPrimary !== undefined) ? img.isPrimary : idx === 0,
          sortOrder: idx,
        })),
      });
    } else if (body.imagePath) {
      const existingPrimary = await prisma.productImage.findFirst({
        where: { productId: id, isPrimary: true },
      });
      if (existingPrimary) {
        await prisma.productImage.update({
          where: { id: existingPrimary.id },
          data: { path: body.imagePath, altText: body.name || undefined },
        });
      } else {
        await prisma.productImage.create({
          data: {
            productId: id,
            path: body.imagePath,
            altText: body.name || "Product Image",
            isPrimary: true,
            sortOrder: 0,
          },
        });
      }
    }

    // If variants array was passed
    if (Array.isArray(body.variants)) {
      const existingVariants = await prisma.productVariant.findMany({
        where: { productId: id },
      });
      const incomingIds = body.variants.filter((v: any) => v.id).map((v: any) => v.id);
      const toDelete = existingVariants.filter((ev) => !incomingIds.includes(ev.id));

      for (const d of toDelete) {
        try {
          await prisma.productVariant.delete({ where: { id: d.id } });
        } catch {
          // If referenced in orderItems, soft-disable it
          await prisma.productVariant.update({
            where: { id: d.id },
            data: { isAvailable: false, stock: 0 },
          }).catch(() => null);
        }
      }

      for (const v of body.variants) {
        if (v.id) {
          await prisma.productVariant.update({
            where: { id: v.id },
            data: {
              size: v.size || null,
              color: v.color || null,
              colorHex: v.colorHex || null,
              sku: v.sku || null,
              stock: v.stock !== undefined && v.stock !== null ? Number(v.stock) : 0,
              priceOverride: v.priceOverride ? Number(v.priceOverride) : null,
              isAvailable: v.isAvailable !== false,
            },
          }).catch(() => null);
        } else {
          await prisma.productVariant.create({
            data: {
              productId: id,
              size: v.size || null,
              color: v.color || null,
              colorHex: v.colorHex || null,
              sku: v.sku || null,
              stock: v.stock !== undefined && v.stock !== null ? Number(v.stock) : 0,
              priceOverride: v.priceOverride ? Number(v.priceOverride) : null,
              isAvailable: v.isAvailable !== false,
            },
          }).catch(() => null);
        }
      }
    }

    // If collectionIds array was passed
    if (Array.isArray(body.collectionIds)) {
      await prisma.collectionProduct.deleteMany({ where: { productId: id } });
      if (body.collectionIds.length > 0) {
        await prisma.collectionProduct.createMany({
          data: body.collectionIds.map((cid: string, idx: number) => ({
            collectionId: cid,
            productId: id,
            sortOrder: idx,
          })),
        });
      }
    }

    return NextResponse.json({ success: true, data: product });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 400 });
  }
}

export { PATCH as PUT };

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    await prisma.product.delete({ where: { id } });

    return NextResponse.json({ success: true, message: "Product deleted" });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 400 });
  }
}

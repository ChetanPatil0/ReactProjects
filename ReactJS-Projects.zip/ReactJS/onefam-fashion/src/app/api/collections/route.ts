import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/server/auth/session";

export async function GET() {
  try {
    const collections = await prisma.collection.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        _count: {
          select: { products: true },
        },
      },
    });

    // Sort by saved order in seoTitle if present
    collections.sort((a, b) => {
      const orderA = a.seoTitle && !isNaN(Number(a.seoTitle)) ? Number(a.seoTitle) : 999;
      const orderB = b.seoTitle && !isNaN(Number(b.seoTitle)) ? Number(b.seoTitle) : 999;
      return orderA - orderB;
    });

    return NextResponse.json({ success: true, data: collections });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const collection = await prisma.collection.create({
      data: {
        title: body.title,
        slug: body.slug,
        description: body.description || null,
        coverImage: body.coverImage || null,
        isActive: body.isActive ?? true,
      },
    });

    return NextResponse.json({ success: true, data: collection }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 400 });
  }
}


import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/server/auth/session";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const collection = await prisma.collection.findUnique({
      where: { id },
      include: {
        products: {
          include: {
            product: {
              select: { id: true, name: true, sku: true, regularPrice: true },
            },
          },
        },
      },
    });

    if (!collection) {
      return NextResponse.json({ success: false, error: "Collection not found" }, { status: 404 });
    }

    const allProducts = await prisma.product.findMany({
      select: { id: true, name: true, sku: true, regularPrice: true },
      orderBy: { name: "asc" },
    });

    return NextResponse.json({
      success: true,
      data: {
        collection,
        assignedProductIds: collection.products.map((cp) => cp.productId),
        allProducts,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const { productIds } = await request.json();

    if (!Array.isArray(productIds)) {
      return NextResponse.json({ success: false, error: "Invalid productIds array" }, { status: 400 });
    }

    await prisma.$transaction(async (tx) => {
      // 1. Delete existing associations
      await tx.collectionProduct.deleteMany({
        where: { collectionId: id },
      });

      // 2. Re-create new associations with sort order
      if (productIds.length > 0) {
        await tx.collectionProduct.createMany({
          data: productIds.map((pid: string, idx: number) => ({
            collectionId: id,
            productId: pid,
            sortOrder: idx,
          })),
        });
      }
    });

    return NextResponse.json({
      success: true,
      message: `Updated assigned products for collection.`,
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}


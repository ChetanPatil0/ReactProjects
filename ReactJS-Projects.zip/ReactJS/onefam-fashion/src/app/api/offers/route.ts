import { NextResponse } from "next/server";
import { offerService } from "@/server/services/offer-service";
import { getAdminSession } from "@/server/auth/session";

export async function GET() {
  try {
    const offers = await offerService.getOffers();
    return NextResponse.json({ success: true, data: offers });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const admin = await getAdminSession();
    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    if (!body.name || !body.discountValue) {
      return NextResponse.json(
        { success: false, error: "Offer name and discount value are required" },
        { status: 400 }
      );
    }

    const offer = await offerService.createOffer(body);
    return NextResponse.json({ success: true, data: offer }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}


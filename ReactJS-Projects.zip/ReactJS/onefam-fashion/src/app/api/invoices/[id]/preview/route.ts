import { NextResponse } from "next/server";
import { invoiceService } from "@/server/services/invoice-service";
import { prisma } from "@/lib/prisma";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const templateId = searchParams.get("templateId") || undefined;
    const isDownload = searchParams.get("download") === "true";
    const format = searchParams.get("format");
    const autoPrint = searchParams.get("print") === "true";

    // Find invoice or orderId
    const invoice = await prisma.invoice.findUnique({
      where: { id },
    });

    const targetOrderId = invoice ? invoice.orderId : id;
    const invoiceNumber =
      invoice?.invoiceNumber || `INV-${targetOrderId.slice(0, 8).toUpperCase()}`;

    // Return real binary PDF if format=pdf or download=true
    if (format === "pdf" || isDownload) {
      const pdfBuffer = await invoiceService.generateInvoicePdf(targetOrderId);
      const disposition = isDownload ? "attachment" : "inline";

      return new NextResponse(pdfBuffer as any, {
        status: 200,
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition": `${disposition}; filename="${invoiceNumber}.pdf"`,
          "Cache-Control": "private, no-cache, no-store, must-revalidate",
        },
      });
    }

    // Default: Return interactive HTML invoice preview
    const html = await invoiceService.renderInvoiceHtml(targetOrderId, templateId, autoPrint);

    return new NextResponse(html, {
      status: 200,
      headers: {
        "Content-Type": "text/html; charset=utf-8",
      },
    });
  } catch (error: any) {
    return new NextResponse(`Error rendering invoice: ${error.message}`, { status: 400 });
  }
}

import { NextResponse } from "next/server";
import { getAdminSession } from "@/server/auth/session";

export async function GET() {
  const admin = await getAdminSession();
  if (!admin) {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }
  return NextResponse.json({ success: true, data: admin });
}


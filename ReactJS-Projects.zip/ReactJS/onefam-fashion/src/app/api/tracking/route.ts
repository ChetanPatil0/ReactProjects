import { NextResponse } from "next/server";
import { trackingService } from "@/server/services/tracking-service";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, identifier, email, phone, orderRef, code } = body;
    const lookupKey = (identifier || email || phone || "").trim();

    if (!lookupKey) {
      return NextResponse.json(
        { success: false, error: "Please provide your registered email address or mobile phone number." },
        { status: 400 }
      );
    }

    if (action === "request_otp") {
      const result = await trackingService.requestVerification(lookupKey);
      return NextResponse.json({
        success: true,
        message: "Verification OTP code generated successfully.",
        data: { token: result.token, demoOtp: result.code, email: result.email },
      });
    }

    // Lookup orders
    const orders = await trackingService.lookupOrder({
      identifier: lookupKey,
      email,
      phone,
      orderRef,
      code,
    });
    return NextResponse.json({ success: true, data: orders });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 400 });
  }
}


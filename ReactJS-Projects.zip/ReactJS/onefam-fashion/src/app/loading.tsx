import { BrandLoader } from "@/components/brand/brand-loader";

export default function RootLoading() {
  return <BrandLoader fullscreen={true} />;
}

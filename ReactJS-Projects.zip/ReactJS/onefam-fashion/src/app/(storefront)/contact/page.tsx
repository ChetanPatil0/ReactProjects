import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { Mail, Clock, HelpCircle, ShieldCheck, CheckCircle2, Headphones, MessageSquare } from "lucide-react";
import { ContactForm } from "@/features/contact/components/contact-form";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "Contact Us & Customer Support",
  description: "Get in touch with our customer support and styling team via WhatsApp or email. Submit your inquiry directly.",
  alternates: {
    canonical: "/contact",
  },
};

export default async function ContactPage() {
  const settings = await prisma.storeSettings.findFirst().catch(() => null);

  const whatsappNumber = settings?.whatsappNumber || siteConfig.contact.whatsappNumber;
  const supportEmail = settings?.supportEmail || siteConfig.contact.supportEmail;
  const cleanPhone = whatsappNumber.replace(/[^0-9]/g, "");

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 space-y-12">
      {/* Page Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-royal-violet/10 text-royal-violet dark:text-[#C6F542] text-xs font-bold uppercase tracking-widest">
          <HelpCircle className="w-3.5 h-3.5" />
          Customer Care &amp; Support
        </div>
        <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-foreground">
          Contact Us
        </h1>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Have questions about sizing, your order status, delivery, or custom styling? Submit your inquiry below or connect via WhatsApp and our dedicated support team will assist you.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Direct Store Support & Resolution Channels */}
        <div className="lg:col-span-5 space-y-6">
          {/* Direct Support Details */}
          <div className="p-7 rounded-2xl bg-card border border-border/80 shadow-xs space-y-6">
            <div className="flex items-center gap-3 border-b border-border/60 pb-4">
              <div className="w-10 h-10 rounded-xl bg-royal-violet/10 text-royal-violet dark:text-[#C6F542] flex items-center justify-center">
                <Headphones className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider text-foreground">
                  Support Channels
                </h2>
                <p className="text-[11px] text-muted-foreground">Direct customer support assistance</p>
              </div>
            </div>

            <div className="space-y-4 text-xs text-muted-foreground">
              {/* WhatsApp Support */}
              <div className="flex items-center gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-emerald-500/10 flex items-center justify-center shrink-0">
                  <MessageSquare className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                </div>
                <div>
                  <strong className="block text-foreground text-xs font-bold">WhatsApp Support</strong>
                  <a
                    href={`https://wa.me/${cleanPhone}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-emerald-600 dark:hover:text-emerald-400 font-bold transition-colors text-foreground"
                  >
                    +{whatsappNumber}
                  </a>
                </div>
              </div>

              {/* Support Email */}
              <div className="flex items-center gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
                  <Mail className="w-4 h-4 text-royal-violet dark:text-[#C6F542]" />
                </div>
                <div>
                  <strong className="block text-foreground text-xs font-bold">Support Email</strong>
                  <a
                    href={`mailto:${supportEmail}`}
                    className="hover:text-royal-violet font-medium transition-colors"
                  >
                    {supportEmail}
                  </a>
                </div>
              </div>

              {/* Hours */}
              <div className="flex items-center gap-3.5 pt-3 border-t border-border/40">
                <div className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4 text-royal-violet dark:text-[#C6F542]" />
                </div>
                <div>
                  <strong className="block text-foreground text-xs font-bold">Customer Care Hours</strong>
                  <span>{siteConfig.contact.operatingHours}</span>
                </div>
              </div>
            </div>
          </div>

          {/* 100% Online Storefront Assurance */}
          <div className="p-7 rounded-2xl bg-gradient-to-br from-royal-violet/5 via-card to-background border border-royal-violet/15 shadow-xs space-y-4">
            <div className="flex items-center gap-2 text-royal-violet dark:text-[#C6F542] text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              100% Online Digital Boutique
            </div>

            <p className="text-xs text-muted-foreground leading-relaxed">
              OneFam is a 100% online family fashion brand. We operate purely digital with no physical retail stores or warehouses. Every order is quality-checked and dispatched directly to your doorstep across India.
            </p>

            <div className="space-y-2.5 pt-2 border-t border-border/50 text-xs">
              <div className="flex items-center gap-2 text-foreground font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>Fast 2-4 hr reply during support hours</span>
              </div>
              <div className="flex items-center gap-2 text-foreground font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>Dedicated ticket tracking for every issue</span>
              </div>
              <div className="flex items-center gap-2 text-foreground font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>Direct email &amp; WhatsApp ticket resolution</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Contact Us Form */}
        <div className="lg:col-span-7">
          <ContactForm />
        </div>
      </div>
    </div>
  );
}

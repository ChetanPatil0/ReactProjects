import { CatalogueView } from "@/features/storefront/components/catalogue-view";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Search Fashion Catalogue",
  description: "Find styles by fabric, cut, color, category, or collection name.",
};

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const params = await searchParams;
  const q = params.q || "";

  return (
    <CatalogueView
      title={q ? `Search Results for "${q}"` : "Catalogue Search"}
      subtitle={q ? `Explore matching silhouettes and wardrobe essentials.` : "Type keywords to filter styles."}
      filters={{
        search: q,
        size: params.size,
        color: params.color,
        minPrice: params.minPrice ? Number(params.minPrice) : undefined,
        maxPrice: params.maxPrice ? Number(params.maxPrice) : undefined,
        inStockOnly: params.inStockOnly === "true",
        sortBy: params.sortBy as any,
      }}
    />
  );
}


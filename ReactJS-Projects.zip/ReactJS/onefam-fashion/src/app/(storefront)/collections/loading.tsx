import { CatalogueSkeleton } from "@/features/storefront/components/catalogue-skeleton";

export default function CollectionsLoading() {
  return <CatalogueSkeleton titleWidth="w-72" />;
}


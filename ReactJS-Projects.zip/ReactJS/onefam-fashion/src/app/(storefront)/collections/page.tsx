import { CatalogueView } from "@/features/storefront/components/catalogue-view";
import { prisma } from "@/lib/prisma";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "All Signature Collections",
  description: "Browse curated ready-to-wear seasonal chapters, minimalist edits, and resort capsules.",
  alternates: {
    canonical: "/collections",
  },
  openGraph: {
    title: "Signature Collections | OneFam Fashion",
    description: "Browse curated ready-to-wear seasonal chapters, minimalist edits, and resort capsules.",
  },
};

export default async function CollectionsIndexPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const sp = await searchParams;

  const collections = await prisma.collection
    .findMany({
      where: { isActive: true },
      orderBy: { createdAt: "desc" },
    })
    .catch(() => []);

  // Determine title based on filter
  const activeCol = collections.find((c) => c.slug === sp.collectionSlug);
  const title = activeCol ? `${activeCol.title} Collection` : "Signature Collections";
  const subtitle = activeCol?.description ||
    "Explore our complete universe of bespoke silhouettes, resort linen edits, and contemporary family ready-to-wear.";

  return (
    <CatalogueView
      title={title}
      subtitle={subtitle}
      filters={{
        collectionSlug: sp.collectionSlug,
        categorySlug: sp.categorySlug,
        size: sp.size,
        color: sp.color,
        minPrice: sp.minPrice ? Number(sp.minPrice) : undefined,
        maxPrice: sp.maxPrice ? Number(sp.maxPrice) : undefined,
        inStockOnly: sp.inStockOnly === "true",
        sortBy: sp.sortBy as any,
      }}
    />
  );
}


import { CatalogueView } from "@/features/storefront/components/catalogue-view";
import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import type { Metadata } from "next";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const collection = await prisma.collection.findUnique({ where: { slug } });
  if (!collection) return { title: "Collection Not Found" };

  return {
    title: `${collection.title} | OneFam Fashion`,
    description: collection.description || `Explore pieces in the ${collection.title} collection.`,
  };
}

export default async function CollectionSlugPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const { slug } = await params;
  const sp = await searchParams;

  const collection = await prisma.collection.findUnique({
    where: { slug },
  });

  if (!collection) {
    notFound();
  }

  return (
    <CatalogueView
      title={collection.title}
      subtitle={collection.description || undefined}
      filters={{
        collectionSlug: slug,
        size: sp.size,
        color: sp.color,
        minPrice: sp.minPrice ? Number(sp.minPrice) : undefined,
        maxPrice: sp.maxPrice ? Number(sp.maxPrice) : undefined,
        inStockOnly: sp.inStockOnly === "true",
        sortBy: sp.sortBy as any,
      }}
    />
  );
}


import { CatalogueSkeleton } from "@/features/storefront/components/catalogue-skeleton";

export default function CollectionSlugLoading() {
  return <CatalogueSkeleton titleWidth="w-64" />;
}


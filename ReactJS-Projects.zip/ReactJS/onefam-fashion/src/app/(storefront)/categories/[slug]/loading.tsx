import { CatalogueSkeleton } from "@/features/storefront/components/catalogue-skeleton";

export default function CategorySlugLoading() {
  return <CatalogueSkeleton titleWidth="w-60" />;
}


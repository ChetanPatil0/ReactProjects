import { CatalogueView } from "@/features/storefront/components/catalogue-view";
import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import type { Metadata } from "next";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const category = await prisma.category.findUnique({ where: { slug } });
  if (!category) return { title: "Category Not Found" };

  return {
    title: `${category.name} | OneFam Fashion`,
    description: category.description || `Browse modern ready-to-wear pieces in ${category.name}.`,
  };
}

export default async function CategorySlugPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const { slug } = await params;
  const sp = await searchParams;

  const category = await prisma.category.findUnique({
    where: { slug },
  });

  if (!category) {
    notFound();
  }

  return (
    <CatalogueView
      title={category.name}
      subtitle={category.description || undefined}
      filters={{
        categorySlug: slug,
        size: sp.size,
        color: sp.color,
        minPrice: sp.minPrice ? Number(sp.minPrice) : undefined,
        maxPrice: sp.maxPrice ? Number(sp.maxPrice) : undefined,
        inStockOnly: sp.inStockOnly === "true",
        sortBy: sp.sortBy as any,
      }}
    />
  );
}


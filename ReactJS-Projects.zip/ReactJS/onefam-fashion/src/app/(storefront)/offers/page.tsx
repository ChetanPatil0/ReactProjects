import { CatalogueView } from "@/features/storefront/components/catalogue-view";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Special Offers & Limited Deals",
  description: "Shop discounted fashion ready-to-wear across Men, Women and Kids.",
};

export default async function OffersPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const params = await searchParams;

  return (
    <CatalogueView
      title="Promotional Offers &amp; Sale"
      subtitle="Exclusive limited-time price advantages on selected luxury wardrobe pieces."
      filters={{
        categorySlug: params.categorySlug,
        collectionSlug: params.collectionSlug,
        size: params.size,
        color: params.color,
        minPrice: params.minPrice ? Number(params.minPrice) : undefined,
        maxPrice: params.maxPrice ? Number(params.maxPrice) : undefined,
        inStockOnly: params.inStockOnly === "true",
        sortBy: params.sortBy as any,
      }}
    />
  );
}


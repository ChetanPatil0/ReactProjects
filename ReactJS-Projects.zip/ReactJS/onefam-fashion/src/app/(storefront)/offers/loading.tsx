import { CatalogueSkeleton } from "@/features/storefront/components/catalogue-skeleton";

export default function OffersLoading() {
  return <CatalogueSkeleton titleWidth="w-72" />;
}


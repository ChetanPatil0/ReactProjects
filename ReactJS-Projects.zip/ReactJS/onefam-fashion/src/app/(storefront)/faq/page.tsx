"use client";

import { useState } from "react";
import Link from "next/link";
import { Search, ChevronDown, ChevronUp, MessageSquare, ShieldCheck, Truck, CreditCard, RefreshCw } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface FaqItem {
  question: string;
  answer: string;
  category: "Ordering" | "Sizing" | "Payments" | "Shipping" | "Complaints & Support";
}

const FAQ_DATA: FaqItem[] = [
  {
    category: "Ordering",
    question: "Do you have any physical retail stores or warehouses?",
    answer:
      "No. OneFam operates as a 100% online digital family fashion boutique across India. We do not operate any physical retail stores or public warehouses. All pieces are inspected and dispatched directly to your doorstep via trusted express couriers.",
  },
  {
    category: "Ordering",
    question: "How does ordering through WhatsApp work?",
    answer:
      "When you discover a piece you love, select your preferred size and colour on the product page, then click 'Order on WhatsApp'. WhatsApp opens with your selected garment details. Our support team verifies stock immediately, confirms your shipping address, provides payment options, and registers your official order in our verified system.",
  },
  {
    category: "Ordering",
    question: "Can I place an order for multiple products at once?",
    answer:
      "Yes! Simply send the links or names of the garments you wish to order to our WhatsApp support team. Our team will consolidate your items into a single confirmed order with one combined invoice.",
  },
  {
    category: "Sizing",
    question: "How do I ensure the size fits me correctly?",
    answer:
      "Every product detail page displays a standard size guide. If you have custom proportion requirements (e.g. bust, waist, length), let our WhatsApp team know before confirmation. Because our garments are crafted with care, we can advise on the ideal fit.",
  },
  {
    category: "Payments",
    question: "What payment methods are supported?",
    answer:
      "We accept instant UPI transfers (Google Pay, PhonePe, Paytm, BHIM), direct Bank IMPS / NEFT transfers, and authorized Cash on Delivery in selected metro areas. Official digital invoices with GST breakdown are generated for every order.",
  },
  {
    category: "Payments",
    question: "Do you allow partial advance payments?",
    answer:
      "Yes. For bespoke or festive pieces, we allow partial advance payments (e.g. 30% to 50% advance to confirm your order, with the remaining balance due upon dispatch or delivery). Your outstanding balance and payment history are tracked transparently in our system.",
  },
  {
    category: "Shipping",
    question: "How long does domestic delivery take?",
    answer:
      "Orders are prepared and dispatched within 24 to 48 business hours. Metro transit takes approximately 2 to 4 business days. Regional destinations across India take approximately 4 to 6 business days via our courier partners (Bluedart, Delhivery, DTDC).",
  },
  {
    category: "Shipping",
    question: "How can I track my order in real-time?",
    answer:
      "Visit our public Track Order page (/track-order) and enter your registered email or mobile number along with your Order ID (e.g. ORD-XXXXXXXX), or request a 6-digit verification code. You can view all stages of fulfillment from Registered to Delivered in real-time.",
  },
  {
    category: "Complaints & Support",
    question: "What should I do if my package arrives damaged or has an issue?",
    answer:
      "We take extreme care in quality inspection. If an item arrives damaged or has a manufacturing defect, please log an official ticket via our Contact Us form under 'Damaged or Defect Item Report' or message our WhatsApp support (+91 98765 43210) within 48 hours of delivery. Our customer support team will investigate and arrange an immediate resolution.",
  },
];

export default function FaqPage() {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [openIndexes, setOpenIndexes] = useState<number[]>([0]);

  const toggleAccordion = (idx: number) => {
    setOpenIndexes((prev) =>
      prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
    );
  };

  const categories = ["All", "Ordering", "Sizing", "Payments", "Shipping", "Complaints & Support"];

  const filteredFaqs = FAQ_DATA.filter((item) => {
    const matchesCat = selectedCategory === "All" || item.category === selectedCategory;
    const matchesSearch =
      !search.trim() ||
      item.question.toLowerCase().includes(search.toLowerCase()) ||
      item.answer.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 text-ink space-y-10">
      {/* Header */}
      <div className="text-center space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-royal-violet">
          Help &amp; Customer Support
        </span>
        <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-ink">
          Frequently Asked Questions
        </h1>
        <p className="text-sm text-muted-foreground max-w-lg mx-auto">
          Everything you need to know about our atelier garments, WhatsApp concierge ordering, payment options, and tracking.
        </p>

        {/* Search */}
        <div className="max-w-md mx-auto pt-4 relative">
          <Search className="absolute left-3.5 top-6 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search questions (e.g. sizing, UPI, tracking, returns)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-12 pl-10 text-sm bg-white rounded-xl shadow-2xs border-border"
          />
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-full text-xs font-bold transition ${
              selectedCategory === cat
                ? "bg-royal-violet text-white shadow-xs"
                : "bg-white border border-border text-ink hover:border-royal-violet"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* FAQ Accordion List */}
      <div className="space-y-3">
        {filteredFaqs.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-border p-6 text-muted-foreground text-xs">
            No matching questions found for "{search}". Feel free to message our WhatsApp Concierge directly!
          </div>
        ) : (
          filteredFaqs.map((faq, idx) => {
            const isOpen = openIndexes.includes(idx);
            return (
              <div
                key={idx}
                className="bg-white rounded-xl border border-border/80 shadow-2xs overflow-hidden transition"
              >
                <button
                  type="button"
                  onClick={() => toggleAccordion(idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-sm text-ink hover:text-royal-violet transition"
                >
                  <span className="flex-1">{faq.question}</span>
                  <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center shrink-0">
                    {isOpen ? <ChevronUp className="w-4 h-4 text-royal-violet" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                  </div>
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 text-xs text-muted-foreground leading-relaxed border-t border-border/40 pt-3">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Still Have Questions CTA */}
      <div className="p-8 rounded-2xl bg-ink text-paper flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-1 text-center sm:text-left">
          <span className="text-xs font-bold uppercase tracking-wider text-electric-lime block">
            Direct Concierge Assistance
          </span>
          <h3 className="text-xl font-bold text-paper">Have a specific inquiry not listed here?</h3>
          <p className="text-xs text-paper/70">
            Our atelier stylists are available 6 days a week on WhatsApp.
          </p>
        </div>

        <Button
          asChild
          size="lg"
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl px-6 shrink-0 shadow-md"
        >
          <a href="https://wa.me/919876543210" target="_blank" rel="noopener noreferrer">
            <MessageSquare className="w-4 h-4 mr-2" />
            Chat with Concierge
          </a>
        </Button>
      </div>
    </div>
  );
}


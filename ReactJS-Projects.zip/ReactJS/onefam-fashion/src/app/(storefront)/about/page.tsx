import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { Heart, Shirt, ArrowRight, Headphones } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SocialCommunitySection } from "@/features/storefront/components/social-community-section";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "Our Story & Philosophy",
  description: "Learn about the founding philosophy, natural materials, and artisan craftsmanship behind OneFam Fashion.",
  alternates: {
    canonical: "/about",
  },
};

export default async function AboutPage() {
  const settings = await prisma.storeSettings.findFirst().catch(() => null);

  const whatsappNumber = settings?.whatsappNumber || siteConfig.contact.whatsappNumber;

  return (
    <div className="space-y-16 sm:space-y-24 py-12 sm:py-16 text-foreground">
      {/* 1. Page Hero Header */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-royal-violet/10 text-royal-violet dark:text-[#C6F542] text-xs font-bold uppercase tracking-widest">
          <span className="w-1.5 h-1.5 rounded-full bg-royal-violet dark:bg-[#C6F542] shrink-0" />
          The OneFam Story
        </div>
        <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-foreground">
          Mindful Design, Natural Textiles &amp; Family Harmony
        </h1>
        <p className="text-sm sm:text-base text-muted-foreground max-w-2xl mx-auto leading-relaxed">
          Founded with a singular conviction: ready-to-wear fashion should balance architectural elegance with tactile ease, crafted for the entire modern family.
        </p>
      </section>

      {/* 2. Our Story Narrative Section */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          <div className="lg:col-span-6 space-y-5">
            <span className="text-xs font-bold uppercase tracking-widest text-royal-violet">
              How We Started
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-foreground">
              Rejecting Fast Trends in Favor of Timeless Ease
            </h2>
            <div className="space-y-4 text-xs sm:text-sm text-muted-foreground leading-relaxed">
              <p>
                OneFam Fashion was born in Bengaluru with a simple observation: modern families were forced to choose between cheap synthetic fast-fashion or inaccessible luxury with rigid sizing.
              </p>
              <p>
                We envisioned a unified sartorial house where Men, Women, and Kids could discover cohesive wardrobe chapters crafted from certified organic cottons, French flax linens, and artisanal handwoven textiles.
              </p>
              <p>
                We operate exclusively as a 100% online direct-to-consumer brand with express delivery across India. We do not operate walk-in physical stores or warehouses, allowing us to invest directly in certified natural fibres, meticulous stitching, and personalized customer care.
              </p>
            </div>

            <div className="pt-2 flex items-center gap-4">
              <Button asChild className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-xl text-xs h-10 px-5 shadow-sm">
                <Link href="/collections/urban-minimalist">
                  Explore Silhouettes <ArrowRight className="w-3.5 h-3.5 ml-1.5" />
                </Link>
              </Button>
              <Button asChild variant="outline" className="rounded-xl text-xs h-10 px-5">
                <Link href="/contact">
                  Contact Team
                </Link>
              </Button>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="relative rounded-[2rem] overflow-hidden aspect-[4/3] bg-muted shadow-xl border border-border/60">
              <img
                src={siteConfig.images.banners.about}
                alt="Studio drape and fabric fitting"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 text-white text-xs">
                <span className="font-bold block text-sm">OneFam Design Studio</span>
                <span className="text-white/80">Tailored with high-performance natural fibres</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Three Core Pillars */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-7 rounded-2xl bg-card border border-border/80 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-royal-violet/10 text-royal-violet flex items-center justify-center">
              <Shirt className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-foreground">Artisanal &amp; Pure Weaves</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              We curate pure Normandy flax linens, GOTS-certified organic cottons, and rich handloom textures that provide unmatched skin comfort.
            </p>
          </div>

          <div className="p-7 rounded-2xl bg-card border border-border/80 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-royal-violet/10 text-royal-violet flex items-center justify-center">
              <Heart className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-foreground">Family-First Harmony</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Coordinated palettes and silhouettes across Men, Women, and Kids make dressing for family milestones effortless and joyful.
            </p>
          </div>

          <div className="p-7 rounded-2xl bg-card border border-border/80 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Headphones className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-foreground">Direct WhatsApp &amp; Online Care</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Connect directly with our support team via WhatsApp or our contact desk for sizing guidance and order assistance.
            </p>
          </div>
        </div>
      </section>

      {/* 4. Compact Premium Social Community Section */}
      <SocialCommunitySection
        whatsappNumber={whatsappNumber}
        instagramUrl={settings?.instagramUrl || undefined}
        facebookUrl={settings?.facebookUrl || undefined}
        showValueProps={false}
      />
    </div>
  );
}

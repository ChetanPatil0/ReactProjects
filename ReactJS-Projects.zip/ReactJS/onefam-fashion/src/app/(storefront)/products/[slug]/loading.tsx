export default function ProductDetailLoading() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16 animate-pulse">
      {/* Breadcrumb Skeleton */}
      <div className="flex items-center gap-2">
        <div className="h-3 w-12 bg-muted rounded-md" />
        <div className="h-3 w-3 bg-muted/40 rounded-full" />
        <div className="h-3 w-20 bg-muted rounded-md" />
        <div className="h-3 w-3 bg-muted/40 rounded-full" />
        <div className="h-3 w-32 bg-muted/60 rounded-md" />
      </div>

      {/* Main Product Skeleton: Left 5 cols (gallery), Right 7 cols (details) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        {/* Left Gallery Skeleton */}
        <div className="lg:col-span-5 max-w-[480px] w-full flex flex-col-reverse sm:flex-row gap-3.5">
          {/* Thumbnails strip skeleton */}
          <div className="flex sm:flex-col gap-2.5 shrink-0">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="w-14 h-18 sm:w-16 sm:h-20 rounded-xl bg-muted/60" />
            ))}
          </div>

          {/* Main regular image skeleton */}
          <div className="flex-1 aspect-[3/4] max-h-[500px] rounded-2xl bg-muted/50 border border-border/60" />
        </div>

        {/* Right Details Skeleton */}
        <div className="lg:col-span-7 space-y-5">
          <div className="h-3 w-24 bg-muted/80 rounded-md" />
          <div className="h-8 w-3/4 bg-muted rounded-xl" />
          <div className="h-4 w-full bg-muted/50 rounded-md max-w-md" />

          {/* Price skeleton */}
          <div className="h-8 w-36 bg-muted rounded-lg pt-2" />

          {/* Color selector skeleton */}
          <div className="space-y-2 pt-4 border-t border-border/40">
            <div className="h-3 w-20 bg-muted/60 rounded-md" />
            <div className="flex gap-2">
              <div className="w-9 h-9 rounded-full bg-muted/70" />
              <div className="w-9 h-9 rounded-full bg-muted/70" />
              <div className="w-9 h-9 rounded-full bg-muted/70" />
            </div>
          </div>

          {/* Size selector skeleton */}
          <div className="space-y-2 pt-4 border-t border-border/40">
            <div className="h-3 w-16 bg-muted/60 rounded-md" />
            <div className="flex gap-2">
              <div className="w-12 h-10 rounded-xl bg-muted/60" />
              <div className="w-12 h-10 rounded-xl bg-muted/60" />
              <div className="w-12 h-10 rounded-xl bg-muted/60" />
              <div className="w-12 h-10 rounded-xl bg-muted/60" />
            </div>
          </div>

          {/* CTA skeleton */}
          <div className="pt-4 space-y-3">
            <div className="w-full h-13 rounded-xl bg-muted" />
          </div>
        </div>
      </div>
    </div>
  );
}


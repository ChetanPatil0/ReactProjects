import { prisma } from "@/lib/prisma";
import { productService } from "@/server/services/product-service";
import { ProductDetailView } from "@/features/products/components/product-detail-view";
import { serializeProduct, serializeProducts } from "@/lib/serializers";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { siteConfig, getProductJsonLd } from "@/config/site";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const product = await productService.getProductBySlug(slug);

  if (!product) {
    return { title: "Product Not Found" };
  }

  const primaryImage = product.images.find((i) => i.isPrimary) || product.images[0];
  const imageUrl = primaryImage?.path || siteConfig.images.placeholders.product;
  const activePrice = product.discountPrice ? Number(product.discountPrice) : Number(product.regularPrice);

  return {
    title: `${product.name} | ${siteConfig.brand.name}`,
    description:
      product.shortDescription ||
      `Shop ${product.name} (₹${activePrice}) at ${siteConfig.brand.name}. Premium ready-to-wear crafted in breathable natural textiles.`,
    alternates: {
      canonical: `/products/${product.slug}`,
    },
    openGraph: {
      title: `${product.name} | ${siteConfig.brand.name}`,
      description: product.shortDescription || product.description || undefined,
      url: `${siteConfig.seo.siteUrl}/products/${product.slug}`,
      siteName: siteConfig.brand.name,
      images: [
        {
          url: imageUrl,
          alt: product.name,
        },
      ],
      type: "article",
    },
    twitter: {
      card: "summary_large_image",
      title: product.name,
      description: product.shortDescription || undefined,
      images: [imageUrl],
    },
  };
}

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = await productService.getProductBySlug(slug);

  if (!product) {
    notFound();
  }

  // Related products from same category or fallback to other published styles
  const [initialRelated, settings] = await Promise.all([
    prisma.product.findMany({
      where: {
        ...(product.categoryId ? { categoryId: product.categoryId } : {}),
        id: { not: product.id },
        status: "PUBLISHED",
      },
      take: 4,
      orderBy: { createdAt: "desc" },
      include: {
        images: true,
        variants: true,
      },
    }),
    prisma.storeSettings.findFirst().catch(() => null),
  ]);

  let rawRelatedProducts = initialRelated;
  if (rawRelatedProducts.length < 4) {
    const fallbackProducts = await prisma.product.findMany({
      where: {
        id: { notIn: [product.id, ...rawRelatedProducts.map((p) => p.id)] },
        status: "PUBLISHED",
      },
      take: 4 - rawRelatedProducts.length,
      orderBy: { createdAt: "desc" },
      include: {
        images: true,
        variants: true,
      },
    });
    rawRelatedProducts = [...rawRelatedProducts, ...fallbackProducts];
  }

  const serializedProduct = serializeProduct(product);
  const relatedProducts = serializeProducts(rawRelatedProducts);

  const primaryImage = product.images.find((i) => i.isPrimary) || product.images[0];
  const activePrice = product.discountPrice ? Number(product.discountPrice) : Number(product.regularPrice);
  const inStock = product.variants.some((v) => (v.stock ?? 0) > 0 && v.isAvailable !== false);

  // Schema.org Product structured data (JSON-LD) for Google Rich Snippets
  const productJsonLd = getProductJsonLd({
    name: product.name,
    description: product.shortDescription || product.description || undefined,
    image: primaryImage?.path || siteConfig.images.placeholders.product,
    sku: product.sku || undefined,
    price: activePrice,
    inStock,
    slug: product.slug,
  });

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(productJsonLd) }}
      />
      <ProductDetailView
        product={serializedProduct}
        relatedProducts={relatedProducts}
        whatsappNumber={settings?.whatsappNumber || siteConfig.contact.whatsappNumber}
      />
    </>
  );
}

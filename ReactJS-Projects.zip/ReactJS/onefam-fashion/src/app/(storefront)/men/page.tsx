import { CatalogueView } from "@/features/storefront/components/catalogue-view";
import type { Metadata } from "next";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "Men's Ready-to-Wear & Linen Tailoring",
  description: "Bespoke linen camp shirts, heavyweight organic cotton tees, relaxed denim and trousers for men.",
  alternates: {
    canonical: "/men",
  },
  openGraph: {
    title: "Men's Fashion & Tailoring | OneFam Fashion",
    description: "Bespoke linen camp shirts, organic cotton tees, and relaxed trousers.",
    images: [{ url: siteConfig.images.banners.men }],
  },
};

export default async function MenPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const params = await searchParams;

  return (
    <CatalogueView
      title="Men's Collection"
      subtitle="Refined silhouettes, architectural cuts, and high-performance natural textiles."
      filters={{
        categorySlug: "men",
        size: params.size,
        color: params.color,
        minPrice: params.minPrice ? Number(params.minPrice) : undefined,
        maxPrice: params.maxPrice ? Number(params.maxPrice) : undefined,
        inStockOnly: params.inStockOnly === "true",
        sortBy: params.sortBy as any,
      }}
    />
  );
}


import { CatalogueSkeleton } from "@/features/storefront/components/catalogue-skeleton";

export default function MenLoading() {
  return <CatalogueSkeleton titleWidth="w-52" />;
}


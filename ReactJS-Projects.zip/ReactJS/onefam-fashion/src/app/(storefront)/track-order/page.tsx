import { OrderTrackingClient } from "@/features/tracking/components/order-tracking-client";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Track Your Order | OneFam Fashion",
  description: "Check the status, fulfillment progress, and shipping timeline of your OneFam order.",
};

export default async function TrackOrderPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const params = await searchParams;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
      <div className="text-center max-w-xl mx-auto mb-10">
        <span className="text-xs font-bold uppercase tracking-widest text-royal-violet dark:text-[#C6F542]">
          Order Transparency
        </span>
        <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-foreground mt-1">
          Track Your Order
        </h1>
        <p className="text-sm text-muted-foreground mt-2">
          Enter your Order ID along with your registered Email or Mobile number to check real-time order status, fulfillment progress, and delivery milestones.
        </p>
      </div>

      <OrderTrackingClient
        initialRef={params.ref || params.orderRef || ""}
        initialContact={params.email || params.phone || params.contact || ""}
      />
    </div>
  );
}


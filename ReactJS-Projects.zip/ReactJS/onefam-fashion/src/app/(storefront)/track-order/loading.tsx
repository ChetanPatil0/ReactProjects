export default function TrackOrderLoading() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 animate-pulse">
      {/* Header Skeleton */}
      <div className="text-center max-w-xl mx-auto mb-10 space-y-3">
        <div className="h-4 w-36 bg-muted/60 rounded-full mx-auto" />
        <div className="h-9 w-64 bg-muted rounded-xl mx-auto" />
        <div className="h-4 w-96 max-w-full bg-muted/50 rounded-md mx-auto" />
      </div>

      {/* Lookup Card Skeleton */}
      <div className="max-w-2xl mx-auto bg-card rounded-2xl border border-border/60 p-6 sm:p-8 space-y-6">
        {/* Mode Toggle Buttons Skeleton */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-muted/40 rounded-xl">
          <div className="h-9 bg-background rounded-lg border border-border/50" />
          <div className="h-9 bg-transparent rounded-lg" />
        </div>

        {/* Form Inputs Skeleton */}
        <div className="space-y-4">
          <div className="space-y-1.5">
            <div className="h-3.5 w-44 bg-muted/70 rounded" />
            <div className="h-11 w-full bg-muted/40 rounded-xl border border-border/40" />
          </div>
          <div className="space-y-1.5">
            <div className="h-3.5 w-32 bg-muted/70 rounded" />
            <div className="h-11 w-full bg-muted/40 rounded-xl border border-border/40" />
          </div>
          <div className="h-12 w-full bg-muted/80 rounded-xl mt-2" />
        </div>

        {/* Feature Hint Skeleton */}
        <div className="pt-4 border-t border-border/40 flex items-center justify-between text-xs">
          <div className="h-3 w-40 bg-muted/40 rounded" />
          <div className="h-3 w-28 bg-muted/40 rounded" />
        </div>
      </div>
    </div>
  );
}


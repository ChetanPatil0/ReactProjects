import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Shipping & Delivery Policy | OneFam Fashion",
  description: "Learn about order dispatch, domestic timelines, carrier partners, and tracking.",
};

export default function ShippingPolicyPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-16 text-ink space-y-8">
      <h1 className="text-3xl font-black tracking-tight">Shipping &amp; Delivery Policy</h1>
      <div className="prose prose-neutral max-w-none text-xs sm:text-sm leading-relaxed space-y-4 text-ink/80">
        <h2 className="text-base font-bold text-ink">1. Order Dispatch &amp; Verification</h2>
        <p>
          Once your order has been confirmed and recorded in our system, your pieces are quality-checked and packaged for dispatch within 24 to 48 business hours. As a 100% online direct-to-consumer boutique, we operate purely digitally without physical walk-in stores or warehouses; all packages are dispatched directly to your doorstep across India via trusted express courier partners.
        </p>

        <h2 className="text-base font-bold text-ink">2. Domestic Delivery Timelines</h2>
        <p>
          We partner with leading express couriers (Bluedart, Delhivery, DTDC). Metro deliveries typically arrive within 2–4 business days. Regional and remote destinations across India take approximately 4–6 business days.
        </p>

        <h2 className="text-base font-bold text-ink">3. Transparent Real-Time Tracking</h2>
        <p>
          Once dispatched, a tracking number and shipping confirmation are generated. You can check real-time progress anytime via our dedicated <a href="/track-order" className="text-royal-violet underline font-semibold">Track Order</a> portal using your registered email or mobile number and Order Reference.
        </p>

        <h2 className="text-base font-bold text-ink">4. Shipping Charges</h2>
        <p>
          Standard ground shipping is complimentary on all prepaid orders exceeding ₹1,499. For expedited express requests, nominal courier fees may apply as confirmed with our team.
        </p>
      </div>
    </div>
  );
}


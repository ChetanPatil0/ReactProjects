import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Terms of Service | OneFam Fashion",
  description: "OneFam Fashion terms of service, ordering policies, and customer guidelines.",
};

export default function TermsPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-16 text-ink space-y-8">
      <h1 className="text-3xl font-black tracking-tight">Terms of Service</h1>
      <div className="prose prose-neutral max-w-none text-xs sm:text-sm leading-relaxed space-y-4 text-ink/80">
        <h2 className="text-base font-bold text-ink">1. Agreement to Terms</h2>
        <p>
          By accessing OneFam Fashion, browsing our catalogue, or placing an order via our WhatsApp concierge, you acknowledge and agree to these terms and conditions.
        </p>

        <h2 className="text-base font-bold text-ink">2. Product Presentation &amp; Sizing</h2>
        <p>
          We photograph our collections in natural studio lighting to convey true fabric textures and colors. Subtle variations may exist depending on display calibration. Please review the sizing measurements with our team before order confirmation.
        </p>

        <h2 className="text-base font-bold text-ink">3. Order Confirmation &amp; Invoices</h2>
        <p>
          Orders are officially recorded once confirmed with our staff. Official digital GST-compliant invoices are generated directly from our verified store system with unique invoice and order numbers.
        </p>
      </div>
    </div>
  );
}


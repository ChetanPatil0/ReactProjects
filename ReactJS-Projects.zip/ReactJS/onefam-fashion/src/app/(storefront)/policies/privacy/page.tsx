import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy | OneFam Fashion",
  description: "OneFam Fashion customer privacy, data retention, and security policies.",
};

export default function PrivacyPolicyPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-16 text-ink space-y-8">
      <h1 className="text-3xl font-black tracking-tight">Privacy Policy</h1>
      <div className="prose prose-neutral max-w-none text-xs sm:text-sm leading-relaxed space-y-4 text-ink/80">
        <h2 className="text-base font-bold text-ink">1. Data Protection Commitment</h2>
        <p>
          At OneFam Fashion, customer privacy is paramount. We only collect the minimal personal data (name, shipping address, contact phone, and email) necessary to fulfill your orders, provide invoices, and track parcel logistics.
        </p>

        <h2 className="text-base font-bold text-ink">2. Non-Disclosure &amp; Security</h2>
        <p>
          We never sell, rent, or trade your personal information to third parties. Customer order tracking endpoints are protected with random non-sequential identifiers and email/OTP verification to prevent unauthorized enumeration.
        </p>

        <h2 className="text-base font-bold text-ink">3. Inquiries &amp; Data Rights</h2>
        <p>
          You may request an update or removal of your contact information at any time by contacting our data protection officer at <span className="font-semibold text-royal-violet">care@onefamfashion.com</span>.
        </p>
      </div>
    </div>
  );
}


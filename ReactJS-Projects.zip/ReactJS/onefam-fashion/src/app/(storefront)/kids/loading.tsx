import { CatalogueSkeleton } from "@/features/storefront/components/catalogue-skeleton";

export default function KidsLoading() {
  return <CatalogueSkeleton titleWidth="w-48" />;
}


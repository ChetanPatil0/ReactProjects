import { CatalogueView } from "@/features/storefront/components/catalogue-view";
import type { Metadata } from "next";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "Kids Apparel & Celebration Wear",
  description: "Organic cotton festive kurta sets, breezy floral frocks and play-ready casuals for boys and girls.",
  alternates: {
    canonical: "/kids",
  },
  openGraph: {
    title: "Kids Collection | OneFam Fashion",
    description: "Crafted with pure organic cottons and joyful silhouettes made for celebration and play.",
    images: [{ url: siteConfig.images.banners.kids }],
  },
};

export default async function KidsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const params = await searchParams;

  return (
    <CatalogueView
      title="Kids Collection"
      subtitle="Crafted with pure organic cottons and joyful silhouettes made for celebration and play."
      filters={{
        categorySlug: "kids",
        size: params.size,
        color: params.color,
        minPrice: params.minPrice ? Number(params.minPrice) : undefined,
        maxPrice: params.maxPrice ? Number(params.maxPrice) : undefined,
        inStockOnly: params.inStockOnly === "true",
        sortBy: params.sortBy as any,
      }}
    />
  );
}


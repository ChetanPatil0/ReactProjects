import { CatalogueView } from "@/features/storefront/components/catalogue-view";
import type { Metadata } from "next";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "Women's Collection & Evening Wear",
  description: "Liquid satin midi dresses, artisanal zari Chanderi kurtis, fluid tops and modern trousers.",
  alternates: {
    canonical: "/women",
  },
  openGraph: {
    title: "Women's Collection | OneFam Fashion",
    description: "Fluid evening silhouettes, tactile textures, and modern interpretations of festive heritage.",
    images: [{ url: siteConfig.images.banners.women }],
  },
};

export default async function WomenPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const params = await searchParams;

  return (
    <CatalogueView
      title="Women's Collection"
      subtitle="Fluid evening silhouettes, tactile textures, and modern interpretations of festive heritage."
      filters={{
        categorySlug: "women",
        size: params.size,
        color: params.color,
        minPrice: params.minPrice ? Number(params.minPrice) : undefined,
        maxPrice: params.maxPrice ? Number(params.maxPrice) : undefined,
        inStockOnly: params.inStockOnly === "true",
        sortBy: params.sortBy as any,
      }}
    />
  );
}


import { CatalogueSkeleton } from "@/features/storefront/components/catalogue-skeleton";

export default function WomenLoading() {
  return <CatalogueSkeleton titleWidth="w-56" />;
}


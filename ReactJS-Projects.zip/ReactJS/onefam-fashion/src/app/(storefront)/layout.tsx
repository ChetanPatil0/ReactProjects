import { StorefrontHeader } from "@/features/storefront/components/header/header";
import { StorefrontFooter } from "@/features/storefront/components/footer/footer";
import { ToastProvider } from "@/components/providers/toast-provider";
import { QueryProvider } from "@/components/providers/query-provider";
import { prisma } from "@/lib/prisma";

export default async function StorefrontLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [settings, categories, collections] = await Promise.all([
    prisma.storeSettings.findFirst().catch(() => null),
    prisma.category
      .findMany({
        where: { parentId: null, isActive: true },
        orderBy: { displayOrder: "asc" },
        include: {
          children: {
            where: { isActive: true },
            orderBy: { displayOrder: "asc" },
          },
        },
      })
      .catch(() => []),
    prisma.collection
      .findMany({
        where: { isActive: true },
        orderBy: { createdAt: "desc" },
      })
      .catch(() => []),
  ]);

  return (
    <QueryProvider>
      <div className="min-h-screen flex flex-col bg-paper text-ink selection:bg-royal-violet selection:text-white">
        <StorefrontHeader
          announcement={settings?.announcementBar || undefined}
          whatsappNumber={settings?.whatsappNumber || undefined}
          categories={categories as any}
          collections={collections as any}
        />
        <main className="flex-1">{children}</main>
        <StorefrontFooter settings={settings} />
        <ToastProvider />
      </div>
    </QueryProvider>
  );
}


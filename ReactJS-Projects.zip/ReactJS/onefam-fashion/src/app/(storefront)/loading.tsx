export default function StorefrontLoading() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8 animate-pulse">
      {/* Header Skeleton */}
      <div className="pb-6 border-b border-border/60 space-y-3">
        <div className="h-4 w-28 bg-muted rounded-full" />
        <div className="h-8 w-64 bg-muted rounded-xl" />
        <div className="h-4 w-96 bg-muted/60 rounded-lg max-w-full" />
      </div>

      {/* Grid Skeleton */}
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
        {Array.from({ length: 8 }).map((_, idx) => (
          <div
            key={idx}
            className="flex flex-col rounded-2xl overflow-hidden border border-border/60 bg-card p-3 space-y-3"
          >
            {/* Image Skeleton */}
            <div className="aspect-[4/5] w-full rounded-xl bg-muted/50" />
            {/* Title & Sizing Skeleton */}
            <div className="space-y-2">
              <div className="h-3 w-1/3 bg-muted/60 rounded-md" />
              <div className="h-4 w-4/5 bg-muted rounded-md" />
            </div>
            {/* Price Skeleton */}
            <div className="pt-2 border-t border-border/40 flex items-center justify-between">
              <div className="h-5 w-20 bg-muted rounded-md" />
              <div className="h-4 w-12 bg-muted/50 rounded-md" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}


import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { serializeProducts } from "@/lib/serializers";
import { HeroSlider } from "@/features/storefront/components/hero-slider/hero-slider";
import { ProductCard } from "@/features/storefront/components/product-card/product-card";
import { SocialCommunitySection } from "@/features/storefront/components/social-community-section";
import { ScrollReveal } from "@/components/shared/scroll-reveal";
import { Button } from "@/components/ui/button";
import { ArrowRight, ArrowUpRight, MessageSquare } from "lucide-react";

export const revalidate = 60; // revalidate at most once every minute

export default async function HomePage() {
  // Fetch dynamic content from PostgreSQL database
  const [slides, categories, rawNewArrivals, rawTrending, rawCollections, settings] = await Promise.all([
    prisma.heroSlide.findMany({
      where: { isActive: true },
      orderBy: { sortOrder: "asc" },
    }),
    prisma.category.findMany({
      where: { parentId: null, isActive: true },
      orderBy: { displayOrder: "asc" },
      include: {
        children: {
          where: { isActive: true },
          orderBy: { displayOrder: "asc" },
        },
      },
    }),
    prisma.product.findMany({
      where: { status: "PUBLISHED", isNewArrival: true },
      take: 8,
      orderBy: { createdAt: "desc" },
      include: {
        images: true,
        variants: true,
      },
    }),
    prisma.product.findMany({
      where: { status: "PUBLISHED", isTrending: true },
      take: 8,
      orderBy: { createdAt: "desc" },
      include: {
        images: true,
        variants: true,
      },
    }),
    prisma.collection.findMany({
      where: { isActive: true },
      take: 6,
      orderBy: { createdAt: "desc" },
    }),
    prisma.storeSettings.findFirst().catch(() => null),
  ]);

  const collections = [...rawCollections].sort((a, b) => {
    const orderA = a.seoTitle && !isNaN(Number(a.seoTitle)) ? Number(a.seoTitle) : 999;
    const orderB = b.seoTitle && !isNaN(Number(b.seoTitle)) ? Number(b.seoTitle) : 999;
    return orderA - orderB;
  }).slice(0, 3);

  const newArrivals = serializeProducts(rawNewArrivals);
  const trending = serializeProducts(rawTrending);

  const whatsappNumber = settings?.whatsappNumber || "919876543210";

  return (
    <div className="space-y-16 sm:space-y-24 pb-20">
      {/* 1. Hero Slider */}
      <section aria-label="Hero Slider">
        <HeroSlider slides={slides} />
      </section>

      {/* 2. Universes of Style - Compact Editorial Cards */}
      <ScrollReveal className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex items-center gap-2 text-xs font-bold tracking-widest text-royal-violet uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-royal-violet shrink-0" />
            Sartorial Realms
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-foreground mt-1">
            Universes of Style
          </h2>
          <p className="text-sm text-muted-foreground mt-2 max-w-2xl leading-relaxed">
            Architectural tailoring, fluid feminine grace, and gentle artisanal weaves — curated chapters crafted for the modern family.
          </p>
        </div>

        {/* Editorial Fashion Cards Grid (Responsive & Compact on Mobile) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5 sm:gap-6 lg:gap-8">
          {categories.map((cat, idx) => {
            const defaultImage =
              idx === 0
                ? "https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?q=80&w=1200&auto=format&fit=crop"
                : idx === 1
                ? "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=1200&auto=format&fit=crop"
                : "https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?q=80&w=1200&auto=format&fit=crop";

            const imageSrc = cat.imagePath || defaultImage;
            const editionTag = idx === 0 ? "THE MEN'S LINE" : idx === 1 ? "THE WOMEN'S LINE" : "THE LITTLE ONES";

            return (
              <Link
                key={cat.id}
                href={`/${cat.slug}`}
                prefetch={true}
                className="group relative rounded-2xl sm:rounded-3xl lg:rounded-[2rem] overflow-hidden h-[200px] sm:h-[270px] md:h-[320px] lg:h-[350px] bg-[#0E0C15] border border-border/80 shadow-sm hover:shadow-xl transition-all duration-700 flex flex-col justify-between p-4 sm:p-6 lg:p-7 select-none"
              >
                {/* Background Photography with Smooth Parallax Zoom */}
                <div
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-1000 ease-out group-hover:scale-106"
                  style={{ backgroundImage: `url(${imageSrc})` }}
                />

                {/* Refined Luxury Vignette */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/15 transition-opacity duration-500 group-hover:via-black/55" />

                {/* Top Corner: Brand Styled Edition Badge & Floating Arrow */}
                <div className="relative z-10 flex items-center justify-between">
                  <span className="px-2.5 py-0.5 sm:px-3 sm:py-1 rounded-full text-[10px] sm:text-[11px] font-bold uppercase tracking-wider bg-royal-violet text-white shadow-xs">
                    {editionTag}
                  </span>

                  <span className="w-7 h-7 sm:w-9 sm:h-9 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white group-hover:bg-white group-hover:text-black group-hover:rotate-45 transition-all duration-500 shadow-sm">
                    <ArrowUpRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 transition-transform" />
                  </span>
                </div>

                {/* Bottom Content: Subcategories, Clean Bold Title & Elegant CTA */}
                <div className="relative z-10 space-y-1 sm:space-y-2">
                  {cat.children && cat.children.length > 0 && (
                    <div className="flex flex-wrap gap-1 sm:gap-1.5">
                      {cat.children.slice(0, 3).map((sub: any) => (
                        <span
                          key={sub.id}
                          className="text-[9px] sm:text-[10px] font-medium tracking-wide px-2 py-0.5 rounded-full bg-white/10 backdrop-blur-xs text-white/90 border border-white/15"
                        >
                          {sub.name}
                        </span>
                      ))}
                    </div>
                  )}

                  <div>
                    <h3 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-white tracking-tight leading-tight">
                      {cat.name}
                    </h3>
                    {cat.description && (
                      <p className="text-[11px] sm:text-xs text-white/80 line-clamp-1 mt-0.5 leading-relaxed font-normal">
                        {cat.description}
                      </p>
                    )}
                  </div>

                  <div className="pt-0.5 sm:pt-1">
                    <span className="inline-flex items-center gap-1.5 text-[11px] sm:text-xs font-bold text-white group-hover:text-electric-lime transition-colors duration-300">
                      <span className="border-b border-white/40 group-hover:border-electric-lime pb-0.5 transition-colors">
                        View Collection
                      </span>
                      <ArrowRight className="w-3 h-3 sm:w-3.5 sm:h-3.5 transition-transform duration-300 group-hover:translate-x-1" />
                    </span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </ScrollReveal>

      {/* 2b. Infinite Statement Marquee Ticker with Bold Fonts & Realistic Professional Highlights */}
      <ScrollReveal>
        <section aria-label="Brand Highlights Marquee" className="w-full overflow-hidden border-y border-border/80 bg-card py-5 sm:py-6 shadow-2xs select-none">
          <div className="animate-marquee flex items-center whitespace-nowrap gap-12 sm:gap-16">
            {[1, 2].map((set) => (
              <div
                key={set}
                className="flex items-center gap-12 sm:gap-16 text-sm sm:text-base md:text-lg font-black tracking-wider text-foreground shrink-0 uppercase"
              >
                <span className="flex items-center gap-3">
                  <span className="text-royal-violet dark:text-[#C6F542] text-xs">●</span>
                  Curated Branded Collections
                </span>
                <span className="flex items-center gap-3">
                  <span className="text-royal-violet dark:text-[#C6F542] text-xs">●</span>
                  Trusted by 1K+ Happy Families
                </span>
                <span className="flex items-center gap-3">
                  <span className="text-royal-violet dark:text-[#C6F542] text-xs">●</span>
                  Honest Luxury Pricing — Unmatched Value
                </span>
                <span className="flex items-center gap-3">
                  <span className="text-royal-violet dark:text-[#C6F542] text-xs">●</span>
                  100% Quality Inspected Garments
                </span>
                <span className="flex items-center gap-3">
                  <span className="text-royal-violet dark:text-[#C6F542] text-xs">●</span>
                  Direct 1-Click WhatsApp Ordering
                </span>
                <span className="flex items-center gap-3">
                  <span className="text-royal-violet dark:text-[#C6F542] text-xs">●</span>
                  Pan-India Express Doorstep Delivery
                </span>
              </div>
            ))}
          </div>
        </section>
      </ScrollReveal>

      {/* 3. New Arrivals Carousel / Grid */}
      <ScrollReveal className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold tracking-widest text-royal-violet uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-royal-violet shrink-0" />
              Fresh In Store
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-foreground mt-1">
              New Arrivals
            </h2>
          </div>
          <Button asChild variant="outline" size="sm" className="rounded-full text-xs font-semibold">
            <Link href="/collections/new-arrivals" prefetch={true}>
              View All <ArrowRight className="ml-1 w-3.5 h-3.5" />
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {newArrivals.map((prod) => (
            <ProductCard key={prod.id} product={prod as any} whatsappNumber={whatsappNumber} />
          ))}
        </div>
      </ScrollReveal>

      {/* 4. Promotional Editorial Banner / Marketing CTA */}
      <ScrollReveal className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-[#15131C] dark:bg-[#1A1726] border border-white/10 dark:border-white/15 text-white p-8 sm:p-12 lg:p-16 shadow-xl">
          <div
            className="absolute inset-0 bg-cover bg-center opacity-30 mix-blend-overlay"
            style={{
              backgroundImage:
                "url('https://images.unsplash.com/photo-1445205170230-053b83016050?q=80&w=1600&auto=format&fit=crop')",
            }}
          />
          <div className="relative z-10 max-w-xl space-y-4">
            <span className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-electric-lime text-[#191720]">
              Limited Edition Release
            </span>
            <h2 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight text-white">
              The Urban Minimalist &amp; Linen Edit
            </h2>
            <p className="text-sm sm:text-base text-white/85 leading-relaxed">
              Timeless silhouettes designed with breathability and pure natural drapes. Available for seamless direct WhatsApp ordering with doorstep delivery.
            </p>
            <div className="pt-2 flex flex-wrap gap-3">
              <Button
                asChild
                size="lg"
                className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold rounded-full px-8 shadow-md"
              >
                <Link href="/collections/urban-minimalist" prefetch={true}>
                  Shop Collection <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
              <a
                href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(
                  "Hello OneFam Fashion! I'd like to ask about the Urban Minimalist collection."
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold shadow-md transition-all hover:scale-102 active:scale-98"
              >
                <MessageSquare className="w-4 h-4 text-white" />
                WhatsApp Us
              </a>
            </div>
          </div>
        </div>
      </ScrollReveal>

      {/* 5. Trending Styles */}
      <ScrollReveal className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <span className="text-xs font-bold tracking-widest text-vermilion uppercase">
              Most Loved Pieces
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-foreground mt-1">
              Trending Now
            </h2>
          </div>
          <Button asChild variant="outline" size="sm" className="rounded-full text-xs font-semibold">
            <Link href="/offers" prefetch={true}>
              Explore All <ArrowRight className="ml-1 w-3.5 h-3.5" />
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {trending.map((prod) => (
            <ProductCard key={prod.id} product={prod as any} whatsappNumber={whatsappNumber} />
          ))}
        </div>
      </ScrollReveal>

      {/* 6. Featured Collections Banners */}
      {collections.length > 0 && (
        <ScrollReveal className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="text-xs font-bold tracking-widest text-royal-violet uppercase">
              Signature Aesthetics
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-foreground mt-1">
              Featured Collections
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {collections.map((col) => (
              <Link
                key={col.id}
                href={`/collections/${col.slug}`}
                prefetch={true}
                className="group relative rounded-2xl overflow-hidden aspect-[4/3] bg-[#110f16]"
              >
                <img
                  src={
                    col.coverImage ||
                    "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=900&auto=format&fit=crop"
                  }
                  alt={col.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-80 group-hover:opacity-90"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#110f16]/95 via-[#110f16]/40 to-transparent" />
                <div className="absolute bottom-5 left-5 right-5 text-white">
                  <h3 className="text-xl font-bold tracking-tight text-white">{col.title}</h3>
                  <p className="text-xs text-white/75 mt-1 line-clamp-2">{col.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </ScrollReveal>
      )}

      {/* 7. Unified Sartorial Community & Brand Assurance Box */}
      <ScrollReveal>
        <SocialCommunitySection
          whatsappNumber={whatsappNumber}
          instagramUrl={settings?.instagramUrl || undefined}
          facebookUrl={settings?.facebookUrl || undefined}
          showValueProps={true}
        />
      </ScrollReveal>
    </div>
  );
}

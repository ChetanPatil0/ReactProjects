import nodemailer from "nodemailer";

export function createEmailTransporter() {
  const host = process.env.SMTP_HOST || "smtp.example.com";
  const port = parseInt(process.env.SMTP_PORT || "587", 10);
  const secure = process.env.SMTP_SECURE === "true";
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: user && pass ? { user, pass } : undefined,
  });
}

export async function sendEmail(params: {
  to: string;
  subject: string;
  html: string;
}) {
  try {
    const transporter = createEmailTransporter();
    const from = process.env.EMAIL_FROM || "OneFam Fashion <noreply@onefamfashion.com>";

    const info = await transporter.sendMail({
      from,
      to: params.to,
      subject: params.subject,
      html: params.html,
    });

    return { success: true, messageId: info.messageId };
  } catch (error: any) {
    console.error("Nodemailer send failure:", error.message);
    return { success: false, error: error.message };
  }
}


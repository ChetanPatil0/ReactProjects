export function getOrderConfirmationEmailHtml(params: {
  customerName: string;
  orderRef: string;
  total: string;
  items: Array<{ name: string; variant?: string; quantity: number; price: string }>;
  trackingUrl: string;
}): string {
  const itemsHtml = params.items
    .map(
      (item) => `
      <tr>
        <td style="padding: 10px 0; border-bottom: 1px solid #E8E6E1; font-size: 14px;">
          <strong>${item.name}</strong><br>
          <span style="color: #6B6A72; font-size: 12px;">${item.variant || ""} · Qty: ${item.quantity}</span>
        </td>
        <td style="padding: 10px 0; border-bottom: 1px solid #E8E6E1; text-align: right; font-weight: bold; font-size: 14px;">
          ${item.price}
        </td>
      </tr>`
    )
    .join("");

  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #FCFAF4; margin: 0; padding: 40px 20px; color: #191720;">
  <div style="max-width: 560px; margin: 0 auto; background: #ffffff; border-radius: 16px; padding: 36px; border: 1px solid #E8E6E1;">
    <div style="text-align: center; margin-bottom: 24px;">
      <h1 style="color: #7137C8; font-size: 26px; font-weight: 800; margin: 0; letter-spacing: -0.5px;">ONEFAM FASHION</h1>
      <p style="font-size: 12px; text-transform: uppercase; letter-spacing: 2px; color: #6B6A72; margin-top: 4px;">Order Confirmed</p>
    </div>

    <p style="font-size: 15px; line-height: 1.6;">Dear <strong>${params.customerName}</strong>,</p>
    <p style="font-size: 14px; line-height: 1.6; color: #4B4A54;">
      Your order has been verified and registered at our atelier. We are preparing your garment with the highest care for express dispatch.
    </p>

    <div style="background: #F7F6F2; padding: 14px 18px; border-radius: 10px; margin: 24px 0; display: flex; justify-content: space-between;">
      <div>
        <span style="font-size: 11px; text-transform: uppercase; color: #6B6A72; font-weight: bold; display: block;">Order Reference</span>
        <strong style="font-size: 16px; font-family: monospace; color: #7137C8;">${params.orderRef}</strong>
      </div>
    </div>

    <table style="width: 100%; border-collapse: collapse; margin-bottom: 24px;">
      <thead>
        <tr>
          <th style="text-align: left; font-size: 12px; color: #6B6A72; text-transform: uppercase; padding-bottom: 8px;">Item Description</th>
          <th style="text-align: right; font-size: 12px; color: #6B6A72; text-transform: uppercase; padding-bottom: 8px;">Price</th>
        </tr>
      </thead>
      <tbody>
        ${itemsHtml}
      </tbody>
    </table>

    <div style="text-align: right; font-size: 18px; font-weight: bold; color: #191720; margin-bottom: 30px;">
      Total: <span style="color: #7137C8;">${params.total}</span>
    </div>

    <div style="text-align: center; margin-top: 30px;">
      <a href="${params.trackingUrl}" style="background: #7137C8; color: #ffffff; text-decoration: none; padding: 14px 28px; border-radius: 50px; font-weight: bold; font-size: 14px; display: inline-block;">
        Track Your Order Journey
      </a>
    </div>

    <div style="border-top: 1px solid #E8E6E1; margin-top: 40px; padding-top: 20px; text-align: center; font-size: 12px; color: #6B6A72;">
      OneFam Fashion Atelier · 104 Design Blvd, Bengaluru, KA<br>
      WhatsApp Concierge Support: +91 98765 43210
    </div>
  </div>
</body>
</html>`;
}

export function getTrackingOtpEmailHtml(params: {
  otpCode: string;
  expiresMinutes: number;
}): string {
  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #FCFAF4; margin: 0; padding: 40px 20px; color: #191720;">
  <div style="max-width: 480px; margin: 0 auto; background: #ffffff; border-radius: 16px; padding: 36px; border: 1px solid #E8E6E1; text-align: center;">
    <h1 style="color: #7137C8; font-size: 24px; font-weight: 800; margin: 0;">ONEFAM FASHION</h1>
    <p style="font-size: 13px; color: #6B6A72; margin-top: 6px;">Order Tracking Verification</p>

    <p style="font-size: 14px; color: #4B4A54; margin: 24px 0 16px;">
      Use the following single-use verification code to look up your recent orders:
    </p>

    <div style="background: #F5F3EF; padding: 18px; border-radius: 12px; letter-spacing: 8px; font-size: 32px; font-weight: 900; color: #7137C8; font-family: monospace; margin: 20px 0;">
      ${params.otpCode}
    </div>

    <p style="font-size: 12px; color: #6B6A72;">
      This code expires in ${params.expiresMinutes} minutes. If you did not request this, please ignore this email.
    </p>
  </div>
</body>
</html>`;
}


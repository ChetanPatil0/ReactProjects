import { prisma } from "@/lib/prisma";
import { DiscountType } from "@prisma/client";

export interface CreateOfferInput {
  name: string;
  description?: string;
  discountType: "PERCENTAGE" | "FIXED";
  discountValue: number;
  minPurchase?: number | null;
  maxDiscount?: number | null;
  startDate?: string | null;
  endDate?: string | null;
  isActive?: boolean;
  productIds?: string[];
  categoryIds?: string[];
}

export const offerService = {
  /**
   * Get all offers with counts of assigned products
   */
  async getOffers() {
    const offers = await prisma.promotion.findMany({
      include: {
        products: {
          include: {
            product: {
              select: {
                id: true,
                name: true,
                slug: true,
                regularPrice: true,
                images: {
                  take: 1,
                  orderBy: { isPrimary: "desc" },
                },
              },
            },
          },
        },
        categories: {
          include: {
            category: {
              select: { id: true, name: true, slug: true },
            },
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return offers.map((offer) => ({
      id: offer.id,
      name: offer.name,
      description: offer.description,
      discountType: offer.discountType,
      discountValue: Number(offer.discountValue),
      minPurchase: offer.minPurchase ? Number(offer.minPurchase) : null,
      maxDiscount: offer.maxDiscount ? Number(offer.maxDiscount) : null,
      startDate: offer.startDate?.toISOString() || null,
      endDate: offer.endDate?.toISOString() || null,
      isActive: offer.isActive,
      productsCount: offer.products.length,
      products: offer.products.map((p) => ({
        id: p.product.id,
        name: p.product.name,
        slug: p.product.slug,
        regularPrice: Number(p.product.regularPrice),
        image: p.product.images[0]?.path || null,
      })),
      categoriesCount: offer.categories.length,
      createdAt: offer.createdAt.toISOString(),
      updatedAt: offer.updatedAt.toISOString(),
    }));
  },

  /**
   * Get offer by ID
   */
  async getOfferById(id: string) {
    const offer = await prisma.promotion.findUnique({
      where: { id },
      include: {
        products: {
          include: {
            product: {
              include: {
                images: {
                  take: 1,
                  orderBy: { isPrimary: "desc" },
                },
                category: {
                  select: { id: true, name: true },
                },
              },
            },
          },
        },
        categories: {
          include: {
            category: true,
          },
        },
      },
    });

    if (!offer) return null;

    return {
      id: offer.id,
      name: offer.name,
      description: offer.description,
      discountType: offer.discountType,
      discountValue: Number(offer.discountValue),
      minPurchase: offer.minPurchase ? Number(offer.minPurchase) : null,
      maxDiscount: offer.maxDiscount ? Number(offer.maxDiscount) : null,
      startDate: offer.startDate?.toISOString() || null,
      endDate: offer.endDate?.toISOString() || null,
      isActive: offer.isActive,
      productIds: offer.products.map((p) => p.productId),
      products: offer.products.map((p) => ({
        id: p.product.id,
        name: p.product.name,
        slug: p.product.slug,
        regularPrice: Number(p.product.regularPrice),
        categoryName: p.product.category?.name || null,
        image: p.product.images[0]?.path || null,
      })),
      categoryIds: offer.categories.map((c) => c.categoryId),
      createdAt: offer.createdAt.toISOString(),
      updatedAt: offer.updatedAt.toISOString(),
    };
  },

  /**
   * Create new offer and attach selected products
   */
  async createOffer(data: CreateOfferInput) {
    return await prisma.$transaction(async (tx) => {
      const offer = await tx.promotion.create({
        data: {
          name: data.name.trim(),
          description: data.description?.trim() || null,
          discountType: data.discountType as DiscountType,
          discountValue: data.discountValue,
          minPurchase: data.minPurchase ? data.minPurchase : null,
          maxDiscount: data.maxDiscount ? data.maxDiscount : null,
          startDate: data.startDate ? new Date(data.startDate) : null,
          endDate: data.endDate ? new Date(data.endDate) : null,
          isActive: data.isActive !== false,
        },
      });

      // Attach products if provided
      if (Array.isArray(data.productIds) && data.productIds.length > 0) {
        await tx.promotionProduct.createMany({
          data: data.productIds.map((pid) => ({
            promotionId: offer.id,
            productId: pid,
          })),
          skipDuplicates: true,
        });
      }

      // Attach categories if provided
      if (Array.isArray(data.categoryIds) && data.categoryIds.length > 0) {
        await tx.promotionCategory.createMany({
          data: data.categoryIds.map((cid) => ({
            promotionId: offer.id,
            categoryId: cid,
          })),
          skipDuplicates: true,
        });
      }

      return offer;
    });
  },

  /**
   * Update existing offer and refresh assigned products
   */
  async updateOffer(id: string, data: Partial<CreateOfferInput>) {
    return await prisma.$transaction(async (tx) => {
      const updateData: any = {};
      if (data.name !== undefined) updateData.name = data.name.trim();
      if (data.description !== undefined) updateData.description = data.description?.trim() || null;
      if (data.discountType !== undefined) updateData.discountType = data.discountType as DiscountType;
      if (data.discountValue !== undefined) updateData.discountValue = data.discountValue;
      if (data.minPurchase !== undefined) updateData.minPurchase = data.minPurchase ? data.minPurchase : null;
      if (data.maxDiscount !== undefined) updateData.maxDiscount = data.maxDiscount ? data.maxDiscount : null;
      if (data.startDate !== undefined) updateData.startDate = data.startDate ? new Date(data.startDate) : null;
      if (data.endDate !== undefined) updateData.endDate = data.endDate ? new Date(data.endDate) : null;
      if (data.isActive !== undefined) updateData.isActive = data.isActive;

      const offer = await tx.promotion.update({
        where: { id },
        data: updateData,
      });

      // If productIds is explicitly passed, sync products
      if (Array.isArray(data.productIds)) {
        await tx.promotionProduct.deleteMany({ where: { promotionId: id } });
        if (data.productIds.length > 0) {
          await tx.promotionProduct.createMany({
            data: data.productIds.map((pid) => ({
              promotionId: id,
              productId: pid,
            })),
            skipDuplicates: true,
          });
        }
      }

      // If categoryIds is explicitly passed, sync categories
      if (Array.isArray(data.categoryIds)) {
        await tx.promotionCategory.deleteMany({ where: { promotionId: id } });
        if (data.categoryIds.length > 0) {
          await tx.promotionCategory.createMany({
            data: data.categoryIds.map((cid) => ({
              promotionId: id,
              categoryId: cid,
            })),
            skipDuplicates: true,
          });
        }
      }

      return offer;
    });
  },

  /**
   * Toggle active state
   */
  async toggleActive(id: string, isActive: boolean) {
    return await prisma.promotion.update({
      where: { id },
      data: { isActive },
    });
  },

  /**
   * Delete offer
   */
  async deleteOffer(id: string) {
    return await prisma.promotion.delete({
      where: { id },
    });
  },
};


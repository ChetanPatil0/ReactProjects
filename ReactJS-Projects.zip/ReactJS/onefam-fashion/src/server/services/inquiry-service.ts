import fs from "fs";
import path from "path";
import crypto from "crypto";

export interface ContactInquiry {
  id: string;
  ticketId: string;
  name: string;
  email: string;
  phone?: string;
  subject: string;
  orderNumber?: string;
  message: string;
  status: "NEW" | "IN_PROGRESS" | "RESOLVED" | "CLOSED";
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateInquiryInput {
  name: string;
  email: string;
  phone?: string;
  subject: string;
  orderNumber?: string;
  message: string;
}

const DATA_DIR = path.resolve(process.cwd(), "data");
const INQUIRIES_FILE = path.join(DATA_DIR, "inquiries.json");

function ensureFile(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(INQUIRIES_FILE)) {
    const initialSeed: ContactInquiry[] = [
      {
        id: crypto.randomUUID(),
        ticketId: "INQ-M7K2-0001",
        name: "Aarav Sharma",
        email: "aarav.sharma@example.com",
        phone: "9876543210",
        subject: "Sizing & Fit Advice",
        orderNumber: "ORD-K7M2-0001",
        message: "Hi, I am looking to purchase the French Linen Camp Shirt in size L, but wanted to verify if it has a relaxed chest drape or slim fit.",
        status: "NEW",
        adminNotes: "",
        createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
        updatedAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
      },
      {
        id: crypto.randomUUID(),
        ticketId: "INQ-R4N8-0002",
        name: "Pooja Mehta",
        email: "pooja.m@example.com",
        phone: "9123456789",
        subject: "Order Status & Tracking",
        orderNumber: "ORD-X3P9-0002",
        message: "Can you please verify when my package will be dispatched from Bengaluru? Need it before this weekend for a wedding.",
        status: "IN_PROGRESS",
        adminNotes: "Customer messaged on WhatsApp. Dispatch scheduled via BlueDart Express today.",
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString(),
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
      },
      {
        id: crypto.randomUUID(),
        ticketId: "INQ-B2L9-0003",
        name: "Vikram Singhania",
        email: "vikram.singh@example.com",
        phone: "9988776655",
        subject: "Order Issue / Complaint",
        orderNumber: "ORD-J9T4-0003",
        message: "Received my order yesterday. The package arrived with loose seam stitching near the collar. Please assist.",
        status: "RESOLVED",
        adminNotes: "Customer complaint reviewed. Replacement parcel dispatched.",
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
      },
    ];
    fs.writeFileSync(INQUIRIES_FILE, JSON.stringify(initialSeed, null, 2), "utf8");
  }
}

function readInquiries(): ContactInquiry[] {
  ensureFile();
  try {
    const raw = fs.readFileSync(INQUIRIES_FILE, "utf8");
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function writeInquiries(inquiries: ContactInquiry[]): void {
  ensureFile();
  fs.writeFileSync(INQUIRIES_FILE, JSON.stringify(inquiries, null, 2), "utf8");
}

function generateTicketId(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const part1 = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
  const part2 = String(Math.floor(1000 + Math.random() * 9000));
  return `INQ-${part1}-${part2}`;
}

export const inquiryService = {
  async getInquiries(filters?: {
    status?: string;
    search?: string;
    subject?: string;
  }) {
    let list = readInquiries();

    if (filters?.status && filters.status !== "ALL") {
      list = list.filter((i) => i.status === filters.status);
    }

    if (filters?.subject && filters.subject !== "ALL") {
      list = list.filter((i) => i.subject.toLowerCase() === filters.subject?.toLowerCase());
    }

    if (filters?.search) {
      const q = filters.search.toLowerCase().trim();
      list = list.filter(
        (i) =>
          i.ticketId.toLowerCase().includes(q) ||
          i.name.toLowerCase().includes(q) ||
          i.email.toLowerCase().includes(q) ||
          (i.phone && i.phone.includes(q)) ||
          (i.orderNumber && i.orderNumber.toLowerCase().includes(q)) ||
          i.message.toLowerCase().includes(q)
      );
    }

    // Sort newest first
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const all = readInquiries();
    const stats = {
      total: all.length,
      new: all.filter((i) => i.status === "NEW").length,
      inProgress: all.filter((i) => i.status === "IN_PROGRESS").length,
      resolved: all.filter((i) => i.status === "RESOLVED").length,
      closed: all.filter((i) => i.status === "CLOSED").length,
    };

    return { inquiries: list, stats };
  },

  async getInquiryById(id: string): Promise<ContactInquiry | null> {
    const list = readInquiries();
    return list.find((i) => i.id === id || i.ticketId === id) || null;
  },

  async createInquiry(data: CreateInquiryInput): Promise<ContactInquiry> {
    const list = readInquiries();
    const now = new Date().toISOString();

    const newInquiry: ContactInquiry = {
      id: crypto.randomUUID(),
      ticketId: generateTicketId(),
      name: data.name.trim(),
      email: data.email.trim().toLowerCase(),
      phone: data.phone?.trim() || undefined,
      subject: data.subject.trim(),
      orderNumber: data.orderNumber?.trim() || undefined,
      message: data.message.trim(),
      status: "NEW",
      adminNotes: "",
      createdAt: now,
      updatedAt: now,
    };

    list.unshift(newInquiry);
    writeInquiries(list);
    return newInquiry;
  },

  async updateInquiry(
    id: string,
    updates: { status?: "NEW" | "IN_PROGRESS" | "RESOLVED" | "CLOSED"; adminNotes?: string }
  ): Promise<ContactInquiry | null> {
    const list = readInquiries();
    const index = list.findIndex((i) => i.id === id || i.ticketId === id);
    if (index === -1) return null;

    list[index] = {
      ...list[index],
      status: updates.status || list[index].status,
      adminNotes: updates.adminNotes !== undefined ? updates.adminNotes : list[index].adminNotes,
      updatedAt: new Date().toISOString(),
    };

    writeInquiries(list);
    return list[index];
  },

  async deleteInquiry(id: string): Promise<boolean> {
    let list = readInquiries();
    const beforeLen = list.length;
    list = list.filter((i) => i.id !== id && i.ticketId !== id);
    if (list.length === beforeLen) return false;
    writeInquiries(list);
    return true;
  },
};


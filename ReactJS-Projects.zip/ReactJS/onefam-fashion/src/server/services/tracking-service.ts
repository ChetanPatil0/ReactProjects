import { prisma } from "@/lib/prisma";
import { generateVerificationOtp } from "@/lib/formatters";
import {
  validateOrderReferenceFormat,
  validateTrackingContact,
} from "@/lib/validations";
import crypto from "crypto";

export const trackingService = {
  /**
   * Request OTP verification code for email or mobile
   */
  async requestVerification(identifier: string) {
    const contactCheck = validateTrackingContact(identifier);
    if (!contactCheck.valid) {
      throw new Error(contactCheck.error || "Please enter a valid email address or 10-digit mobile number.");
    }

    const raw = identifier.trim();
    let cleanEmail = raw.toLowerCase();

    // If identifier is a phone number, find associated customer email
    if (contactCheck.type === "phone") {
      const phoneDigits = contactCheck.cleanValue!;
      const customer = await prisma.customer.findFirst({
        where: {
          OR: [
            { phone: { contains: phoneDigits } },
            { alternatePhone: { contains: phoneDigits } },
          ],
        },
      });

      if (!customer?.email) {
        throw new Error("No account found matching this mobile number.");
      }
      cleanEmail = customer.email;
    }

    const code = generateVerificationOtp();
    const token = crypto.randomBytes(24).toString("hex");
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 mins

    await prisma.orderTrackingVerification.create({
      data: {
        email: cleanEmail,
        code,
        token,
        expiresAt,
      },
    });

    // In production, nodemailer or SMS/WhatsApp sends the OTP code
    return { token, code, expiresAt, email: cleanEmail };
  },

  /**
   * Verify and track customer orders using:
   * 1. (Email OR Mobile Number) + Order Reference
   * 2. (Email OR Mobile Number) + OTP Verification Code
   */
  async lookupOrder(params: {
    identifier?: string;
    email?: string;
    phone?: string;
    orderRef?: string;
    code?: string;
  }) {
    const rawInput = (params.identifier || params.email || params.phone || "").trim();
    const contactCheck = validateTrackingContact(rawInput);
    if (!contactCheck.valid) {
      throw new Error(contactCheck.error || "Please enter a valid email address or 10-digit mobile number.");
    }

    const isEmail = contactCheck.type === "email";
    const phone10 = contactCheck.cleanValue || "";

    // Define customer lookup condition for either email OR mobile phone
    const customerWhere = isEmail
      ? { email: { equals: contactCheck.cleanValue, mode: "insensitive" as const } }
      : {
          OR: [
            { phone: { contains: phone10 } },
            { alternatePhone: { contains: phone10 } },
          ],
        };

    // 1. Verification by OTP code
    if (params.code) {
      // Find customer email if mobile phone was entered
      let emailForOtp = rawInput.toLowerCase();
      if (!isEmail) {
        const matchedCust = await prisma.customer.findFirst({
          where: customerWhere,
          select: { email: true },
        });
        if (!matchedCust) {
          throw new Error("No orders found matching this mobile phone number.");
        }
        emailForOtp = matchedCust.email;
      }

      const verification = await prisma.orderTrackingVerification.findFirst({
        where: {
          email: emailForOtp,
          code: params.code.trim(),
          expiresAt: { gt: new Date() },
          verifiedAt: null,
        },
      });

      if (!verification) {
        throw new Error("Invalid or expired verification code.");
      }

      // Mark verified
      await prisma.orderTrackingVerification.update({
        where: { id: verification.id },
        data: { verifiedAt: new Date() },
      });

      // Return customer's recent orders (safe fields only!)
      const orders = await prisma.order.findMany({
        where: {
          customer: customerWhere,
        },
        orderBy: { createdAt: "desc" },
        take: 5,
        select: {
          orderRef: true,
          status: true,
          paymentStatus: true,
          total: true,
          amountPaid: true,
          balanceDue: true,
          shippingCarrier: true,
          trackingNumber: true,
          createdAt: true,
          customer: {
            select: {
              name: true,
              shippingAddress: true,
            },
          },
          items: {
            select: {
              productName: true,
              size: true,
              color: true,
              quantity: true,
              unitPrice: true,
              totalPrice: true,
            },
          },
          statusHistory: {
            orderBy: { createdAt: "asc" },
            select: {
              status: true,
              note: true,
              createdAt: true,
            },
          },
        },
      });

      return orders;
    }

    // 2. Verification by Email/Mobile + Order Reference
    if (params.orderRef) {
      const refCheck = validateOrderReferenceFormat(params.orderRef);
      if (!refCheck.valid) {
        throw new Error(
          refCheck.error ||
            "Invalid Order ID format. Please enter a valid Order ID like ORD-XXXXXXXX (1st & 3rd must be letters, 2nd & 4th must be numbers, followed by 4 digits)."
        );
      }

      const canonicalRef = refCheck.normalized!; // e.g. ORD-K7M20001
      const unhyphenated = canonicalRef.replace(/[^A-Z0-9]/g, ""); // ORDK7M20001
      const hyphenated = `ORD-${unhyphenated.slice(3, 7)}-${unhyphenated.slice(7)}`; // ORD-K7M2-0001

      // Search matching canonical format, hyphenated variation, or continuous string
      const refQueryVariations: Array<{ orderRef: any }> = [
        { orderRef: { equals: canonicalRef, mode: "insensitive" } },
        { orderRef: { equals: hyphenated, mode: "insensitive" } },
        { orderRef: { equals: unhyphenated, mode: "insensitive" } },
      ];

      const order = await prisma.order.findFirst({
        where: {
          OR: refQueryVariations,
          customer: customerWhere,
        },
        select: {
          orderRef: true,
          status: true,
          paymentStatus: true,
          total: true,
          amountPaid: true,
          balanceDue: true,
          shippingCarrier: true,
          trackingNumber: true,
          createdAt: true,
          customer: {
            select: {
              name: true,
              shippingAddress: true,
            },
          },
          items: {
            select: {
              productName: true,
              size: true,
              color: true,
              quantity: true,
              unitPrice: true,
              totalPrice: true,
            },
          },
          statusHistory: {
            orderBy: { createdAt: "asc" },
            select: {
              status: true,
              note: true,
              createdAt: true,
            },
          },
        },
      });

      if (!order) {
        throw new Error("No matching order found for this reference and email / mobile number.");
      }

      return [order];
    }

    throw new Error("Please provide your Order Reference or enter a Verification Code.");
  },
};


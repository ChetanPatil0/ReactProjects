import { prisma } from "@/lib/prisma";
import { generateOrderReference } from "@/lib/formatters";
import { OrderStatus, PaymentStatus, PaymentMethod } from "@prisma/client";
import { reportService } from "./report-service";

export interface RegisterOrderInput {
  customer: {
    name: string;
    email: string;
    phone: string;
    alternatePhone?: string;
    shippingAddress: string;
    billingAddress?: string;
  };
  items: Array<{
    productId?: string;
    variantId?: string;
    productName: string;
    sku?: string;
    size?: string;
    color?: string;
    unitPrice: number;
    quantity: number;
  }>;
  pricing: {
    subtotal: number;
    discount?: number;
    shipping?: number;
    tax?: number;
  };
  payment?: {
    amount: number;
    method: PaymentMethod;
    reference?: string;
    notes?: string;
  };
  notes?: {
    customerNotes?: string;
    adminNotes?: string;
  };
}

export const orderService = {
  /**
   * Register a customer order manually (from WhatsApp or store staff)
   */
  async registerOrder(input: RegisterOrderInput) {
    return await prisma.$transaction(async (tx) => {
      // 1. Find or create Customer
      let customer = await tx.customer.findFirst({
        where: {
          OR: [
            { email: input.customer.email.trim().toLowerCase() },
            { phone: input.customer.phone.trim() },
          ],
        },
      });

      if (!customer) {
        customer = await tx.customer.create({
          data: {
            name: input.customer.name.trim(),
            email: input.customer.email.trim().toLowerCase(),
            phone: input.customer.phone.trim(),
            alternatePhone: input.customer.alternatePhone?.trim() || null,
            shippingAddress: input.customer.shippingAddress.trim(),
            billingAddress: input.customer.billingAddress?.trim() || input.customer.shippingAddress.trim(),
          },
        });
      }

      // 2. Compute financial totals on server
      const calculatedSubtotal = input.items.reduce(
        (sum, item) => sum + item.unitPrice * item.quantity,
        0
      );
      const discount = Math.max(0, input.pricing.discount || 0);
      const shipping = Math.max(0, input.pricing.shipping || 0);
      const tax = Math.max(0, input.pricing.tax || 0);
      const total = Math.max(0, calculatedSubtotal - discount + shipping + tax);

      const initialPaid = Math.max(0, input.payment?.amount || 0);
      const balanceDue = Math.max(0, total - initialPaid);

      let paymentStatus: PaymentStatus = PaymentStatus.UNPAID;
      if (initialPaid >= total && total > 0) {
        paymentStatus = PaymentStatus.PAID;
      } else if (initialPaid > 0) {
        paymentStatus = PaymentStatus.PARTIALLY_PAID;
      }

      // Generate guaranteed unique, non-duplicable order reference (e.g. ORD-K7M20001)
      let orderRef = "";
      let sequence = (await tx.order.count()) + 1;
      let isUnique = false;
      let attempts = 0;

      while (!isUnique && attempts < 20) {
        const candidate = generateOrderReference(sequence);
        const existing = await tx.order.findUnique({
          where: { orderRef: candidate },
          select: { id: true },
        });
        if (!existing) {
          orderRef = candidate;
          isUnique = true;
        } else {
          sequence++;
          attempts++;
        }
      }

      if (!orderRef) {
        orderRef = generateOrderReference(Math.floor(1000 + Math.random() * 9000));
      }

      // 3. Create the Order
      const order = await tx.order.create({
        data: {
          orderRef,
          customerId: customer.id,
          status: OrderStatus.CONFIRMED,
          paymentStatus,
          subtotal: calculatedSubtotal,
          discount,
          shipping,
          tax,
          total,
          amountPaid: initialPaid,
          balanceDue,
          customerNotes: input.notes?.customerNotes || null,
          adminNotes: input.notes?.adminNotes || null,
          items: {
            create: input.items.map((item) => ({
              productId: item.productId || null,
              variantId: item.variantId || null,
              productName: item.productName,
              sku: item.sku || null,
              size: item.size || null,
              color: item.color || null,
              unitPrice: item.unitPrice,
              quantity: item.quantity,
              totalPrice: item.unitPrice * item.quantity,
            })),
          },
          statusHistory: {
            create: [
              {
                status: OrderStatus.PENDING_CONFIRMATION,
                note: "Order created in OneFam management system",
                changedBy: "Admin / Staff",
              },
              {
                status: OrderStatus.CONFIRMED,
                note: "Order confirmed with customer",
                changedBy: "Admin / Staff",
              },
            ],
          },
        },
        include: {
          items: true,
          customer: true,
        },
      });

      // 4. Record payment if initial payment was made
      if (initialPaid > 0 && input.payment) {
        await tx.payment.create({
          data: {
            orderId: order.id,
            amount: initialPaid,
            method: input.payment.method,
            reference: input.payment.reference || null,
            notes: input.payment.notes || "Initial order registration payment",
          },
        });
      }

      return order;
    });
  },

  /**
   * Get orders list with filters and pagination
   */
  async getOrders(params: {
    page?: number;
    limit?: number;
    status?: OrderStatus;
    paymentStatus?: PaymentStatus;
    search?: string;
  }) {
    const page = Math.max(1, params.page || 1);
    const limit = Math.min(100, Math.max(1, params.limit || 20));
    const skip = (page - 1) * limit;

    const where: any = {};

    if (params.status) {
      where.status = params.status;
    }

    if (params.paymentStatus) {
      where.paymentStatus = params.paymentStatus;
    }

    if (params.search) {
      const q = params.search.trim();
      where.OR = [
        { orderRef: { contains: q, mode: "insensitive" } },
        { customer: { name: { contains: q, mode: "insensitive" } } },
        { customer: { email: { contains: q, mode: "insensitive" } } },
        { customer: { phone: { contains: q, mode: "insensitive" } } },
      ];
    }

    const [orders, totalCount] = await Promise.all([
      prisma.order.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: "desc" },
        include: {
          customer: {
            select: {
              name: true,
              email: true,
              phone: true,
            },
          },
          items: {
            select: {
              id: true,
              productName: true,
              size: true,
              color: true,
              quantity: true,
              unitPrice: true,
            },
          },
          payments: {
            select: {
              id: true,
              amount: true,
              method: true,
              paymentDate: true,
            },
          },
        },
      }),
      prisma.order.count({ where }),
    ]);

    return {
      orders,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
      },
    };
  },

  /**
   * Get complete order details by ID or orderRef
   */
  async getOrderDetail(idOrRef: string) {
    const isRef = idOrRef.startsWith("OFF-");
    return prisma.order.findFirst({
      where: isRef ? { orderRef: idOrRef } : { id: idOrRef },
      include: {
        customer: true,
        items: {
          include: {
            product: {
              select: {
                slug: true,
                images: {
                  take: 1,
                  select: { path: true },
                },
              },
            },
          },
        },
        payments: {
          orderBy: { paymentDate: "desc" },
        },
        statusHistory: {
          orderBy: { createdAt: "desc" },
        },
        invoices: {
          orderBy: { createdAt: "desc" },
        },
      },
    });
  },

  /**
   * Update order status
   */
  async updateStatus(orderId: string, status: OrderStatus, note?: string, changedBy = "Admin") {
    return prisma.$transaction(async (tx) => {
      const order = await tx.order.update({
        where: { id: orderId },
        data: { status },
      });

      await tx.orderStatusHistory.create({
        data: {
          orderId,
          status,
          note: note || `Status changed to ${status}`,
          changedBy,
        },
      });

      return order;
    });
  },

  /**
   * Dashboard Summary Metrics
   */
  async getDashboardSummary() {
    const [
      totalProducts,
      publishedProducts,
      draftProducts,
      totalOrders,
      pendingOrders,
      processingOrders,
      paidOrders,
      unpaidOrders,
      deliveredOrders,
      cancelledOrders,
      revenueResult,
      recentOrders,
      pendingAlerts,
      weeklyAnalytics,
    ] = await Promise.all([
      prisma.product.count(),
      prisma.product.count({ where: { status: "PUBLISHED" } }),
      prisma.product.count({ where: { status: "DRAFT" } }),
      prisma.order.count(),
      prisma.order.count({ where: { status: "PENDING_CONFIRMATION" } }),
      prisma.order.count({ where: { status: "PROCESSING" } }),
      prisma.order.count({ where: { paymentStatus: "PAID" } }),
      prisma.order.count({ where: { paymentStatus: "UNPAID" } }),
      prisma.order.count({ where: { status: "DELIVERED" } }),
      prisma.order.count({ where: { status: "CANCELLED" } }),
      prisma.order.aggregate({
        _sum: {
          total: true,
          amountPaid: true,
          balanceDue: true,
        },
      }),
      prisma.order.findMany({
        take: 6,
        orderBy: { createdAt: "desc" },
        include: {
          customer: { select: { name: true, phone: true } },
          items: { take: 2 },
        },
      }),
      // Orders needing attention: pending confirmation, confirmed but not shipped, or unpaid
      prisma.order.findMany({
        where: {
          OR: [
            { status: "PENDING_CONFIRMATION" },
            { paymentStatus: "UNPAID" },
            { status: "CONFIRMED" },
          ],
        },
        take: 5,
        orderBy: { createdAt: "desc" },
        include: {
          customer: { select: { name: true, phone: true } },
        },
      }),
      reportService.getAnalytics("7d"),
    ]);

    return {
      metrics: {
        totalProducts,
        publishedProducts,
        draftProducts,
        totalOrders,
        pendingOrders,
        processingOrders,
        paidOrders,
        unpaidOrders,
        deliveredOrders,
        cancelledOrders,
        totalRevenue: Number(revenueResult._sum.total || 0),
        totalAmountPaid: Number(revenueResult._sum.amountPaid || 0),
        totalBalanceDue: Number(revenueResult._sum.balanceDue || 0),
      },
      recentOrders,
      pendingAlerts,
      revenueTrend: weeklyAnalytics.revenueTrend,
      statusBreakdown: weeklyAnalytics.statusBreakdown,
      paymentMethods: weeklyAnalytics.paymentMethods,
    };
  },
};


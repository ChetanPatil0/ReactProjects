import { prisma } from "@/lib/prisma";
import { PaymentMethod, PaymentStatus } from "@prisma/client";

export interface RecordPaymentInput {
  orderId: string;
  amount: number;
  method: PaymentMethod;
  reference?: string;
  notes?: string;
  paymentDate?: Date;
}

export const paymentService = {
  /**
   * Record a payment against an order and update order balances
   */
  async recordPayment(input: RecordPaymentInput) {
    return prisma.$transaction(async (tx) => {
      const order = await tx.order.findUnique({
        where: { id: input.orderId },
      });

      if (!order) {
        throw new Error("Order not found");
      }

      const paymentAmount = Number(input.amount);
      if (paymentAmount <= 0) {
        throw new Error("Payment amount must be greater than zero");
      }

      const currentPaid = Number(order.amountPaid);
      const orderTotal = Number(order.total);
      const newTotalPaid = currentPaid + paymentAmount;
      const newBalanceDue = Math.max(0, orderTotal - newTotalPaid);

      let newPaymentStatus: PaymentStatus = order.paymentStatus;
      if (newTotalPaid >= orderTotal) {
        newPaymentStatus = PaymentStatus.PAID;
      } else if (newTotalPaid > 0) {
        newPaymentStatus = PaymentStatus.PARTIALLY_PAID;
      }

      // 1. Create payment transaction record
      const payment = await tx.payment.create({
        data: {
          orderId: order.id,
          amount: paymentAmount,
          method: input.method,
          reference: input.reference || null,
          notes: input.notes || null,
          paymentDate: input.paymentDate || new Date(),
        },
      });

      // 2. Update order totals and status
      const updatedOrder = await tx.order.update({
        where: { id: order.id },
        data: {
          amountPaid: newTotalPaid,
          balanceDue: newBalanceDue,
          paymentStatus: newPaymentStatus,
        },
      });

      return { payment, order: updatedOrder };
    });
  },

  /**
   * Get all payment transactions ledger
   */
  async getPayments(params?: { limit?: number; page?: number; method?: PaymentMethod }) {
    const page = params?.page || 1;
    const limit = params?.limit || 25;
    const skip = (page - 1) * limit;

    const where: any = {};
    if (params?.method) {
      where.method = params.method;
    }

    const [payments, totalCount] = await Promise.all([
      prisma.payment.findMany({
        where,
        skip,
        take: limit,
        orderBy: { paymentDate: "desc" },
        include: {
          order: {
            select: {
              orderRef: true,
              total: true,
              customer: {
                select: {
                  name: true,
                  phone: true,
                  email: true,
                },
              },
            },
          },
        },
      }),
      prisma.payment.count({ where }),
    ]);

    return {
      payments,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
      },
    };
  },
};


import { prisma } from "@/lib/prisma";
import { ProductStatus } from "@prisma/client";
import { calculateDynamicOffer } from "@/lib/dynamic-offers";

export interface ProductFilters {
  categorySlug?: string;
  collectionSlug?: string;
  search?: string;
  minPrice?: number;
  maxPrice?: number;
  size?: string;
  color?: string;
  isFeatured?: boolean;
  isTrending?: boolean;
  isNewArrival?: boolean;
  inStockOnly?: boolean;
  status?: ProductStatus;
  sortBy?: "newest" | "price_asc" | "price_desc" | "popularity";
  page?: number;
  limit?: number;
}

export const productService = {
  /**
   * Search and filter products
   */
  async getProducts(filters: ProductFilters = {}) {
    const page = Math.max(1, filters.page || 1);
    const limit = Math.min(100, Math.max(1, filters.limit || 20));
    const skip = (page - 1) * limit;

    const where: any = {};

    // Filter by publication status (storefront defaults to PUBLISHED)
    if (filters.status) {
      where.status = filters.status;
    }

    // Category filter (parent or subcategory)
    if (filters.categorySlug) {
      where.category = {
        OR: [
          { slug: filters.categorySlug },
          { parent: { slug: filters.categorySlug } },
        ],
      };
    }

    // Collection filter
    if (filters.collectionSlug) {
      where.collectionProducts = {
        some: {
          collection: { slug: filters.collectionSlug },
        },
      };
    }

    // Search query
    if (filters.search) {
      const q = filters.search.trim();
      where.OR = [
        { name: { contains: q, mode: "insensitive" } },
        { shortDescription: { contains: q, mode: "insensitive" } },
        { description: { contains: q, mode: "insensitive" } },
        { sku: { contains: q, mode: "insensitive" } },
      ];
    }

    // Price range
    if (filters.minPrice !== undefined || filters.maxPrice !== undefined) {
      where.regularPrice = {};
      if (filters.minPrice !== undefined) where.regularPrice.gte = filters.minPrice;
      if (filters.maxPrice !== undefined) where.regularPrice.lte = filters.maxPrice;
    }

    // Variants filter (size / color / inStockOnly)
    if (filters.size || filters.color || filters.inStockOnly) {
      where.variants = {
        some: {
          isAvailable: true,
          ...(filters.inStockOnly ? { OR: [{ stock: null }, { stock: { gt: 0 } }] } : {}),
          ...(filters.size ? { size: { equals: filters.size, mode: "insensitive" } } : {}),
          ...(filters.color ? { color: { equals: filters.color, mode: "insensitive" } } : {}),
        },
      };
    }

    if (filters.isFeatured !== undefined) where.isFeatured = filters.isFeatured;
    if (filters.isTrending !== undefined) where.isTrending = filters.isTrending;
    if (filters.isNewArrival !== undefined) where.isNewArrival = filters.isNewArrival;

    // Sort order
    let orderBy: any = { createdAt: "desc" };
    if (filters.sortBy === "price_asc") orderBy = { regularPrice: "asc" };
    if (filters.sortBy === "price_desc") orderBy = { regularPrice: "desc" };
    if (filters.sortBy === "popularity") orderBy = { isTrending: "desc" };

    const [products, totalCount] = await Promise.all([
      prisma.product.findMany({
        where,
        skip,
        take: limit,
        orderBy,
        include: {
          category: { select: { id: true, name: true, slug: true } },
          images: {
            orderBy: [{ isPrimary: "desc" }, { sortOrder: "asc" }],
          },
          variants: {
            where: { isAvailable: true },
          },
          promotionProducts: {
            include: {
              promotion: true,
            },
          },
        },
      }),
      prisma.product.count({ where }),
    ]);

    const serializedProducts = products.map((p) => {
      const regPrice = Number(p.regularPrice);
      const dynamic = calculateDynamicOffer(regPrice, p.promotionProducts);
      const discountPrice =
        dynamic.discountPrice !== null
          ? dynamic.discountPrice
          : p.discountPrice !== null
          ? Number(p.discountPrice)
          : null;

      return {
        ...p,
        regularPrice: regPrice,
        discountPrice,
        activeOffer: dynamic.activeOffer,
        discountPercent: dynamic.discountPercent,
        variants: p.variants.map((v) => ({
          ...v,
          priceOverride: v.priceOverride !== null ? Number(v.priceOverride) : null,
        })),
      };
    });

    return {
      products: serializedProducts,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
      },
    };
  },

  /**
   * Get product by slug for storefront details
   */
  async getProductBySlug(slug: string) {
    const product = await prisma.product.findUnique({
      where: { slug },
      include: {
        category: {
          include: {
            parent: true,
          },
        },
        images: {
          orderBy: [{ isPrimary: "desc" }, { sortOrder: "asc" }],
        },
        variants: {
          orderBy: [{ size: "asc" }, { color: "asc" }],
        },
        collectionProducts: {
          include: {
            collection: true,
          },
        },
        promotionProducts: {
          include: {
            promotion: true,
          },
        },
      },
    });

    if (!product) return null;

    const regPrice = Number(product.regularPrice);
    const dynamic = calculateDynamicOffer(regPrice, product.promotionProducts);
    const discountPrice =
      dynamic.discountPrice !== null
        ? dynamic.discountPrice
        : product.discountPrice !== null
        ? Number(product.discountPrice)
        : null;

    return {
      ...product,
      regularPrice: regPrice,
      discountPrice,
      activeOffer: dynamic.activeOffer,
      discountPercent: dynamic.discountPercent,
      variants: product.variants.map((v) => ({
        ...v,
        priceOverride: v.priceOverride !== null ? Number(v.priceOverride) : null,
      })),
    };
  },

  /**
   * Create product
   */
  async createProduct(data: {
    name: string;
    slug: string;
    sku?: string;
    shortDescription?: string;
    description?: string;
    regularPrice: number;
    discountPrice?: number;
    categoryId?: string;
    isFeatured?: boolean;
    isTrending?: boolean;
    isNewArrival?: boolean;
    status?: ProductStatus;
    images?: Array<{ path: string; altText?: string; isPrimary: boolean; sortOrder: number }>;
    variants?: Array<{ size?: string; color?: string; colorHex?: string; sku?: string; stock?: number; isAvailable?: boolean }>;
    collectionIds?: string[];
  }) {
    return prisma.$transaction(async (tx) => {
      const product = await tx.product.create({
        data: {
          name: data.name,
          slug: data.slug,
          sku: data.sku || null,
          shortDescription: data.shortDescription || null,
          description: data.description || null,
          regularPrice: data.regularPrice,
          discountPrice: data.discountPrice || null,
          categoryId: data.categoryId || null,
          isFeatured: data.isFeatured || false,
          isTrending: data.isTrending || false,
          isNewArrival: data.isNewArrival || false,
          status: data.status || ProductStatus.DRAFT,
          images: {
            create: data.images?.map((img) => ({
              path: img.path,
              altText: img.altText || null,
              isPrimary: img.isPrimary,
              sortOrder: img.sortOrder,
            })),
          },
          variants: {
            create: data.variants?.map((v: any) => ({
              size: v.size || null,
              color: v.color || null,
              colorHex: v.colorHex || null,
              sku: v.sku || null,
              stock: v.stock !== undefined && v.stock !== null ? Number(v.stock) : 0,
              priceOverride: v.priceOverride ? Number(v.priceOverride) : null,
              isAvailable: v.isAvailable ?? true,
            })),
          },
        },
      });

      if (data.collectionIds && data.collectionIds.length > 0) {
        await tx.collectionProduct.createMany({
          data: data.collectionIds.map((cid, idx) => ({
            collectionId: cid,
            productId: product.id,
            sortOrder: idx,
          })),
        });
      }

      return product;
    });
  },

  /**
   * Bulk update status (PUBLISH / UNPUBLISH)
   */
  async bulkUpdateStatus(productIds: string[], status: ProductStatus) {
    return prisma.product.updateMany({
      where: { id: { in: productIds } },
      data: { status },
    });
  },

  /**
   * Bulk delete products
   */
  async bulkDelete(productIds: string[]) {
    return prisma.product.deleteMany({
      where: { id: { in: productIds } },
    });
  },

  /**
   * Export Products as JSON array
   */
  async exportJson(): Promise<any[]> {
    const products = await prisma.product.findMany({
      include: {
        category: true,
        images: {
          orderBy: { sortOrder: "asc" },
        },
        variants: {
          orderBy: { createdAt: "asc" },
        },
        collectionProducts: {
          include: {
            collection: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return products.map((p) => ({
      id: p.id,
      name: p.name,
      slug: p.slug,
      sku: p.sku,
      categorySlug: p.category?.slug || null,
      categoryName: p.category?.name || null,
      shortDescription: p.shortDescription,
      description: p.description,
      regularPrice: Number(p.regularPrice),
      discountPrice: p.discountPrice ? Number(p.discountPrice) : null,
      status: p.status,
      isFeatured: p.isFeatured,
      isTrending: p.isTrending,
      isNewArrival: p.isNewArrival,
      images: p.images.map((img) => ({
        path: img.path,
        altText: img.altText,
        isPrimary: img.isPrimary,
        sortOrder: img.sortOrder,
      })),
      variants: p.variants.map((v) => {
        const variantImg = p.images.find(
          (img) =>
            img.altText === `variant:${v.color}` ||
            img.altText === `variant:${v.sku}` ||
            (v.color && img.altText?.toLowerCase() === v.color.toLowerCase())
        );
        return {
          size: v.size,
          color: v.color,
          colorHex: v.colorHex,
          sku: v.sku,
          stock: v.stock,
          priceOverride: v.priceOverride ? Number(v.priceOverride) : null,
          isAvailable: v.isAvailable,
          image: variantImg?.path || null,
        };
      }),
      collections: p.collectionProducts.map((cp) => cp.collection.slug),
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
    }));
  },

  /**
   * Bulk import products from structured JSON array
   */
  async bulkImportJson(items: any[], updateExisting: boolean = true) {
    let createdCount = 0;
    let updatedCount = 0;
    const errors: Array<{ row: number; name?: string; error: string }> = [];

    // Preload categories and collections to resolve slugs efficiently
    const [allCategories, allCollections] = await Promise.all([
      prisma.category.findMany(),
      prisma.collection.findMany(),
    ]);

    const categoryBySlug = new Map(allCategories.map((c) => [c.slug.toLowerCase(), c.id]));
    const categoryByName = new Map(allCategories.map((c) => [c.name.toLowerCase(), c.id]));
    const collectionBySlug = new Map(allCollections.map((col) => [col.slug.toLowerCase(), col.id]));

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      try {
        if (!item || typeof item !== "object") {
          errors.push({ row: i + 1, error: "Invalid product item object" });
          continue;
        }

        if (!item.name || typeof item.name !== "string" || !item.name.trim()) {
          errors.push({ row: i + 1, name: item.name, error: "Product name is required" });
          continue;
        }

        const regularPrice = Number(item.regularPrice);
        if (isNaN(regularPrice) || regularPrice < 0) {
          errors.push({ row: i + 1, name: item.name, error: "Valid regularPrice is required" });
          continue;
        }

        const slug =
          (item.slug && typeof item.slug === "string" && item.slug.trim()) ||
          item.name
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")
            .replace(/(^-|-$)+/g, "");

        // Resolve category
        let categoryId: string | null = null;
        if (item.categoryId) {
          categoryId = item.categoryId;
        } else if (item.categorySlug) {
          categoryId = categoryBySlug.get(item.categorySlug.toLowerCase().trim()) || null;
        } else if (item.categoryName) {
          categoryId = categoryByName.get(item.categoryName.toLowerCase().trim()) || null;
        }

        // Resolve collections
        const collectionIds: string[] = [];
        if (Array.isArray(item.collections)) {
          for (const colSlug of item.collections) {
            const cid = collectionBySlug.get(String(colSlug).toLowerCase().trim());
            if (cid) collectionIds.push(cid);
          }
        }

        // Determine status
        let status: ProductStatus = ProductStatus.DRAFT;
        if (item.status === "PUBLISHED" || item.status === "UNPUBLISHED" || item.status === "DRAFT") {
          status = item.status as ProductStatus;
        }

        // Check if existing product by slug or sku
        const existing = await prisma.product.findFirst({
          where: {
            OR: [
              { slug },
              ...(item.sku ? [{ sku: item.sku }] : []),
            ],
          },
        });

        // Compile prepared images list including any variant-specific images
        const preparedImages: Array<{ path: string; altText: string | null; isPrimary: boolean; sortOrder: number }> = [];

        if (Array.isArray(item.images)) {
          item.images.forEach((img: any, idx: number) => {
            const path = typeof img === "string" ? img : img.path;
            if (path) {
              preparedImages.push({
                path,
                altText: typeof img === "object" ? img.altText || null : null,
                isPrimary: typeof img === "object" ? Boolean(img.isPrimary) : idx === 0,
                sortOrder: typeof img === "object" && img.sortOrder !== undefined ? Number(img.sortOrder) : idx,
              });
            }
          });
        }

        // If variants have image or imagePath, ensure it's registered in preparedImages
        if (Array.isArray(item.variants)) {
          for (const v of item.variants) {
            const vImg = v.image || v.imagePath;
            if (vImg && typeof vImg === "string") {
              const alreadyHas = preparedImages.some((p) => p.path === vImg);
              if (!alreadyHas) {
                preparedImages.push({
                  path: vImg,
                  altText: v.color ? `variant:${v.color}` : v.sku ? `variant:${v.sku}` : "variant",
                  isPrimary: false,
                  sortOrder: preparedImages.length,
                });
              }
            }
          }
        }

        if (existing) {
          if (!updateExisting) {
            errors.push({ row: i + 1, name: item.name, error: `Product with slug "${slug}" already exists (skipped)` });
            continue;
          }

          // Update existing product
          await prisma.$transaction(async (tx) => {
            await tx.product.update({
              where: { id: existing.id },
              data: {
                name: item.name.trim(),
                sku: item.sku || existing.sku,
                shortDescription: item.shortDescription || null,
                description: item.description || null,
                regularPrice,
                discountPrice: item.discountPrice !== undefined && item.discountPrice !== null ? Number(item.discountPrice) : null,
                categoryId: categoryId || existing.categoryId,
                isFeatured: Boolean(item.isFeatured),
                isTrending: Boolean(item.isTrending),
                isNewArrival: Boolean(item.isNewArrival),
                status,
              },
            });

            // If images provided or prepared from variants, refresh images
            if (preparedImages.length > 0) {
              await tx.productImage.deleteMany({ where: { productId: existing.id } });
              await tx.productImage.createMany({
                data: preparedImages.map((img) => ({
                  productId: existing.id,
                  path: img.path,
                  altText: img.altText,
                  isPrimary: img.isPrimary,
                  sortOrder: img.sortOrder,
                })),
              });
            }

            // If variants provided, refresh variants
            if (Array.isArray(item.variants) && item.variants.length > 0) {
              await tx.productVariant.deleteMany({ where: { productId: existing.id } });
              await tx.productVariant.createMany({
                data: item.variants.map((v: any, vIdx: number) => ({
                  productId: existing.id,
                  size: v.size || null,
                  color: v.color || null,
                  colorHex: v.colorHex || null,
                  sku: v.sku || `${slug}-${v.size || vIdx}-${v.color || "def"}`.toUpperCase(),
                  stock: v.stock !== undefined && v.stock !== null ? Number(v.stock) : 0,
                  priceOverride: v.priceOverride ? Number(v.priceOverride) : null,
                  isAvailable: v.isAvailable !== false,
                })),
              });
            }

            // If collections provided, update collections
            if (collectionIds.length > 0) {
              await tx.collectionProduct.deleteMany({ where: { productId: existing.id } });
              await tx.collectionProduct.createMany({
                data: collectionIds.map((cid, cIdx) => ({
                  productId: existing.id,
                  collectionId: cid,
                  sortOrder: cIdx,
                })),
              });
            }
          });

          updatedCount++;
        } else {
          // Create new product
          await prisma.$transaction(async (tx) => {
            const product = await tx.product.create({
              data: {
                name: item.name.trim(),
                slug,
                sku: item.sku || null,
                shortDescription: item.shortDescription || null,
                description: item.description || null,
                regularPrice,
                discountPrice: item.discountPrice !== undefined && item.discountPrice !== null ? Number(item.discountPrice) : null,
                categoryId,
                isFeatured: Boolean(item.isFeatured),
                isTrending: Boolean(item.isTrending),
                isNewArrival: Boolean(item.isNewArrival),
                status,
                images: {
                  create: preparedImages.map((img) => ({
                    path: img.path,
                    altText: img.altText,
                    isPrimary: img.isPrimary,
                    sortOrder: img.sortOrder,
                  })),
                },
                variants: {
                  create: (Array.isArray(item.variants) ? item.variants : []).map((v: any, vIdx: number) => ({
                    size: v.size || null,
                    color: v.color || null,
                    colorHex: v.colorHex || null,
                    sku: v.sku || `${slug}-${v.size || vIdx}-${v.color || "def"}`.toUpperCase(),
                    stock: v.stock !== undefined && v.stock !== null ? Number(v.stock) : 0,
                    priceOverride: v.priceOverride ? Number(v.priceOverride) : null,
                    isAvailable: v.isAvailable !== false,
                  })),
                },
              },
            });

            if (collectionIds.length > 0) {
              await tx.collectionProduct.createMany({
                data: collectionIds.map((cid, cIdx) => ({
                  productId: product.id,
                  collectionId: cid,
                  sortOrder: cIdx,
                })),
              });
            }
          });

          createdCount++;
        }
      } catch (err: any) {
        errors.push({ row: i + 1, name: item?.name, error: err.message || "Failed to process product" });
      }
    }

    return {
      success: true,
      totalProcessed: items.length,
      createdCount,
      updatedCount,
      errorsCount: errors.length,
      errors,
    };
  },

  /**
   * Export Products as CSV string (kept for fallback)
   */
  async exportCsv(): Promise<string> {
    const products = await prisma.product.findMany({
      include: {
        category: true,
        variants: true,
      },
    });

    const headers = ["ID", "Name", "SKU", "Category", "RegularPrice", "DiscountPrice", "Status", "VariantsCount", "CreatedAt"];
    const rows = products.map((p) => [
      p.id,
      `"${p.name.replace(/"/g, '""')}"`,
      p.sku || "",
      p.category?.name || "",
      p.regularPrice.toString(),
      p.discountPrice ? p.discountPrice.toString() : "",
      p.status,
      p.variants.length,
      p.createdAt.toISOString(),
    ]);

    return [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
  },
};


import { prisma } from "@/lib/prisma";
import { formatCurrency, formatDate, generateInvoiceNumber } from "@/lib/formatters";
import { siteConfig } from "@/config/site";
import { generateQrSvg } from "@/lib/qr-code";
import { buildInvoicePdf } from "@/server/services/pdf-invoice-generator";

export const invoiceService = {
  /**
   * Generate an invoice for an order
   */
  async generateInvoice(orderId: string, templateId?: string) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: {
        customer: true,
        items: true,
      },
    });

    if (!order) {
      throw new Error("Order not found");
    }

    // Check if invoice already exists
    let invoice = await prisma.invoice.findFirst({
      where: { orderId: order.id },
    });

    if (invoice) {
      return invoice;
    }

    const count = await prisma.invoice.count();
    const invoiceNumber = generateInvoiceNumber(count + 1);

    // Get default template if not specified
    let selectedTemplateId = templateId;
    if (!selectedTemplateId) {
      const defaultTemplate = await prisma.invoiceTemplate.findFirst({
        where: { isDefault: true },
      });
      selectedTemplateId = defaultTemplate?.id;
    }

    invoice = await prisma.invoice.create({
      data: {
        invoiceNumber,
        orderId: order.id,
        subtotal: order.subtotal,
        discount: order.discount,
        tax: order.tax,
        shipping: order.shipping,
        total: order.total,
        amountPaid: order.amountPaid,
        balanceDue: order.balanceDue,
        templateId: selectedTemplateId || null,
      },
    });

    return invoice;
  },

  /**
   * Generate standards-compliant binary PDF for an order's invoice
   */
  async generateInvoicePdf(orderId: string): Promise<Uint8Array> {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: {
        customer: true,
        items: true,
        invoices: { take: 1, orderBy: { createdAt: "desc" } },
      },
    });

    if (!order) {
      throw new Error("Order not found");
    }

    const settings = (await prisma.storeSettings.findFirst()) || {
      storeName: "OneFam Fashion",
      gstNumber: null,
      supportEmail: siteConfig.contact.supportEmail,
      supportPhone: siteConfig.contact.whatsappNumber,
      whatsappNumber: siteConfig.contact.whatsappNumber,
      address: "OneFam Boutique, India",
    };

    const invoiceNumber = order.invoices[0]?.invoiceNumber || `INV-${order.orderRef}`;
    const invoiceDate = formatDate(order.invoices[0]?.invoiceDate || order.createdAt);
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || siteConfig.seo.siteUrl;
    const verificationUrl = `${appUrl}/orders/verify/${order.orderRef}`;

    return buildInvoicePdf({
      invoiceNumber,
      invoiceDate,
      orderRef: order.orderRef,
      storeName: settings.storeName || "OneFam Fashion",
      gstNumber: settings.gstNumber,
      supportEmail: settings.supportEmail || siteConfig.contact.supportEmail,
      supportPhone: settings.supportPhone || siteConfig.contact.whatsappNumber,
      whatsappNumber: settings.whatsappNumber || siteConfig.contact.whatsappNumber,
      customerName: order.customer.name,
      customerPhone: order.customer.phone,
      customerAddress: order.customer.shippingAddress || "",
      items: order.items.map((i) => ({
        name: i.productName,
        variant: [i.size, i.color].filter(Boolean).join(" / "),
        qty: i.quantity,
        unitPrice: Number(i.unitPrice),
        totalPrice: Number(i.totalPrice),
      })),
      subtotal: Number(order.subtotal),
      discount: Number(order.discount),
      shipping: Number(order.shipping),
      tax: Number(order.tax),
      total: Number(order.total),
      amountPaid: Number(order.amountPaid),
      balanceDue: Number(order.balanceDue),
      verificationUrl,
    });
  },

  /**
   * Render invoice HTML with live order data, QR verification code, & template variables
   */
  async renderInvoiceHtml(orderId: string, customTemplateId?: string, autoPrint = false) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: {
        customer: true,
        items: true,
        invoices: { take: 1, orderBy: { createdAt: "desc" } },
      },
    });

    if (!order) {
      throw new Error("Order not found");
    }

    const settings = (await prisma.storeSettings.findFirst()) || {
      storeName: "OneFam Fashion",
      logoUrl: null,
      gstNumber: null,
      supportEmail: siteConfig.contact.supportEmail,
      supportPhone: siteConfig.contact.whatsappNumber,
      whatsappNumber: siteConfig.contact.whatsappNumber,
      address: "OneFam Studio, Indiranagar, Bengaluru, KA 560038",
    };

    let template = null;
    if (customTemplateId) {
      template = await prisma.invoiceTemplate.findUnique({ where: { id: customTemplateId } });
    }
    if (!template) {
      template = await prisma.invoiceTemplate.findFirst({ where: { isDefault: true } });
    }

    const invoiceNumber = order.invoices[0]?.invoiceNumber || `INV-${order.orderRef}`;
    const invoiceDate = formatDate(order.invoices[0]?.invoiceDate || order.createdAt);
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || siteConfig.seo.siteUrl;
    const verificationUrl = `${appUrl}/orders/verify/${order.orderRef}`;

    // Generate pure SVG QR Code for verification
    const qrSvg = generateQrSvg(verificationUrl, { size: 95 });

    // Official Logo: Custom uploaded Store Logo or fallback to OneFam Dark Logo
    const logoSrc = settings.logoUrl || siteConfig.images.logo.light;
    const storeLogoHtml = `<img src="${escapeHtml(logoSrc)}" alt="${escapeHtml(
      settings.storeName
    )}" style="height: 44px; max-width: 220px; object-fit: contain; display: block;" />`;

    const itemsHtml = order.items
      .map(
        (item) => `
      <tr>
        <td style="padding: 12px; border-bottom: 1px solid #E8E6E1; font-weight: 500;">
          ${escapeHtml(item.productName)}
          ${item.sku ? `<br><small style="color:#6B6A72;">SKU: ${escapeHtml(item.sku)}</small>` : ""}
        </td>
        <td style="padding: 12px; border-bottom: 1px solid #E8E6E1; color:#6B6A72;">
          ${[item.size, item.color].filter(Boolean).join(" / ") || "-"}
        </td>
        <td style="padding: 12px; border-bottom: 1px solid #E8E6E1; text-align: center;">${item.quantity}</td>
        <td style="padding: 12px; border-bottom: 1px solid #E8E6E1; text-align: right;">${formatCurrency(item.unitPrice)}</td>
        <td style="padding: 12px; border-bottom: 1px solid #E8E6E1; text-align: right; font-weight: 600;">${formatCurrency(item.totalPrice)}</td>
      </tr>`
      )
      .join("");

    const templateHtml = template?.customHtml || defaultHtmlTemplate;

    const storeEmail = settings.supportEmail || siteConfig.contact.supportEmail;
    const whatsappNum = settings.whatsappNumber || siteConfig.contact.whatsappNumber;
    const storePhone = settings.supportPhone || whatsappNum;
    const storeAddress = settings.address || "Online Direct Boutique, India";

    const rendered = templateHtml
      .replace(/{{logo}}/g, storeLogoHtml)
      .replace(/{{store_logo}}/g, storeLogoHtml)
      .replace(/{{store_name}}/g, escapeHtml(settings.storeName))
      .replace(/{{gst_number}}/g, settings.gstNumber ? `GSTIN: ${escapeHtml(settings.gstNumber)}` : "")
      .replace(/{{store_email}}/g, escapeHtml(storeEmail))
      .replace(/{{support_email}}/g, escapeHtml(storeEmail))
      .replace(/{{whatsapp_number}}/g, escapeHtml(whatsappNum))
      .replace(/{{whatsapp_no}}/g, escapeHtml(whatsappNum))
      .replace(/{{store_whatsapp}}/g, escapeHtml(whatsappNum))
      .replace(/{{store_phone}}/g, escapeHtml(storePhone))
      .replace(/{{store_address}}/g, escapeHtml(storeAddress))
      .replace(/{{invoice_number}}/g, escapeHtml(invoiceNumber))
      .replace(/{{invoice_date}}/g, escapeHtml(invoiceDate))
      .replace(/{{order_reference}}/g, escapeHtml(order.orderRef))
      .replace(/{{customer_name}}/g, escapeHtml(order.customer.name))
      .replace(/{{customer_email}}/g, escapeHtml(order.customer.email))
      .replace(/{{customer_phone}}/g, escapeHtml(order.customer.phone))
      .replace(/{{customer_address}}/g, escapeHtml(order.customer.shippingAddress || ""))
      .replace(/{{items_table}}/g, itemsHtml)
      .replace(/{{subtotal}}/g, formatCurrency(order.subtotal))
      .replace(/{{discount}}/g, formatCurrency(order.discount))
      .replace(/{{shipping}}/g, formatCurrency(order.shipping))
      .replace(/{{tax}}/g, formatCurrency(order.tax))
      .replace(/{{total}}/g, formatCurrency(order.total))
      .replace(/{{amount_paid}}/g, formatCurrency(order.amountPaid))
      .replace(/{{balance_due}}/g, formatCurrency(order.balanceDue))
      .replace(
        /{{qr_code}}/g,
        `<a href="${escapeHtml(verificationUrl)}" target="_blank" rel="noopener noreferrer" style="display:inline-block; text-decoration:none; color:inherit;" title="Verify order in new tab">${qrSvg}</a>`
      )
      .replace(/{{verification_url}}/g, escapeHtml(verificationUrl))
      .replace(/{{footer_note}}/g, "Thank you for shopping with OneFam Fashion. For queries, contact our WhatsApp Concierge.");

    // Inject print toolbar and auto-print script
    const actionToolbar = `
    <div class="no-print" style="position: sticky; top: 0; background: #191720; color: #fff; padding: 12px 24px; display: flex; align-items: center; justify-content: space-between; z-index: 100; box-shadow: 0 4px 12px rgba(0,0,0,0.15); margin: -40px -40px 30px -40px;">
      <div style="font-size: 13px; font-weight: 700; display: flex; items-center; gap: 8px;">
        <span style="color: #C6F542;">●</span>
        <span>${escapeHtml(invoiceNumber)} — Official Invoice</span>
      </div>
      <div style="display: flex; gap: 10px;">
        <a href="?format=pdf&download=true" style="background: #7137C8; color: #fff; border: none; padding: 8px 16px; border-radius: 9999px; font-size: 12px; font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 6px;">
          📥 Download PDF
        </a>
        <button onclick="window.print()" style="background: #fff; color: #191720; border: none; padding: 8px 16px; border-radius: 9999px; font-size: 12px; font-weight: 700; cursor: pointer;">
          🖨️ Print Invoice
        </button>
      </div>
    </div>
    ${autoPrint ? `<script>window.addEventListener('DOMContentLoaded', () => window.print());</script>` : ""}`;

    return rendered.replace("<body>", `<body>${actionToolbar}`);
  },
};

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

const defaultHtmlTemplate = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Invoice - {{invoice_number}}</title>
<style>
  @page { size: A4; margin: 15mm; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #191720; margin: 0; padding: 40px; background: #fff; line-height: 1.5; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #7137C8; padding-bottom: 24px; margin-bottom: 24px; }
  .logo-area { display: flex; flex-direction: column; gap: 6px; }
  .inv-meta { text-align: right; }
  .customer-box { margin-bottom: 24px; background: #FCFAF4; padding: 16px; border-radius: 8px; border: 1px solid #E8E6E1; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
  th { text-align: left; padding: 10px 12px; background: #F5F3EF; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #E8E6E1; }
  td { padding: 12px; border-bottom: 1px solid #E8E6E1; font-size: 13px; }
  .bottom-layout { display: flex; justify-content: space-between; align-items: flex-start; margin-top: 10px; }
  .qr-section { width: 260px; padding: 14px; background: #FCFAF4; border: 1px solid #E8E6E1; border-radius: 8px; text-align: center; }
  .totals { width: 300px; }
  .totals-row { display: flex; justify-content: space-between; padding: 5px 0; font-size: 13px; }
  .totals-row.grand { font-size: 16px; font-weight: 700; color: #7137C8; border-top: 2px solid #191720; padding-top: 8px; margin-top: 6px; }
  .footer { text-align: center; font-size: 11px; color: #6B6A72; border-top: 1px solid #E8E6E1; padding-top: 18px; margin-top: 30px; }
  @media print {
    .no-print { display: none !important; }
    body { padding: 0; }
  }
</style>
</head>
<body>
  <div class="header">
    <div class="logo-area">
      {{store_logo}}
      <p style="margin:4px 0 0; color:#6B6A72; font-size:12px;">Official Tax Invoice &amp; Store Receipt</p>
      <p style="margin:2px 0 0; color:#6B6A72; font-size:11px; font-weight:600;">{{gst_number}}</p>
      <p style="margin:2px 0 0; color:#6B6A72; font-size:11px;">Email: {{store_email}} | WhatsApp: +{{whatsapp_number}}</p>
    </div>
    <div class="inv-meta">
      <h2 style="margin:0; font-size:22px; color:#7137C8; font-weight:800;">INVOICE</h2>
      <p style="margin:4px 0; font-size:13px;"><strong>No:</strong> {{invoice_number}}</p>
      <p style="margin:0; font-size:13px;"><strong>Date:</strong> {{invoice_date}}</p>
      <p style="margin:4px 0 0; font-size:13px;"><strong>Order Ref:</strong> {{order_reference}}</p>
    </div>
  </div>

  <div class="customer-box">
    <div style="font-size:11px; text-transform:uppercase; color:#6B6A72; font-weight:700; margin-bottom:4px;">Customer &amp; Shipping Details:</div>
    <div style="font-weight:700; font-size:14px; color:#191720;">{{customer_name}}</div>
    <div style="color:#6B6A72; font-size:12px; margin-top:2px;">{{customer_email}} | {{customer_phone}}</div>
    <div style="color:#6B6A72; font-size:12px; margin-top:2px;">{{customer_address}}</div>
  </div>

  <table>
    <thead>
      <tr>
        <th>Item</th>
        <th>Variant</th>
        <th style="text-align:center;">Qty</th>
        <th style="text-align:right;">Price</th>
        <th style="text-align:right;">Total</th>
      </tr>
    </thead>
    <tbody>
      {{items_table}}
    </tbody>
  </table>

  <div class="bottom-layout">
    <div class="qr-section">
      <div style="display:flex; justify-content:center; margin-bottom:6px;">
        {{qr_code}}
      </div>
      <div style="font-size:10.5px; font-weight:700; color:#191720;">Official Digital Verification QR</div>
      <div style="font-size:9.5px; color:#6B6A72; margin-top:2px;">Scan with phone camera to verify authentic order &amp; track parcel.</div>
    </div>

    <div class="totals">
      <div class="totals-row"><span>Subtotal:</span><span>{{subtotal}}</span></div>
      <div class="totals-row"><span>Discount:</span><span style="color:#F45B45;">-{{discount}}</span></div>
      <div class="totals-row"><span>Shipping:</span><span>{{shipping}}</span></div>
      <div class="totals-row grand"><span>Total Payable:</span><span>{{total}}</span></div>
      <div class="totals-row" style="color:#2E8B57; font-weight:600;"><span>Amount Paid:</span><span>{{amount_paid}}</span></div>
      <div class="totals-row" style="color:#7137C8; font-weight:600;"><span>Balance Due:</span><span>{{balance_due}}</span></div>
    </div>
  </div>

  <div class="footer">
    <p>{{footer_note}}</p>
  </div>
</body>
</html>`;

/**
 * Pure TypeScript PDF Generator for OneFam Fashion Invoices.
 * Produces standards-compliant PDF 1.4 binary documents (Zero external dependencies).
 * Renders vector lines, typography, tables, and totals for A4 paper.
 */

interface InvoicePdfData {
  invoiceNumber: string;
  invoiceDate: string;
  orderRef: string;
  storeName: string;
  gstNumber?: string | null;
  supportEmail?: string | null;
  supportPhone?: string | null;
  whatsappNumber?: string | null;
  customerName: string;
  customerPhone?: string | null;
  customerAddress?: string | null;
  items: Array<{
    name: string;
    variant?: string;
    qty: number;
    unitPrice: number;
    totalPrice: number;
  }>;
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  amountPaid: number;
  balanceDue: number;
  verificationUrl: string;
}

function escapePdfText(text: string): string {
  return text
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)")
    .replace(/[^\x20-\x7E]/g, " "); // Keep standard ASCII range for Helvetica
}

export function buildInvoicePdf(data: InvoicePdfData): Uint8Array {
  // Page geometry (A4: 595.28 x 841.89 points)
  const pageWidth = 595.28;
  const pageHeight = 841.89;
  const margin = 45;
  const contentWidth = pageWidth - margin * 2;

  const streamOps: string[] = [];

  // Helper operators
  const setStrokeColor = (r: number, g: number, b: number) => {
    streamOps.push(`${(r / 255).toFixed(3)} ${(g / 255).toFixed(3)} ${(b / 255).toFixed(3)} RG`);
  };
  const setFillColor = (r: number, g: number, b: number) => {
    streamOps.push(`${(r / 255).toFixed(3)} ${(g / 255).toFixed(3)} ${(b / 255).toFixed(3)} rg`);
  };
  const drawLine = (x1: number, y1: number, x2: number, y2: number, lineWidth = 1) => {
    streamOps.push(`q ${lineWidth} w ${x1.toFixed(1)} ${y1.toFixed(1)} m ${x2.toFixed(1)} ${y2.toFixed(1)} l S Q`);
  };
  const drawRect = (x: number, y: number, w: number, h: number, fill = true, stroke = false) => {
    const op = fill && stroke ? "B" : fill ? "f" : "s";
    streamOps.push(`q ${x.toFixed(1)} ${y.toFixed(1)} ${w.toFixed(1)} ${h.toFixed(1)} re ${op} Q`);
  };
  const drawText = (
    text: string,
    x: number,
    y: number,
    fontSize = 10,
    font = "F1", // F1 = Regular, F2 = Bold
    align: "left" | "right" | "center" = "left"
  ) => {
    const escaped = escapePdfText(text);
    // Rough width estimation for Helvetica
    const charWidth = fontSize * 0.52;
    let startX = x;
    if (align === "right") {
      startX = x - escaped.length * charWidth;
    } else if (align === "center") {
      startX = x - (escaped.length * charWidth) / 2;
    }
    streamOps.push(`BT /${font} ${fontSize} Tf 1 0 0 1 ${startX.toFixed(1)} ${y.toFixed(1)} Tm (${escaped}) Tj ET`);
  };

  // 1. Header Banner & Branding
  let currentY = pageHeight - 55;

  // Royal Violet Brand Bar at top
  setFillColor(113, 55, 200); // Royal Violet #7137C8
  drawRect(margin, currentY + 12, contentWidth, 4);

  // Store Brand Name (Helvetica Bold)
  setFillColor(25, 23, 32); // Ink
  drawText(data.storeName.toUpperCase(), margin, currentY - 5, 20, "F2");

  setFillColor(107, 106, 114);
  drawText("Official Tax Invoice & Store Receipt", margin, currentY - 20, 9, "F1");
  const storeContactParts = [
    data.supportEmail ? `Email: ${data.supportEmail}` : null,
    data.whatsappNumber ? `WhatsApp: +${data.whatsappNumber}` : null,
  ].filter(Boolean).join("  |  ");
  if (storeContactParts) {
    drawText(storeContactParts, margin, currentY - 31, 8, "F1");
  }
  if (data.gstNumber) {
    drawText(`GSTIN: ${data.gstNumber}`, margin, currentY - 42, 8.5, "F1");
  }

  // Invoice Number & Meta (Right Aligned)
  setFillColor(113, 55, 200);
  drawText("INVOICE", pageWidth - margin, currentY - 5, 18, "F2", "right");

  setFillColor(25, 23, 32);
  drawText(`Invoice No: ${data.invoiceNumber}`, pageWidth - margin, currentY - 20, 9, "F2", "right");
  drawText(`Date: ${data.invoiceDate}`, pageWidth - margin, currentY - 32, 9, "F1", "right");
  drawText(`Order Ref: ${data.orderRef}`, pageWidth - margin, currentY - 44, 9, "F1", "right");

  currentY -= 65;

  // Divider
  setStrokeColor(232, 230, 225);
  drawLine(margin, currentY, pageWidth - margin, currentY, 1);
  currentY -= 15;

  // 2. Customer Information Box
  setFillColor(250, 248, 244); // Paper background
  setStrokeColor(232, 230, 225);
  drawRect(margin, currentY - 45, contentWidth, 52, true, true);

  setFillColor(107, 106, 114);
  drawText("BILLED & SHIPPED TO:", margin + 12, currentY - 8, 8, "F2");

  setFillColor(25, 23, 32);
  drawText(data.customerName, margin + 12, currentY - 22, 11, "F2");

  setFillColor(107, 106, 114);
  const contactText = [data.customerPhone, data.customerAddress].filter(Boolean).join("  |  ");
  drawText(contactText || "Online Verified Customer", margin + 12, currentY - 36, 8.5, "F1");

  currentY -= 65;

  // 3. Table Header
  setFillColor(245, 243, 239);
  drawRect(margin, currentY - 18, contentWidth, 22, true, false);

  setFillColor(25, 23, 32);
  drawText("ITEM DESCRIPTION", margin + 8, currentY - 13, 8.5, "F2");
  drawText("VARIANT", margin + 250, currentY - 13, 8.5, "F2");
  drawText("QTY", margin + 340, currentY - 13, 8.5, "F2", "center");
  drawText("PRICE", margin + 420, currentY - 13, 8.5, "F2", "right");
  drawText("TOTAL", pageWidth - margin - 8, currentY - 13, 8.5, "F2", "right");

  currentY -= 20;

  // Table Items
  const items = data.items.slice(0, 10); // Fits comfortably on page 1
  for (const item of items) {
    currentY -= 18;
    setStrokeColor(240, 238, 234);
    drawLine(margin, currentY - 4, pageWidth - margin, currentY - 4, 0.5);

    setFillColor(25, 23, 32);
    drawText(item.name.slice(0, 38), margin + 8, currentY, 9, "F1");

    setFillColor(107, 106, 114);
    drawText((item.variant || "-").slice(0, 16), margin + 250, currentY, 8.5, "F1");

    setFillColor(25, 23, 32);
    drawText(String(item.qty), margin + 340, currentY, 9, "F1", "center");
    drawText(`Rs. ${item.unitPrice.toLocaleString("en-IN")}`, margin + 420, currentY, 9, "F1", "right");
    drawText(`Rs. ${item.totalPrice.toLocaleString("en-IN")}`, pageWidth - margin - 8, currentY, 9, "F2", "right");
  }

  currentY -= 25;

  // 4. Financial Summary (Right Column) & Verification Info (Left Column)
  const summaryBoxWidth = 220;
  const summaryX = pageWidth - margin - summaryBoxWidth;

  // Left side: Digital Order Verification box
  setFillColor(250, 248, 244);
  setStrokeColor(232, 230, 225);
  drawRect(margin, currentY - 95, contentWidth - summaryBoxWidth - 20, 105, true, true);

  setFillColor(113, 55, 200);
  drawText("ONLINE ORDER VERIFICATION & AUTHENTICITY", margin + 12, currentY - 8, 8, "F2");

  setFillColor(25, 23, 32);
  drawText("Scan QR code or visit verification portal to track parcel:", margin + 12, currentY - 24, 8, "F1");

  setFillColor(113, 55, 200);
  drawText(data.verificationUrl.slice(0, 48), margin + 12, currentY - 38, 8, "F2");

  setFillColor(107, 106, 114);
  drawText("100% Genuine OneFam Fashion Boutique Garment", margin + 12, currentY - 54, 7.5, "F1");
  drawText("For inquiries: care@onefamfashion.com | WhatsApp Support", margin + 12, currentY - 68, 7.5, "F1");

  // Right side: Financial Totals
  const rowH = 14;
  let totY = currentY;

  setFillColor(107, 106, 114);
  drawText("Subtotal:", summaryX, totY, 9, "F1");
  setFillColor(25, 23, 32);
  drawText(`Rs. ${data.subtotal.toLocaleString("en-IN")}`, pageWidth - margin - 8, totY, 9, "F1", "right");

  if (data.discount > 0) {
    totY -= rowH;
    setFillColor(244, 91, 69); // Vermilion
    drawText("Discount:", summaryX, totY, 9, "F1");
    drawText(`-Rs. ${data.discount.toLocaleString("en-IN")}`, pageWidth - margin - 8, totY, 9, "F1", "right");
  }

  totY -= rowH;
  setFillColor(107, 106, 114);
  drawText("Shipping:", summaryX, totY, 9, "F1");
  setFillColor(25, 23, 32);
  drawText(data.shipping > 0 ? `Rs. ${data.shipping.toLocaleString("en-IN")}` : "FREE", pageWidth - margin - 8, totY, 9, "F1", "right");

  totY -= rowH + 2;
  setStrokeColor(25, 23, 32);
  drawLine(summaryX, totY + 4, pageWidth - margin, totY + 4, 1.2);

  setFillColor(113, 55, 200);
  drawText("Total Payable:", summaryX, totY - 8, 12, "F2");
  drawText(`Rs. ${data.total.toLocaleString("en-IN")}`, pageWidth - margin - 8, totY - 8, 12, "F2", "right");

  totY -= rowH + 10;
  setFillColor(46, 139, 87);
  drawText("Amount Paid:", summaryX, totY, 9, "F2");
  drawText(`Rs. ${data.amountPaid.toLocaleString("en-IN")}`, pageWidth - margin - 8, totY, 9, "F2", "right");

  if (data.balanceDue > 0) {
    totY -= rowH;
    setFillColor(244, 91, 69);
    drawText("Balance Due (COD):", summaryX, totY, 9, "F2");
    drawText(`Rs. ${data.balanceDue.toLocaleString("en-IN")}`, pageWidth - margin - 8, totY, 9, "F2", "right");
  }

  // 5. Footer Note
  setStrokeColor(232, 230, 225);
  drawLine(margin, 50, pageWidth - margin, 50, 0.5);

  setFillColor(107, 106, 114);
  drawText(
    "Thank you for choosing OneFam Fashion. All garments crafted with mindful natural fibres.",
    pageWidth / 2,
    38,
    7.5,
    "F1",
    "center"
  );
  drawText(
    `Invoice ${data.invoiceNumber} • Generated on ${data.invoiceDate}`,
    pageWidth / 2,
    28,
    7,
    "F1",
    "center"
  );

  // Assemble Complete PDF Objects
  const streamContent = streamOps.join("\n");
  const streamLength = Buffer.byteLength(streamContent, "utf8");

  const objects = [
    `1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj`,
    `2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj`,
    `3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >>\nendobj`,
    `4 0 obj\n<< /Length ${streamLength} >>\nstream\n${streamContent}\nendstream\nendobj`,
    `5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj`,
    `6 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj`,
  ];

  let currentOffset = 0;
  const header = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
  currentOffset += Buffer.byteLength(header, "utf8");

  const xrefOffsets: number[] = [0];
  const bodyParts: string[] = [];

  for (const obj of objects) {
    xrefOffsets.push(currentOffset);
    bodyParts.push(obj + "\n");
    currentOffset += Buffer.byteLength(obj + "\n", "utf8");
  }

  const xrefOffset = currentOffset;
  let xref = `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= objects.length; i++) {
    const offStr = String(xrefOffsets[i]).padStart(10, "0");
    xref += `${offStr} 00000 n \n`;
  }

  const trailer = `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;

  const fullPdfString = header + bodyParts.join("") + xref + trailer;
  return Buffer.from(fullPdfString, "latin1");
}


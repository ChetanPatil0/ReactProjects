import { prisma } from "@/lib/prisma";
import { format, subDays, startOfDay, endOfDay } from "date-fns";

export interface DateRangeFilter {
  range?: "7d" | "30d" | "90d" | "all";
}

export const reportService = {
  /**
   * Comprehensive Analytics & Reporting Service
   */
  async getAnalytics(filterRange: "7d" | "30d" | "90d" | "all" = "30d") {
    const now = new Date();
    let startDate: Date | undefined;
    let daysCount = 30;

    if (filterRange === "7d") {
      startDate = startOfDay(subDays(now, 6));
      daysCount = 7;
    } else if (filterRange === "30d") {
      startDate = startOfDay(subDays(now, 29));
      daysCount = 30;
    } else if (filterRange === "90d") {
      startDate = startOfDay(subDays(now, 89));
      daysCount = 90;
    }

    const whereDateClause = startDate ? { createdAt: { gte: startDate } } : {};

    // 1. Fetch Orders within date range
    const orders = await prisma.order.findMany({
      where: whereDateClause,
      select: {
        id: true,
        orderRef: true,
        status: true,
        paymentStatus: true,
        total: true,
        amountPaid: true,
        balanceDue: true,
        createdAt: true,
        payments: {
          select: {
            method: true,
            amount: true,
          },
        },
        items: {
          select: {
            productId: true,
            productName: true,
            sku: true,
            quantity: true,
            unitPrice: true,
            totalPrice: true,
          },
        },
      },
      orderBy: { createdAt: "asc" },
    });

    // 2. Compute KPI Metrics
    const totalOrders = orders.length;
    let totalRevenue = 0;
    let totalPaid = 0;
    let totalBalance = 0;
    let totalUnitsSold = 0;

    for (const order of orders) {
      totalRevenue += Number(order.total || 0);
      totalPaid += Number(order.amountPaid || 0);
      totalBalance += Number(order.balanceDue || 0);
      for (const item of order.items) {
        totalUnitsSold += item.quantity || 1;
      }
    }

    const averageOrderValue = totalOrders > 0 ? Math.round(totalRevenue / totalOrders) : 0;

    // 3. Build Daily Revenue Trend
    // Prepopulate map of dates
    const trendMap = new Map<string, { date: string; label: string; revenue: number; orders: number }>();
    if (daysCount <= 30) {
      for (let i = daysCount - 1; i >= 0; i--) {
        const d = subDays(now, i);
        const key = format(d, "yyyy-MM-dd");
        trendMap.set(key, {
          date: key,
          label: format(d, "dd MMM"),
          revenue: 0,
          orders: 0,
        });
      }
    }

    for (const order of orders) {
      const key = format(order.createdAt, "yyyy-MM-dd");
      if (trendMap.has(key)) {
        const point = trendMap.get(key)!;
        point.revenue += Number(order.total || 0);
        point.orders += 1;
      } else if (daysCount > 30) {
        // Group by month for 90d/all
        const monthKey = format(order.createdAt, "MMM yyyy");
        if (!trendMap.has(monthKey)) {
          trendMap.set(monthKey, {
            date: monthKey,
            label: monthKey,
            revenue: 0,
            orders: 0,
          });
        }
        const point = trendMap.get(monthKey)!;
        point.revenue += Number(order.total || 0);
        point.orders += 1;
      }
    }

    const revenueTrend = Array.from(trendMap.values());

    // 4. Status Breakdown
    const statusCounts: Record<string, number> = {};
    for (const order of orders) {
      const s = order.status || "CONFIRMED";
      statusCounts[s] = (statusCounts[s] || 0) + 1;
    }

    const statusBreakdown = Object.entries(statusCounts).map(([status, count]) => ({
      status,
      label: status.replace(/_/g, " "),
      count,
      percentage: totalOrders > 0 ? Math.round((count / totalOrders) * 100) : 0,
    }));

    // 5. Payment Methods Breakdown
    const paymentMap = new Map<string, { count: number; totalAmount: number }>();
    for (const order of orders) {
      if (order.payments && order.payments.length > 0) {
        for (const p of order.payments) {
          const method = p.method || "UPI";
          const current = paymentMap.get(method) || { count: 0, totalAmount: 0 };
          current.count += 1;
          current.totalAmount += Number(p.amount || 0);
          paymentMap.set(method, current);
        }
      } else {
        // Default to UPI if recorded directly
        const defaultMethod = "UPI";
        const current = paymentMap.get(defaultMethod) || { count: 0, totalAmount: 0 };
        current.count += 1;
        current.totalAmount += Number(order.amountPaid || 0);
        paymentMap.set(defaultMethod, current);
      }
    }

    const paymentMethods = Array.from(paymentMap.entries()).map(([method, data]) => ({
      method,
      label: method.replace(/_/g, " "),
      count: data.count,
      amount: data.totalAmount,
      percentage: totalPaid > 0 ? Math.round((data.totalAmount / totalPaid) * 100) : 0,
    }));

    // 6. Top Selling Products
    const productStats = new Map<
      string,
      { name: string; sku: string; unitsSold: number; revenue: number }
    >();

    for (const order of orders) {
      for (const item of order.items) {
        const key = item.productId || item.productName;
        const current = productStats.get(key) || {
          name: item.productName,
          sku: item.sku || "N/A",
          unitsSold: 0,
          revenue: 0,
        };
        current.unitsSold += item.quantity || 1;
        current.revenue += Number(item.totalPrice || Number(item.unitPrice) * (item.quantity || 1));
        productStats.set(key, current);
      }
    }

    const topSellingProducts = Array.from(productStats.values())
      .sort((a, b) => b.unitsSold - a.unitsSold)
      .slice(0, 8);

    return {
      filterRange,
      kpis: {
        totalRevenue,
        totalPaid,
        totalBalance,
        totalOrders,
        averageOrderValue,
        totalUnitsSold,
      },
      revenueTrend,
      statusBreakdown,
      paymentMethods,
      topSellingProducts,
    };
  },
};


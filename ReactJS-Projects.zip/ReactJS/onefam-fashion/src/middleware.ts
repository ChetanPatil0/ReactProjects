import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(request: NextRequest) {
  const { pathname, search } = request.nextUrl;

  // 1. Security: Block Path Traversal & Null Byte Injections
  const rawUrl = request.url.toLowerCase();
  if (
    rawUrl.includes("%00") ||
    rawUrl.includes("\\0") ||
    pathname.includes("..") ||
    pathname.includes("//")
  ) {
    return new NextResponse("Bad Request - Malicious URI Pattern Detected", {
      status: 400,
    });
  }

  // 2. Security: Block obvious script injection in query params
  if (
    search &&
    (/<script\b/i.test(search) ||
      /javascript:/i.test(search) ||
      /data:text\/html/i.test(search) ||
      /onload\s*=/i.test(search) ||
      /onerror\s*=/i.test(search))
  ) {
    return new NextResponse("Forbidden - Malicious Script Query Detected", {
      status: 403,
    });
  }

  // 3. Security: Protect admin routes except login and auth APIs
  if (pathname.startsWith("/admin") && pathname !== "/admin/login") {
    const sessionCookie = request.cookies.get("off_admin_session")?.value;
    if (!sessionCookie) {
      const loginUrl = new URL("/admin/login", request.url);
      return NextResponse.redirect(loginUrl);
    }
  }

  const response = NextResponse.next();

  // Additional defense-in-depth headers
  response.headers.set("X-Frame-Options", "SAMEORIGIN");
  response.headers.set("X-Content-Type-Options", "nosniff");
  response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");

  return response;
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};

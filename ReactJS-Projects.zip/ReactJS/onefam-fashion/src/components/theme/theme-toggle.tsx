"use client";

import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { Sun, Moon, Laptop, Check } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";

interface ThemeToggleProps {
  variant?: "dropdown" | "segmented" | "icon";
  className?: string;
}

export function ThemeToggle({ variant = "dropdown", className = "" }: ThemeToggleProps) {
  const { theme, setTheme, resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <div className={`w-9 h-9 rounded-full border border-border/60 bg-muted/50 animate-pulse ${className}`} />
    );
  }

  if (variant === "segmented") {
    return (
      <div
        className={`inline-flex items-center p-1 rounded-full bg-muted/60 border border-border/80 text-xs font-semibold select-none ${className}`}
        role="group"
        aria-label="Theme Switcher"
      >
        <button
          type="button"
          onClick={() => setTheme("light")}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full transition-all ${
            theme === "light"
              ? "bg-white dark:bg-card text-royal-violet shadow-2xs font-bold"
              : "text-muted-foreground hover:text-foreground"
          }`}
          title="Light Theme"
        >
          <Sun className="w-3.5 h-3.5" />
          <span>Light</span>
        </button>

        <button
          type="button"
          onClick={() => setTheme("dark")}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full transition-all ${
            theme === "dark"
              ? "bg-white dark:bg-card text-royal-violet shadow-2xs font-bold"
              : "text-muted-foreground hover:text-foreground"
          }`}
          title="Dark Theme"
        >
          <Moon className="w-3.5 h-3.5" />
          <span>Dark</span>
        </button>

        <button
          type="button"
          onClick={() => setTheme("system")}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full transition-all ${
            theme === "system"
              ? "bg-white dark:bg-card text-royal-violet shadow-2xs font-bold"
              : "text-muted-foreground hover:text-foreground"
          }`}
          title="Match System Settings"
        >
          <Laptop className="w-3.5 h-3.5" />
          <span>System</span>
        </button>
      </div>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className={`relative rounded-full text-foreground hover:bg-muted/80 transition-colors ${className}`}
          aria-label="Switch Theme (Light, Dark, System)"
          title="Select display mode"
        >
          {resolvedTheme === "dark" ? (
            <Moon className="w-4 h-4 text-electric-lime" />
          ) : (
            <Sun className="w-4 h-4 text-royal-violet" />
          )}
          <span className="sr-only">Toggle theme</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-38 p-1.5 rounded-2xl shadow-xl bg-card border border-border">
        <DropdownMenuItem
          onClick={() => setTheme("light")}
          className={`flex items-center justify-between text-xs font-semibold py-2 px-2.5 rounded-xl cursor-pointer ${
            theme === "light" ? "text-royal-violet font-bold bg-muted/60" : "text-foreground"
          }`}
        >
          <span className="flex items-center gap-2">
            <Sun className="w-4 h-4 text-royal-violet" />
            Light Mode
          </span>
          {theme === "light" && <Check className="w-3.5 h-3.5 text-royal-violet" />}
        </DropdownMenuItem>

        <DropdownMenuItem
          onClick={() => setTheme("dark")}
          className={`flex items-center justify-between text-xs font-semibold py-2 px-2.5 rounded-xl cursor-pointer ${
            theme === "dark" ? "text-royal-violet font-bold bg-muted/60" : "text-foreground"
          }`}
        >
          <span className="flex items-center gap-2">
            <Moon className="w-4 h-4 text-electric-lime" />
            Dark Mode
          </span>
          {theme === "dark" && <Check className="w-3.5 h-3.5 text-royal-violet" />}
        </DropdownMenuItem>

        <DropdownMenuItem
          onClick={() => setTheme("system")}
          className={`flex items-center justify-between text-xs font-semibold py-2 px-2.5 rounded-xl cursor-pointer ${
            theme === "system" ? "text-royal-violet font-bold bg-muted/60" : "text-foreground"
          }`}
        >
          <span className="flex items-center gap-2">
            <Laptop className="w-4 h-4 text-muted-foreground" />
            System Auto
          </span>
          {theme === "system" && <Check className="w-3.5 h-3.5 text-royal-violet" />}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}


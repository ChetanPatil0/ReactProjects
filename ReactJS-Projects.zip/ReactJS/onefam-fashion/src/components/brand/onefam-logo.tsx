import React from "react";
import { siteConfig } from "@/config/site";

interface OneFamLogoProps {
  variant?: "auto" | "light" | "dark" | "symbol" | "symbol-dark";
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
}

/**
 * Official OneFam Fashion Brand Identity Logo
 * Uses the authentic WebP assets:
 * - OneFamFashionDarkLogo.webp (Dark/Black full logo for light surfaces)
 * - OneFamFashionWhiteLogo.webp (White full logo for dark surfaces)
 * - OneFamFashionDarkSymbol.webp (1:1 Symbol Emblem)
 */
export function OneFamLogo({
  variant = "auto",
  className = "",
  size = "md",
}: OneFamLogoProps) {
  const isSymbolOnly = variant === "symbol" || variant === "symbol-dark";

  const heightClass = {
    sm: isSymbolOnly ? "h-7 w-7" : "h-7 w-auto",
    md: isSymbolOnly ? "h-9 w-9" : "h-9 w-auto",
    lg: isSymbolOnly ? "h-11 w-11" : "h-11 w-auto",
    xl: isSymbolOnly ? "h-14 w-14" : "h-14 w-auto",
  }[size];

  if (variant === "dark") {
    return (
      <img
        src={siteConfig.images.logo.dark}
        alt={siteConfig.brand.name}
        className={`${heightClass} object-contain shrink-0 select-none ${className}`}
        loading="eager"
      />
    );
  }

  if (variant === "light") {
    return (
      <img
        src={siteConfig.images.logo.light}
        alt={siteConfig.brand.name}
        className={`${heightClass} object-contain shrink-0 select-none ${className}`}
        loading="eager"
      />
    );
  }

  if (variant === "symbol-dark") {
    return (
      <img
        src={siteConfig.images.logo.symbol}
        alt={`${siteConfig.brand.name} Emblem`}
        className={`${heightClass} object-contain shrink-0 select-none brightness-0 invert ${className}`}
        loading="eager"
      />
    );
  }

  if (variant === "symbol") {
    return (
      <div className={`inline-flex shrink-0 select-none ${className}`}>
        <img
          src={siteConfig.images.logo.symbol}
          alt={`${siteConfig.brand.name} Emblem`}
          className={`${heightClass} object-contain block dark:hidden`}
          loading="eager"
        />
        <img
          src={siteConfig.images.logo.symbol}
          alt={`${siteConfig.brand.name} Emblem`}
          className={`${heightClass} object-contain hidden dark:block brightness-0 invert`}
          loading="eager"
        />
      </div>
    );
  }

  // variant === "auto": theme-adaptive using real WebP logo images
  return (
    <div className={`inline-flex items-center shrink-0 select-none ${className}`}>
      {/* Light Theme: dark full logo */}
      <img
        src={siteConfig.images.logo.light}
        alt={siteConfig.brand.name}
        className={`${heightClass} object-contain block dark:hidden`}
        loading="eager"
      />
      {/* Dark Theme: white full logo */}
      <img
        src={siteConfig.images.logo.dark}
        alt={siteConfig.brand.name}
        className={`${heightClass} object-contain hidden dark:block`}
        loading="eager"
      />
    </div>
  );
}

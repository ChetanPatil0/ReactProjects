"use client";

import { useEffect, useState } from "react";
import { OneFamLogo } from "@/components/brand/onefam-logo";

interface BrandLoaderProps {
  fullscreen?: boolean;
  message?: string;
  subtext?: string;
}

const PREMIUM_PHRASES = [
  "Curating Mindful Family Silhouettes",
  "Tailoring With Pure Breathable Natural Fibres",
  "Crafted For Modern Elegance & Everyday Ease",
  "Elegance For Every Generation",
];

export function BrandLoader({
  fullscreen = true,
  message,
  subtext,
}: BrandLoaderProps) {
  const [phraseIndex, setPhraseIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setPhraseIndex((prev) => (prev + 1) % PREMIUM_PHRASES.length);
    }, 2200);
    return () => clearInterval(timer);
  }, []);

  const activeSubtext = subtext || message || PREMIUM_PHRASES[phraseIndex];

  const content = (
    <div className="relative flex flex-col items-center justify-center p-8 text-center select-none">
      {/* Soft Ambient Radial Glow */}
      <div className="absolute -inset-10 bg-radial from-royal-violet/20 via-royal-violet/5 to-transparent rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -top-12 w-48 h-48 bg-[#C6F542]/15 rounded-full blur-3xl pointer-events-none" />

      {/* Official Real Brand Logo - Solid & Crisp (No Fade / No Pulse) */}
      <div className="relative mb-5 flex items-center justify-center">
        <div className="p-3.5 rounded-2xl bg-card border border-border shadow-md backdrop-blur-md flex items-center justify-center">
          <OneFamLogo variant="auto" size="lg" />
        </div>
      </div>

      {/* Animated Subtitle that Cycles */}
      <div className="space-y-3 z-10 max-w-sm">
        <div className="h-6 flex items-center justify-center overflow-hidden">
          <p
            key={phraseIndex}
            className="text-xs font-semibold text-royal-violet dark:text-[#C6F542] tracking-wider animate-in fade-in slide-in-from-bottom-2 duration-500 leading-none"
          >
            {activeSubtext}
          </p>
        </div>

        {/* Sleek Gradient Progress Bar */}
        <div className="w-36 sm:w-44 h-1 bg-muted rounded-full overflow-hidden mx-auto">
          <div className="w-full h-full bg-gradient-to-r from-royal-violet via-[#C6F542] to-royal-violet animate-marquee" />
        </div>
      </div>
    </div>
  );

  if (fullscreen) {
    return (
      <div
        role="status"
        aria-live="polite"
        className="fixed inset-0 z-50 flex items-center justify-center bg-background/85 backdrop-blur-md"
      >
        {content}
      </div>
    );
  }

  return (
    <div role="status" aria-live="polite" className="w-full py-16 flex items-center justify-center">
      {content}
    </div>
  );
}

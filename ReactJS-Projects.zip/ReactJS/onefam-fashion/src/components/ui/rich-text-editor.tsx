"use client";

import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import { useState, useEffect } from "react";
import {
  Bold,
  Italic,
  List,
  ListOrdered,
  Heading1,
  Heading2,
  Heading3,
  Quote,
  Code,
  Undo,
  Redo,
  CodeXml,
  Eye,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  minHeight?: string;
}

export function RichTextEditor({
  value,
  onChange,
  placeholder = "Write atmospheric description or paste HTML...",
  minHeight = "160px",
}: RichTextEditorProps) {
  const [isHtmlMode, setIsHtmlMode] = useState(false);
  const [rawHtml, setRawHtml] = useState(value || "");

  const editor = useEditor({
    extensions: [StarterKit],
    content: value || "",
    immediatelyRender: false,
    editorProps: {
      attributes: {
        class: `prose prose-sm dark:prose-invert max-w-none focus:outline-none p-3 text-xs leading-relaxed`,
        style: `min-height: ${minHeight};`,
      },
    },
    onUpdate: ({ editor }) => {
      const html = editor.getHTML();
      onChange(html);
      setRawHtml(html);
    },
  });

  // Sync value changes if value changes externally
  useEffect(() => {
    if (editor && value !== editor.getHTML() && !isHtmlMode) {
      editor.commands.setContent(value || "");
      setRawHtml(value || "");
    }
  }, [value, editor, isHtmlMode]);

  const handleRawHtmlChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newHtml = e.target.value;
    setRawHtml(newHtml);
    onChange(newHtml);
  };

  const handleToggleMode = () => {
    if (isHtmlMode) {
      // Switching from HTML to Visual
      if (editor) {
        editor.commands.setContent(rawHtml || "");
      }
      setIsHtmlMode(false);
    } else {
      // Switching from Visual to HTML
      if (editor) {
        setRawHtml(editor.getHTML());
      }
      setIsHtmlMode(true);
    }
  };

  const insertHighlightTag = () => {
    if (editor) {
      editor.commands.insertContent('<span class="text-electric-lime font-bold">✨ Highlight</span> ');
    }
  };

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden shadow-2xs">
      {/* Top Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-1 p-1.5 border-b border-border bg-muted/30">
        <div className="flex flex-wrap items-center gap-0.5">
          {!isHtmlMode && editor ? (
            <>
              <button
                type="button"
                onClick={() => editor.chain().focus().toggleBold().run()}
                className={`p-1.5 rounded-lg text-xs transition ${
                  editor.isActive("bold")
                    ? "bg-royal-violet text-white"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                title="Bold"
              >
                <Bold className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => editor.chain().focus().toggleItalic().run()}
                className={`p-1.5 rounded-lg text-xs transition ${
                  editor.isActive("italic")
                    ? "bg-royal-violet text-white"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                title="Italic"
              >
                <Italic className="w-3.5 h-3.5" />
              </button>

              <div className="w-[1px] h-4 bg-border mx-1" />

              <button
                type="button"
                onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
                className={`p-1.5 rounded-lg text-xs transition ${
                  editor.isActive("heading", { level: 1 })
                    ? "bg-royal-violet text-white"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                title="Heading 1"
              >
                <Heading1 className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
                className={`p-1.5 rounded-lg text-xs transition ${
                  editor.isActive("heading", { level: 2 })
                    ? "bg-royal-violet text-white"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                title="Heading 2"
              >
                <Heading2 className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
                className={`p-1.5 rounded-lg text-xs transition ${
                  editor.isActive("heading", { level: 3 })
                    ? "bg-royal-violet text-white"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                title="Heading 3"
              >
                <Heading3 className="w-3.5 h-3.5" />
              </button>

              <div className="w-[1px] h-4 bg-border mx-1" />

              <button
                type="button"
                onClick={() => editor.chain().focus().toggleBulletList().run()}
                className={`p-1.5 rounded-lg text-xs transition ${
                  editor.isActive("bulletList")
                    ? "bg-royal-violet text-white"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                title="Bullet List"
              >
                <List className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => editor.chain().focus().toggleOrderedList().run()}
                className={`p-1.5 rounded-lg text-xs transition ${
                  editor.isActive("orderedList")
                    ? "bg-royal-violet text-white"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                title="Numbered List"
              >
                <ListOrdered className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => editor.chain().focus().toggleBlockquote().run()}
                className={`p-1.5 rounded-lg text-xs transition ${
                  editor.isActive("blockquote")
                    ? "bg-royal-violet text-white"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                title="Quote"
              >
                <Quote className="w-3.5 h-3.5" />
              </button>

              <div className="w-[1px] h-4 bg-border mx-1" />

              <button
                type="button"
                onClick={insertHighlightTag}
                className="px-2 py-1 rounded-lg text-[11px] font-semibold text-royal-violet hover:bg-violet-50 dark:hover:bg-violet-950/30 flex items-center gap-1 transition"
                title="Insert Electric Lime Highlight"
              >
                <Sparkles className="w-3 h-3 text-electric-lime" />
                <span>Highlight</span>
              </button>

              <div className="w-[1px] h-4 bg-border mx-1" />

              <button
                type="button"
                onClick={() => editor.chain().focus().undo().run()}
                disabled={!editor.can().undo()}
                className="p-1.5 rounded-lg text-xs text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-30"
                title="Undo"
              >
                <Undo className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => editor.chain().focus().redo().run()}
                disabled={!editor.can().redo()}
                className="p-1.5 rounded-lg text-xs text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-30"
                title="Redo"
              >
                <Redo className="w-3.5 h-3.5" />
              </button>
            </>
          ) : (
            <div className="flex items-center gap-1.5 px-2 py-0.5 text-xs text-muted-foreground font-mono">
              <CodeXml className="w-3.5 h-3.5 text-royal-violet" />
              <span className="font-semibold text-foreground">HTML Code Mode:</span> Write or paste custom HTML code
            </div>
          )}
        </div>

        {/* Mode Switcher Toggle Button */}
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleToggleMode}
          className="h-7 px-2.5 text-[11px] font-semibold rounded-lg flex items-center gap-1.5 border-royal-violet/30 hover:bg-royal-violet/10 text-royal-violet"
        >
          {isHtmlMode ? (
            <>
              <Eye className="w-3.5 h-3.5" />
              <span>Switch to Visual Editor</span>
            </>
          ) : (
            <>
              <CodeXml className="w-3.5 h-3.5" />
              <span>HTML Source Code</span>
            </>
          )}
        </Button>
      </div>

      {/* Editor Content Area */}
      {isHtmlMode ? (
        <textarea
          value={rawHtml}
          onChange={handleRawHtmlChange}
          placeholder="<p>Enter custom HTML code here...</p>"
          style={{ minHeight }}
          className="w-full p-3 font-mono text-xs leading-relaxed bg-zinc-950 text-emerald-400 focus:outline-none resize-y border-0"
        />
      ) : (
        <EditorContent editor={editor} />
      )}
    </div>
  );
}


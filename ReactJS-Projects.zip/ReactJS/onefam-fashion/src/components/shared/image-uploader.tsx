"use client";

import { useState, useRef, useEffect } from "react";
import { Upload, X, Check, AlertCircle, Loader2, Sparkles, Image as ImageIcon, Crop } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PRODUCT_IMAGE } from "@/lib/constants";
import { ImageSnipperModal } from "@/components/shared/image-snipper-modal";

interface ImageUploaderProps {
  value?: string;
  onChange: (url: string) => void;
  onFileSelect?: (file: File | null) => void;
  label?: string;
  required?: boolean;
}

/**
 * Upload helper called ONLY upon explicit form submission and success.
 * Prevents orphaned files from ever touching disk/storage on form cancellation.
 */
export async function uploadImageFile(file: File): Promise<{
  url: string;
  filename: string;
  sizeBytes: number;
}> {
  const formData = new FormData();
  formData.append("file", file);

  const res = await fetch("/api/uploads", {
    method: "POST",
    body: formData,
  });

  const json = await res.json();
  if (!res.ok || !json.success) {
    throw new Error(json.error || "Failed to upload image.");
  }

  return json.data;
}

export function ImageUploader({
  value,
  onChange,
  onFileSelect,
  label = "Image Upload",
  required = false,
}: ImageUploaderProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(value || null);
  const [selectedFileName, setSelectedFileName] = useState<string | null>(null);
  const [isPendingUpload, setIsPendingUpload] = useState(false);
  const [showUrlFallback, setShowUrlFallback] = useState(false);
  const [isSnipperOpen, setIsSnipperOpen] = useState(false);

  const handleSnippedImage = (croppedFile: File, croppedDataUrl: string) => {
    setPreviewUrl(croppedDataUrl);
    setSelectedFileName(croppedFile.name);
    setIsPendingUpload(true);
    onChange(croppedDataUrl);
    onFileSelect?.(croppedFile);
  };

  useEffect(() => {
    if (value && !isPendingUpload) {
      setPreviewUrl(value);
    }
  }, [value, isPendingUpload]);

  const handleSelectFile = (file: File) => {
    setErrorMessage(null);

    // 1. Format validation
    const allowed = ["image/jpeg", "image/png", "image/webp", "image/jpg"];
    if (!allowed.includes(file.type.toLowerCase())) {
      setErrorMessage("Invalid format. Please select JPEG, PNG, or WebP only.");
      return;
    }

    // 2. Size validation (2MB limit)
    if (file.size > PRODUCT_IMAGE.maxUploadBytes) {
      setErrorMessage(
        `File size (${(file.size / (1024 * 1024)).toFixed(2)} MB) exceeds the 2MB upload limit.`
      );
      return;
    }

    // 3. Local browser preview with zero network traffic (does NOT store on server)
    const localPreview = URL.createObjectURL(file);
    setPreviewUrl(localPreview);
    setSelectedFileName(file.name);
    setIsPendingUpload(true);

    // Notify parent form of selected File and temporary preview
    onChange(localPreview);
    onFileSelect?.(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleSelectFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleSelectFile(file);
    }
  };

  const handleRemove = () => {
    if (previewUrl && previewUrl.startsWith("blob:")) {
      URL.revokeObjectURL(previewUrl);
    }
    setPreviewUrl(null);
    setSelectedFileName(null);
    setIsPendingUpload(false);
    setErrorMessage(null);
    onChange("");
    onFileSelect?.(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center">
          {label}
          {required && <span className="text-vermilion ml-0.5">*</span>}
        </label>
        <button
          type="button"
          onClick={() => {
            setShowUrlFallback(!showUrlFallback);
            setErrorMessage(null);
          }}
          className="text-[11px] font-semibold text-royal-violet hover:underline"
        >
          {showUrlFallback ? "Switch to Local File Picker" : "Enter Direct Image Link"}
        </button>
      </div>

      {showUrlFallback ? (
        <div className="space-y-1">
          <Input
            placeholder="https://images.unsplash.com/photo-..."
            value={value || ""}
            onChange={(e) => {
              setPreviewUrl(e.target.value);
              setIsPendingUpload(false);
              setSelectedFileName(null);
              onFileSelect?.(null);
              onChange(e.target.value);
            }}
            className="h-9 text-xs"
          />
          <p className="text-[10px] text-muted-foreground">
            Provide a direct public HTTPS URL for the image asset.
          </p>
        </div>
      ) : (
        <div>
          {previewUrl ? (
            <div className="relative rounded-xl border border-border overflow-hidden bg-muted aspect-[4/3] max-h-56 w-full flex items-center justify-center group">
              <img
                src={previewUrl}
                alt="Selected preview"
                className="w-full h-full object-cover"
              />

              {/* Status pill for deferred upload */}
              {isPendingUpload && (
                <div className="absolute top-2 left-2 bg-ink/80 dark:bg-black/80 backdrop-blur-md text-white text-[10px] font-semibold px-2.5 py-1 rounded-full flex items-center gap-1.5 shadow-sm border border-white/10">
                  <span className="w-1.5 h-1.5 rounded-full bg-electric-lime animate-pulse" />
                  <span>Staged (Stores on submit)</span>
                </div>
              )}

              {selectedFileName && (
                <div className="absolute bottom-2 left-2 right-12 bg-ink/80 dark:bg-black/80 backdrop-blur-md text-white text-[10px] font-medium px-2 py-0.5 rounded-md truncate">
                  {selectedFileName}
                </div>
              )}

              {/* Snip / Adjust Button */}
              <button
                type="button"
                onClick={() => setIsSnipperOpen(true)}
                className="absolute top-2 right-10 px-2.5 py-1 rounded-full bg-royal-violet text-white text-[11px] font-bold flex items-center gap-1 shadow-md hover:scale-105 hover:bg-royal-violet/90 transition select-none"
                title="Adjust & Crop (Snipping Tool)"
              >
                <Crop className="w-3.5 h-3.5 text-[#C6F542]" />
                <span>Snip / Crop</span>
              </button>

              <button
                type="button"
                onClick={handleRemove}
                className="absolute top-2 right-2 w-7 h-7 rounded-full bg-vermilion text-white flex items-center justify-center shadow-md hover:scale-105 transition"
                title="Remove image"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`p-6 border-2 border-dashed rounded-xl flex flex-col items-center justify-center text-center cursor-pointer transition ${
                errorMessage
                  ? "border-vermilion bg-rose-50/30 dark:bg-rose-950/20"
                  : "border-border hover:border-royal-violet hover:bg-violet-50/20 dark:hover:bg-violet-950/20"
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={handleFileChange}
                className="hidden"
              />
              <div className="w-10 h-10 rounded-full bg-violet-50 dark:bg-royal-violet/20 text-royal-violet flex items-center justify-center mb-2">
                <Upload className="w-5 h-5" />
              </div>
              <p className="text-xs font-bold text-ink dark:text-foreground">
                Click or drag &amp; drop fashion image
              </p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                WebP, PNG, JPEG · Max 2MB · Stored only when form is submitted
              </p>
            </div>
          )}
        </div>
      )}

      {errorMessage && (
        <p className="text-[11px] text-vermilion font-medium flex items-center gap-1 mt-1">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          {errorMessage}
        </p>
      )}

      {/* Snipping & Crop Modal */}
      {previewUrl && (
        <ImageSnipperModal
          isOpen={isSnipperOpen}
          imageUrl={previewUrl}
          originalFileName={selectedFileName || "image.webp"}
          onClose={() => setIsSnipperOpen(false)}
          onApplyCrop={handleSnippedImage}
        />
      )}
    </div>
  );
}

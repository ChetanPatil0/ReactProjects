"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Crop,
  RotateCw,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Check,
  RotateCcw,
  Sparkles,
} from "lucide-react";

interface ImageSnipperModalProps {
  isOpen: boolean;
  imageUrl: string;
  originalFileName?: string;
  onClose: () => void;
  onApplyCrop: (croppedFile: File, croppedDataUrl: string) => void;
}

type AspectRatioPreset = "free" | "1:1" | "4:5" | "16:9";

export function ImageSnipperModal({
  isOpen,
  imageUrl,
  originalFileName = "snipped-image.webp",
  onClose,
  onApplyCrop,
}: ImageSnipperModalProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);

  const [zoom, setZoom] = useState<number>(1);
  const [rotation, setRotation] = useState<number>(0);
  const [aspectPreset, setAspectPreset] = useState<AspectRatioPreset>("free");

  // Normalized crop rectangle: percentages (0 - 100)
  const [cropRect, setCropRect] = useState({ x: 10, y: 10, width: 80, height: 80 });

  // Dragging state
  const isDraggingRef = useRef(false);
  const dragHandleRef = useRef<string | null>(null); // 'move' or handle name e.g. 'se', 'nw'
  const dragStartPosRef = useRef({ x: 0, y: 0 });
  const startCropRectRef = useRef({ x: 10, y: 10, width: 80, height: 80 });

  // Reset state when opening new image
  useEffect(() => {
    if (isOpen) {
      setZoom(1);
      setRotation(0);
      setAspectPreset("free");
      setCropRect({ x: 10, y: 10, width: 80, height: 80 });
    }
  }, [isOpen, imageUrl]);

  // Handle Preset changes
  const applyPreset = useCallback(
    (preset: AspectRatioPreset) => {
      setAspectPreset(preset);
      if (preset === "1:1") {
        setCropRect({ x: 15, y: 15, width: 70, height: 70 });
      } else if (preset === "4:5") {
        setCropRect({ x: 18, y: 10, width: 64, height: 80 });
      } else if (preset === "16:9") {
        setCropRect({ x: 10, y: 27, width: 80, height: 45 });
      }
    },
    []
  );

  // Mouse / Pointer Down for Dragging / Resizing
  const handlePointerDown = (e: React.PointerEvent, handle: string) => {
    e.preventDefault();
    e.stopPropagation();
    isDraggingRef.current = true;
    dragHandleRef.current = handle;
    dragStartPosRef.current = { x: e.clientX, y: e.clientY };
    startCropRectRef.current = { ...cropRect };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  // Pointer Move
  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDraggingRef.current || !containerRef.current) return;

    const bounds = containerRef.current.getBoundingClientRect();
    const dxPercent = ((e.clientX - dragStartPosRef.current.x) / bounds.width) * 100;
    const dyPercent = ((e.clientY - dragStartPosRef.current.y) / bounds.height) * 100;

    const start = startCropRectRef.current;
    let nextX = start.x;
    let nextY = start.y;
    let nextW = start.width;
    let nextH = start.height;

    const handle = dragHandleRef.current;

    if (handle === "move") {
      nextX = Math.min(Math.max(0, start.x + dxPercent), 100 - start.width);
      nextY = Math.min(Math.max(0, start.y + dyPercent), 100 - start.height);
    } else if (handle === "se") {
      nextW = Math.max(10, Math.min(100 - start.x, start.width + dxPercent));
      nextH = Math.max(10, Math.min(100 - start.y, start.height + dyPercent));
    } else if (handle === "nw") {
      const rawW = start.width - dxPercent;
      const rawH = start.height - dyPercent;
      if (rawW >= 10 && start.x + dxPercent >= 0) {
        nextX = start.x + dxPercent;
        nextW = rawW;
      }
      if (rawH >= 10 && start.y + dyPercent >= 0) {
        nextY = start.y + dyPercent;
        nextH = rawH;
      }
    } else if (handle === "ne") {
      nextW = Math.max(10, Math.min(100 - start.x, start.width + dxPercent));
      const rawH = start.height - dyPercent;
      if (rawH >= 10 && start.y + dyPercent >= 0) {
        nextY = start.y + dyPercent;
        nextH = rawH;
      }
    } else if (handle === "sw") {
      const rawW = start.width - dxPercent;
      if (rawW >= 10 && start.x + dxPercent >= 0) {
        nextX = start.x + dxPercent;
        nextW = rawW;
      }
      nextH = Math.max(10, Math.min(100 - start.y, start.height + dyPercent));
    }

    setCropRect({
      x: Math.round(nextX * 10) / 10,
      y: Math.round(nextY * 10) / 10,
      width: Math.round(nextW * 10) / 10,
      height: Math.round(nextH * 10) / 10,
    });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    isDraggingRef.current = false;
    dragHandleRef.current = null;
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  // Perform Final Crop on Native Offscreen Canvas
  const handleApply = async () => {
    const img = imageRef.current;
    if (!img) return;

    // Load full-resolution image to draw from
    const naturalWidth = img.naturalWidth || img.width;
    const naturalHeight = img.naturalHeight || img.height;

    // Canvas for rotation and zoom
    const offscreenCanvas = document.createElement("canvas");
    const ctx = offscreenCanvas.getContext("2d");
    if (!ctx) return;

    // Calculate crop coordinates relative to natural image dimensions
    const cropPixelX = (cropRect.x / 100) * naturalWidth;
    const cropPixelY = (cropRect.y / 100) * naturalHeight;
    const cropPixelW = (cropRect.width / 100) * naturalWidth;
    const cropPixelH = (cropRect.height / 100) * naturalHeight;

    offscreenCanvas.width = Math.max(10, Math.round(cropPixelW));
    offscreenCanvas.height = Math.max(10, Math.round(cropPixelH));

    ctx.save();
    // Rotate canvas around center if rotated
    if (rotation !== 0) {
      ctx.translate(offscreenCanvas.width / 2, offscreenCanvas.height / 2);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.translate(-offscreenCanvas.width / 2, -offscreenCanvas.height / 2);
    }

    ctx.drawImage(
      img,
      cropPixelX,
      cropPixelY,
      cropPixelW,
      cropPixelH,
      0,
      0,
      offscreenCanvas.width,
      offscreenCanvas.height
    );
    ctx.restore();

    offscreenCanvas.toBlob(
      (blob) => {
        if (!blob) return;
        const newFileName = originalFileName.replace(/\.[^/.]+$/, "") + "-snipped.webp";
        const croppedFile = new File([blob], newFileName, { type: "image/webp" });
        const croppedDataUrl = offscreenCanvas.toDataURL("image/webp", 0.92);
        onApplyCrop(croppedFile, croppedDataUrl);
        onClose();
      },
      "image/webp",
      0.92
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl bg-card border-border p-6 rounded-2xl shadow-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base font-bold text-foreground">
            <Crop className="w-5 h-5 text-royal-violet" />
            <span>Image Snipping &amp; Adjustment Tool</span>
          </DialogTitle>
        </DialogHeader>

        {/* Toolbar Controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 py-2 border-b border-border text-xs">
          {/* Preset Buttons */}
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-muted-foreground mr-1">Aspect:</span>
            {(["free", "1:1", "4:5", "16:9"] as AspectRatioPreset[]).map((preset) => (
              <Button
                key={preset}
                type="button"
                variant={aspectPreset === preset ? "default" : "outline"}
                size="sm"
                onClick={() => applyPreset(preset)}
                className={`h-7 px-2.5 text-[11px] font-bold rounded-lg ${
                  aspectPreset === preset
                    ? "bg-royal-violet hover:bg-royal-violet/90 text-white"
                    : ""
                }`}
              >
                {preset === "free" ? "Freeform" : preset}
              </Button>
            ))}
          </div>

          {/* Rotation & Zoom Controls */}
          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setRotation((prev) => (prev + 90) % 360)}
              className="h-7 px-2 gap-1 text-[11px]"
              title="Rotate 90 degrees"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Rotate {rotation}°</span>
            </Button>

            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => {
                setZoom(1);
                setRotation(0);
                setCropRect({ x: 10, y: 10, width: 80, height: 80 });
              }}
              className="h-7 px-2 text-[11px]"
              title="Reset all adjustments"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>

        {/* Main Canvas / Image Snipping Area */}
        <div
          ref={containerRef}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="relative w-full h-[340px] sm:h-[400px] bg-black/90 rounded-xl overflow-hidden flex items-center justify-center select-none touch-none border border-border"
        >
          {/* Underlying Image */}
          <img
            ref={imageRef}
            src={imageUrl}
            alt="To adjust"
            crossOrigin="anonymous"
            style={{
              transform: `scale(${zoom}) rotate(${rotation}deg)`,
              transition: "transform 0.15s ease-out",
            }}
            className="max-w-full max-h-full object-contain pointer-events-none select-none"
          />

          {/* Dimmed Overlay outside the Snipping Box */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: `rgba(0, 0, 0, 0.55)`,
              clipPath: `polygon(
                0% 0%, 0% 100%, 100% 100%, 100% 0%, 0% 0%,
                ${cropRect.x}% ${cropRect.y}%,
                ${cropRect.x + cropRect.width}% ${cropRect.y}%,
                ${cropRect.x + cropRect.width}% ${cropRect.y + cropRect.height}%,
                ${cropRect.x}% ${cropRect.y + cropRect.height}%,
                ${cropRect.x}% ${cropRect.y}%
              )`,
            }}
          />

          {/* Interactive Snipping Box */}
          <div
            onPointerDown={(e) => handlePointerDown(e, "move")}
            style={{
              left: `${cropRect.x}%`,
              top: `${cropRect.y}%`,
              width: `${cropRect.width}%`,
              height: `${cropRect.height}%`,
            }}
            className="absolute border-2 border-dashed border-[#C6F542] shadow-[0_0_0_1px_rgba(0,0,0,0.5)] cursor-move transition-shadow"
          >
            {/* Rule-of-Thirds Grid Lines */}
            <div className="absolute inset-0 pointer-events-none grid grid-cols-3 grid-rows-3 opacity-30">
              <div className="border-r border-b border-white" />
              <div className="border-r border-b border-white" />
              <div className="border-b border-white" />
              <div className="border-r border-b border-white" />
              <div className="border-r border-b border-white" />
              <div className="border-b border-white" />
              <div className="border-r border-white" />
              <div className="border-r border-white" />
              <div />
            </div>

            {/* Corner Resize Handles */}
            <div
              onPointerDown={(e) => handlePointerDown(e, "nw")}
              className="absolute -top-2 -left-2 w-4 h-4 bg-royal-violet border-2 border-white rounded-full cursor-nwse-resize shadow-md hover:scale-125 transition-transform"
            />
            <div
              onPointerDown={(e) => handlePointerDown(e, "ne")}
              className="absolute -top-2 -right-2 w-4 h-4 bg-royal-violet border-2 border-white rounded-full cursor-nesw-resize shadow-md hover:scale-125 transition-transform"
            />
            <div
              onPointerDown={(e) => handlePointerDown(e, "sw")}
              className="absolute -bottom-2 -left-2 w-4 h-4 bg-royal-violet border-2 border-white rounded-full cursor-nesw-resize shadow-md hover:scale-125 transition-transform"
            />
            <div
              onPointerDown={(e) => handlePointerDown(e, "se")}
              className="absolute -bottom-2 -right-2 w-4 h-4 bg-[#C6F542] border-2 border-[#191720] rounded-full cursor-nwse-resize shadow-md hover:scale-125 transition-transform"
            />
          </div>
        </div>

        {/* Zoom Slider */}
        <div className="flex items-center gap-3 pt-2 text-xs">
          <ZoomOut className="w-4 h-4 text-muted-foreground" />
          <input
            type="range"
            value={zoom}
            min={0.8}
            max={2.5}
            step={0.05}
            onChange={(e) => setZoom(parseFloat(e.target.value))}
            className="flex-1 accent-royal-violet cursor-pointer h-1.5 bg-muted rounded-lg"
          />
          <ZoomIn className="w-4 h-4 text-muted-foreground" />
          <span className="w-12 text-right font-mono text-[11px] text-muted-foreground">
            {Math.round(zoom * 100)}%
          </span>
        </div>

        <DialogFooter className="flex items-center justify-between sm:justify-between pt-2 border-t border-border">
          <p className="text-[11px] text-muted-foreground">
            Drag the frame to position, pull corners to resize, or choose an aspect preset.
          </p>
          <div className="flex items-center gap-2">
            <Button type="button" variant="outline" size="sm" onClick={onClose} className="text-xs">
              Cancel
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={handleApply}
              className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold text-xs gap-1.5"
            >
              <Check className="w-3.5 h-3.5 text-[#C6F542]" />
              <span>Apply Snipping</span>
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

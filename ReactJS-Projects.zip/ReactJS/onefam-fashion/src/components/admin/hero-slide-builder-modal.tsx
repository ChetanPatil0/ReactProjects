"use client";

import { useState, useEffect, useMemo } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ImageUploader, uploadImageFile } from "@/components/shared/image-uploader";
import {
  CodeXml,
  Monitor,
  Tablet,
  Smartphone,
  Loader2,
  Check,
  AlertCircle,
  Sparkles,
  Copy,
  RotateCcw,
  Sliders,
  Eye,
  Plus,
} from "lucide-react";
import { toast } from "sonner";

interface HeroSlideBuilderModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  slide?: any | null; // If passed, edit mode; otherwise, create mode
  onSave: (slideData: any) => Promise<void>;
}

// Default OneFam Fashion brand HTML starter templates with heading, description, and CTA button with icon
export const HTML_TEMPLATES = {
  default: `<div class="space-y-4 max-w-xl">
  <!-- Accent Category / Collection Pill with SVG Icon -->
  <span class="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-[#191720]/80 text-[#C6F542] border border-[#C6F542]/30 backdrop-blur-md">
    <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
    New Season · 2026 Edition
  </span>

  <!-- Main Slide Heading with Electric Lime accent -->
  <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black text-[#FCFAF4] tracking-tight leading-[1.08]">
    Architectural Silhouettes &amp; <span class="text-[#C6F542]">Pure Linen</span>
  </h1>

  <!-- Slide Description -->
  <p class="text-xs sm:text-sm md:text-base text-[#FCFAF4]/90 leading-relaxed max-w-lg">
    Curated ready-to-wear tailored with breathable natural fabrics. Order directly on WhatsApp with complimentary doorstep delivery.
  </p>

  <!-- CTA Buttons with icons -->
  <div class="pt-2 flex flex-wrap items-center gap-3">
    <a href="/collections/new-arrivals" class="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-[#7137C8] hover:bg-[#7137C8]/90 text-white font-bold text-xs shadow-lg transition">
      <span>Explore Collection</span>
      <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
    </a>
    <a href="/offers" class="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/40 text-white hover:bg-white/10 font-semibold text-xs backdrop-blur-xs transition">
      View Offers
    </a>
  </div>
</div>`,
};

export const DEFAULT_SLIDE_HTML = HTML_TEMPLATES.default;

export function HeroSlideBuilderModal({
  open,
  onOpenChange,
  slide,
  onSave,
}: HeroSlideBuilderModalProps) {
  const isEditing = Boolean(slide?.id);

  // Simplified Form State: Title, Image, Sort Order, HTML Content, Active
  const [title, setTitle] = useState("");
  const [sortOrder, setSortOrder] = useState<number>(1);
  const [htmlContent, setHtmlContent] = useState("");
  const [desktopImage, setDesktopImage] = useState("");
  const [desktopImageFile, setDesktopImageFile] = useState<File | null>(null);
  const [isActive, setIsActive] = useState(true);

  // Bottom Live Preview Device Mode: Desktop (16:9), Tablet (4:3), Mobile (9:16)
  const [previewDevice, setPreviewDevice] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Local object URL for staged image file preview (so live preview updates instantly when user selects a file)
  const previewImageUrl = useMemo(() => {
    if (desktopImageFile) {
      return URL.createObjectURL(desktopImageFile);
    }
    return desktopImage;
  }, [desktopImageFile, desktopImage]);

  // Clean up object URL when component unmounts or file changes
  useEffect(() => {
    return () => {
      if (desktopImageFile && previewImageUrl.startsWith("blob:")) {
        URL.revokeObjectURL(previewImageUrl);
      }
    };
  }, [desktopImageFile, previewImageUrl]);

  // Reset or Populate form
  useEffect(() => {
    if (slide && open) {
      setTitle(slide.title || "");
      setSortOrder(typeof slide.sortOrder === "number" ? slide.sortOrder : 1);
      // If slide has HTML description, use it; otherwise generate HTML or use default
      if (slide.description && slide.description.includes("<")) {
        setHtmlContent(slide.description);
      } else if (slide.title) {
        setHtmlContent(
          `<div class="space-y-4 max-w-xl">\n` +
          `  <h1 class="text-3xl sm:text-5xl font-black text-[#FCFAF4] mb-3">${slide.title}</h1>\n` +
          (slide.subtitle ? `  <p class="text-xs uppercase tracking-widest text-[#C6F542] font-bold mb-3">${slide.subtitle}</p>\n` : "") +
          (slide.description ? `  <p class="text-sm text-[#FCFAF4]/80 max-w-lg mb-5">${slide.description}</p>\n` : "") +
          (slide.primaryCtaText ? `  <a href="${slide.primaryCtaUrl || "/men"}" class="inline-block px-7 py-3 rounded-full bg-[#7137C8] text-white font-bold text-xs">${slide.primaryCtaText}</a>\n` : "") +
          `</div>`
        );
      } else {
        setHtmlContent(DEFAULT_SLIDE_HTML);
      }
      setDesktopImage(slide.desktopImage || "");
      setDesktopImageFile(null);
      setIsActive(slide.isActive !== false);
      setErrors({});
    } else if (!slide && open) {
      setTitle("");
      setSortOrder(1);
      setHtmlContent(DEFAULT_SLIDE_HTML);
      setDesktopImage("");
      setDesktopImageFile(null);
      setIsActive(true);
      setErrors({});
    }
  }, [slide, open]);

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!title.trim()) errs.title = "Please provide an internal slide reference name.";
    if (!desktopImage.trim() && !desktopImageFile) {
      errs.desktopImage = "Background image is required.";
    }
    if (!htmlContent.trim()) {
      errs.htmlContent = "HTML content is required to render the slide.";
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      return;
    }

    setIsSubmitting(true);
    try {
      let finalImage = desktopImage;

      // Staged file upload through our system only when user submits
      if (desktopImageFile) {
        const uploadRes = await uploadImageFile(desktopImageFile);
        finalImage = uploadRes.url;
      }

      await onSave({
        title: title.trim(),
        description: htmlContent.trim(), // Storing raw HTML markup
        desktopImage: finalImage.trim(),
        mobileImage: finalImage.trim(),
        sortOrder: Number(sortOrder) || 1,
        isActive,
      });

      onOpenChange(false);
    } catch (err: any) {
      toast.error(err.message || "Failed to save hero slide.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetToDefaultTemplate = () => {
    setHtmlContent(DEFAULT_SLIDE_HTML);
    toast.success("Loaded default reference HTML template");
  };

  const handleInsertSnippet = (snippet: string, label: string) => {
    setHtmlContent((prev) => `${prev.trim()}\n\n${snippet}`);
    toast.success(`Inserted ${label}`);
  };

  const handleCopyCode = () => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(htmlContent);
      toast.success("HTML code copied to clipboard");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[92vh] flex flex-col p-0 gap-0 overflow-hidden bg-card border-border">
        {/* Top Header */}
        <DialogHeader className="p-5 pb-4 border-b border-border bg-muted/20 shrink-0">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <DialogTitle className="text-lg font-black text-foreground flex items-center gap-2">
                <CodeXml className="w-5 h-5 text-royal-violet" />
                {isEditing ? "Edit HTML Hero Slide" : "Create HTML Hero Slide"}
              </DialogTitle>
              <DialogDescription className="text-xs mt-0.5">
                Full-control slide editor: upload background image, write raw HTML/CSS &amp; preview live on Desktop, Tablet, and Mobile below.
              </DialogDescription>
            </div>

            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleResetToDefaultTemplate}
                className="h-8 text-xs font-semibold rounded-lg flex items-center gap-1.5 hover:border-royal-violet hover:text-royal-violet"
                title="Reset editor to official default reference template"
              >
                <RotateCcw className="w-3.5 h-3.5 text-royal-violet" />
                <span>Default Template</span>
              </Button>
            </div>
          </div>
        </DialogHeader>

        {/* Scrollable Container (Form on Top, Live Preview on Bottom) */}
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          <form id="hero-slide-code-form" onSubmit={handleSubmit} className="space-y-6">
            {/* Top Grid: Slide Name, Sort Order, Active Status */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Slide Reference Name */}
              <div className="sm:col-span-2">
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                  Slide Reference Name <span className="text-vermilion">*</span>
                </label>
                <Input
                  placeholder="e.g. Summer Linen Atelier 2026"
                  value={title}
                  onChange={(e) => {
                    setTitle(e.target.value);
                    if (e.target.value.trim()) {
                      setErrors((prev) => {
                        const c = { ...prev };
                        delete c.title;
                        return c;
                      });
                    }
                  }}
                  className={`h-10 text-xs font-semibold ${errors.title ? "border-vermilion" : ""}`}
                />
                {errors.title && (
                  <p className="text-[11px] text-vermilion font-medium mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {errors.title}
                  </p>
                )}
              </div>

              {/* Sort Order & Active Status */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                    Sort Order
                  </label>
                  <Input
                    type="number"
                    min={1}
                    value={sortOrder}
                    onChange={(e) => setSortOrder(Number(e.target.value) || 1)}
                    className="h-10 text-xs font-semibold text-center"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                    Status
                  </label>
                  <Button
                    type="button"
                    variant={isActive ? "default" : "outline"}
                    size="sm"
                    onClick={() => setIsActive(!isActive)}
                    className={`w-full h-10 text-xs font-bold rounded-md ${
                      isActive
                        ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                        : "text-muted-foreground"
                    }`}
                  >
                    {isActive ? "Active" : "Hidden"}
                  </Button>
                </div>
              </div>
            </div>

            {/* Background Hero Image Upload via System */}
            <div className="p-4 rounded-xl border border-border bg-muted/15 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-foreground">
                  Background Hero Image <span className="text-vermilion">*</span>
                </span>
                <span className="text-[11px] text-muted-foreground">
                  Uploaded through system · high-res 16:9 fashion imagery
                </span>
              </div>

              <ImageUploader
                value={desktopImage}
                onChange={setDesktopImage}
                onFileSelect={setDesktopImageFile}
                label="Slide Background Photo"
                required={true}
              />
              {errors.desktopImage && (
                <p className="text-[11px] text-vermilion font-medium mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {errors.desktopImage}
                </p>
              )}
            </div>

            {/* Pure HTML & CSS Code Editor */}
            <div className="space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                  <CodeXml className="w-4 h-4 text-royal-violet" />
                  <span>HTML &amp; CSS Code Editor (Full Control Over Design &amp; Icons)</span>
                </label>

                {/* Helper Insert Snippets */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[11px] text-muted-foreground mr-1">Insert Snippet:</span>
                  <button
                    type="button"
                    onClick={() =>
                      handleInsertSnippet(
                        `<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold uppercase bg-[#191720]/80 text-[#C6F542] border border-[#C6F542]/30">\n  ★ Highlight Badge\n</span>`,
                        "Accent Badge"
                      )
                    }
                    className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-muted hover:bg-muted/80 text-foreground border border-border"
                  >
                    + Lime Badge
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      handleInsertSnippet(
                        `<a href="/men" class="inline-flex items-center gap-2 px-7 py-3 rounded-full bg-[#7137C8] hover:bg-[#7137C8]/90 text-white font-bold text-xs shadow-md transition">\n  Shop Now →\n</a>`,
                        "Violet Button"
                      )
                    }
                    className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-muted hover:bg-muted/80 text-foreground border border-border"
                  >
                    + CTA Button
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      handleInsertSnippet(
                        `<svg class="w-4 h-4 text-[#C6F542]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>`,
                        "SVG Star Icon"
                      )
                    }
                    className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-muted hover:bg-muted/80 text-foreground border border-border"
                  >
                    + SVG Icon
                  </button>
                  <button
                    type="button"
                    onClick={handleCopyCode}
                    className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-muted hover:bg-muted/80 text-foreground border border-border flex items-center gap-1"
                    title="Copy current HTML code"
                  >
                    <Copy className="w-3 h-3" />
                    <span>Copy</span>
                  </button>
                </div>
              </div>

              {/* Code Textarea */}
              <div className="rounded-xl border border-border overflow-hidden shadow-2xs">
                <div className="bg-[#191720] px-3.5 py-1.5 border-b border-border/40 flex items-center justify-between text-[11px] text-[#FCFAF4]/70 font-mono">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#7137C8]" />
                    <span>slide-overlay.html</span>
                  </span>
                  <span>Direct HTML with Tailwind &amp; CSS support</span>
                </div>
                <textarea
                  rows={10}
                  value={htmlContent}
                  onChange={(e) => {
                    setHtmlContent(e.target.value);
                    if (e.target.value.trim()) {
                      setErrors((prev) => {
                        const c = { ...prev };
                        delete c.htmlContent;
                        return c;
                      });
                    }
                  }}
                  placeholder="Enter HTML markup with inline CSS or Tailwind classes..."
                  className="w-full p-4 font-mono text-xs sm:text-sm leading-relaxed bg-[#121118] text-[#E6E1E5] focus:outline-none resize-y border-0 selection:bg-royal-violet selection:text-white"
                />
              </div>
              {errors.htmlContent && (
                <p className="text-[11px] text-vermilion font-medium mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {errors.htmlContent}
                </p>
              )}
            </div>
          </form>

          {/* ========================================================================= */}
          {/* LIVE PREVIEW SECTION (PLACED AT THE BOTTOM, NOT ON THE ROW) */}
          {/* ========================================================================= */}
          <div className="pt-4 border-t-2 border-border/80 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-black text-foreground flex items-center gap-2">
                  <Eye className="w-4 h-4 text-royal-violet" />
                  <span>Live Storefront Preview (Bottom Preview)</span>
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Real-time render of your background photo + custom HTML overlay. Switch viewports below to inspect responsiveness.
                </p>
              </div>

              {/* Responsive Device Viewport Switcher Tabs */}
              <div className="flex items-center p-1 rounded-xl bg-muted border border-border self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => setPreviewDevice("desktop")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    previewDevice === "desktop"
                      ? "bg-card text-foreground shadow-xs border border-border/80"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5 text-royal-violet" />
                  <span>Desktop (16:9)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPreviewDevice("tablet")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    previewDevice === "tablet"
                      ? "bg-card text-foreground shadow-xs border border-border/80"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Tablet className="w-3.5 h-3.5 text-royal-violet" />
                  <span>Tablet (4:3)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPreviewDevice("mobile")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    previewDevice === "mobile"
                      ? "bg-card text-foreground shadow-xs border border-border/80"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5 text-royal-violet" />
                  <span>Mobile (9:16)</span>
                </button>
              </div>
            </div>

            {/* The Live Interactive Hero Slide Canvas */}
            <div className="flex justify-center bg-[#0B0A0F] p-4 sm:p-8 rounded-2xl border border-border/80 overflow-hidden shadow-inner">
              <div
                className={`relative overflow-hidden rounded-2xl shadow-2xl transition-all duration-300 border border-white/10 ${
                  previewDevice === "desktop"
                    ? "w-full aspect-[16/9] min-h-[380px] max-h-[520px]"
                    : previewDevice === "tablet"
                    ? "w-full max-w-[640px] aspect-[4/3] min-h-[440px]"
                    : "w-[340px] aspect-[9/16] min-h-[540px]"
                }`}
                style={{ backgroundColor: "#15131C" }}
              >
                {/* Background Hero Image Asset */}
                {previewImageUrl ? (
                  <img
                    src={previewImageUrl}
                    alt={title || "Slide Preview"}
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-white/40 text-xs gap-2 p-6 text-center">
                    <Sparkles className="w-8 h-8 text-royal-violet/50" />
                    <span>Upload a background hero photo above to see the full composition</span>
                  </div>
                )}

                {/* Dark Vignette Overlay Matching Storefront */}
                <div className="absolute inset-0 bg-gradient-to-r from-[#15131C]/95 via-[#15131C]/65 to-transparent pointer-events-none" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#15131C]/80 via-transparent to-transparent pointer-events-none" />

                {/* Rendered Custom HTML Overlay */}
                <div className="relative h-full p-6 sm:p-10 md:p-12 flex flex-col justify-center text-[#FCFAF4] max-w-2xl overflow-y-auto">
                  {htmlContent ? (
                    <div
                      className="hero-html-preview leading-normal"
                      dangerouslySetInnerHTML={{ __html: htmlContent }}
                    />
                  ) : (
                    <p className="text-white/40 text-xs italic">
                      Type HTML markup in the editor above to view the live preview...
                    </p>
                  )}
                </div>

                {/* Viewport Dimension Indicator Badge */}
                <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded-full bg-black/75 backdrop-blur-md text-[10px] font-mono text-white/70 border border-white/10 pointer-events-none">
                  {previewDevice === "desktop"
                    ? "Desktop 16:9 Canvas"
                    : previewDevice === "tablet"
                    ? "Tablet 4:3 Viewport"
                    : "Mobile 9:16 Portrait"}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Sticky Actions */}
        <div className="p-4 px-6 border-t border-border bg-muted/20 flex items-center justify-between shrink-0">
          <div className="text-xs text-muted-foreground">
            {isActive ? (
              <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Will be published as Active slide
              </span>
            ) : (
              <span className="text-muted-foreground flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-zinc-400" />
                Will be saved as Hidden slide
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>

            <Button
              type="submit"
              form="hero-slide-code-form"
              disabled={isSubmitting}
              className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold text-xs shadow-md"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                  <span>Saving Slide...</span>
                </>
              ) : (
                <>
                  <Check className="w-3.5 h-3.5 mr-1.5" />
                  <span>{isEditing ? "Update Slide" : "Save & Publish Slide"}</span>
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

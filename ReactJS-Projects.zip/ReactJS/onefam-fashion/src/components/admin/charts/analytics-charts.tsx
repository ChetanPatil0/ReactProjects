"use client";

import { useState } from "react";
import { formatCurrency } from "@/lib/formatters";
import { TrendingUp, ShoppingBag, CreditCard, Award } from "lucide-react";

interface RevenueTrendPoint {
  date: string;
  label: string;
  revenue: number;
  orders: number;
}

interface StatusBreakdownItem {
  status: string;
  label: string;
  count: number;
  percentage: number;
}

interface PaymentMethodItem {
  method: string;
  label: string;
  count: number;
  amount: number;
  percentage: number;
}

interface TopProductItem {
  name: string;
  sku: string;
  unitsSold: number;
  revenue: number;
}

/**
 * Interactive SVG Area / Line Chart for Revenue Trends
 */
export function RevenueTrendChart({
  data,
  title = "Revenue & Sales Trend",
  subtitle = "Daily gross turnover and order volume",
}: {
  data: RevenueTrendPoint[];
  title?: string;
  subtitle?: string;
}) {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div className="p-8 text-center text-xs text-muted-foreground bg-card rounded-2xl border border-border">
        No sales transaction data recorded for this period.
      </div>
    );
  }

  const maxRevenue = Math.max(...data.map((d) => d.revenue), 1000);
  const totalPeriodRevenue = data.reduce((sum, d) => sum + d.revenue, 0);
  const totalPeriodOrders = data.reduce((sum, d) => sum + d.orders, 0);

  // SVG dimensions
  const width = 700;
  const height = 240;
  const paddingX = 40;
  const paddingTop = 20;
  const paddingBottom = 40;
  const chartWidth = width - paddingX * 2;
  const chartHeight = height - paddingTop - paddingBottom;

  const points = data.map((d, i) => {
    const x = paddingX + (i / Math.max(data.length - 1, 1)) * chartWidth;
    const y = paddingTop + chartHeight - (d.revenue / maxRevenue) * chartHeight;
    return { x, y, ...d };
  });

  const linePath = points.reduce((acc, p, i) => {
    return i === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`;
  }, "");

  const areaPath = `${linePath} L ${points[points.length - 1].x} ${
    paddingTop + chartHeight
  } L ${points[0].x} ${paddingTop + chartHeight} Z`;

  const activePoint = hoveredIdx !== null ? points[hoveredIdx] : null;

  return (
    <div className="p-6 bg-card rounded-2xl border border-border shadow-2xs space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-border/70">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-royal-violet dark:text-[#C6F542]" />
            <h3 className="font-bold text-sm text-foreground">{title}</h3>
          </div>
          <p className="text-[11px] text-muted-foreground mt-0.5">{subtitle}</p>
        </div>

        <div className="flex items-center gap-4 text-xs">
          <div className="text-right">
            <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">
              Period Turnover
            </span>
            <span className="font-black text-sm text-foreground">
              {formatCurrency(totalPeriodRevenue)}
            </span>
          </div>
          <div className="text-right border-l border-border pl-4">
            <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">
              Total Orders
            </span>
            <span className="font-black text-sm text-royal-violet dark:text-[#C6F542]">
              {totalPeriodOrders}
            </span>
          </div>
        </div>
      </div>

      {/* SVG Canvas */}
      <div className="relative w-full overflow-hidden">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto overflow-visible select-none"
        >
          <defs>
            <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#7137C8" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#7137C8" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines (horizontal) */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
            const y = paddingTop + chartHeight * (1 - ratio);
            const val = Math.round(maxRevenue * ratio);
            return (
              <g key={ratio}>
                <line
                  x1={paddingX}
                  y1={y}
                  x2={width - paddingX}
                  y2={y}
                  stroke="currentColor"
                  strokeOpacity="0.1"
                  strokeDasharray="4 4"
                />
                <text
                  x={paddingX - 8}
                  y={y + 4}
                  textAnchor="end"
                  fontSize="9"
                  fill="currentColor"
                  opacity="0.5"
                  className="font-mono"
                >
                  ₹{val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val}
                </text>
              </g>
            );
          })}

          {/* Area Fill */}
          <path d={areaPath} fill="url(#revenueGradient)" />

          {/* Line Stroke */}
          <path
            d={linePath}
            fill="none"
            stroke="#7137C8"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Data Points */}
          {points.map((p, idx) => {
            const isHovered = hoveredIdx === idx;
            return (
              <g key={idx} className="cursor-pointer" onMouseEnter={() => setHoveredIdx(idx)}>
                <circle
                  cx={p.x}
                  cy={p.y}
                  r={isHovered ? 6 : 3.5}
                  fill={isHovered ? "#C6F542" : "#7137C8"}
                  stroke="white"
                  strokeWidth={isHovered ? 2.5 : 1.5}
                  className="transition-all duration-150"
                />
                {/* Invisible hover target */}
                <rect
                  x={p.x - 15}
                  y={paddingTop}
                  width="30"
                  height={chartHeight}
                  fill="transparent"
                  onMouseEnter={() => setHoveredIdx(idx)}
                />
              </g>
            );
          })}

          {/* X Axis Labels */}
          {points
            .filter((_, idx) => {
              if (points.length <= 7) return true;
              if (points.length <= 15) return idx % 2 === 0;
              return idx % 4 === 0 || idx === points.length - 1;
            })
            .map((p, idx) => (
              <text
                key={idx}
                x={p.x}
                y={height - 12}
                textAnchor="middle"
                fontSize="10"
                fill="currentColor"
                opacity="0.6"
                className="font-medium"
              >
                {p.label}
              </text>
            ))}

          {/* Active Hover Guide Line */}
          {activePoint && (
            <line
              x1={activePoint.x}
              y1={paddingTop}
              x2={activePoint.x}
              y2={paddingTop + chartHeight}
              stroke="#7137C8"
              strokeWidth="1.5"
              strokeDasharray="3 3"
              opacity="0.7"
            />
          )}
        </svg>

        {/* Floating Tooltip */}
        {activePoint && (
          <div
            className="absolute pointer-events-none transform -translate-x-1/2 -translate-y-full bg-foreground text-background text-xs px-3 py-1.5 rounded-lg shadow-lg font-medium space-y-0.5 z-10 transition-all duration-75"
            style={{
              left: `${(activePoint.x / width) * 100}%`,
              top: `${(activePoint.y / height) * 100 - 8}%`,
            }}
          >
            <div className="font-bold text-[11px] opacity-80">{activePoint.label}</div>
            <div className="text-sm font-black text-[#C6F542] dark:text-[#7137C8]">
              {formatCurrency(activePoint.revenue)}
            </div>
            <div className="text-[10px] opacity-80">
              {activePoint.orders} order{activePoint.orders !== 1 ? "s" : ""}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * Order Status Donut Chart & Fulfillment Pipeline Breakdown
 */
export function OrderStatusDonutChart({ data }: { data: StatusBreakdownItem[] }) {
  const total = data.reduce((acc, d) => acc + d.count, 0);

  const STATUS_COLORS: Record<string, string> = {
    DELIVERED: "#10B981",
    SHIPPED: "#3B82F6",
    OUT_FOR_DELIVERY: "#06B6D4",
    PACKED: "#8B5CF6",
    PROCESSING: "#F59E0B",
    CONFIRMED: "#7137C8",
    PENDING_CONFIRMATION: "#EAB308",
    CANCELLED: "#EF4444",
  };

  // Build SVG Donut Segments
  const radius = 60;
  const strokeWidth = 22;
  const circumference = 2 * Math.PI * radius;
  let accumulatedOffset = 0;

  return (
    <div className="p-6 bg-card rounded-2xl border border-border shadow-2xs space-y-4">
      <div className="flex items-center justify-between pb-2 border-b border-border/70">
        <div className="flex items-center gap-2">
          <ShoppingBag className="w-4 h-4 text-royal-violet dark:text-[#C6F542]" />
          <h3 className="font-bold text-sm text-foreground">Fulfillment Status</h3>
        </div>
        <span className="text-xs font-bold text-muted-foreground">{total} Total Orders</span>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-between gap-6 pt-2">
        {/* SVG Donut */}
        <div className="relative w-36 h-36 flex items-center justify-center shrink-0">
          <svg viewBox="0 0 160 160" className="w-full h-full -rotate-90">
            {/* Background Track */}
            <circle
              cx="80"
              cy="80"
              r={radius}
              fill="transparent"
              stroke="currentColor"
              strokeOpacity="0.08"
              strokeWidth={strokeWidth}
            />

            {total === 0 ? (
              <circle
                cx="80"
                cy="80"
                r={radius}
                fill="transparent"
                stroke="currentColor"
                strokeOpacity="0.15"
                strokeWidth={strokeWidth}
              />
            ) : (
              data.map((item, idx) => {
                const strokeDasharray = `${(item.count / total) * circumference} ${circumference}`;
                const strokeDashoffset = -accumulatedOffset;
                accumulatedOffset += (item.count / total) * circumference;
                const color = STATUS_COLORS[item.status] || "#6B7280";

                return (
                  <circle
                    key={idx}
                    cx="80"
                    cy="80"
                    r={radius}
                    fill="transparent"
                    stroke={color}
                    strokeWidth={strokeWidth}
                    strokeDasharray={strokeDasharray}
                    strokeDashoffset={strokeDashoffset}
                    className="transition-all duration-300"
                  />
                );
              })
            )}
          </svg>

          {/* Center Text */}
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
            <span className="text-xl font-black text-foreground">{total}</span>
            <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider">
              Orders
            </span>
          </div>
        </div>

        {/* Legend */}
        <div className="w-full space-y-2 text-xs">
          {data.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-4">No order records</p>
          ) : (
            data.map((item) => {
              const color = STATUS_COLORS[item.status] || "#6B7280";
              return (
                <div key={item.status} className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: color }}
                    />
                    <span className="font-medium text-foreground text-xs">{item.label}</span>
                  </div>
                  <div className="flex items-center gap-2 font-mono">
                    <span className="font-bold text-foreground">{item.count}</span>
                    <span className="text-muted-foreground text-[11px] w-9 text-right">
                      ({item.percentage}%)
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

/**
 * Payment Methods & Financial Settlement Distribution
 */
export function PaymentMethodsChart({ data }: { data: PaymentMethodItem[] }) {
  const totalAmount = data.reduce((sum, d) => sum + d.amount, 0);

  const METHOD_LABELS: Record<string, string> = {
    UPI: "UPI (GPay / PhonePe / QR)",
    BANK_TRANSFER: "Bank Transfer (NEFT / IMPS)",
    CASH: "Cash on Delivery",
    OTHER: "Cards & Other Gateways",
  };

  return (
    <div className="p-6 bg-card rounded-2xl border border-border shadow-2xs space-y-4">
      <div className="flex items-center justify-between pb-2 border-b border-border/70">
        <div className="flex items-center gap-2">
          <CreditCard className="w-4 h-4 text-royal-violet dark:text-[#C6F542]" />
          <h3 className="font-bold text-sm text-foreground">Payment Methods</h3>
        </div>
        <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
          {formatCurrency(totalAmount)}
        </span>
      </div>

      <div className="space-y-3.5 pt-1">
        {data.length === 0 ? (
          <p className="text-xs text-muted-foreground text-center py-4">No payments recorded</p>
        ) : (
          data.map((item) => (
            <div key={item.method} className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-foreground">
                  {METHOD_LABELS[item.method] || item.label}
                </span>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-foreground">{formatCurrency(item.amount)}</span>
                  <span className="text-muted-foreground text-[11px] font-mono">
                    ({item.percentage}%)
                  </span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full bg-royal-violet dark:bg-[#C6F542] rounded-full transition-all duration-500"
                  style={{ width: `${Math.max(item.percentage, 3)}%` }}
                />
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

/**
 * Top Selling Products Leaderboard Table
 */
export function TopProductsTable({ data }: { data: TopProductItem[] }) {
  return (
    <div className="p-6 bg-card rounded-2xl border border-border shadow-2xs space-y-4">
      <div className="flex items-center justify-between pb-2 border-b border-border/70">
        <div className="flex items-center gap-2">
          <Award className="w-4 h-4 text-royal-violet dark:text-[#C6F542]" />
          <h3 className="font-bold text-sm text-foreground">Best Performing Garments</h3>
        </div>
        <span className="text-xs font-bold text-muted-foreground">By Units Dispatched</span>
      </div>

      <div className="divide-y divide-border/60">
        {data.length === 0 ? (
          <p className="text-xs text-muted-foreground text-center py-6">
            No product dispatch volume recorded for this period.
          </p>
        ) : (
          data.map((product, idx) => (
            <div key={idx} className="py-3 flex items-center justify-between text-xs gap-3">
              <div className="flex items-center gap-3">
                <span className="w-6 h-6 rounded-md bg-muted text-muted-foreground font-black text-[11px] flex items-center justify-center shrink-0">
                  #{idx + 1}
                </span>
                <div>
                  <span className="font-bold text-foreground block">{product.name}</span>
                  <span className="font-mono text-muted-foreground text-[10px] block">
                    SKU: {product.sku}
                  </span>
                </div>
              </div>

              <div className="text-right shrink-0">
                <span className="font-bold text-foreground block">
                  {formatCurrency(product.revenue)}
                </span>
                <span className="text-muted-foreground text-[11px] block">
                  {product.unitsSold} unit{product.unitsSold !== 1 ? "s" : ""} sold
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}


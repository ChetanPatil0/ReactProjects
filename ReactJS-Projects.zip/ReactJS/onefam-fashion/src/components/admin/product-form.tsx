"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { apiClient } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ImageUploader, uploadImageFile } from "@/components/shared/image-uploader";
import { formatCurrency } from "@/lib/formatters";
import {
  ArrowLeft,
  Sparkles,
  Plus,
  Trash2,
  Check,
  Loader2,
  AlertCircle,
  Shirt,
  Tag,
  Palette,
  Layers,
  Wand2,
  Eye,
  Upload,
  X,
  Image as ImageIcon,
} from "lucide-react";
import { toast } from "sonner";

export interface VariantItem {
  id?: string;
  size: string;
  color: string;
  colorHex: string;
  sku: string;
  stock: number;
  priceOverride?: number | null;
  isAvailable: boolean;
  imagePath?: string;
}

interface ProductFormProps {
  initialData?: any;
  isEditing?: boolean;
  onSave: (data: any) => Promise<void>;
}

export function ProductForm({ initialData, isEditing = false, onSave }: ProductFormProps) {
  const router = useRouter();

  // Basic Information
  const [name, setName] = useState(initialData?.name || "");
  const [slug, setSlug] = useState(initialData?.slug || "");
  const [sku, setSku] = useState(initialData?.sku || "");
  const [categoryId, setCategoryId] = useState(initialData?.categoryId || "");
  const [status, setStatus] = useState<"DRAFT" | "PUBLISHED" | "UNPUBLISHED">(
    initialData?.status || "PUBLISHED"
  );

  // Pricing
  const [regularPrice, setRegularPrice] = useState(
    initialData?.regularPrice !== undefined ? String(initialData.regularPrice) : ""
  );

  // Flags
  const [isFeatured, setIsFeatured] = useState<boolean>(initialData?.isFeatured || false);
  const [isTrending, setIsTrending] = useState<boolean>(initialData?.isTrending || false);
  const [isNewArrival, setIsNewArrival] = useState<boolean>(
    initialData?.isNewArrival !== undefined ? initialData.isNewArrival : true
  );

  // Descriptions
  const [shortDescription, setShortDescription] = useState(initialData?.shortDescription || "");
  const [description, setDescription] = useState(initialData?.description || "");

  // Primary Thumbnail Image (Separated)
  const primaryExistingImage =
    initialData?.images?.find((img: any) => img.isPrimary)?.path ||
    initialData?.images?.[0]?.path ||
    "";
  const [imagePath, setImagePath] = useState(primaryExistingImage);
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);

  // General Gallery Images (Optional Extra Views)
  const initialGalleryImages =
    initialData?.images
      ?.filter((img: any) => !img.isPrimary && !img.altText?.startsWith("variant:"))
      ?.map((img: any) => ({
        id: img.id,
        path: img.path,
        altText: img.altText || "Gallery",
      })) || [];
  const [galleryImages, setGalleryImages] = useState<Array<{ id?: string; path: string; altText?: string }>>(
    initialGalleryImages
  );
  const [newGalleryUrl, setNewGalleryUrl] = useState("");

  // Collections
  const initialCollectionIds = initialData?.collectionProducts?.map((cp: any) => cp.collectionId) || [];
  const [selectedCollectionIds, setSelectedCollectionIds] = useState<string[]>(initialCollectionIds);

  // Variants Array with Variant-Wise Image Media
  const initialVariants: VariantItem[] =
    initialData?.variants?.map((v: any) => {
      // Find variant-specific image if present
      const variantImg = initialData?.images?.find(
        (img: any) =>
          img.altText === `variant:${v.color}` ||
          img.altText === `variant:${v.sku}` ||
          (v.color && img.altText?.toLowerCase() === v.color.toLowerCase())
      );

      return {
        id: v.id,
        size: v.size || "",
        color: v.color || "",
        colorHex: v.colorHex || "#191720",
        sku: v.sku || "",
        stock: v.stock ?? 10,
        priceOverride: v.priceOverride ? Number(v.priceOverride) : null,
        isAvailable: v.isAvailable !== false,
        imagePath: v.imagePath || variantImg?.path || "",
      };
    }) || [
      { size: "S", color: "Obsidian Black", colorHex: "#191720", sku: "", stock: 15, isAvailable: true, imagePath: "" },
      { size: "M", color: "Obsidian Black", colorHex: "#191720", sku: "", stock: 20, isAvailable: true, imagePath: "" },
      { size: "L", color: "Obsidian Black", colorHex: "#191720", sku: "", stock: 15, isAvailable: true, imagePath: "" },
      { size: "XL", color: "Obsidian Black", colorHex: "#191720", sku: "", stock: 10, isAvailable: true, imagePath: "" },
    ];

  const [variants, setVariants] = useState<VariantItem[]>(initialVariants);

  // Helper: Apply a variant's image to all variants with the same color
  const handleApplyImageToColor = (color: string, imgPath: string) => {
    if (!color || !imgPath) return;
    setVariants((prev) =>
      prev.map((v) =>
        v.color.toLowerCase() === color.toLowerCase() ? { ...v, imagePath: imgPath } : v
      )
    );
    toast.success(`Applied variant image to all "${color}" combinations!`);
  };

  // Quick Combinations Generator Inputs
  const [generatorSizes, setGeneratorSizes] = useState("S, M, L, XL");
  const [generatorColors, setGeneratorColors] = useState("Obsidian Black, Bone White, Royal Violet");
  const [showGenerator, setShowGenerator] = useState(false);

  // Submitting & Errors
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Fetch Categories & Collections
  const { data: categories = [] } = useQuery({
    queryKey: queryKeys.categories.all,
    queryFn: () => apiClient.get("/categories"),
  });

  const { data: collections = [] } = useQuery({
    queryKey: queryKeys.collections.all,
    queryFn: () => apiClient.get("/collections"),
  });

  // Calculate discount percentage live
  const discountPercent = initialData?.discountPercent || 0;

  // Auto-slugify on title change if slug wasn't manually edited
  const handleNameChange = (val: string) => {
    setName(val);
    if (!isEditing && (!slug || slug === name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""))) {
      setSlug(val.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""));
    }
    if (!sku && val) {
      const code = val.slice(0, 3).toUpperCase();
      setSku(`OFF-${code}-${Math.floor(100 + Math.random() * 900)}`);
    }
  };

  // Add a blank variant row
  const handleAddVariant = () => {
    setVariants((prev) => [
      ...prev,
      {
        size: "M",
        color: "Obsidian Black",
        colorHex: "#191720",
        sku: sku ? `${sku}-${prev.length + 1}` : "",
        stock: 10,
        isAvailable: true,
      },
    ]);
  };

  // Remove a variant row
  const handleRemoveVariant = (index: number) => {
    setVariants((prev) => prev.filter((_, idx) => idx !== index));
  };

  // Update a single variant field
  const handleUpdateVariant = (index: number, field: keyof VariantItem, value: any) => {
    setVariants((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  // Color Presets for quick Hex assignment
  const COLOR_HEX_MAP: Record<string, string> = {
    "black": "#191720",
    "obsidian black": "#191720",
    "white": "#FCFAF4",
    "bone white": "#F5F3EF",
    "royal violet": "#7137C8",
    "violet": "#7137C8",
    "purple": "#7137C8",
    "electric lime": "#C6F542",
    "lime": "#C6F542",
    "vermilion": "#F45B45",
    "red": "#F45B45",
    "navy": "#1B2A4A",
    "blue": "#2563EB",
    "sage": "#708238",
    "sage olive": "#708238",
    "olive": "#556B2F",
    "beige": "#DDCBB3",
    "sand": "#E6D7B9",
    "grey": "#6B7280",
    "gray": "#6B7280",
    "pink": "#FFB6C1",
    "blush pink": "#FFB6C1",
    "gold": "#DAA520",
    "yellow": "#FACC15",
  };

  // Generate All Size x Color combinations
  const handleGenerateCombinations = () => {
    const rawSizes = generatorSizes
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    const rawColors = generatorColors
      .split(",")
      .map((c) => c.trim())
      .filter(Boolean);

    if (rawSizes.length === 0 || rawColors.length === 0) {
      toast.error("Please enter at least one size and one color.");
      return;
    }

    const newVariants: VariantItem[] = [];
    const baseSku = sku || (name ? name.slice(0, 3).toUpperCase() : "OFF");

    for (const color of rawColors) {
      const normalizedColor = color.toLowerCase();
      const colorHex = COLOR_HEX_MAP[normalizedColor] || "#191720";
      const colorCode = color.slice(0, 3).toUpperCase();

      for (const size of rawSizes) {
        newVariants.push({
          size,
          color,
          colorHex,
          sku: `${baseSku}-${colorCode}-${size}`.toUpperCase(),
          stock: 15,
          isAvailable: true,
        });
      }
    }

    setVariants(newVariants);
    setShowGenerator(false);
    toast.success(`Generated ${newVariants.length} variant combinations!`);
  };

  // Toggle collection selection
  const handleToggleCollection = (id: string) => {
    setSelectedCollectionIds((prev) =>
      prev.includes(id) ? prev.filter((c) => c !== id) : [...prev, id]
    );
  };

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!name.trim()) errs.name = "Product name is required.";
    if (!slug.trim()) errs.slug = "Product slug is required.";
    if (!regularPrice || isNaN(parseFloat(regularPrice)) || parseFloat(regularPrice) <= 0) {
      errs.regularPrice = "A valid positive regular price is required.";
    }
    if (!imagePath && !selectedImageFile) {
      errs.imagePath = "Primary product image is required.";
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      toast.error("Please review the highlighted errors before saving.");
      return;
    }

    setIsSubmitting(true);
    try {
      let finalImagePath = imagePath;

      // Staged upload: only upload the image file when saving
      if (selectedImageFile) {
        const uploadRes = await uploadImageFile(selectedImageFile);
        finalImagePath = uploadRes.url;
      }

      // 1. Primary Thumbnail (Kept Separated)
      const allImages: Array<{ path: string; altText: string; isPrimary: boolean; sortOrder: number }> = [];

      if (finalImagePath) {
        allImages.push({
          path: finalImagePath,
          altText: name.trim(),
          isPrimary: true,
          sortOrder: 0,
        });
      }

      // 2. Additional General Gallery Images
      galleryImages.forEach((gImg) => {
        if (gImg.path && gImg.path !== finalImagePath) {
          allImages.push({
            path: gImg.path,
            altText: gImg.altText || "Gallery",
            isPrimary: false,
            sortOrder: allImages.length,
          });
        }
      });

      // 3. Variant-Specific Images (Direct Media)
      const variantImageSet = new Set<string>();
      variants.forEach((v) => {
        if (v.imagePath && !variantImageSet.has(v.imagePath) && v.imagePath !== finalImagePath) {
          variantImageSet.add(v.imagePath);
          allImages.push({
            path: v.imagePath,
            altText: `variant:${v.color}`,
            isPrimary: false,
            sortOrder: allImages.length,
          });
        }
      });

      await onSave({
        name: name.trim(),
        slug: slug.trim(),
        sku: sku.trim() || undefined,
        categoryId: categoryId || undefined,
        status,
        regularPrice: parseFloat(regularPrice),
        discountPrice: null,
        isFeatured,
        isTrending,
        isNewArrival,
        shortDescription: shortDescription.trim() || undefined,
        description: description.trim() || undefined,
        imagePath: finalImagePath,
        images: allImages,
        variants: variants.map((v) => ({
          ...(v.id ? { id: v.id } : {}),
          size: v.size.trim(),
          color: v.color.trim(),
          colorHex: v.colorHex.trim() || "#191720",
          sku: v.sku.trim() || undefined,
          stock: Number(v.stock) || 0,
          priceOverride: v.priceOverride ? Number(v.priceOverride) : null,
          isAvailable: v.isAvailable !== false,
          imagePath: v.imagePath?.trim() || undefined,
        })),
        collectionIds: selectedCollectionIds,
      });

      router.push("/admin/products");
    } catch (err: any) {
      toast.error(err.message || "Failed to save product.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const totalStock = variants.reduce((acc, v) => acc + (v.isAvailable ? Number(v.stock) || 0 : 0), 0);

  return (
    <form onSubmit={handleSubmit} className="space-y-8 max-w-6xl mx-auto pb-24">
      {/* Top Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border">
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" asChild className="h-9 px-3 rounded-xl">
            <Link href="/admin/products" className="flex items-center gap-1.5 text-xs">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Products</span>
            </Link>
          </Button>

          <div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-foreground flex items-center gap-2">
              <Shirt className="w-6 h-6 text-royal-violet" />
              {isEditing ? `Edit Product: ${initialData?.name || "Ready-to-Wear"}` : "Create New Fashion Piece"}
            </h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              Full product definition with color &amp; size combinations, inventory stock, imagery, and collections.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            asChild
            className="h-9 text-xs"
          >
            <Link href="/admin/products">Cancel</Link>
          </Button>

          <Button
            type="submit"
            disabled={isSubmitting}
            className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold text-xs rounded-xl shadow-md h-9 px-5"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                <span>Saving Product...</span>
              </>
            ) : (
              <>
                <Check className="w-3.5 h-3.5 mr-1.5" />
                <span>{isEditing ? "Update Product" : "Publish Product"}</span>
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Main Form 2-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column (8 cols): Core info, Images, Variants */}
        <div className="lg:col-span-8 space-y-6">
          {/* 1. General Product Details */}
          <div className="bg-card rounded-2xl border border-border shadow-2xs p-6 space-y-4">
            <h2 className="text-sm font-black uppercase tracking-wider text-foreground flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-royal-violet" />
              <span>General Information</span>
            </h2>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Product Title <span className="text-vermilion">*</span>
              </label>
              <Input
                placeholder="e.g. Oversized Heavyweight Cotton Tee"
                value={name}
                onChange={(e) => handleNameChange(e.target.value)}
                className={`h-10 text-xs font-semibold ${errors.name ? "border-vermilion" : ""}`}
              />
              {errors.name && (
                <p className="text-[11px] text-vermilion font-medium mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {errors.name}
                </p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                  Storefront URL Slug <span className="text-vermilion">*</span>
                </label>
                <Input
                  placeholder="oversized-heavyweight-cotton-tee"
                  value={slug}
                  onChange={(e) => setSlug(e.target.value)}
                  className={`h-10 text-xs font-semibold ${errors.slug ? "border-vermilion" : ""}`}
                />
                {errors.slug && (
                  <p className="text-[11px] text-vermilion font-medium mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {errors.slug}
                  </p>
                )}
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                  Master SKU
                </label>
                <Input
                  placeholder="OFF-M-TEE-001"
                  value={sku}
                  onChange={(e) => setSku(e.target.value)}
                  className="h-10 text-xs font-semibold"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Short Editorial Hook (1-2 Sentences)
              </label>
              <Input
                placeholder="e.g. 300 GSM combed cotton drop-shoulder silhouette with structured crew neckline."
                value={shortDescription}
                onChange={(e) => setShortDescription(e.target.value)}
                className="h-10 text-xs"
              />
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Detailed Garment Description &amp; Fabric Care
              </label>
              <Textarea
                rows={5}
                placeholder="Describe fabric composition, tailoring silhouette, model fit, wash instructions..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="text-xs leading-relaxed"
              />
            </div>
          </div>

          {/* 2. Product Imagery */}
          <div className="bg-card rounded-2xl border border-border shadow-2xs p-6 space-y-5">
            <div>
              <h2 className="text-sm font-black uppercase tracking-wider text-foreground flex items-center gap-2">
                <Eye className="w-4 h-4 text-royal-violet" />
                <span>Garment Photography &amp; Media</span>
              </h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                Keep the main catalogue thumbnail separated, and add general gallery photos. Variant-specific media can be assigned directly in the table below.
              </p>
            </div>

            {/* Primary Thumbnail (Cover Photo) - Kept Separated! */}
            <div className="p-4 rounded-xl border border-royal-violet/30 bg-royal-violet/5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-royal-violet flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-royal-violet" />
                  Main Product Thumbnail (Cover / Listing Photo) <span className="text-vermilion">*</span>
                </span>
                <Badge variant="outline" className="text-[10px] font-bold bg-royal-violet/10 text-royal-violet border-royal-violet/30">
                  Primary Thumbnail (Separated)
                </Badge>
              </div>
              <p className="text-[11px] text-muted-foreground">
                This is the primary thumbnail shown on product cards, category pages, search results, and checkout cart.
              </p>

              <ImageUploader
                value={imagePath}
                onChange={setImagePath}
                onFileSelect={setSelectedImageFile}
                label="Primary Thumbnail Image"
                required={true}
              />
              {errors.imagePath && (
                <p className="text-[11px] text-vermilion font-medium mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {errors.imagePath}
                </p>
              )}
            </div>

            {/* Additional General Gallery Images */}
            <div className="p-4 rounded-xl border border-border bg-muted/15 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-foreground block">
                    General Gallery Photos (Optional)
                  </span>
                  <span className="text-[11px] text-muted-foreground">
                    Extra lookbook views (back angle, fabric drape, close-up texture)
                  </span>
                </div>
                {galleryImages.length > 0 && (
                  <Badge variant="outline" className="text-[10px]">
                    {galleryImages.length} photos
                  </Badge>
                )}
              </div>

              {/* Gallery Images List */}
              {galleryImages.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-1">
                  {galleryImages.map((gImg, gIdx) => (
                    <div key={gIdx} className="relative aspect-[4/5] rounded-xl overflow-hidden border border-border group/gimg bg-muted">
                      <img src={gImg.path} alt={gImg.altText || "Gallery"} className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setGalleryImages((prev) => prev.filter((_, i) => i !== gIdx))}
                        className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/70 text-white flex items-center justify-center opacity-0 group-hover/gimg:opacity-100 transition-opacity hover:bg-vermilion"
                        title="Remove photo"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Add Gallery Image Row */}
              <div className="flex flex-col sm:flex-row gap-2 pt-2">
                <Input
                  value={newGalleryUrl}
                  onChange={(e) => setNewGalleryUrl(e.target.value)}
                  placeholder="Paste extra gallery photo URL (e.g. https://...)"
                  className="text-xs h-9 bg-background"
                />
                <div className="flex items-center gap-2 shrink-0">
                  <label className="h-9 px-3 rounded-lg border border-border bg-card hover:bg-muted/50 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition">
                    <Upload className="w-3.5 h-3.5 text-royal-violet" />
                    <span>Upload File</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        try {
                          toast.loading("Uploading gallery photo...", { id: "gallery-up" });
                          const res = await uploadImageFile(file);
                          setGalleryImages((prev) => [...prev, { path: res.url, altText: "Gallery" }]);
                          toast.success("Gallery photo uploaded", { id: "gallery-up" });
                        } catch (err: any) {
                          toast.error(err.message || "Failed to upload", { id: "gallery-up" });
                        }
                      }}
                    />
                  </label>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      if (newGalleryUrl.trim()) {
                        setGalleryImages((prev) => [...prev, { path: newGalleryUrl.trim(), altText: "Gallery" }]);
                        setNewGalleryUrl("");
                      }
                    }}
                    className="h-9 text-xs font-bold"
                  >
                    Add URL
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* 3. COLOR & SIZE VARIANTS (Combinations Generator & Management) */}
          <div className="bg-card rounded-2xl border border-border shadow-2xs p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-black uppercase tracking-wider text-foreground flex items-center gap-2">
                  <Layers className="w-4 h-4 text-royal-violet" />
                  <span>Size &amp; Color Variants</span>
                </h2>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Configure size options, exact color hex swatches, inventory stock, and unique SKUs.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setShowGenerator(!showGenerator)}
                  className="h-8 text-xs font-bold rounded-lg border-royal-violet/40 text-royal-violet hover:bg-royal-violet/10 flex items-center gap-1.5"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>{showGenerator ? "Hide Generator" : "Generate Combinations"}</span>
                </Button>

                <Button
                  type="button"
                  variant="default"
                  size="sm"
                  onClick={handleAddVariant}
                  className="h-8 text-xs font-bold rounded-lg bg-royal-violet hover:bg-royal-violet/90 text-white flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Single</span>
                </Button>
              </div>
            </div>

            {/* Quick Combinations Generator Drawer */}
            {showGenerator && (
              <div className="p-4 rounded-xl border border-royal-violet/30 bg-royal-violet/5 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-royal-violet uppercase tracking-wider flex items-center gap-1.5">
                    <Palette className="w-4 h-4" />
                    <span>Variant Matrix Generator (Size × Color)</span>
                  </span>
                  <span className="text-[11px] text-muted-foreground">
                    Comma-separated values
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] font-bold text-foreground block mb-1">
                      Sizes (e.g. S, M, L, XL or 30, 32, 34)
                    </label>
                    <Input
                      value={generatorSizes}
                      onChange={(e) => setGeneratorSizes(e.target.value)}
                      placeholder="S, M, L, XL"
                      className="h-9 text-xs bg-background"
                    />
                    <div className="flex gap-1.5 mt-1.5">
                      <button
                        type="button"
                        onClick={() => setGeneratorSizes("XS, S, M, L, XL, XXL")}
                        className="text-[10px] px-2 py-0.5 rounded bg-muted hover:bg-muted/80 text-foreground"
                      >
                        Clothing (XS-XXL)
                      </button>
                      <button
                        type="button"
                        onClick={() => setGeneratorSizes("28, 30, 32, 34, 36")}
                        className="text-[10px] px-2 py-0.5 rounded bg-muted hover:bg-muted/80 text-foreground"
                      >
                        Waist (28-36)
                      </button>
                      <button
                        type="button"
                        onClick={() => setGeneratorSizes("2-3Y, 4-5Y, 6-7Y, 8-9Y")}
                        className="text-[10px] px-2 py-0.5 rounded bg-muted hover:bg-muted/80 text-foreground"
                      >
                        Kids Ages
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-foreground block mb-1">
                      Color Names (e.g. Obsidian Black, Bone White, Royal Violet)
                    </label>
                    <Input
                      value={generatorColors}
                      onChange={(e) => setGeneratorColors(e.target.value)}
                      placeholder="Obsidian Black, Bone White"
                      className="h-9 text-xs bg-background"
                    />
                    <div className="flex gap-1.5 mt-1.5">
                      <button
                        type="button"
                        onClick={() => setGeneratorColors("Obsidian Black, Bone White, Royal Violet")}
                        className="text-[10px] px-2 py-0.5 rounded bg-muted hover:bg-muted/80 text-foreground"
                      >
                        Signature OneFam
                      </button>
                      <button
                        type="button"
                        onClick={() => setGeneratorColors("Navy, Sage Olive, Sand Dune")}
                        className="text-[10px] px-2 py-0.5 rounded bg-muted hover:bg-muted/80 text-foreground"
                      >
                        Earth Tones
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-1">
                  <Button
                    type="button"
                    onClick={handleGenerateCombinations}
                    size="sm"
                    className="bg-royal-violet hover:bg-royal-violet/90 text-white font-bold text-xs"
                  >
                    Generate Combinations
                  </Button>
                </div>
              </div>
            )}

            {/* Variants Table */}
            <div className="rounded-xl border border-border overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-border bg-muted/40 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                      <th className="py-2.5 px-3 w-56">Variant Media</th>
                      <th className="py-2.5 px-3 w-20">Size</th>
                      <th className="py-2.5 px-3 w-36">Color Name</th>
                      <th className="py-2.5 px-3 w-28">Color Hex</th>
                      <th className="py-2.5 px-3">Variant SKU</th>
                      <th className="py-2.5 px-3 w-24 text-center">Stock</th>
                      <th className="py-2.5 px-3 w-28">Price Override</th>
                      <th className="py-2.5 px-3 w-24 text-center">Status</th>
                      <th className="py-2.5 px-3 w-12 text-center"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border text-xs">
                    {variants.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="py-8 text-center text-muted-foreground">
                          No variants added. Click &ldquo;Add Single&rdquo; or &ldquo;Generate Combinations&rdquo; above.
                        </td>
                      </tr>
                    ) : (
                      variants.map((v, idx) => (
                        <tr key={idx} className="hover:bg-muted/20 transition-colors">
                          {/* Variant Media (Direct Upload or URL) */}
                          <td className="py-2.5 px-3">
                            <div className="flex items-center gap-2">
                              {v.imagePath ? (
                                <div className="relative group w-9 h-9 rounded-lg border border-border overflow-hidden shrink-0 bg-muted/40">
                                  {/* eslint-disable-next-line @next/next/no-img-element */}
                                  <img
                                    src={v.imagePath}
                                    alt={v.color || "Variant"}
                                    className="w-full h-full object-cover"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => handleUpdateVariant(idx, "imagePath", "")}
                                    className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity"
                                    title="Remove image"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ) : (
                                <label
                                  className="w-9 h-9 rounded-lg border border-dashed border-border hover:border-royal-violet bg-muted/20 hover:bg-royal-violet/5 flex items-center justify-center cursor-pointer transition shrink-0"
                                  title="Upload variant photo"
                                >
                                  <Upload className="w-3.5 h-3.5 text-muted-foreground" />
                                  <input
                                    type="file"
                                    accept="image/*"
                                    className="hidden"
                                    onChange={async (e) => {
                                      const file = e.target.files?.[0];
                                      if (!file) return;
                                      try {
                                        toast.loading("Uploading variant image...", { id: `var-up-${idx}` });
                                        const res = await uploadImageFile(file);
                                        handleUpdateVariant(idx, "imagePath", res.url);
                                        toast.success("Variant image uploaded!", { id: `var-up-${idx}` });
                                      } catch (err: any) {
                                        toast.error(err.message || "Failed to upload", { id: `var-up-${idx}` });
                                      }
                                    }}
                                  />
                                </label>
                              )}
                              <div className="flex flex-col gap-1 min-w-[120px]">
                                <Input
                                  value={v.imagePath || ""}
                                  onChange={(e) => handleUpdateVariant(idx, "imagePath", e.target.value)}
                                  placeholder="Image URL or upload"
                                  className="h-7 text-[10px]"
                                />
                                {v.imagePath && v.color && (
                                  <button
                                    type="button"
                                    onClick={() => handleApplyImageToColor(v.color, v.imagePath!)}
                                    className="text-[10px] text-royal-violet hover:underline text-left font-medium leading-none"
                                    title={`Copy this image to all variants with color "${v.color}"`}
                                  >
                                    Apply to all {v.color}
                                  </button>
                                )}
                              </div>
                            </div>
                          </td>
                          {/* Size */}
                          <td className="py-2.5 px-3">
                            <Input
                              value={v.size}
                              onChange={(e) => handleUpdateVariant(idx, "size", e.target.value)}
                              placeholder="Size"
                              className="h-8 text-xs font-bold text-center uppercase"
                            />
                          </td>

                          {/* Color Name */}
                          <td className="py-2.5 px-3">
                            <Input
                              value={v.color}
                              onChange={(e) => handleUpdateVariant(idx, "color", e.target.value)}
                              placeholder="Color name"
                              className="h-8 text-xs"
                            />
                          </td>

                          {/* Color Hex & Swatch */}
                          <td className="py-2.5 px-3">
                            <div className="flex items-center gap-1.5">
                              <input
                                type="color"
                                value={v.colorHex || "#191720"}
                                onChange={(e) => handleUpdateVariant(idx, "colorHex", e.target.value)}
                                className="w-7 h-7 rounded border border-border cursor-pointer p-0 bg-transparent shrink-0"
                                title="Pick exact color swatch"
                              />
                              <Input
                                value={v.colorHex}
                                onChange={(e) => handleUpdateVariant(idx, "colorHex", e.target.value)}
                                placeholder="#hex"
                                className="h-8 text-[11px] font-mono uppercase"
                              />
                            </div>
                          </td>

                          {/* Variant SKU */}
                          <td className="py-2.5 px-3">
                            <Input
                              value={v.sku}
                              onChange={(e) => handleUpdateVariant(idx, "sku", e.target.value)}
                              placeholder="SKU"
                              className="h-8 text-[11px] font-mono"
                            />
                          </td>

                          {/* Stock Quantity */}
                          <td className="py-2.5 px-3 text-center">
                            <Input
                              type="number"
                              min={0}
                              value={v.stock}
                              onChange={(e) => handleUpdateVariant(idx, "stock", parseInt(e.target.value, 10) || 0)}
                              className="h-8 text-xs font-bold text-center w-20 mx-auto"
                            />
                          </td>

                          {/* Price Override */}
                          <td className="py-2.5 px-3">
                            <Input
                              type="number"
                              min={0}
                              value={v.priceOverride ?? ""}
                              onChange={(e) =>
                                handleUpdateVariant(
                                  idx,
                                  "priceOverride",
                                  e.target.value ? parseFloat(e.target.value) : null
                                )
                              }
                              placeholder="Optional ₹"
                              className="h-8 text-[11px]"
                            />
                          </td>

                          {/* Available Toggle */}
                          <td className="py-2.5 px-3 text-center">
                            <button
                              type="button"
                              onClick={() => handleUpdateVariant(idx, "isAvailable", !v.isAvailable)}
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                v.isAvailable
                                  ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400"
                                  : "bg-muted text-muted-foreground"
                              }`}
                            >
                              {v.isAvailable ? "Active" : "Out"}
                            </button>
                          </td>

                          {/* Delete Action */}
                          <td className="py-2.5 px-3 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveVariant(idx)}
                              className="text-muted-foreground hover:text-vermilion p-1 transition-colors"
                              title="Remove variant"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Variant Stats */}
            <div className="flex items-center justify-between text-xs text-muted-foreground pt-1">
              <span>
                Total Variants: <strong className="text-foreground">{variants.length}</strong>
              </span>
              <span>
                Available Inventory Stock: <strong className="text-royal-violet">{totalStock} units</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Right Column (4 cols): Pricing, Status, Category, Collections */}
        <div className="lg:col-span-4 space-y-6">
          {/* Status & Storefront Visibility */}
          <div className="bg-card rounded-2xl border border-border shadow-2xs p-6 space-y-4">
            <h2 className="text-sm font-black uppercase tracking-wider text-foreground flex items-center gap-2">
              <Tag className="w-4 h-4 text-royal-violet" />
              <span>Publishing &amp; Status</span>
            </h2>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Storefront State
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full h-10 px-3 rounded-lg border border-border bg-background text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-royal-violet"
              >
                <option value="PUBLISHED">Published (Visible in Store)</option>
                <option value="DRAFT">Draft (Internal Only)</option>
                <option value="UNPUBLISHED">Unpublished (Archived)</option>
              </select>
            </div>

            {/* Badges and Merchandising Flags */}
            <div className="space-y-2.5 pt-2 border-t border-border">
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Merchandising Badges
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isNewArrival}
                  onChange={(e) => setIsNewArrival(e.target.checked)}
                  className="rounded border-border text-royal-violet focus:ring-royal-violet"
                />
                <span className="text-xs font-semibold text-foreground flex items-center gap-1.5">
                  <Badge variant="accent" className="text-[10px] py-0">New Arrival</Badge>
                  <span className="text-[11px] text-muted-foreground">Show in New Drops</span>
                </span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isTrending}
                  onChange={(e) => setIsTrending(e.target.checked)}
                  className="rounded border-border text-royal-violet focus:ring-royal-violet"
                />
                <span className="text-xs font-semibold text-foreground flex items-center gap-1.5">
                  <Badge variant="destructive" className="text-[10px] py-0 bg-vermilion text-white">Trending</Badge>
                  <span className="text-[11px] text-muted-foreground">Most loved piece</span>
                </span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isFeatured}
                  onChange={(e) => setIsFeatured(e.target.checked)}
                  className="rounded border-border text-royal-violet focus:ring-royal-violet"
                />
                <span className="text-xs font-semibold text-foreground flex items-center gap-1.5">
                  <Badge variant="secondary" className="text-[10px] py-0">Featured</Badge>
                  <span className="text-[11px] text-muted-foreground">Feature in showcase</span>
                </span>
              </label>
            </div>
          </div>

          {/* Pricing Card */}
          <div className="bg-card rounded-2xl border border-border shadow-2xs p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-black uppercase tracking-wider text-foreground">
                Pricing &amp; Valuation
              </h2>
              {initialData?.activeOffer && (
                <Badge variant="destructive" className="bg-vermilion text-white text-[10px] font-black uppercase">
                  {initialData.activeOffer.discountType === "PERCENTAGE"
                    ? `${initialData.activeOffer.discountValue}% OFF`
                    : `₹${initialData.activeOffer.discountValue} OFF`}
                </Badge>
              )}
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Regular Retail Price (₹) <span className="text-vermilion">*</span>
              </label>
              <Input
                type="number"
                min={0}
                step="0.01"
                placeholder="2999"
                value={regularPrice}
                onChange={(e) => setRegularPrice(e.target.value)}
                className={`h-10 text-xs font-bold ${errors.regularPrice ? "border-vermilion" : ""}`}
              />
              {errors.regularPrice && (
                <p className="text-[11px] text-vermilion font-medium mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {errors.regularPrice}
                </p>
              )}
            </div>

            {/* Dynamic Offers & Discounts Integration */}
            <div className="pt-2 border-t border-border">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-royal-violet" />
                  Dynamic Offers &amp; Discounts
                </span>
                <Link
                  href="/admin/offers"
                  className="text-[11px] font-bold text-royal-violet hover:underline flex items-center gap-1"
                >
                  Manage Offers &rarr;
                </Link>
              </div>

              {initialData?.activeOffer ? (
                <div className="p-3.5 rounded-xl border border-royal-violet/30 bg-royal-violet/5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-royal-violet flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-royal-violet" />
                      {initialData.activeOffer.name}
                    </span>
                    <Badge className="bg-vermilion text-white text-[10px] font-black uppercase">
                      {initialData.activeOffer.discountType === "PERCENTAGE"
                        ? `${initialData.activeOffer.discountValue}% OFF`
                        : `₹${initialData.activeOffer.discountValue} OFF`}
                    </Badge>
                  </div>
                  <div className="flex items-baseline justify-between pt-1 border-t border-royal-violet/15 text-xs">
                    <span className="text-muted-foreground">Effective Storefront Price:</span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-sm font-black text-foreground">
                        {formatCurrency(initialData.discountPrice)}
                      </span>
                      <span className="text-xs text-muted-foreground line-through">
                        {formatCurrency(regularPrice ? parseFloat(regularPrice) : 0)}
                      </span>
                    </div>
                  </div>
                  <p className="text-[10px] text-muted-foreground leading-normal">
                    Calculated automatically by backend. To change or remove, edit the offer in Offers &amp; Discounts.
                  </p>
                </div>
              ) : (
                <div className="p-3 rounded-xl border border-dashed border-border bg-muted/20 text-xs space-y-1.5">
                  <p className="text-[11px] text-muted-foreground leading-relaxed">
                    Discounts are managed dynamically through <strong>Offers &amp; Discounts</strong>. Products can be added to seasonal or clearance offers with automatic backend price calculations.
                  </p>
                  <Link
                    href="/admin/offers"
                    className="inline-block text-[11px] font-bold text-royal-violet hover:underline pt-0.5"
                  >
                    + Add this product to an Offer &rarr;
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* Category & Department */}
          <div className="bg-card rounded-2xl border border-border shadow-2xs p-6 space-y-4">
            <h2 className="text-sm font-black uppercase tracking-wider text-foreground">
              Department &amp; Category
            </h2>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-1">
                Primary Category
              </label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="w-full h-10 px-3 rounded-lg border border-border bg-background text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-royal-violet"
              >
                <option value="">Select Category...</option>
                {categories.map((c: any) => (
                  <option key={c.id} value={c.id}>
                    {c.parent ? `${c.parent.name} → ` : ""}{c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Featured Collections */}
          <div className="bg-card rounded-2xl border border-border shadow-2xs p-6 space-y-3">
            <h2 className="text-sm font-black uppercase tracking-wider text-foreground">
              Curated Collections
            </h2>
            <p className="text-xs text-muted-foreground">
              Select which curated lookbooks this product appears in:
            </p>

            <div className="space-y-2 pt-1">
              {collections.map((col: any) => {
                const isSelected = selectedCollectionIds.includes(col.id);
                return (
                  <label
                    key={col.id}
                    className={`flex items-center gap-2.5 p-2 rounded-lg border cursor-pointer transition ${
                      isSelected
                        ? "border-royal-violet/60 bg-royal-violet/5 text-foreground"
                        : "border-border text-muted-foreground hover:bg-muted/40"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => handleToggleCollection(col.id)}
                      className="rounded border-border text-royal-violet focus:ring-royal-violet"
                    />
                    <span className="text-xs font-semibold">{col.title}</span>
                  </label>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </form>
  );
}


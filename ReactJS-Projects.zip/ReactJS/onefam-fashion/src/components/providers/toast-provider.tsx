"use client";

import { Toaster } from "sonner";

export function ToastProvider() {
  return (
    <Toaster
      position="top-right"
      toastOptions={{
        style: {
          background: "#191720",
          color: "#FCFAF4",
          border: "1px solid rgba(255,255,255,0.1)",
          fontFamily: "var(--font-plus-jakarta)",
        },
      }}
    />
  );
}


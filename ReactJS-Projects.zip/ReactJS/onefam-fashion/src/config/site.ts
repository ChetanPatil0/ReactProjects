import siteConfigData from "./site-config.json";
import type { Metadata } from "next";

export type SiteConfig = typeof siteConfigData;

export const siteConfig: SiteConfig = siteConfigData;

/**
 * Returns structured metadata for Next.js pages
 */
export function buildPageMetadata({
  title,
  description,
  path = "",
  keywords = [],
  image,
  noIndex = false,
}: {
  title?: string;
  description?: string;
  path?: string;
  keywords?: string[];
  image?: string;
  noIndex?: boolean;
} = {}): Metadata {
  const fullTitle = title
    ? `${title} | ${siteConfig.brand.name}`
    : siteConfig.seo.defaultTitle;
  const metaDescription = description || siteConfig.brand.description;
  const canonicalUrl = `${siteConfig.seo.siteUrl}${path.startsWith("/") ? path : `/${path}`}`;
  const ogImage = image || siteConfig.images.ogImage;
  const allKeywords = Array.from(new Set([...siteConfig.seo.keywords, ...keywords]));

  return {
    title: title ? title : { default: siteConfig.seo.defaultTitle, template: siteConfig.seo.titleTemplate },
    description: metaDescription,
    keywords: allKeywords,
    authors: [{ name: siteConfig.seo.author }],
    creator: siteConfig.seo.creator,
    publisher: siteConfig.seo.publisher,
    metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || siteConfig.seo.siteUrl),
    alternates: {
      canonical: canonicalUrl,
    },
    openGraph: {
      title: fullTitle,
      description: metaDescription,
      url: canonicalUrl,
      siteName: siteConfig.brand.name,
      locale: siteConfig.seo.locale,
      type: "website",
      images: [
        {
          url: ogImage,
          width: 1200,
          height: 630,
          alt: `${siteConfig.brand.name} - ${siteConfig.brand.tagline}`,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: fullTitle,
      description: metaDescription,
      creator: siteConfig.seo.twitterHandle,
      images: [ogImage],
    },
    robots: noIndex
      ? { index: false, follow: false }
      : {
          index: true,
          follow: true,
          googleBot: {
            index: true,
            follow: true,
            "max-video-preview": -1,
            "max-image-preview": "large",
            "max-snippet": -1,
          },
        },
    icons: {
      icon: siteConfig.images.icons.icon,
      shortcut: siteConfig.images.icons.favicon,
      apple: siteConfig.images.icons.appleTouchIcon,
    },
  };
}

/**
 * Generates Schema.org Organization structured data (JSON-LD)
 */
export function getOrganizationJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "ClothingStore",
    "@id": `${siteConfig.seo.siteUrl}/#organization`,
    name: siteConfig.brand.name,
    legalName: siteConfig.brand.legalName,
    url: siteConfig.seo.siteUrl,
    logo: `${siteConfig.seo.siteUrl}${siteConfig.images.logo.light}`,
    image: siteConfig.images.ogImage,
    description: siteConfig.brand.description,
    email: siteConfig.contact.supportEmail,
    currenciesAccepted: siteConfig.brand.currency,
    paymentAccepted: "Credit Card, Debit Card, Net Banking, UPI, Cash on Delivery",
    address: {
      "@type": "PostalAddress",
      addressCountry: "IN",
      addressRegion: "Karnataka",
      addressLocality: "Bengaluru",
    },
    sameAs: [
      siteConfig.social.instagram,
      siteConfig.social.facebook,
      siteConfig.social.youtube,
      siteConfig.social.twitter,
    ].filter(Boolean),
    contactPoint: {
      "@type": "ContactPoint",
      contactType: "customer support",
      url: `https://wa.me/${siteConfig.contact.whatsappNumber}`,
      availableLanguage: ["en", "hi"],
      hoursAvailable: {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
        ],
        opens: "10:00",
        closes: "20:00",
      },
    },
  };
}

/**
 * Generates Schema.org WebSite structured data (JSON-LD) with Sitelinks Searchbox
 */
export function getWebsiteJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": `${siteConfig.seo.siteUrl}/#website`,
    url: siteConfig.seo.siteUrl,
    name: siteConfig.brand.name,
    description: siteConfig.brand.description,
    publisher: {
      "@id": `${siteConfig.seo.siteUrl}/#organization`,
    },
    potentialAction: {
      "@type": "SearchAction",
      target: {
        "@type": "EntryPoint",
        urlTemplate: `${siteConfig.seo.siteUrl}/search?q={search_term_string}`,
      },
      "query-input": "required name=search_term_string",
    },
  };
}

/**
 * Generates Schema.org Product structured data (JSON-LD)
 */
export function getProductJsonLd(product: {
  name: string;
  description?: string;
  image?: string;
  sku?: string;
  price: number;
  currency?: string;
  inStock?: boolean;
  slug: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    description: product.description || siteConfig.brand.description,
    image: product.image || siteConfig.images.placeholders.product,
    sku: product.sku || product.slug,
    brand: {
      "@type": "Brand",
      name: siteConfig.brand.name,
    },
    offers: {
      "@type": "Offer",
      url: `${siteConfig.seo.siteUrl}/products/${product.slug}`,
      priceCurrency: product.currency || siteConfig.brand.currency,
      price: product.price,
      availability: product.inStock !== false
        ? "https://schema.org/InStock"
        : "https://schema.org/OutOfStock",
      seller: {
        "@type": "Organization",
        name: siteConfig.brand.name,
      },
    },
  };
}


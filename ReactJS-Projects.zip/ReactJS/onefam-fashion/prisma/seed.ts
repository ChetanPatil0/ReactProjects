import { PrismaClient, ProductStatus, DiscountType } from "@prisma/client";
import * as argon2 from "argon2";

const prisma = new PrismaClient();

async function main() {
  console.log("--------------------------------------------------");
  console.log("OneFam Fashion - Comprehensive Database Reseed");
  console.log("--------------------------------------------------");

  // ==========================================
  // STEP 1: CLEAR ALL EXISTING DATA IN DB
  // ==========================================
  console.log("Clearing all existing database records...");

  await prisma.orderStatusHistory.deleteMany();
  await prisma.payment.deleteMany();
  await prisma.invoice.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.customer.deleteMany();

  await prisma.promotionProduct.deleteMany();
  await prisma.promotionCategory.deleteMany();
  await prisma.promotionCollection.deleteMany();
  await prisma.promotion.deleteMany();

  await prisma.collectionProduct.deleteMany();
  await prisma.collection.deleteMany();

  await prisma.productImage.deleteMany();
  await prisma.productVariant.deleteMany();
  await prisma.product.deleteMany();
  await prisma.category.deleteMany();

  await prisma.heroSlide.deleteMany();
  await prisma.banner.deleteMany();
  await prisma.homepageSection.deleteMany();

  await prisma.adminSession.deleteMany();
  await prisma.passwordResetToken.deleteMany();
  await prisma.adminUser.deleteMany();
  await prisma.storeSettings.deleteMany();
  await prisma.invoiceTemplate.deleteMany();

  console.log("✓ Database successfully wiped clean.");

  // ==========================================
  // STEP 2: ADMIN USER
  // ==========================================
  const passwordHash = await argon2.hash(
    process.env.ADMIN_PASSWORD || "Admin@OneFam2026!",
    { type: argon2.argon2id }
  );

  const admin = await prisma.adminUser.create({
    data: {
      email: process.env.ADMIN_EMAIL || "admin@onefamfashion.com",
      passwordHash,
      name: "OneFam Administrator",
      role: "ADMIN",
      isActive: true,
    },
  });
  console.log(`✓ Admin user created: ${admin.email} / Admin@OneFam2026!`);

  // ==========================================
  // STEP 3: STORE SETTINGS
  // ==========================================
  await prisma.storeSettings.create({
    data: {
      storeName: "OneFam Fashion",
      logoUrl: "/logo/onefam-logo.svg",
      supportEmail: "care@onefamfashion.com",
      supportPhone: "+91 98765 43210",
      whatsappNumber: "919876543210",
      address: "OneFam Fashion Studio, 104 Design Boulevard, Indiranagar, Bengaluru, KA 560038",
      currency: "INR",
      currencySymbol: "₹",
      announcementBar: "✨ Festive Season Launch: Complimentary express packaging & doorstep delivery on all orders!",
    },
  });
  console.log("✓ Store settings initialized");

  // ==========================================
  // STEP 4: CATEGORIES (Hierarchical: Men, Women, Kids)
  // ==========================================
  const categoryDefs = [
    {
      name: "Men",
      slug: "men",
      description: "Contemporary menswear crafted for effortless modern sophistication and all-day comfort.",
      imagePath: "https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?q=80&w=900&auto=format&fit=crop",
      subcategories: [
        { name: "T-Shirts & Polos", slug: "men-t-shirts", description: "Heavyweight cotton oversized tees and slim piqué polos." },
        { name: "Casual & Linen Shirts", slug: "men-shirts", description: "Bespoke linen, resort-collar shirts and structured overshirts." },
        { name: "Denim & Jeans", slug: "men-jeans", description: "Selvedge denim, relaxed straight cuts and tapered silhouettes." },
        { name: "Trousers & Chinos", slug: "men-trousers", description: "Pleated tailored trousers and breathable cotton stretch chinos." },
      ],
    },
    {
      name: "Women",
      slug: "women",
      description: "Fluid elegance, refined textiles, modern silhouettes and statement dresses.",
      imagePath: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=900&auto=format&fit=crop",
      subcategories: [
        { name: "Dresses & Jumpsuits", slug: "women-dresses", description: "Daytime maxi dresses, slip gowns and tailored jumpsuits." },
        { name: "Tops & Blouses", slug: "women-tops", description: "Architectural tops, draped silk-blend blouses and organic knits." },
        { name: "Ethnic Kurtis & Sets", slug: "women-kurtis", description: "Hand-embellished contemporary kurtis and co-ord festive sets." },
        { name: "Pants & Skirts", slug: "women-pants", description: "Wide-leg trousers, bias-cut satin skirts and relaxed cargo pants." },
      ],
    },
    {
      name: "Kids",
      slug: "kids",
      description: "Playful, comfortable and durable apparel designed for children to explore in style.",
      imagePath: "https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?q=80&w=900&auto=format&fit=crop",
      subcategories: [
        { name: "Boys Apparel", slug: "kids-boys", description: "Soft cotton shirts, playful graphic tees and comfy joggers." },
        { name: "Girls Apparel", slug: "kids-girls", description: "Whimsical floral frocks, dungarees and everyday basics." },
        { name: "Clothing Sets & Rompers", slug: "kids-sets", description: "Coordinated festive sets, twin sets and breathable rompers." },
      ],
    },
  ];

  const categoryMap = new Map<string, string>();

  let catDisplayOrder = 1;
  for (const parent of categoryDefs) {
    const parentCat = await prisma.category.create({
      data: {
        name: parent.name,
        slug: parent.slug,
        description: parent.description,
        imagePath: parent.imagePath,
        isActive: true,
        displayOrder: catDisplayOrder++,
      },
    });
    categoryMap.set(parent.slug, parentCat.id);

    let subIndex = 1;
    for (const sub of parent.subcategories) {
      const subCat = await prisma.category.create({
        data: {
          name: sub.name,
          slug: sub.slug,
          description: sub.description,
          parentId: parentCat.id,
          isActive: true,
          displayOrder: subIndex++,
        },
      });
      categoryMap.set(sub.slug, subCat.id);
    }
  }
  console.log("✓ Categories and subcategories seeded");

  // ==========================================
  // STEP 5: COLLECTIONS
  // ==========================================
  const collectionsData = [
    {
      title: "New Arrivals 2026",
      slug: "new-arrivals",
      description: "The latest seasonal arrivals blending architectural silhouettes with tactile luxury fabrics.",
      coverImage: "https://images.unsplash.com/photo-1469334031218-e382a71b716b?q=80&w=1200&auto=format&fit=crop",
    },
    {
      title: "Urban Minimalist",
      slug: "urban-minimalist",
      description: "Clean lines, monochrome accents, and understated luxury for everyday city dressing.",
      coverImage: "https://images.unsplash.com/photo-1445205170230-053b83016050?q=80&w=1200&auto=format&fit=crop",
    },
    {
      title: "Festive Bloom",
      slug: "festive-bloom",
      description: "Rich tones, intricate brocades and modern festive silhouettes crafted for special celebrations.",
      coverImage: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1200&auto=format&fit=crop",
    },
    {
      title: "Resort & Linen Edit",
      slug: "resort-linen",
      description: "Sun-drenched hues and ultra-breathable European linens designed for holiday ease.",
      coverImage: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1200&auto=format&fit=crop",
    },
  ];

  const collectionMap = new Map<string, string>();
  for (const c of collectionsData) {
    const col = await prisma.collection.create({
      data: {
        title: c.title,
        slug: c.slug,
        description: c.description,
        coverImage: c.coverImage,
        isActive: true,
      },
    });
    collectionMap.set(c.slug, col.id);
  }
  console.log("✓ Collections seeded");

  // ==========================================
  // STEP 6: HERO SLIDES (HTML Code Overlay)
  // ==========================================
  await prisma.heroSlide.createMany({
    data: [
      {
        title: "Summer Linen & Resort Atelier 2026",
        description: `<div class="space-y-4 max-w-xl">
  <span class="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-[#191720]/80 text-[#C6F542] border border-[#C6F542]/30 backdrop-blur-md">
    <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
    New Season · 2026 Edition
  </span>
  <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black text-[#FCFAF4] tracking-tight leading-[1.08]">
    Architectural Silhouettes &amp; <span class="text-[#C6F542]">Pure Linen</span>
  </h1>
  <p class="text-xs sm:text-sm md:text-base text-[#FCFAF4]/90 leading-relaxed max-w-lg">
    Curated ready-to-wear tailored with breathable natural fabrics. Order directly on WhatsApp with complimentary doorstep delivery.
  </p>
  <div class="pt-2 flex flex-wrap items-center gap-3">
    <a href="/collections/new-arrivals" class="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-[#7137C8] hover:bg-[#7137C8]/90 text-white font-bold text-xs shadow-lg transition">
      <span>Explore Collection</span>
      <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
    </a>
    <a href="/offers" class="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/40 text-white hover:bg-white/10 font-semibold text-xs backdrop-blur-xs transition">
      View Offers
    </a>
  </div>
</div>`,
        desktopImage: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=1920&auto=format&fit=crop",
        mobileImage: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=800&auto=format&fit=crop",
        sortOrder: 1,
        isActive: true,
      },
      {
        title: "Festive Zari & Chanderi Silk",
        description: `<div class="space-y-4 max-w-xl">
  <span class="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-[#F45B45] text-white shadow-md">
    🔥 Special Limited Edition
  </span>
  <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black text-[#FCFAF4] tracking-tight leading-[1.08]">
    Festive Zari &amp; <span class="text-[#C6F542]">Chanderi Silk</span>
  </h1>
  <p class="text-xs sm:text-sm md:text-base text-[#FCFAF4]/90 leading-relaxed max-w-lg">
    Handcrafted celebratory co-ords with delicate gold zari embroidery. Available now for seamless concierge WhatsApp ordering.
  </p>
  <div class="pt-2 flex flex-wrap items-center gap-3">
    <a href="/women" class="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-[#7137C8] hover:bg-[#7137C8]/90 text-white font-bold text-xs shadow-lg transition">
      <span>Shop Women's Edit</span>
      <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
    </a>
    <a href="/collections/festive-bloom" class="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/40 text-white hover:bg-white/10 font-semibold text-xs backdrop-blur-xs transition">
      Festive Lookbook
    </a>
  </div>
</div>`,
        desktopImage: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1920&auto=format&fit=crop",
        mobileImage: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=800&auto=format&fit=crop",
        sortOrder: 2,
        isActive: true,
      },
      {
        title: "Little Wonders: Kids Atelier",
        description: `<div class="space-y-4 max-w-xl">
  <span class="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-[#191720]/80 text-[#C6F542] border border-[#C6F542]/30 backdrop-blur-md">
    ✨ Gentle Organic Cottons
  </span>
  <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black text-[#FCFAF4] tracking-tight leading-[1.08]">
    Little Wonders: <span class="text-[#C6F542]">Kids Atelier</span>
  </h1>
  <p class="text-xs sm:text-sm md:text-base text-[#FCFAF4]/90 leading-relaxed max-w-lg">
    Breathable festive apparel and charming playwear tailored for delicate young skin and joyful celebrations.
  </p>
  <div class="pt-2 flex flex-wrap items-center gap-3">
    <a href="/kids" class="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-[#7137C8] hover:bg-[#7137C8]/90 text-white font-bold text-xs shadow-lg transition">
      <span>Explore Kids</span>
      <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
    </a>
  </div>
</div>`,
        desktopImage: "https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?q=80&w=1920&auto=format&fit=crop",
        mobileImage: "https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?q=80&w=800&auto=format&fit=crop",
        sortOrder: 3,
        isActive: true,
      },
    ],
  });
  console.log("✓ Hero slides seeded");

  // ==========================================
  // STEP 7: PRODUCTS WITH PRIMARY THUMBNAIL, GENERAL GALLERY & VARIANT IMAGES
  // ==========================================
  const productsSeed = [
    {
      name: "Oversized Heavyweight Cotton Tee",
      slug: "oversized-heavyweight-cotton-tee",
      sku: "OFF-M-TEE-001",
      categorySlug: "men-t-shirts",
      shortDescription: "300 GSM combed cotton drop-shoulder silhouette with structured crew neckline.",
      description: "Crafted from 100% long-staple organic cotton in a dense 300 GSM weight. Features pre-shrunk fabric, dropped shoulders, reinforced twin-needle stitching and a high ribbed collar that retains its shape wear after wear.",
      regularPrice: 1899,
      isFeatured: true,
      isTrending: true,
      isNewArrival: true,
      status: ProductStatus.PUBLISHED,
      collections: ["urban-minimalist", "new-arrivals"],
      // Primary thumbnail separated, general gallery, and variant-wise photos!
      images: [
        { path: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=1200&auto=format&fit=crop", alt: "Oversized Heavyweight Cotton Tee", isPrimary: true, sortOrder: 0 },
        { path: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?q=80&w=1200&auto=format&fit=crop", alt: "Fabric Drape & Detail", isPrimary: false, sortOrder: 1 },
        { path: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=1200&auto=format&fit=crop", alt: "variant:Obsidian Black", isPrimary: false, sortOrder: 2 },
        { path: "https://images.unsplash.com/photo-1581655353564-df123a1eb820?q=80&w=1200&auto=format&fit=crop", alt: "variant:Bone White", isPrimary: false, sortOrder: 3 },
      ],
      variants: [
        { size: "S", color: "Obsidian Black", colorHex: "#191720", sku: "OFF-M-TEE-001-BLK-S", stock: 15 },
        { size: "M", color: "Obsidian Black", colorHex: "#191720", sku: "OFF-M-TEE-001-BLK-M", stock: 24 },
        { size: "L", color: "Obsidian Black", colorHex: "#191720", sku: "OFF-M-TEE-001-BLK-L", stock: 18 },
        { size: "XL", color: "Obsidian Black", colorHex: "#191720", sku: "OFF-M-TEE-001-BLK-XL", stock: 10 },
        { size: "M", color: "Bone White", colorHex: "#F5F3EF", sku: "OFF-M-TEE-001-WHT-M", stock: 20 },
        { size: "L", color: "Bone White", colorHex: "#F5F3EF", sku: "OFF-M-TEE-001-WHT-L", stock: 16 },
      ],
    },
    {
      name: "Relaxed French Linen Camp Shirt",
      slug: "relaxed-french-linen-camp-shirt",
      sku: "OFF-M-SHIRT-002",
      categorySlug: "men-shirts",
      shortDescription: "Garment-washed pure French flax with an airy retro camp collar.",
      description: "Tailored from 100% Normandy flax linen with a natural textured drape. Features genuine river shell buttons, a relaxed spread collar, subtle side hem gussets and a soft hand feel that softens beautifully with every wash.",
      regularPrice: 3499,
      isFeatured: true,
      isTrending: false,
      isNewArrival: true,
      status: ProductStatus.PUBLISHED,
      collections: ["resort-linen", "new-arrivals"],
      images: [
        { path: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=1200&auto=format&fit=crop", alt: "Relaxed French Linen Camp Shirt", isPrimary: true, sortOrder: 0 },
        { path: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=1200&auto=format&fit=crop", alt: "Linen Texture Close Up", isPrimary: false, sortOrder: 1 },
        { path: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=1200&auto=format&fit=crop", alt: "variant:Sage Olive", isPrimary: false, sortOrder: 2 },
        { path: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=1200&auto=format&fit=crop", alt: "variant:Sand Dune", isPrimary: false, sortOrder: 3 },
      ],
      variants: [
        { size: "M", color: "Sage Olive", colorHex: "#708238", sku: "OFF-M-SHIRT-002-SAG-M", stock: 12 },
        { size: "L", color: "Sage Olive", colorHex: "#708238", sku: "OFF-M-SHIRT-002-SAG-L", stock: 14 },
        { size: "XL", color: "Sage Olive", colorHex: "#708238", sku: "OFF-M-SHIRT-002-SAG-XL", stock: 8 },
        { size: "M", color: "Sand Dune", colorHex: "#E6D7B9", sku: "OFF-M-SHIRT-002-SND-M", stock: 15 },
        { size: "L", color: "Sand Dune", colorHex: "#E6D7B9", sku: "OFF-M-SHIRT-002-SND-L", stock: 10 },
      ],
    },
    {
      name: "Draped Asymmetric Satin Midi Dress",
      slug: "draped-asymmetric-satin-midi-dress",
      sku: "OFF-W-DRS-003",
      categorySlug: "women-dresses",
      shortDescription: "Liquid viscose satin with a gathered waist, side slit and cowl neck.",
      description: "An evocative evening piece cut on the bias to cascade smoothly across the body. Features adjustable delicate straps, a sculpted waist cinch and a flowing midi-length hemline with an alluring side split.",
      regularPrice: 4899,
      isFeatured: true,
      isTrending: true,
      isNewArrival: true,
      status: ProductStatus.PUBLISHED,
      collections: ["urban-minimalist", "new-arrivals"],
      images: [
        { path: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?q=80&w=1200&auto=format&fit=crop", alt: "Draped Asymmetric Satin Midi Dress", isPrimary: true, sortOrder: 0 },
        { path: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?q=80&w=1200&auto=format&fit=crop", alt: "Satin Dress Movement", isPrimary: false, sortOrder: 1 },
        { path: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?q=80&w=1200&auto=format&fit=crop", alt: "variant:Royal Plum", isPrimary: false, sortOrder: 2 },
        { path: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?q=80&w=1200&auto=format&fit=crop", alt: "variant:Champagne Gold", isPrimary: false, sortOrder: 3 },
      ],
      variants: [
        { size: "XS", color: "Royal Plum", colorHex: "#7137C8", sku: "OFF-W-DRS-003-PLM-XS", stock: 8 },
        { size: "S", color: "Royal Plum", colorHex: "#7137C8", sku: "OFF-W-DRS-003-PLM-S", stock: 14 },
        { size: "M", color: "Royal Plum", colorHex: "#7137C8", sku: "OFF-W-DRS-003-PLM-M", stock: 12 },
        { size: "L", color: "Royal Plum", colorHex: "#7137C8", sku: "OFF-W-DRS-003-PLM-L", stock: 6 },
        { size: "S", color: "Champagne Gold", colorHex: "#F7E7CE", sku: "OFF-W-DRS-003-GLD-S", stock: 10 },
        { size: "M", color: "Champagne Gold", colorHex: "#F7E7CE", sku: "OFF-W-DRS-003-GLD-M", stock: 11 },
      ],
    },
    {
      name: "Handcrafted Zari Chanderi Kurti Set",
      slug: "handcrafted-zari-chanderi-kurti-set",
      sku: "OFF-W-KRT-004",
      categorySlug: "women-kurtis",
      shortDescription: "Chanderi silk blend kurti with hand-embroidered metallic zari yoke and organza dupatta.",
      description: "A tribute to Indian heritage woven on handlooms with fine silk yarns and gold metallic thread highlights. Paired with comfortable scalloped cropped pants and an ethereal hand-painted organza dupatta with tassel accents.",
      regularPrice: 5999,
      isFeatured: true,
      isTrending: true,
      isNewArrival: false,
      status: ProductStatus.PUBLISHED,
      collections: ["festive-bloom"],
      images: [
        { path: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop", alt: "Handcrafted Zari Chanderi Kurti Set", isPrimary: true, sortOrder: 0 },
        { path: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1200&auto=format&fit=crop", alt: "Zari Yoke & Embroidery Details", isPrimary: false, sortOrder: 1 },
        { path: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop", alt: "variant:Emerald Mint", isPrimary: false, sortOrder: 2 },
      ],
      variants: [
        { size: "S", color: "Emerald Mint", colorHex: "#2E8B57", sku: "OFF-W-KRT-004-MNT-S", stock: 9 },
        { size: "M", color: "Emerald Mint", colorHex: "#2E8B57", sku: "OFF-W-KRT-004-MNT-M", stock: 16 },
        { size: "L", color: "Emerald Mint", colorHex: "#2E8B57", sku: "OFF-W-KRT-004-MNT-L", stock: 12 },
        { size: "XL", color: "Emerald Mint", colorHex: "#2E8B57", sku: "OFF-W-KRT-004-MNT-XL", stock: 5 },
      ],
    },
    {
      name: "Tailored High-Waist Pleated Trousers",
      slug: "tailored-high-waist-pleated-trousers",
      sku: "OFF-W-PNT-007",
      categorySlug: "women-pants",
      shortDescription: "Double-pleated wide-leg drape tailored from wrinkle-resistant poly-viscose blend.",
      description: "Effortlessly architectural trousers engineered with a clean high-rise waistband, deep inverted front pleats, and generous slash pockets.",
      regularPrice: 3299,
      isFeatured: true,
      isTrending: true,
      isNewArrival: true,
      status: ProductStatus.PUBLISHED,
      collections: ["urban-minimalist", "new-arrivals"],
      images: [
        { path: "https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=1200&auto=format&fit=crop", alt: "Tailored High-Waist Pleated Trousers", isPrimary: true, sortOrder: 0 },
        { path: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1200&auto=format&fit=crop", alt: "Pleat Structure & Side View", isPrimary: false, sortOrder: 1 },
        { path: "https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=1200&auto=format&fit=crop", alt: "variant:Obsidian Black", isPrimary: false, sortOrder: 2 },
        { path: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1200&auto=format&fit=crop", alt: "variant:Oat Milk", isPrimary: false, sortOrder: 3 },
      ],
      variants: [
        { size: "S", color: "Obsidian Black", colorHex: "#191720", sku: "OFF-W-PNT-007-BLK-S", stock: 12 },
        { size: "M", color: "Obsidian Black", colorHex: "#191720", sku: "OFF-W-PNT-007-BLK-M", stock: 18 },
        { size: "L", color: "Obsidian Black", colorHex: "#191720", sku: "OFF-W-PNT-007-BLK-L", stock: 10 },
        { size: "M", color: "Oat Milk", colorHex: "#E6D7B9", sku: "OFF-W-PNT-007-OAT-M", stock: 14 },
      ],
    },
    {
      name: "Relaxed Japanese Selvedge Denim",
      slug: "relaxed-japanese-selvedge-denim",
      sku: "OFF-M-JNS-008",
      categorySlug: "men-jeans",
      shortDescription: "13.5 oz shuttle-loom selvedge denim with natural indigo fade and button fly.",
      description: "Woven in Kurashiki on vintage Toyoda shuttle looms. Features custom matte gunmetal hardware, hidden back pocket rivets, and vegetable-tanned leather patch.",
      regularPrice: 4299,
      isFeatured: true,
      isTrending: false,
      isNewArrival: true,
      status: ProductStatus.PUBLISHED,
      collections: ["urban-minimalist", "new-arrivals"],
      images: [
        { path: "https://images.unsplash.com/photo-1542272604-780c96856592?q=80&w=1200&auto=format&fit=crop", alt: "Relaxed Japanese Selvedge Denim", isPrimary: true, sortOrder: 0 },
        { path: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=1200&auto=format&fit=crop", alt: "Redline Selvedge ID & Hem Detail", isPrimary: false, sortOrder: 1 },
        { path: "https://images.unsplash.com/photo-1542272604-780c96856592?q=80&w=1200&auto=format&fit=crop", alt: "variant:Indigo Wash", isPrimary: false, sortOrder: 2 },
      ],
      variants: [
        { size: "30", color: "Indigo Wash", colorHex: "#1B2A4A", sku: "OFF-M-JNS-008-IND-30", stock: 10 },
        { size: "32", color: "Indigo Wash", colorHex: "#1B2A4A", sku: "OFF-M-JNS-008-IND-32", stock: 16 },
        { size: "34", color: "Indigo Wash", colorHex: "#1B2A4A", sku: "OFF-M-JNS-008-IND-34", stock: 14 },
        { size: "36", color: "Indigo Wash", colorHex: "#1B2A4A", sku: "OFF-M-JNS-008-IND-36", stock: 8 },
      ],
    },
    {
      name: "Boy's Organic Cotton Festive Kurta Set",
      slug: "boys-organic-cotton-festive-kurta-set",
      sku: "OFF-K-BOY-005",
      categorySlug: "kids-boys",
      shortDescription: "Ultra-gentle GOTS certified organic cotton festive kurta with soft drawstring pajama.",
      description: "Designed specifically for sensitive young skin. Features soft cotton lining, non-scratchy mandarin collar, wooden buttons and breathable elasticated waist bottoms allowing full freedom to run and play.",
      regularPrice: 2299,
      isFeatured: false,
      isTrending: false,
      isNewArrival: true,
      status: ProductStatus.PUBLISHED,
      collections: ["festive-bloom", "new-arrivals"],
      images: [
        { path: "https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?q=80&w=1200&auto=format&fit=crop", alt: "Boy's Organic Cotton Festive Kurta Set", isPrimary: true, sortOrder: 0 },
        { path: "https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?q=80&w=1200&auto=format&fit=crop", alt: "variant:Sunny Ochre", isPrimary: false, sortOrder: 1 },
      ],
      variants: [
        { size: "3-4Y", color: "Sunny Ochre", colorHex: "#DAA520", sku: "OFF-K-BOY-005-OCH-3Y", stock: 10 },
        { size: "5-6Y", color: "Sunny Ochre", colorHex: "#DAA520", sku: "OFF-K-BOY-005-OCH-5Y", stock: 12 },
        { size: "7-8Y", color: "Sunny Ochre", colorHex: "#DAA520", sku: "OFF-K-BOY-005-OCH-7Y", stock: 8 },
      ],
    },
    {
      name: "Girl's Tiered Pastel Blossom Frock",
      slug: "girls-tiered-pastel-blossom-frock",
      sku: "OFF-K-GRL-006",
      categorySlug: "kids-girls",
      shortDescription: "Layered cotton voile frock with hand-printed botanical florals and bow back sash.",
      description: "Crafted in whisper-light breathable cotton voile with cotton mulmul lining. Tiered frill skirt with comfortable flutter sleeves and back button fastening.",
      regularPrice: 1999,
      isFeatured: false,
      isTrending: true,
      isNewArrival: true,
      status: ProductStatus.PUBLISHED,
      collections: ["new-arrivals"],
      images: [
        { path: "https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?q=80&w=1200&auto=format&fit=crop", alt: "Girl's Tiered Pastel Blossom Frock", isPrimary: true, sortOrder: 0 },
        { path: "https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?q=80&w=1200&auto=format&fit=crop", alt: "variant:Blush Pink", isPrimary: false, sortOrder: 1 },
      ],
      variants: [
        { size: "2-3Y", color: "Blush Pink", colorHex: "#FFB6C1", sku: "OFF-K-GRL-006-PNK-2Y", stock: 8 },
        { size: "4-5Y", color: "Blush Pink", colorHex: "#FFB6C1", sku: "OFF-K-GRL-006-PNK-4Y", stock: 14 },
        { size: "6-7Y", color: "Blush Pink", colorHex: "#FFB6C1", sku: "OFF-K-GRL-006-PNK-6Y", stock: 10 },
      ],
    },
  ];

  const createdProductsMap = new Map<string, any>();

  for (const p of productsSeed) {
    const categoryId = categoryMap.get(p.categorySlug);
    const product = await prisma.product.create({
      data: {
        name: p.name,
        slug: p.slug,
        sku: p.sku,
        shortDescription: p.shortDescription,
        description: p.description,
        regularPrice: p.regularPrice,
        discountPrice: null, // Dynamic discounts are now calculated via Offers & Discounts!
        categoryId,
        isFeatured: p.isFeatured,
        isTrending: p.isTrending,
        isNewArrival: p.isNewArrival,
        status: p.status,
        images: {
          create: p.images.map((img) => ({
            path: img.path,
            altText: img.alt,
            isPrimary: img.isPrimary,
            sortOrder: img.sortOrder,
          })),
        },
        variants: {
          create: p.variants.map((v) => ({
            size: v.size,
            color: v.color,
            colorHex: v.colorHex,
            sku: v.sku,
            stock: v.stock,
            isAvailable: true,
          })),
        },
      },
    });

    createdProductsMap.set(p.slug, product);

    // Connect collections
    for (const colSlug of p.collections) {
      const colId = collectionMap.get(colSlug);
      if (colId) {
        await prisma.collectionProduct.create({
          data: {
            collectionId: colId,
            productId: product.id,
          },
        });
      }
    }
  }
  console.log(`✓ Seeded ${productsSeed.length} fashion pieces with separated thumbnails, galleries, and variant media.`);

  // ==========================================
  // STEP 8: DYNAMIC OFFERS & DISCOUNTS
  // ==========================================
  const summerOffer = await prisma.promotion.create({
    data: {
      name: "Festive Season Launch 2026",
      description: "Exclusive 20% off on all festive kurtis, resort shirts and signature tailored sets.",
      discountType: DiscountType.PERCENTAGE,
      discountValue: 20,
      minPurchase: 1999,
      isActive: true,
      startDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // Active 2 days ago
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // Valid for next 30 days
    },
  });

  const welcomeOffer = await prisma.promotion.create({
    data: {
      name: "First Order Concierge Welcome",
      description: "Flat ₹400 off on first verified WhatsApp order across menswear and trousers.",
      discountType: DiscountType.FIXED,
      discountValue: 400,
      minPurchase: 2499,
      isActive: true,
      startDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      endDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
    },
  });

  // Attach products to Summer Offer (20% OFF)
  const summerProductSlugs = [
    "oversized-heavyweight-cotton-tee",
    "relaxed-french-linen-camp-shirt",
    "draped-asymmetric-satin-midi-dress",
    "handcrafted-zari-chanderi-kurti-set",
  ];
  for (const slug of summerProductSlugs) {
    const prod = createdProductsMap.get(slug);
    if (prod) {
      await prisma.promotionProduct.create({
        data: {
          promotionId: summerOffer.id,
          productId: prod.id,
        },
      });
    }
  }

  // Attach products to Welcome Offer (₹400 FLAT OFF)
  const welcomeProductSlugs = [
    "tailored-high-waist-pleated-trousers",
    "relaxed-japanese-selvedge-denim",
  ];
  for (const slug of welcomeProductSlugs) {
    const prod = createdProductsMap.get(slug);
    if (prod) {
      await prisma.promotionProduct.create({
        data: {
          promotionId: welcomeOffer.id,
          productId: prod.id,
        },
      });
    }
  }
  console.log("✓ Dynamic Offers & Discounts seeded and linked to products.");

  // ==========================================
  // STEP 9: INVOICE TEMPLATE
  // ==========================================
  await prisma.invoiceTemplate.create({
    data: {
      name: "Standard OneFam Editorial Template",
      isDefault: true,
      type: "VISUAL",
      visualConfig: {
        primaryColor: "#7137C8",
        textColor: "#191720",
        accentColor: "#F45B45",
        fontFamily: "Plus Jakarta Sans, sans-serif",
        showGst: true,
        showBankDetails: true,
        footerText: "Thank you for shopping with OneFam Fashion. For bespoke inquiries or size adjustments, reach our WhatsApp concierge.",
      },
      customHtml: `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  body { font-family: 'Plus Jakarta Sans', sans-serif; color: #191720; margin: 0; padding: 40px; background: #fff; }
  .header { display: flex; justify-content: space-between; border-bottom: 2px solid #7137C8; padding-bottom: 24px; margin-bottom: 30px; }
  .logo { font-size: 26px; font-weight: 800; color: #7137C8; letter-spacing: -0.5px; }
  .inv-meta { text-align: right; }
  .customer-box { margin-bottom: 30px; background: #FCFAF4; padding: 18px; border-radius: 8px; border: 1px solid #E8E6E1; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
  th { text-align: left; padding: 12px; background: #F5F3EF; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #E8E6E1; }
  td { padding: 14px 12px; border-bottom: 1px solid #E8E6E1; font-size: 14px; }
  .totals { width: 320px; margin-left: auto; margin-bottom: 30px; }
  .totals-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 14px; }
  .totals-row.grand { font-size: 18px; font-weight: 700; color: #7137C8; border-top: 2px solid #191720; padding-top: 10px; margin-top: 8px; }
  .footer { text-align: center; font-size: 12px; color: #6B6A72; border-top: 1px solid #E8E6E1; padding-top: 20px; }
</style>
</head>
<body>
  <div class="header">
    <div>
      <div class="logo">{{store_name}}</div>
      <p style="margin:4px 0 0; color:#6B6A72; font-size:13px;">Luxury Ready-to-Wear</p>
    </div>
    <div class="inv-meta">
      <h2 style="margin:0; font-size:20px;">INVOICE</h2>
      <p style="margin:4px 0; font-size:13px;"><strong>No:</strong> {{invoice_number}}</p>
      <p style="margin:0; font-size:13px;"><strong>Date:</strong> {{invoice_date}}</p>
      <p style="margin:4px 0 0; font-size:13px;"><strong>Ref:</strong> {{order_reference}}</p>
    </div>
  </div>

  <div class="customer-box">
    <div style="font-size:12px; text-transform:uppercase; color:#6B6A72; font-weight:600; margin-bottom:6px;">Billed To:</div>
    <div style="font-weight:700; font-size:16px;">{{customer_name}}</div>
    <div style="color:#4B4A54; font-size:14px; margin-top:4px;">{{customer_email}} | {{customer_phone}}</div>
    <div style="color:#4B4A54; font-size:14px; margin-top:4px;">{{customer_address}}</div>
  </div>

  <table>
    <thead>
      <tr>
        <th>Item Description</th>
        <th>Variant</th>
        <th style="text-align:center;">Qty</th>
        <th style="text-align:right;">Unit Price</th>
        <th style="text-align:right;">Total</th>
      </tr>
    </thead>
    <tbody>
      {{items_table}}
    </tbody>
  </table>

  <div class="totals">
    <div class="totals-row"><span>Subtotal:</span><span>{{subtotal}}</span></div>
    <div class="totals-row"><span>Discount:</span><span style="color:#F45B45;">-{{discount}}</span></div>
    <div class="totals-row"><span>Shipping:</span><span>{{shipping}}</span></div>
    <div class="totals-row grand"><span>Total Payable:</span><span>{{total}}</span></div>
    <div class="totals-row" style="color:#2E8B57; font-weight:600;"><span>Amount Paid:</span><span>{{amount_paid}}</span></div>
    <div class="totals-row" style="color:#7137C8; font-weight:600;"><span>Balance Due:</span><span>{{balance_due}}</span></div>
  </div>

  <div class="footer">
    <p>{{footer_note}}</p>
  </div>
</body>
</html>`,
    },
  });
  console.log("✓ Default invoice template seeded");

  // ==========================================
  // STEP 10: SAMPLE VERIFIED CUSTOMER & ORDER
  // ==========================================
  const customer = await prisma.customer.create({
    data: {
      name: "Aarav Sharma",
      email: "aarav.sharma@example.com",
      phone: "+91 98201 54321",
      shippingAddress: "Flat 402, Royal Palms Residency, Indiranagar, Bengaluru, KA 560038",
      billingAddress: "Flat 402, Royal Palms Residency, Indiranagar, Bengaluru, KA 560038",
    },
  });

  const sampleProduct = createdProductsMap.get("oversized-heavyweight-cotton-tee");
  if (sampleProduct) {
    const variants = await prisma.productVariant.findMany({
      where: { productId: sampleProduct.id },
    });
    const v = variants[0];

    const order = await prisma.order.create({
      data: {
        orderRef: "ORD-K7M20001",
        customerId: customer.id,
        status: "CONFIRMED",
        paymentStatus: "PARTIALLY_PAID",
        subtotal: 1899,
        discount: 380, // 20% discount from Festive Offer
        shipping: 0,
        tax: 0,
        total: 1519,
        amountPaid: 519,
        balanceDue: 1000,
        customerNotes: "Please deliver before 6 PM on weekdays.",
        adminNotes: "Customer ordered via WhatsApp inquiry. ₹519 advance received via UPI.",
        items: {
          create: [
            {
              productId: sampleProduct.id,
              variantId: v.id,
              productName: sampleProduct.name,
              sku: v.sku,
              size: v.size,
              color: v.color,
              unitPrice: 1519,
              quantity: 1,
              totalPrice: 1519,
            },
          ],
        },
        statusHistory: {
          create: [
            { status: "PENDING_CONFIRMATION", note: "Order placed via WhatsApp Concierge" },
            { status: "CONFIRMED", note: "Verified details with customer on WhatsApp" },
          ],
        },
        payments: {
          create: [
            {
              amount: 519,
              method: "UPI",
              reference: "UPI/329482910482/PAYTM",
              notes: "Advance payment at order confirmation",
            },
          ],
        },
      },
    });
    console.log(`✓ Sample order created: ${order.orderRef}`);
  }

  console.log("--------------------------------------------------");
  console.log("Database successfully seeded with all updated modules!");
  console.log("--------------------------------------------------");
}

main()
  .catch((e) => {
    console.error("Seed error:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

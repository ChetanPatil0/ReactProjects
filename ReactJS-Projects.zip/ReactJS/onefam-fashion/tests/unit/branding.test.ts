import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";

describe("OneFam Fashion - Brand Identity & Design System", () => {
  it("has official OneFam logo and symbol WebP files present in public/logo", () => {
    const publicDir = path.resolve(__dirname, "../../public/logo");
    expect(fs.existsSync(path.join(publicDir, "OneFamFashionDarkLogo.webp"))).toBe(true);
    expect(fs.existsSync(path.join(publicDir, "OneFamFashionWhiteLogo.webp"))).toBe(true);
    expect(fs.existsSync(path.join(publicDir, "OneFamFashionDarkSymbol.webp"))).toBe(true);
  });

  it("verifies official brand colour palette in CSS variables", () => {
    const globalsCss = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/globals.css"),
      "utf8"
    );

    // Official Light Palette Check
    expect(globalsCss).toContain("--royal-violet: #7137c8");
    expect(globalsCss).toContain("--electric-lime: #c6f542");
    expect(globalsCss).toContain("--vermilion: #f45b45");
    expect(globalsCss).toContain("--ink: #191720");
    expect(globalsCss).toContain("--paper: #fcfaf4");
  });

  it("verifies dark mode theme tokens and custom-variant support", () => {
    const globalsCss = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/globals.css"),
      "utf8"
    );

    // Dark Mode Theme Rules
    expect(globalsCss).toContain(".dark {");
    expect(globalsCss).toContain("@custom-variant dark");
    expect(globalsCss).toContain("--background: #110f16");
  });

  it("verifies next-themes ThemeProvider configuration with localStorage persistence and system mode", () => {
    const providerFile = fs.readFileSync(
      path.resolve(__dirname, "../../src/components/providers/theme-provider.tsx"),
      "utf8"
    );

    expect(providerFile).toContain('attribute="class"');
    expect(providerFile).toContain('defaultTheme="system"');
    expect(providerFile).toContain("enableSystem");
    expect(providerFile).toContain('storageKey="onefam-fashion-theme"');
  });

  it("uses Plus Jakarta Sans as primary font-sans", () => {
    const globalsCss = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/globals.css"),
      "utf8"
    );
    expect(globalsCss).toContain("--font-sans: var(--font-plus-jakarta)");
  });

  it("verifies official logo component uses original user assets and handles dark & light variants", () => {
    const logoComponent = fs.readFileSync(
      path.resolve(__dirname, "../../src/components/brand/onefam-logo.tsx"),
      "utf8"
    );
    expect(logoComponent).toContain("OneFamLogo");
    expect(logoComponent).toContain("siteConfig.images.logo.light");
    expect(logoComponent).toContain("siteConfig.images.logo.dark");
    expect(logoComponent).toContain("siteConfig.images.logo.symbol");
  });

  it("verifies homepage uses refined 'Universes of Style' premium terminology with modern editorial card layout", () => {
    const homePage = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/(storefront)/page.tsx"),
      "utf8"
    );

    // Replaced generic 'Shop by Category' with premium luxury fashion 'Universes of Style'
    expect(homePage).toContain("Universes of Style");
    expect(homePage).toContain("Sartorial Realms");
    expect(homePage).not.toContain("Shop by Department");

    // Modern card UI tokens
    expect(homePage).toContain("rounded-[2rem]");
  });

  it("verifies ImageUploader exports deferred uploadImageFile helper for submit-time storage", () => {
    const uploaderCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/components/shared/image-uploader.tsx"),
      "utf8"
    );

    // Exported function for explicit submit-time upload
    expect(uploaderCode).toContain("export async function uploadImageFile");
    expect(uploaderCode).toContain("onFileSelect");
    expect(uploaderCode).toContain("Staged (Stores on submit)");
  });

  it("verifies global BrandLoader component renders authentic logo with luxury tagline animation", () => {
    const loaderCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/components/brand/brand-loader.tsx"),
      "utf8"
    );
    expect(loaderCode).toContain("BrandLoader");
    expect(loaderCode).toContain("<OneFamLogo");
    expect(loaderCode).toContain("Curating Mindful Family Silhouettes");
  });

  it("verifies SocialCommunitySection unifies social community with brand value props in one section box without AI-looking sparkle icons", () => {
    const communityCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/features/storefront/components/social-community-section.tsx"),
      "utf8"
    );
    expect(communityCode).toContain("Join Our Sartorial Community");
    expect(communityCode).toContain("Connect With OneFam");
    expect(communityCode).toContain("Express Shipping");
    expect(communityCode).toContain("Customer Support");
    expect(communityCode).toContain("Pure Materials");
    expect(communityCode).toContain("Transparent Tracking");
    expect(communityCode).not.toContain("Sparkles");

    const homePage = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/(storefront)/page.tsx"),
      "utf8"
    );
    expect(homePage).toContain("<SocialCommunitySection");
    expect(homePage).not.toContain('import { ArrowRight, ArrowUpRight, Sparkles');
  });

  it("verifies mobile filter drawer has smooth right-side slide animations and responsive width", () => {
    const globalsCss = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/globals.css"),
      "utf8"
    );
    expect(globalsCss).toContain("sheetSlideInFromRight");
    expect(globalsCss).toContain("sheetSlideOutToRight");
    expect(globalsCss).toContain('data-side="right"');

    const sheetCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/components/ui/sheet.tsx"),
      "utf8"
    );
    expect(sheetCode).toContain('data-side={side}');
    expect(sheetCode).toContain("w-[88vw]");

    const catalogueView = fs.readFileSync(
      path.resolve(__dirname, "../../src/features/storefront/components/catalogue-view.tsx"),
      "utf8"
    );
    expect(catalogueView).toContain('side="right"');
    expect(catalogueView).toContain("w-[88vw]");
  });

  it("verifies header announcement bar smoothly hides on scroll", () => {
    const headerCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/features/storefront/components/header/header.tsx"),
      "utf8"
    );
    expect(headerCode).toContain("isScrolled");
    expect(headerCode).toContain("window.scrollY > 20");
    expect(headerCode).toContain("max-h-0 opacity-0");
  });
});

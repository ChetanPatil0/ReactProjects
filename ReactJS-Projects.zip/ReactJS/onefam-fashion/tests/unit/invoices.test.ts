import { describe, it, expect } from "vitest";
import { buildInvoicePdf } from "@/server/services/pdf-invoice-generator";
import { generateQrSvg, generateQrDataUrl } from "@/lib/qr-code";
import fs from "fs";
import path from "path";

describe("OneFam Fashion - Invoices, PDF Generation & Public QR Verification", () => {
  it("builds standards-compliant binary PDF with %PDF-1.4 header and %%EOF trailer", () => {
    const pdfBuffer = buildInvoicePdf({
      invoiceNumber: "INV-2026-TEST01",
      invoiceDate: "06 Nov 2026",
      orderRef: "ORD-K7M20001",
      storeName: "OneFam Fashion",
      gstNumber: "29AAAAA0000A1Z5",
      customerName: "Aarav Sharma",
      customerPhone: "+91 98201 54321",
      customerAddress: "Indiranagar, Bengaluru, 560038",
      items: [
        {
          name: "Bespoke Linen Camp Shirt",
          variant: "M / Sage Green",
          qty: 2,
          unitPrice: 1999,
          totalPrice: 3998,
        },
      ],
      subtotal: 3998,
      discount: 200,
      shipping: 0,
      tax: 0,
      total: 3798,
      amountPaid: 3798,
      balanceDue: 0,
      verificationUrl: "https://onefamfashion.com/orders/verify/ORD-K7M20001",
    });

    expect(pdfBuffer).toBeInstanceOf(Uint8Array);
    const pdfStr = Buffer.from(pdfBuffer).toString("latin1");

    // Standards-compliant PDF 1.4 checks
    expect(pdfStr.startsWith("%PDF-1.4")).toBe(true);
    expect(pdfStr).toContain("/Type /Catalog");
    expect(pdfStr).toContain("/Type /Pages");
    expect(pdfStr).toContain("/Type /Page");
    expect(pdfStr).toContain("INV-2026-TEST01");
    expect(pdfStr).toContain("ORD-K7M20001");
    expect(pdfStr).toContain("Aarav Sharma");
    expect(pdfStr).toContain("%%EOF");
  });

  it("verifies QR code generator creates SVG with clean vector paths for order verification", () => {
    const url = "https://onefamfashion.com/orders/verify/ORD-K7M20001";
    const svg = generateQrSvg(url, { size: 100 });

    expect(svg).toContain("<svg");
    expect(svg).toContain("<path");
    expect(svg).toContain('width="100"');
    expect(svg).toContain('height="100"');
  });

  it("verifies ImageUploader integrates the ImageSnipperModal with crop and rotation controls", () => {
    const uploaderCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/components/shared/image-uploader.tsx"),
      "utf8"
    );
    expect(uploaderCode).toContain("ImageSnipperModal");
    expect(uploaderCode).toContain("Snip / Crop");
    expect(uploaderCode).toContain("handleSnippedImage");

    const snipperCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/components/shared/image-snipper-modal.tsx"),
      "utf8"
    );
    expect(snipperCode).toContain("ImageSnipperModal");
    expect(snipperCode).toContain("AspectRatioPreset");
    expect(snipperCode).toContain("Rotate");
    expect(snipperCode).toContain("Apply Snipping");
  });

  it("verifies store settings page supports main store logo upload without invoice-specific clutter", () => {
    const settingsCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/admin/(protected)/settings/page.tsx"),
      "utf8"
    );
    expect(settingsCode).toContain("logoUrl");
    expect(settingsCode).toContain("Store Brand Logo");
    expect(settingsCode).toContain("ImageUploader");
    expect(settingsCode).not.toContain("Invoice Header Preview");
  });

  it("verifies invoice templates page supports {{logo}}, {{qr_code}}, {{store_email}}, and {{whatsapp_number}} in custom HTML code", () => {
    const templateCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/admin/(protected)/invoice-templates/page.tsx"),
      "utf8"
    );
    expect(templateCode).toContain("{{logo}}");
    expect(templateCode).toContain("{{qr_code}}");
    expect(templateCode).toContain("{{gst_number}}");
    expect(templateCode).toContain("{{store_email}}");
    expect(templateCode).toContain("{{whatsapp_number}}");

    const serviceCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/server/services/invoice-service.ts"),
      "utf8"
    );
    expect(serviceCode).toContain("{{store_email}}");
    expect(serviceCode).toContain("{{whatsapp_number}}");
  });

  it("verifies invoice templates page and API support reset to official default", () => {
    const templateCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/admin/(protected)/invoice-templates/page.tsx"),
      "utf8"
    );
    expect(templateCode).toContain("Reset to Default");
    expect(templateCode).toContain("OFFICIAL_DEFAULT_HTML");
    expect(templateCode).toContain("Revert Code to Default");

    const apiRouteCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/api/invoice-templates/route.ts"),
      "utf8"
    );
    expect(apiRouteCode).toContain("export async function DELETE");
    expect(apiRouteCode).toContain("deleteMany");
  });

  it("verifies public order verification page safely queries orderRef without crashing PostgreSQL UUID column and provides standalone clean layout with logo and Go to Home button", () => {
    const verifyCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/orders/verify/[orderRef]/page.tsx"),
      "utf8"
    );
    expect(verifyCode).toContain("Officially Verified Order");
    expect(verifyCode).toContain("orderRef");
    expect(verifyCode).toContain("isUuid");
    expect(verifyCode).toContain("Contact Us");
    expect(verifyCode).not.toContain("WhatsApp");
    expect(verifyCode).toContain("Official PDF Invoice");
    expect(verifyCode).toContain("Go to Home");
    expect(verifyCode).toContain("OneFamLogo");
    // Ensure we do not unconditionally query id with non-UUID string
    expect(verifyCode).not.toContain("{ id: orderRef }");
  });
});

import { describe, it, expect } from "vitest";
import {
  productSchema,
  variantSchema,
  collectionSchema,
  categorySchema,
  orderRegistrationSchema,
  heroSlideSchema,
  validateOrderReferenceFormat,
  validateTrackingContact,
  validateContactInquiry,
  isMaliciousContent,
  sanitizeString,
} from "@/lib/validations";
import { maskMobile, maskEmail } from "@/lib/formatters";

describe("Validation Schemas - OneFam Fashion Requirements", () => {
  describe("Product Schema", () => {
    it("validates valid luxury product data", () => {
      const valid = {
        name: "Liquid Satin Bias-Cut Slip Dress",
        sku: "OFM-W-SAT-001",
        regularPrice: 4299,
        discountPrice: 3899,
        categoryId: "cat_12345",
        status: "PUBLISHED",
        isFeatured: true,
      };

      const result = productSchema.safeParse(valid);
      expect(result.success).toBe(true);
    });

    it("rejects non-positive prices and missing required fields", () => {
      const invalid = {
        name: "S",
        sku: "12",
        regularPrice: -100,
        categoryId: "",
      };

      const result = productSchema.safeParse(invalid);
      expect(result.success).toBe(false);
      if (!result.success) {
        const issues = result.error.issues.map((i) => i.path[0]);
        expect(issues).toContain("name");
        expect(issues).toContain("regularPrice");
        expect(issues).toContain("categoryId");
      }
    });
  });

  describe("Variant Schema", () => {
    it("validates size, color, stock and hex formatting", () => {
      const variant = {
        sku: "OFM-VAR-M-01",
        size: "M",
        color: "Royal Plum",
        colorHex: "#7137C8",
        stock: 12,
        isAvailable: true,
      };

      const result = variantSchema.safeParse(variant);
      expect(result.success).toBe(true);
    });

    it("rejects invalid hex codes or negative inventory stock", () => {
      const invalid = {
        sku: "VAR-X",
        size: "",
        color: "",
        colorHex: "invalid-color-code",
        stock: -5,
      };

      const result = variantSchema.safeParse(invalid);
      expect(result.success).toBe(false);
    });
  });

  describe("Collection Schema", () => {
    it("allows collections without an image (cover image optional as requested)", () => {
      const collectionWithoutImage = {
        title: "Monsoon Festive Reverie",
        slug: "monsoon-festive-reverie",
        description: "Curated rich silks and lightweight festive ensembles.",
        imageUrl: "", // Cover image optional
      };

      const result = collectionSchema.safeParse(collectionWithoutImage);
      expect(result.success).toBe(true);
    });

    it("rejects invalid slugs with uppercase or special characters", () => {
      const invalidSlug = {
        title: "Autumn Capsule",
        slug: "Autumn Capsule 2026!",
      };

      const result = collectionSchema.safeParse(invalidSlug);
      expect(result.success).toBe(false);
    });
  });

  describe("Order Registration & Negotiation Schema", () => {
    it("validates manual order with discount negotiation and advance payment", () => {
      const order = {
        customerName: "Aarav Sharma",
        customerPhone: "9876543210",
        customerEmail: "aarav.sharma@example.com",
        shippingAddress: "Flat 402, Royal Palms, Bandra West",
        city: "Mumbai",
        state: "Maharashtra",
        postalCode: "400050",
        discountType: "FLAT",
        discountValue: 500,
        shippingFee: 0,
        advancePaid: 1500,
        items: [
          {
            productId: "prod_01",
            title: "Oversized Pure Linen Camp Shirt",
            unitPrice: 2499,
            quantity: 2,
            size: "L",
            color: "Bone White",
          },
        ],
      };

      const result = orderRegistrationSchema.safeParse(order);
      expect(result.success).toBe(true);
    });

    it("rejects orders without items or with invalid contact number", () => {
      const invalidOrder = {
        customerName: "A",
        customerPhone: "123", // too short
        shippingAddress: "",
        city: "",
        state: "",
        postalCode: "",
        items: [],
      };

      const result = orderRegistrationSchema.safeParse(invalidOrder);
      expect(result.success).toBe(false);
      if (!result.success) {
        const issues = result.error.issues.map((i) => i.path[0]);
        expect(issues).toContain("customerPhone");
        expect(issues).toContain("items");
      }
    });
  });

  describe("Hero Slide Schema", () => {
    it("requires headline, link and image banner", () => {
      const valid = {
        title: "Autumn / Winter '26 Lookbook",
        buttonText: "Shop Ready-to-Wear",
        buttonLink: "/collections/winter-luxe",
        imageUrl: "https://images.unsplash.com/photo-luxury-banner.jpg",
      };

      const result = heroSlideSchema.safeParse(valid);
      expect(result.success).toBe(true);
    });
  });

  describe("Admin Edit Options Verification", () => {
    it("verifies products page has edit modal and update mutation", async () => {
      const fs = await import("fs");
      const path = await import("path");
      const productPage = fs.readFileSync(
        path.resolve(__dirname, "../../src/app/admin/(protected)/products/page.tsx"),
        "utf8"
      );
      expect(productPage).toContain("handleOpenEdit");
      expect(productPage).toContain("handleUpdateProduct");
      expect(productPage).toContain("Edit Fashion Product");
    });

    it("verifies hero sliders page has dedicated builder modal with rich text and live preview", async () => {
      const fs = await import("fs");
      const path = await import("path");
      const heroPage = fs.readFileSync(
        path.resolve(__dirname, "../../src/app/admin/(protected)/hero-sliders/page.tsx"),
        "utf8"
      );
      const builderModal = fs.readFileSync(
        path.resolve(__dirname, "../../src/components/admin/hero-slide-builder-modal.tsx"),
        "utf8"
      );
      expect(heroPage).toContain("HeroSlideBuilderModal");
      expect(heroPage).toContain("handleOpenEdit");
      expect(heroPage).toContain("handleSaveSlide");

      // Builder modal features
      expect(builderModal).toContain("dangerouslySetInnerHTML");
      expect(builderModal).toContain("HTML_TEMPLATES");
    });

    it("verifies categories page has edit modal and update mutation", async () => {
      const fs = await import("fs");
      const path = await import("path");
      const catPage = fs.readFileSync(
        path.resolve(__dirname, "../../src/app/admin/(protected)/categories/page.tsx"),
        "utf8"
      );
      expect(catPage).toContain("handleOpenEdit");
      expect(catPage).toContain("handleUpdateCategory");
      expect(catPage).toContain("Edit Category Details");
    });

    it("verifies collections page has edit modal and update mutation", async () => {
      const fs = await import("fs");
      const path = await import("path");
      const colPage = fs.readFileSync(
        path.resolve(__dirname, "../../src/app/admin/(protected)/collections/page.tsx"),
        "utf8"
      );
      expect(colPage).toContain("handleOpenEdit");
      expect(colPage).toContain("handleUpdateCollection");
      expect(colPage).toContain("Edit Collection");
    });
  });

  describe("Order Tracking Reference & Contact Validation (ORD-K7M20001)", () => {
    it("accepts valid ORD-C1N1C2N20001 format across case and hyphen variations", () => {
      // Standard exact format
      const res1 = validateOrderReferenceFormat("ORD-K7M20001");
      expect(res1.valid).toBe(true);
      expect(res1.normalized).toBe("ORD-K7M20001");

      // Lowercase
      const res2 = validateOrderReferenceFormat("ord-k7m20001");
      expect(res2.valid).toBe(true);
      expect(res2.normalized).toBe("ORD-K7M20001");

      // Hyphenated variant ORD-K7M2-0001
      const res3 = validateOrderReferenceFormat("ORD-K7M2-0001");
      expect(res3.valid).toBe(true);
      expect(res3.normalized).toBe("ORD-K7M20001");

      // Unhyphenated variant ORDK7M20001
      const res4 = validateOrderReferenceFormat("ORDK7M20001");
      expect(res4.valid).toBe(true);
      expect(res4.normalized).toBe("ORD-K7M20001");
    });

    it("rejects invalid Order ID formats with descriptive errors", () => {
      // Pos 1 is digit instead of letter
      const res1 = validateOrderReferenceFormat("ORD-7KM20001");
      expect(res1.valid).toBe(false);
      expect(res1.error).toContain("Invalid Order ID format");

      // Pos 2 is letter instead of digit
      const res2 = validateOrderReferenceFormat("ORD-KKM20001");
      expect(res2.valid).toBe(false);

      // Pos 3 is digit instead of letter
      const res3 = validateOrderReferenceFormat("ORD-K7720001");
      expect(res3.valid).toBe(false);

      // Pos 4 is letter instead of digit
      const res4 = validateOrderReferenceFormat("ORD-K7MM0001");
      expect(res4.valid).toBe(false);

      // Wrong serial length (3 digits instead of 4)
      const res5 = validateOrderReferenceFormat("ORD-K7M2001");
      expect(res5.valid).toBe(false);

      // Random invalid text
      const res6 = validateOrderReferenceFormat("123456");
      expect(res6.valid).toBe(false);
      expect(res6.error).toContain("ORD-XXXXXXXX");
    });

    it("validates registered email addresses and mobile numbers", () => {
      // Valid email
      const emailRes = validateTrackingContact("aarav.sharma@example.com");
      expect(emailRes.valid).toBe(true);
      expect(emailRes.type).toBe("email");
      expect(emailRes.cleanValue).toBe("aarav.sharma@example.com");

      // Invalid email
      const badEmailRes = validateTrackingContact("aarav@invalid");
      expect(badEmailRes.valid).toBe(false);

      // Valid Indian 10-digit mobile
      const phoneRes = validateTrackingContact("9820154321");
      expect(phoneRes.valid).toBe(true);
      expect(phoneRes.type).toBe("phone");
      expect(phoneRes.cleanValue).toBe("9820154321");

      // Valid phone with country code prefix
      const phonePrefixRes = validateTrackingContact("+91 98201 54321");
      expect(phonePrefixRes.valid).toBe(true);
      expect(phonePrefixRes.cleanValue).toBe("9820154321");

      // Invalid mobile (< 10 digits)
      const badPhoneRes = validateTrackingContact("12345");
      expect(badPhoneRes.valid).toBe(false);
    });

    it("masks mobile phone numbers and email addresses to protect customer privacy", () => {
      expect(maskMobile("9820154321")).toBe("******4321");
      expect(maskMobile("+91 98201 54321")).toBe("******4321");
      expect(maskEmail("aarav.sharma@example.com")).toBe("a***a@example.com");
    });
  });

  describe("Contact Form Security & Indian Mobile Validation", () => {
    it("detects malicious scripts, iframe injections, and event handlers", () => {
      expect(isMaliciousContent("<script>alert('xss')</script>")).toBe(true);
      expect(isMaliciousContent("<img src=x onerror=alert(1)>")).toBe(true);
      expect(isMaliciousContent("javascript:stealData()")).toBe(true);
      expect(isMaliciousContent("<iframe src='evil.com'></iframe>")).toBe(true);
      expect(isMaliciousContent("eval('danger')")).toBe(true);
      expect(isMaliciousContent("Hello, I need help with my dress sizing.")).toBe(false);
    });

    it("sanitizes HTML tags and malicious schemas properly", () => {
      expect(sanitizeString("Hello <b>World</b>")).toBe("Hello World");
      expect(sanitizeString("Test <script>evil</script> text")).toBe("Test evil text");
      expect(sanitizeString("  Clean message with space   ")).toBe("Clean message with space");
    });

    it("strictly requires 10-digit Indian mobile starting with 6, 7, 8, or 9", () => {
      // Valid Indian 10-digit mobile
      const valid = validateContactInquiry({
        name: "Priyanshu Roy",
        email: "priyanshu@example.com",
        phone: "9876543210",
        message: "Can you provide the chest measurements for size L?",
      });
      expect(valid.valid).toBe(true);
      expect(valid.sanitized.phone).toBe("9876543210");

      // Valid with pasted +91
      const validWithPrefix = validateContactInquiry({
        name: "Priyanshu Roy",
        email: "priyanshu@example.com",
        phone: "+91 9876543210",
        message: "Can you provide the chest measurements for size L?",
      });
      expect(validWithPrefix.valid).toBe(true);
      expect(validWithPrefix.sanitized.phone).toBe("9876543210");

      // Invalid: < 10 digits
      const shortPhone = validateContactInquiry({
        name: "Priyanshu Roy",
        email: "priyanshu@example.com",
        phone: "98765432",
        message: "Can you provide the chest measurements for size L?",
      });
      expect(shortPhone.valid).toBe(false);
      expect(shortPhone.errors.phone).toContain("must be exactly 10 digits");

      // Invalid: starts with 1-5 (not a valid Indian mobile)
      const invalidPrefix = validateContactInquiry({
        name: "Priyanshu Roy",
        email: "priyanshu@example.com",
        phone: "2345678901",
        message: "Can you provide the chest measurements for size L?",
      });
      expect(invalidPrefix.valid).toBe(false);
      expect(invalidPrefix.errors.phone).toContain("must start with 6, 7, 8, or 9");
    });

    it("rejects malicious payload in contact form submission", () => {
      const malicious = validateContactInquiry({
        name: "<script>alert('hack')</script>",
        email: "hacker@example.com",
        phone: "9876543210",
        message: "Normal message text goes here",
      });
      expect(malicious.valid).toBe(false);
      expect(malicious.errors.general).toContain("Malicious or unsafe characters detected");
    });
  });
});


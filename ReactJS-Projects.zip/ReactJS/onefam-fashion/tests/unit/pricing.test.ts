import { describe, it, expect } from "vitest";

describe("OneFam Fashion - Order Financial & Payment Logic", () => {
  it("calculates order subtotal and final payable accurately", () => {
    const items = [
      { unitPrice: 1499, quantity: 2 }, // 2998
      { unitPrice: 2799, quantity: 1 }, // 2799
    ];

    const subtotal = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
    expect(subtotal).toBe(5797);

    const discount = 500;
    const shipping = 0;
    const total = Math.max(0, subtotal - discount + shipping);
    expect(total).toBe(5297);
  });

  it("determines correct PaymentStatus transitions", () => {
    const total = 3000;

    // Case 1: 0 paid
    const paid0 = 0;
    let status0 = "UNPAID";
    if (paid0 >= total) status0 = "PAID";
    else if (paid0 > 0) status0 = "PARTIALLY_PAID";
    expect(status0).toBe("UNPAID");

    // Case 2: partial payment
    const paid1 = 1000;
    let status1 = "UNPAID";
    if (paid1 >= total) status1 = "PAID";
    else if (paid1 > 0) status1 = "PARTIALLY_PAID";
    expect(status1).toBe("PARTIALLY_PAID");

    // Case 3: full payment
    const paid2 = 3000;
    let status2 = "UNPAID";
    if (paid2 >= total) status2 = "PAID";
    else if (paid2 > 0) status2 = "PARTIALLY_PAID";
    expect(status2).toBe("PAID");
  });

  it("calculates balance due correctly without negative balances", () => {
    const total = 2500;
    const amountPaid = 3000;
    const balanceDue = Math.max(0, total - amountPaid);
    expect(balanceDue).toBe(0);
  });
});


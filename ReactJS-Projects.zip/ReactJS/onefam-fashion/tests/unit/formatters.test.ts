import { describe, it, expect } from "vitest";
import {
  formatCurrency,
  calculateDiscountPercent,
  generateOrderReference,
  generateVerificationOtp,
  buildWhatsAppUrl,
} from "../../src/lib/formatters";

describe("OneFam Fashion - Formatters & Calculators", () => {
  it("formats Indian Rupee currency correctly", () => {
    const formatted = formatCurrency(1499);
    expect(formatted).toContain("1,499");
    expect(formatted).toContain("₹");
  });

  it("calculates discount percentages accurately", () => {
    // 2000 regular, 1500 discount = 25%
    expect(calculateDiscountPercent(2000, 1500)).toBe(25);
    // 1000 regular, 800 discount = 20%
    expect(calculateDiscountPercent(1000, 800)).toBe(20);
    // No discount
    expect(calculateDiscountPercent(1000, null)).toBe(0);
    expect(calculateDiscountPercent(1000, 1000)).toBe(0);
  });

  it("generates structured order references like ORD-K7M20001 (pos 1 & 3 are char, pos 2 & 4 are no)", () => {
    const ref1 = generateOrderReference(1);
    const ref2 = generateOrderReference(2);

    // Format: ORD- + [Char][Digit][Char][Digit] + [4-digit serial]
    expect(ref1).toMatch(/^ORD-[A-Z]\d[A-Z]\d0001$/);
    expect(ref2).toMatch(/^ORD-[A-Z]\d[A-Z]\d0002$/);
    expect(ref1).not.toBe(ref2);
  });

  it("generates 6-digit numeric OTPs", () => {
    const otp = generateVerificationOtp();
    expect(otp).toHaveLength(6);
    expect(Number(otp)).toBeGreaterThanOrEqual(100000);
    expect(Number(otp)).toBeLessThanOrEqual(999999);
  });

  it("constructs compliant WhatsApp enquiry URLs with selected variant details", () => {
    const url = buildWhatsAppUrl({
      whatsappNumber: "+91 98765-43210",
      productName: "Oversized Heavyweight Cotton Tee",
      productSku: "OFF-M-TEE-001",
      size: "XL",
      color: "Obsidian Black",
      price: 1499,
      productUrl: "https://onefamfashion.com/products/oversized-heavyweight-cotton-tee",
    });

    expect(url).toContain("https://wa.me/919876543210?text=");
    expect(decodeURIComponent(url)).toContain("Oversized Heavyweight Cotton Tee");
    expect(decodeURIComponent(url)).toContain("OFF-M-TEE-001");
    expect(decodeURIComponent(url)).toContain("XL");
    expect(decodeURIComponent(url)).toContain("Obsidian Black");
  });
});


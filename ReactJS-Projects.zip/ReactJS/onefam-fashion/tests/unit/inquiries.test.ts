import { describe, it, expect, beforeEach } from "vitest";
import { inquiryService } from "@/server/services/inquiry-service";

describe("Customer Inquiries & Concierge Support Module", () => {
  it("creates a new customer inquiry with generated ticket ID and default NEW status", async () => {
    const inquiry = await inquiryService.createInquiry({
      name: "Diya Patel",
      email: "diya.patel@example.com",
      phone: "9876501234",
      subject: "Sizing & Fit Advice",
      orderNumber: "ORD-K7M2-0001",
      message: "Looking for size guidance on the Linen Camp shirt.",
    });

    expect(inquiry.id).toBeDefined();
    expect(inquiry.ticketId).toMatch(/^INQ-[A-Z0-9]{4}-\d{4}$/);
    expect(inquiry.name).toBe("Diya Patel");
    expect(inquiry.email).toBe("diya.patel@example.com");
    expect(inquiry.phone).toBe("9876501234");
    expect(inquiry.status).toBe("NEW");
    expect(inquiry.orderNumber).toBe("ORD-K7M2-0001");
  });

  it("filters inquiries by search query across customer name and ticket id", async () => {
    const res = await inquiryService.getInquiries({ search: "Diya" });
    expect(res.inquiries.length).toBeGreaterThanOrEqual(1);
    expect(res.inquiries.some((i) => i.name.includes("Diya"))).toBe(true);
  });

  it("updates inquiry status and admin internal notes", async () => {
    const created = await inquiryService.createInquiry({
      name: "Rohan Kapoor",
      email: "rohan.k@example.com",
      subject: "Order Issue / Complaint",
      message: "Package arrived damaged.",
    });

    const updated = await inquiryService.updateInquiry(created.id, {
      status: "IN_PROGRESS",
      adminNotes: "Contacted customer on WhatsApp for pickup scheduling.",
    });

    expect(updated).not.toBeNull();
    expect(updated?.status).toBe("IN_PROGRESS");
    expect(updated?.adminNotes).toContain("WhatsApp");
  });
});


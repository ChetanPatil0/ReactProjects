import { describe, it, expect } from "vitest";
import { calculateDynamicOffer } from "../../src/lib/dynamic-offers";

describe("OneFam Fashion - Dynamic Offers & Discounts Engine", () => {
  it("returns null discountPrice when no promotions are attached", () => {
    const res = calculateDynamicOffer(2999, []);
    expect(res.discountPrice).toBeNull();
    expect(res.activeOffer).toBeNull();
    expect(res.discountPercent).toBe(0);
  });

  it("calculates dynamic percentage discount accurately", () => {
    const promotionProducts = [
      {
        promotion: {
          id: "promo-1",
          name: "Festive Clearance",
          discountType: "PERCENTAGE",
          discountValue: 20,
          isActive: true,
        },
      },
    ];

    const res = calculateDynamicOffer(3000, promotionProducts);
    expect(res.discountPrice).toBe(2400);
    expect(res.discountPercent).toBe(20);
    expect(res.activeOffer?.name).toBe("Festive Clearance");
    expect(res.activeOffer?.discountType).toBe("PERCENTAGE");
  });

  it("enforces maxDiscount cap for percentage discounts", () => {
    const promotionProducts = [
      {
        promotion: {
          id: "promo-2",
          name: "50% Drop (Capped at ₹500)",
          discountType: "PERCENTAGE",
          discountValue: 50,
          maxDiscount: 500,
          isActive: true,
        },
      },
    ];

    // 50% of 4000 would be 2000, but capped at 500 -> discountPrice = 3500
    const res = calculateDynamicOffer(4000, promotionProducts);
    expect(res.discountPrice).toBe(3500);
  });

  it("calculates flat fixed rupee discount correctly", () => {
    const promotionProducts = [
      {
        promotion: {
          id: "promo-3",
          name: "₹400 Welcome Credit",
          discountType: "FIXED",
          discountValue: 400,
          isActive: true,
        },
      },
    ];

    const res = calculateDynamicOffer(1999, promotionProducts);
    expect(res.discountPrice).toBe(1599);
    expect(res.activeOffer?.discountType).toBe("FIXED");
  });

  it("ignores inactive or expired promotions", () => {
    const pastDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000); // 7 days ago
    const futureDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    const promotionProducts = [
      {
        promotion: {
          id: "promo-expired",
          name: "Expired Deal",
          discountType: "PERCENTAGE",
          discountValue: 30,
          endDate: pastDate,
          isActive: true,
        },
      },
      {
        promotion: {
          id: "promo-disabled",
          name: "Disabled Deal",
          discountType: "PERCENTAGE",
          discountValue: 25,
          isActive: false,
        },
      },
      {
        promotion: {
          id: "promo-valid",
          name: "Live Valid Deal",
          discountType: "PERCENTAGE",
          discountValue: 15,
          startDate: pastDate,
          endDate: futureDate,
          isActive: true,
        },
      },
    ];

    const res = calculateDynamicOffer(2000, promotionProducts);
    expect(res.activeOffer?.name).toBe("Live Valid Deal");
    expect(res.discountPrice).toBe(1700);
    expect(res.discountPercent).toBe(15);
  });
});


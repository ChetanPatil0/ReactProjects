import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";

describe("OneFam Fashion - JSON Bulk Product Setup & Export", () => {
  it("verifies bulk import API route exists and processes JSON payload", () => {
    const routeFile = path.resolve(
      __dirname,
      "../../src/app/api/products/bulk-import/route.ts"
    );
    expect(fs.existsSync(routeFile)).toBe(true);

    const routeCode = fs.readFileSync(routeFile, "utf8");
    expect(routeCode).toContain("bulkImportJson");
    expect(routeCode).toContain("products");
    expect(routeCode).toContain("updateExisting");
  });

  it("verifies export route exports JSON with attachment header (not CSV)", () => {
    const exportFile = path.resolve(
      __dirname,
      "../../src/app/api/products/export/route.ts"
    );
    const exportCode = fs.readFileSync(exportFile, "utf8");

    expect(exportCode).toContain("application/json");
    expect(exportCode).toContain(".json");
    expect(exportCode).toContain("exportJson");
    expect(exportCode).not.toContain(".csv");
  });

  it("verifies dedicated JSON bulk setup page exists with upload, editor, validation, and sample data", () => {
    const bulkPage = path.resolve(
      __dirname,
      "../../src/app/admin/(protected)/products/bulk/page.tsx"
    );
    expect(fs.existsSync(bulkPage)).toBe(true);

    const pageCode = fs.readFileSync(bulkPage, "utf8");
    expect(pageCode).toContain("Upload JSON File (.json)");
    expect(pageCode).toContain("Paste &amp; Edit Raw JSON");
    expect(pageCode).toContain("Download Sample JSON");
    expect(pageCode).toContain("Load Sample Demo");
    expect(pageCode).toContain("Pre-Import Verification Table");
    expect(pageCode).toContain("Execute Import");
    expect(pageCode).toContain("updateExisting");
  });

  it("verifies products catalogue header has direct links to JSON Bulk Setup and JSON Export", () => {
    const productsPage = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/admin/(protected)/products/page.tsx"),
      "utf8"
    );

    expect(productsPage).toContain("/admin/products/bulk");
    expect(productsPage).toContain("Bulk Setup (JSON)");
    expect(productsPage).toContain("/api/products/export");
    expect(productsPage).toContain("Export JSON");
  });
});

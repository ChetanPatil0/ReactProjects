import { describe, it, expect } from "vitest";
import { generateOrderReference } from "../../src/lib/formatters";

describe("Order Reference & Analytics Formatting", () => {
  it("generates structured order reference with ORD- prefix, [Char][No][Char][No], and 4-digit serial", () => {
    const ref1 = generateOrderReference(1);
    const ref2 = generateOrderReference(42);

    expect(ref1).toMatch(/^ORD-[A-Z]\d[A-Z]\d0001$/);
    expect(ref2).toMatch(/^ORD-[A-Z]\d[A-Z]\d0042$/);
    expect(ref1).not.toBe(ref2);
  });

  it("pads serial numbers up to 4 digits accurately", () => {
    expect(generateOrderReference(99)).toMatch(/^ORD-[A-Z]\d[A-Z]\d0099$/);
    expect(generateOrderReference(1234)).toMatch(/^ORD-[A-Z]\d[A-Z]\d1234$/);
  });

  it("ensures position 1 and 3 are letters, position 2 and 4 are numbers", () => {
    for (let i = 1; i <= 20; i++) {
      const ref = generateOrderReference(i);
      // Remove "ORD-"
      const code = ref.slice(4);
      const c1 = code[0];
      const n1 = code[1];
      const c2 = code[2];
      const n2 = code[3];

      expect(c1).toMatch(/^[A-Z]$/);
      expect(n1).toMatch(/^[0-9]$/);
      expect(c2).toMatch(/^[A-Z]$/);
      expect(n2).toMatch(/^[0-9]$/);
    }
  });
});


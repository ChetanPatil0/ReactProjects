import { describe, it, expect } from "vitest";
import { generateQrSvg, generateQrDataUrl } from "@/lib/qr-code";

describe("OneFam Fashion - Pure TypeScript QR Code Generator", () => {
  it("generates valid SVG QR code for verification URL", () => {
    const url = "https://onefamfashion.com/orders/verify/ORD-K7M20001";
    const svg = generateQrSvg(url, { size: 140 });

    expect(svg).toContain("<svg");
    expect(svg).toContain('xmlns="http://www.w3.org/2000/svg"');
    expect(svg).toContain('width="140"');
    expect(svg).toContain('height="140"');
    expect(svg).toContain("<path");
  });

  it("generates data:image/svg+xml Data URL suitable for img src", () => {
    const url = "https://onefamfashion.com/orders/verify/ORD-2026-TEST";
    const dataUrl = generateQrDataUrl(url);

    expect(dataUrl.startsWith("data:image/svg+xml;utf8,")).toBe(true);
    expect(dataUrl).toContain(encodeURIComponent("<svg"));
  });
});


import { describe, it, expect } from "vitest";
import { siteConfig, getOrganizationJsonLd, getWebsiteJsonLd, getProductJsonLd } from "@/config/site";
import siteConfigJson from "@/config/site-config.json";

describe("Centralized Site Configuration & SEO Structured Data", () => {
  it("loads brand details and contact information from site-config.json", () => {
    expect(siteConfig.brand.name).toBe("OneFam Fashion");
    expect(siteConfig.contact.supportEmail).toBe("care@onefamfashion.com");
    expect(siteConfig.contact.whatsappDisplay).toContain("98765 43210");
    expect(siteConfig.contact.country).toBe("India");
    expect(siteConfig.contact.countryCode).toBe("+91");
  });

  it("contains valid image paths for logos, icons, placeholders and banners", () => {
    expect(siteConfig.images.logo.light).toBe("/logo/OneFamFashionDarkLogo.webp");
    expect(siteConfig.images.logo.dark).toBe("/logo/OneFamFashionWhiteLogo.webp");
    expect(siteConfig.images.logo.symbol).toBe("/logo/OneFamFashionDarkSymbol.webp");
    expect(siteConfig.images.icons.favicon).toBe("/logo/OneFamFashionDarkSymbol.webp");
    expect(siteConfig.images.banners.men).toBeDefined();
    expect(siteConfig.images.banners.women).toBeDefined();
    expect(siteConfig.images.banners.kids).toBeDefined();
    expect(siteConfig.images.banners.about).toBeDefined();
  });

  it("matches siteConfig export with site-config.json directly", () => {
    expect(siteConfig).toEqual(siteConfigJson);
  });

  it("generates valid Schema.org Organization structured data", () => {
    const orgLd = getOrganizationJsonLd();
    expect(orgLd["@context"]).toBe("https://schema.org");
    expect(orgLd["@type"]).toBe("ClothingStore");
    expect(orgLd.name).toBe("OneFam Fashion");
    expect(orgLd.email).toBe(siteConfig.contact.supportEmail);
    expect(orgLd.contactPoint.url).toContain("wa.me");
    expect(orgLd.address.addressCountry).toBe("IN");
  });

  it("generates valid Schema.org WebSite structured data with SearchAction", () => {
    const webLd = getWebsiteJsonLd();
    expect(webLd["@context"]).toBe("https://schema.org");
    expect(webLd["@type"]).toBe("WebSite");
    expect(webLd.potentialAction["@type"]).toBe("SearchAction");
    expect(webLd.potentialAction.target.urlTemplate).toContain("/search?q=");
  });

  it("generates valid Schema.org Product structured data for rich cards", () => {
    const productLd = getProductJsonLd({
      name: "French Flax Linen Camp Shirt",
      description: "Relaxed silhouette crafted in pure French linen.",
      sku: "OFM-M-LIN-001",
      price: 2899,
      currency: "INR",
      inStock: true,
      slug: "french-flax-linen-camp-shirt",
    });

    expect(productLd["@context"]).toBe("https://schema.org");
    expect(productLd["@type"]).toBe("Product");
    expect(productLd.name).toBe("French Flax Linen Camp Shirt");
    expect(productLd.offers.price).toBe(2899);
    expect(productLd.offers.priceCurrency).toBe("INR");
    expect(productLd.offers.availability).toBe("https://schema.org/InStock");
  });
});


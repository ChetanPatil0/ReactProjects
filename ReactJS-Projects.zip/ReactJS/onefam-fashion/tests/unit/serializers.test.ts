import { describe, it, expect } from "vitest";
import { serializeProduct, serializeProducts } from "../../src/lib/serializers";

describe("OneFam Fashion - Serializers", () => {
  it("converts Decimal-like objects and strings to numbers", () => {
    const mockProduct = {
      id: "prod-1",
      name: "Luxury Silk Shirt",
      slug: "luxury-silk-shirt",
      regularPrice: { toNumber: () => 2999.0, toString: () => "2999.00" },
      discountPrice: { toNumber: () => 2499.0, toString: () => "2499.00" },
      variants: [
        {
          id: "var-1",
          size: "M",
          priceOverride: { toNumber: () => 2699.0, toString: () => "2699.00" },
        },
      ],
    };

    const serialized = serializeProduct(mockProduct);
    expect(typeof serialized.regularPrice).toBe("number");
    expect(serialized.regularPrice).toBe(2999);
    expect(typeof serialized.discountPrice).toBe("number");
    expect(serialized.discountPrice).toBe(2499);
    expect(typeof serialized.variants[0].priceOverride).toBe("number");
    expect(serialized.variants[0].priceOverride).toBe(2699);
  });

  it("handles null discountPrice and variants correctly", () => {
    const mockProduct = {
      id: "prod-2",
      name: "Basic Linen Pants",
      slug: "basic-linen-pants",
      regularPrice: "1999.50",
      discountPrice: null,
      variants: [],
    };

    const serialized = serializeProduct(mockProduct);
    expect(serialized.regularPrice).toBe(1999.5);
    expect(serialized.discountPrice).toBeNull();
  });

  it("safely serializes an array of products", () => {
    const products = [
      { id: "1", regularPrice: "100", discountPrice: null },
      { id: "2", regularPrice: "200", discountPrice: "150" },
    ];
    const result = serializeProducts(products);
    expect(result).toHaveLength(2);
    expect(result[0].regularPrice).toBe(100);
    expect(result[1].discountPrice).toBe(150);
  });

  it("resolves variant-wise direct image from product images", () => {
    const mockProduct = {
      id: "prod-3",
      name: "Tailored Blazer",
      slug: "tailored-blazer",
      regularPrice: "4999",
      discountPrice: null,
      images: [
        { path: "/uploads/main.jpg", altText: "Main Front", isPrimary: true },
        { path: "/uploads/black-blazer.jpg", altText: "variant:Obsidian Black", isPrimary: false },
        { path: "/uploads/navy-blazer.jpg", altText: "variant:Navy Blue", isPrimary: false },
      ],
      variants: [
        { id: "v1", size: "M", color: "Obsidian Black", sku: "BLZ-BLK-M" },
        { id: "v2", size: "L", color: "Navy Blue", sku: "BLZ-NVY-L" },
        { id: "v3", size: "S", color: "Camel", sku: "BLZ-CML-S" },
      ],
    };

    const serialized = serializeProduct(mockProduct);
    expect(serialized.variants[0].imagePath).toBe("/uploads/black-blazer.jpg");
    expect(serialized.variants[1].imagePath).toBe("/uploads/navy-blazer.jpg");
    expect(serialized.variants[2].imagePath).toBeNull();
  });
});

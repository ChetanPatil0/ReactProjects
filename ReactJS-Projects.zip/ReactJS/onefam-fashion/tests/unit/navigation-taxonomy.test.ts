import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";

describe("OneFam Fashion - Categories & Collections Control & Storefront Mega Dropdown", () => {
  it("verifies categories admin page supports drag-and-drop ordering and active switch", () => {
    const categoriesPage = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/admin/(protected)/categories/page.tsx"),
      "utf8"
    );

    expect(categoriesPage).toContain("draggable");
    expect(categoriesPage).toContain("onDragStart");
    expect(categoriesPage).toContain("onDrop");
    expect(categoriesPage).toContain("GripVertical");
    expect(categoriesPage).toContain("toggleActiveMutation");
    expect(categoriesPage).toContain("reorderMutation");
    expect(categoriesPage).toContain("/categories/reorder");
  });

  it("verifies collections admin page supports drag-and-drop ordering and active switch", () => {
    const collectionsPage = fs.readFileSync(
      path.resolve(__dirname, "../../src/app/admin/(protected)/collections/page.tsx"),
      "utf8"
    );

    expect(collectionsPage).toContain("draggable");
    expect(collectionsPage).toContain("onDragStart");
    expect(collectionsPage).toContain("onDrop");
    expect(collectionsPage).toContain("GripVertical");
    expect(collectionsPage).toContain("toggleActiveMutation");
    expect(collectionsPage).toContain("reorderMutation");
    expect(collectionsPage).toContain("/collections/reorder");
  });

  it("verifies storefront header renders professional category mega-menu dropdown with subcategories", () => {
    const headerCode = fs.readFileSync(
      path.resolve(__dirname, "../../src/features/storefront/components/header/header.tsx"),
      "utf8"
    );

    expect(headerCode).toContain("activeDropdownId");
    expect(headerCode).toContain("handleMouseEnter");
    expect(headerCode).toContain("handleMouseLeave");
    expect(headerCode).toContain("ChevronDown");
    expect(headerCode).toContain("Shop ");
    expect(headerCode).toContain("Curated Visual Editorial Capsule");
    expect(headerCode).toContain("openMobileCategories"); // mobile accordion
  });

  it("verifies reorder API routes exist for both categories and collections", () => {
    const categoriesReorderRoute = path.resolve(
      __dirname,
      "../../src/app/api/categories/reorder/route.ts"
    );
    const collectionsReorderRoute = path.resolve(
      __dirname,
      "../../src/app/api/collections/reorder/route.ts"
    );

    expect(fs.existsSync(categoriesReorderRoute)).toBe(true);
    expect(fs.existsSync(collectionsReorderRoute)).toBe(true);
  });
});


import { test, expect } from "@playwright/test";

test.describe("OneFam Fashion - Storefront & Customer Journey", () => {
  test("Homepage displays official brand identity, header navigation and departments", async ({ page }) => {
    await page.goto("/");
    await expect(page).toHaveTitle(/OneFam Fashion/i);

    // Verify main department navigation items
    await expect(page.locator("nav").getByText("Men", { exact: true })).toBeVisible();
    await expect(page.locator("nav").getByText("Women", { exact: true })).toBeVisible();
    await expect(page.locator("nav").getByText("Kids", { exact: true })).toBeVisible();
    await expect(page.locator("nav").getByText("Collections", { exact: true })).toBeVisible();
    await expect(page.locator("nav").getByText("Offers", { exact: true })).toBeVisible();
  });

  test("Men catalogue page displays styles and filtering sidebar", async ({ page }) => {
    await page.goto("/men");
    await expect(page.locator("h1")).toContainText(/Men/i);

    // Filter controls should be present
    await expect(page.getByText("In-Stock Styles Only")).toBeVisible();
    await expect(page.getByText("Size", { exact: true })).toBeVisible();
    await expect(page.getByText("Colour Palette", { exact: true })).toBeVisible();
  });

  test("Catalogue displays empty state when over-refined filters are selected", async ({ page }) => {
    // Navigate with restrictive filter combination
    await page.goto("/men?size=XXL&color=Blush+Pink&minPrice=90000");

    // Verify luxury empty state box is rendered
    await expect(page.getByText("No Wardrobe Pieces Match Your Refinements")).toBeVisible();
    await expect(page.getByRole("button", { name: /Reset All Filters/i })).toBeVisible();
    await expect(page.getByText(/Quick suggestions to find your fit/i)).toBeVisible();
  });

  test("FAQ page renders categories, live search, and accordions", async ({ page }) => {
    await page.goto("/faq");
    await expect(page.locator("h1")).toContainText(/Client Concierge & FAQs/i);

    // Live search input
    const searchInput = page.getByPlaceholder(/Search questions across sizing/i);
    await expect(searchInput).toBeVisible();

    // Accordion interaction
    await page.getByText(/What materials and natural fabrics/i).click();
    await expect(page.getByText(/GOTS-certified organic cotton/i)).toBeVisible();
  });

  test("Theme switcher toggles light, dark, and system modes and persists in localStorage", async ({ page }) => {
    await page.goto("/");

    // Open theme menu
    const themeBtn = page.getByRole("button", { name: /Switch Theme/i });
    await expect(themeBtn).toBeVisible();
    await themeBtn.click();

    // Select Dark Mode
    await page.getByRole("menuitem", { name: /Dark Mode/i }).click();

    // Verify html element has dark class
    await expect(page.locator("html")).toHaveClass(/dark/);

    // Verify localStorage contains theme selection
    const storedTheme = await page.evaluate(() => localStorage.getItem("onefam-fashion-theme"));
    expect(storedTheme).toBe("dark");

    // Switch to Light Mode
    await themeBtn.click();
    await page.getByRole("menuitem", { name: /Light Mode/i }).click();
    await expect(page.locator("html")).not.toHaveClass(/dark/);
  });
});

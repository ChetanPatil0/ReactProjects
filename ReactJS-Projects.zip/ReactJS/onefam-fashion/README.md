# OneFam Fashion

Modern fashion ecommerce website with comprehensive admin management system.

**Stack:** Next.js (App Router) · TypeScript · Tailwind CSS · shadcn/ui · PostgreSQL · Prisma · Supabase Storage · TanStack Query/Table · Zustand · React Hook Form · Zod

## Phase 0 / Foundation Status

This is the initial project scaffolding for **Phase 1 — Foundation**.

### Completed in this setup

- Next.js 16 App Router + TypeScript project
- Tailwind CSS v4 with brand design tokens (Royal Violet, Electric Lime, Vermilion, Ink, Paper)
- Plus Jakarta Sans font
- Project folder structure matching the specification
- Prisma schema skeleton (Auth + Catalogue entities)
- Environment example (`.env.example`)
- Basic root layout, homepage placeholder, utilities
- Scripts for Prisma, testing, linting, formatting

### Next steps (Phase 1 continuation)

1. Install dependencies: `yarn install` or `npm install`
2. Configure `.env` from `.env.example`
3. Set up PostgreSQL + run `yarn db:push` or migrations
4. Initialize shadcn/ui: `npx shadcn@latest init`
5. Add remaining foundation packages and auth system
6. Supabase Storage integration
7. Central API client + TanStack Query setup

## Brand Palette

| Token          | Hex       | Usage                          |
|----------------|-----------|--------------------------------|
| Royal Violet   | `#7137C8` | Primary actions, accents       |
| Electric Lime  | `#C6F542` | Highlights, CTAs               |
| Vermilion      | `#F45B45` | Destructive / alerts           |
| Ink            | `#191720` | Text, dark UI                  |
| Paper          | `#FCFAF4` | Backgrounds                    |

## Scripts

```bash
yarn dev              # Start development server
yarn build            # Production build
yarn db:generate      # Generate Prisma client
yarn db:push          # Push schema to DB
yarn db:migrate       # Create migration
yarn db:seed          # Seed data
yarn db:studio        # Prisma Studio
yarn lint             # ESLint
yarn typecheck        # TypeScript check
yarn test             # Vitest
yarn test:e2e         # Playwright
```

## Project Structure

See the specification document for the full intended structure under `src/`.

Key directories:

- `src/app/(storefront)/` — Customer-facing pages
- `src/app/admin/` — Admin login + protected dashboard
- `src/app/api/` — Route handlers
- `src/features/` — Feature modules (products, orders, etc.)
- `src/server/` — Server-only services, repositories, auth, storage
- `src/lib/` — Shared utilities, Prisma, API client
- `prisma/` — Schema & migrations

## Security Notes

- Never commit `.env`
- Never expose `SUPABASE_SERVICE_ROLE_KEY` or SMTP credentials to the client
- Use Argon2id for password hashing
- Prefer UUIDs internally; public order references for customers

---

**OneFam Fashion** — Built for maintainability, performance and operational clarity.

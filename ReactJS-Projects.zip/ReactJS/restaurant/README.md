# Restaurant Website, CMS & Billing / POS System

A modern, fast, and responsive single-restaurant management solution built with Next.js (App Router), Strapi 5, PostgreSQL, and a custom billing / POS module.

## Project Structure

```text
restaurant/
├── apps/
│   ├── website/                    # Next.js App Router public website
│   └── cms/                        # Strapi 5 CMS & Custom POS Plugin
├── infrastructure/
│   ├── docker/                     # Docker Compose (PostgreSQL 16)
│   ├── database/backup/            # Database backups
│   └── scripts/                    # Backup & recovery scripts
├── docs/                           # Architecture, database & permissions specs
├── package.json                    # Monorepo root (npm workspaces)
└── README.md
```

## Quick Start

### 1. Start Database
```bash
npm run db:up
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Run Applications
- **Strapi CMS (Backend & Admin)**:
  ```bash
  npm run dev:cms
  ```
  Accessible at `http://localhost:1337/admin`

- **Public Website (Frontend)**:
  ```bash
  npm run dev:website
  ```
  Accessible at `http://localhost:3000`

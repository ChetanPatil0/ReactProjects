import path from 'path';

export default ({ env }: { env: any }) => {
  const databaseUrl = env('DATABASE_URL');

  if (databaseUrl) {
    const isSsl =
      env.bool('DATABASE_SSL', false) ||
      databaseUrl.includes('sslmode=require') ||
      databaseUrl.includes('neon.tech') ||
      databaseUrl.includes('supabase.co');

    return {
      connection: {
        client: 'postgres',
        connection: {
          connectionString: databaseUrl,
          ssl: isSsl ? { rejectUnauthorized: false } : false,
        },
        pool: { min: env.int('DATABASE_POOL_MIN', 2), max: env.int('DATABASE_POOL_MAX', 10) },
        acquireConnectionTimeout: env.int('DATABASE_CONNECTION_TIMEOUT', 60000),
      },
    };
  }

  const client = env('DATABASE_CLIENT', 'postgres');

  const connections: Record<string, any> = {
    postgres: {
      connection: {
        host: env('DATABASE_HOST', '127.0.0.1'),
        port: env.int('DATABASE_PORT', 5432),
        database: env('DATABASE_NAME', 'restaurant_db'),
        user: env('DATABASE_USERNAME', 'restaurant_user'),
        password: env('DATABASE_PASSWORD', 'restaurant_secure_pass'),
        ssl: env.bool('DATABASE_SSL', false) ? { rejectUnauthorized: false } : false,
      },
      pool: { min: env.int('DATABASE_POOL_MIN', 2), max: env.int('DATABASE_POOL_MAX', 10) },
    },
    sqlite: {
      connection: {
        filename: path.join(__dirname, '..', '..', env('DATABASE_FILENAME', '.tmp/data.db')),
      },
      useNullAsDefault: true,
    },
  };

  return {
    connection: {
      client,
      ...connections[client],
      acquireConnectionTimeout: env.int('DATABASE_CONNECTION_TIMEOUT', 60000),
    },
  };
};

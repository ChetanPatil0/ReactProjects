export default ({ env }: { env: any }) => ({
  host: env('HOST', '0.0.0.0'),
  port: env.int('PORT', 1337),
  app: {
    keys: env.array('APP_KEYS', [
      'restaurant_app_key_alpha_123',
      'restaurant_app_key_beta_456',
      'restaurant_app_key_gamma_789',
      'restaurant_app_key_delta_012'
    ]),
  },
  webhooks: {
    populateRelations: env.bool('WEBHOOKS_POPULATE_RELATIONS', false),
  },
});

export default ({ env }: { env: any }) => ({
  'restaurant-pos': {
    enabled: true,
    resolve: './src/plugins/restaurant-pos',
  },
});

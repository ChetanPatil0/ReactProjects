import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::offer.offer');

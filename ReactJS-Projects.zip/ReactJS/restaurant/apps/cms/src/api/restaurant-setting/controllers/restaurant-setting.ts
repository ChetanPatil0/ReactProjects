import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::restaurant-setting.restaurant-setting');

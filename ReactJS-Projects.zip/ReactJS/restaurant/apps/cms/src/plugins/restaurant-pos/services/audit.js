'use strict';

module.exports = ({ strapi }) => ({
  async log({ adminUser, action, module: mod, recordRef, metadata = {} }) {
    try {
      await strapi.db.query('plugin::restaurant-pos.activity-log').create({
        data: {
          adminId: adminUser?.id || null,
          adminEmail: adminUser?.email || 'system@aura.internal',
          action,
          module: mod,
          recordRef: String(recordRef || ''),
          metadata,
          timestamp: new Date(),
        },
      });
    } catch (err) {
      strapi.log.error('Failed to write activity log:', err);
    }
  },
});

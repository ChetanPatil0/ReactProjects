'use strict';

module.exports = ({ strapi }) => ({
  /**
   * Optimized payload for POS counter screen
   */
  async getPosMenu(ctx) {
    const categories = await strapi.db.query('api::menu-category.menu-category').findMany({
      where: { isActive: true },
      orderBy: { displayOrder: 'asc' },
    });

    const items = await strapi.db.query('api::menu-item.menu-item').findMany({
      where: { isAvailable: true },
      populate: ['category'],
      orderBy: { displayOrder: 'asc' },
    });

    const settings = await strapi.db.query('api::restaurant-setting.restaurant-setting').findOne();

    ctx.body = {
      categories,
      items,
      settings: {
        currency: settings?.currency || 'INR',
        currencySymbol: settings?.currencySymbol || '₹',
        taxRate: parseFloat(settings?.taxRate) || 5.0,
        invoicePrefix: settings?.invoicePrefix || 'INV-2026-',
      },
    };
  },

  async calculate(ctx) {
    const { items, discountAmount, taxRate } = ctx.request.body || {};
    const settings = await strapi.db.query('api::restaurant-setting.restaurant-setting').findOne();
    const rate = taxRate !== undefined ? parseFloat(taxRate) : (parseFloat(settings?.taxRate) || 5.0);

    const totals = strapi.plugin('restaurant-pos').service('billing').calculateTotals({
      items: items || [],
      discountAmount,
      taxRate: rate,
    });

    ctx.body = totals;
  },

  async createBill(ctx) {
    const adminUser = ctx.state.user;
    try {
      const bill = await strapi.plugin('restaurant-pos').service('billing').createBill(
        ctx.request.body,
        adminUser
      );
      ctx.body = bill;
    } catch (err) {
      ctx.badRequest(err.message);
    }
  },

  async getBills(ctx) {
    const result = await strapi.plugin('restaurant-pos').service('billing').getBills(ctx.query);
    ctx.body = result;
  },

  async getBill(ctx) {
    const { id } = ctx.params;
    const bill = await strapi.plugin('restaurant-pos').service('billing').getBillById(id);
    if (!bill) {
      return ctx.notFound('Bill not found');
    }
    ctx.body = bill;
  },

  async recordPayment(ctx) {
    const { id } = ctx.params;
    const adminUser = ctx.state.user;
    try {
      const updated = await strapi.plugin('restaurant-pos').service('billing').recordPayment(
        id,
        ctx.request.body,
        adminUser
      );
      ctx.body = updated;
    } catch (err) {
      ctx.badRequest(err.message);
    }
  },

  async cancelBill(ctx) {
    const { id } = ctx.params;
    const adminUser = ctx.state.user;
    try {
      const cancelled = await strapi.plugin('restaurant-pos').service('billing').cancelBill(
        id,
        ctx.request.body,
        adminUser
      );
      ctx.body = cancelled;
    } catch (err) {
      ctx.badRequest(err.message);
    }
  },

  async refundBill(ctx) {
    const { id } = ctx.params;
    const adminUser = ctx.state.user;
    try {
      const refund = await strapi.plugin('restaurant-pos').service('billing').refundBill(
        id,
        ctx.request.body,
        adminUser
      );
      ctx.body = refund;
    } catch (err) {
      ctx.badRequest(err.message);
    }
  },
});

import React, { useState, useEffect } from 'react';

export function PosApp() {
  const [activeTab, setActiveTab] = useState('pos'); // 'pos' | 'history' | 'reports' | 'customers' | 'logs'
  const [loading, setLoading] = useState(false);
  const [menuData, setMenuData] = useState({ categories: [], items: [], settings: {} });
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Cart / Bill state
  const [cart, setCart] = useState([]);
  const [orderType, setOrderType] = useState('dine_in');
  const [tableNumber, setTableNumber] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [discountAmount, setDiscountAmount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [paymentAmount, setPaymentAmount] = useState(0);
  const [notes, setNotes] = useState('');

  // History & Reports state
  const [bills, setBills] = useState([]);
  const [reportsDate, setReportsDate] = useState(new Date().toISOString().split('T')[0]);
  const [dailySummary, setDailySummary] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [activityLogs, setActivityLogs] = useState([]);

  // Modals
  const [printBill, setPrintBill] = useState(null);
  const [printFormat, setPrintFormat] = useState('thermal80'); // 'thermal58' | 'thermal80' | 'a4'
  const [cancelModalBill, setCancelModalBill] = useState(null);
  const [cancelReason, setCancelReason] = useState('');
  const [payModalBill, setPayModalBill] = useState(null);
  const [payModalAmount, setPayModalAmount] = useState(0);
  const [payModalMethod, setPayModalMethod] = useState('cash');
  const [feedback, setFeedback] = useState(null);

  // Fetch POS Menu on mount
  const fetchPosMenu = async () => {
    try {
      const res = await fetch('/restaurant-pos/pos/menu');
      if (res.ok) {
        const data = await res.json();
        setMenuData(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchBills = async () => {
    try {
      const res = await fetch('/restaurant-pos/bills');
      if (res.ok) {
        const data = await res.json();
        setBills(data.data || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchDailySummary = async (date) => {
    try {
      const res = await fetch(`/restaurant-pos/reports/daily-summary?date=${date || reportsDate}`);
      if (res.ok) {
        const data = await res.json();
        setDailySummary(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchCustomers = async () => {
    try {
      const res = await fetch('/restaurant-pos/customers');
      if (res.ok) {
        const data = await res.json();
        setCustomers(data.data || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchLogs = async () => {
    try {
      const res = await fetch('/restaurant-pos/activity-logs');
      if (res.ok) {
        const data = await res.json();
        setActivityLogs(data.data || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchPosMenu();
  }, []);

  useEffect(() => {
    if (activeTab === 'history') fetchBills();
    if (activeTab === 'reports') fetchDailySummary();
    if (activeTab === 'customers') fetchCustomers();
    if (activeTab === 'logs') fetchLogs();
  }, [activeTab]);

  // Cart operations
  const addToCart = (item) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i));
      }
      return [...prev, { ...item, quantity: 1, unitPrice: parseFloat(item.price) || 0 }];
    });
  };

  const updateQuantity = (itemId, delta) => {
    setCart((prev) =>
      prev
        .map((i) => {
          if (i.id === itemId) {
            const newQty = i.quantity + delta;
            return newQty > 0 ? { ...i, quantity: newQty } : null;
          }
          return i;
        })
        .filter(Boolean)
    );
  };

  const removeFromCart = (itemId) => {
    setCart((prev) => prev.filter((i) => i.id !== itemId));
  };

  // Financial calculations
  const subtotal = cart.reduce((sum, item) => sum + (parseFloat(item.unitPrice) || 0) * item.quantity, 0);
  const discount = Math.min(subtotal, Math.max(0, parseFloat(discountAmount) || 0));
  const taxable = Math.max(0, subtotal - discount);
  const taxRate = menuData.settings?.taxRate || 5.0;
  const taxAmount = Math.round(((taxable * taxRate) / 100) * 100) / 100;
  const grandTotal = Math.round((taxable + taxAmount) * 100) / 100;

  // Auto-set payment amount to grandTotal when cart changes if previously matching
  useEffect(() => {
    setPaymentAmount(grandTotal);
  }, [grandTotal]);

  const handleCreateBill = async () => {
    if (cart.length === 0) {
      setFeedback({ type: 'error', message: 'Please add at least one item to the bill.' });
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/restaurant-pos/bills', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cart,
          orderType,
          tableNumber,
          customerName,
          customerPhone,
          discountAmount: discount,
          paymentMethod,
          paymentAmount: parseFloat(paymentAmount) || 0,
          notes,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error?.message || 'Failed to save bill');
      }

      const createdBill = await res.json();
      setFeedback({ type: 'success', message: `Invoice #${createdBill.invoiceNumber} created successfully!` });
      // Reset cart
      setCart([]);
      setTableNumber('');
      setCustomerName('');
      setCustomerPhone('');
      setDiscountAmount(0);
      setNotes('');
      // Open print preview
      setPrintBill(createdBill);
    } catch (err) {
      setFeedback({ type: 'error', message: err.message });
    } finally {
      setLoading(false);
    }
  };

  const handleRecordPayment = async () => {
    if (!payModalBill || payModalAmount <= 0) return;
    try {
      const res = await fetch(`/restaurant-pos/bills/${payModalBill.id}/payments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: parseFloat(payModalAmount),
          method: payModalMethod,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error?.message || 'Payment recording failed');
      }

      setFeedback({ type: 'success', message: 'Payment recorded successfully!' });
      setPayModalBill(null);
      fetchBills();
    } catch (err) {
      setFeedback({ type: 'error', message: err.message });
    }
  };

  const handleCancelBill = async () => {
    if (!cancelModalBill || !cancelReason.trim()) return;
    try {
      const res = await fetch(`/restaurant-pos/bills/${cancelModalBill.id}/cancel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: cancelReason }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error?.message || 'Cancellation failed');
      }

      setFeedback({ type: 'success', message: `Invoice #${cancelModalBill.invoiceNumber} has been cancelled.` });
      setCancelModalBill(null);
      setCancelReason('');
      fetchBills();
    } catch (err) {
      setFeedback({ type: 'error', message: err.message });
    }
  };

  const filteredMenuItems = menuData.items.filter((item) => {
    if (selectedCategory !== 'all') {
      const catId = item.category?.id || item.category;
      if (String(catId) !== String(selectedCategory)) return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return item.name.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div style={{ fontFamily: 'system-ui, -apple-system, sans-serif', padding: '24px', backgroundColor: '#f6f6f9', minHeight: '100vh', color: '#212134' }}>
      {/* Top Navbar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', backgroundColor: '#ffffff', padding: '16px 24px', borderRadius: '12px', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ width: '40px', height: '40px', borderRadius: '8px', backgroundColor: '#f59e0b', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#ffffff', fontWeight: 'bold', fontSize: '20px' }}>
            🍽
          </div>
          <div>
            <h1 style={{ margin: 0, fontSize: '18px', fontWeight: '700' }}>Restaurant Billing & POS</h1>
            <p style={{ margin: 0, fontSize: '12px', color: '#666687' }}>Aura Fine Dining Management</p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div style={{ display: 'flex', gap: '8px', backgroundColor: '#f0f0f5', padding: '4px', borderRadius: '8px' }}>
          {[
            { id: 'pos', label: 'Billing Terminal' },
            { id: 'history', label: 'Bill History' },
            { id: 'reports', label: 'Day Summary & Reports' },
            { id: 'customers', label: 'Customers' },
            { id: 'logs', label: 'Activity Logs' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                border: 'none',
                padding: '8px 16px',
                borderRadius: '6px',
                fontSize: '13px',
                fontWeight: activeTab === tab.id ? '600' : '500',
                backgroundColor: activeTab === tab.id ? '#ffffff' : 'transparent',
                color: activeTab === tab.id ? '#212134' : '#666687',
                boxShadow: activeTab === tab.id ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
                cursor: 'pointer',
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Global Feedback Banner */}
      {feedback && (
        <div
          style={{
            padding: '12px 16px',
            marginBottom: '16px',
            borderRadius: '8px',
            fontSize: '13px',
            backgroundColor: feedback.type === 'error' ? '#fee2e2' : '#dcfce7',
            color: feedback.type === 'error' ? '#991b1b' : '#166534',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <span>{feedback.message}</span>
          <button onClick={() => setFeedback(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px' }}>✕</button>
        </div>
      )}

      {/* TAB 1: POS BILLING TERMINAL */}
      {activeTab === 'pos' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 400px', gap: '24px' }}>
          {/* Menu Catalog Section */}
          <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '20px', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
            <div style={{ display: 'flex', gap: '12px', marginBottom: '16px' }}>
              <input
                type="text"
                placeholder="Search food & beverages..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{ flex: 1, padding: '10px 14px', borderRadius: '8px', border: '1px solid #dcdce4', fontSize: '14px' }}
              />
            </div>

            {/* Categories */}
            <div style={{ display: 'flex', gap: '8px', overflowX: 'auto', paddingBottom: '12px', marginBottom: '16px' }}>
              <button
                onClick={() => setSelectedCategory('all')}
                style={{
                  padding: '6px 14px',
                  borderRadius: '20px',
                  border: '1px solid #dcdce4',
                  backgroundColor: selectedCategory === 'all' ? '#212134' : '#ffffff',
                  color: selectedCategory === 'all' ? '#ffffff' : '#4a4a6a',
                  fontSize: '12px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                }}
              >
                All Items ({menuData.items.length})
              </button>
              {menuData.categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  style={{
                    padding: '6px 14px',
                    borderRadius: '20px',
                    border: '1px solid #dcdce4',
                    backgroundColor: String(selectedCategory) === String(cat.id) ? '#212134' : '#ffffff',
                    color: String(selectedCategory) === String(cat.id) ? '#ffffff' : '#4a4a6a',
                    fontSize: '12px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {cat.name}
                </button>
              ))}
            </div>

            {/* Items Grid */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '14px', maxHeight: '550px', overflowY: 'auto' }}>
              {filteredMenuItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => addToCart(item)}
                  style={{
                    border: '1px solid #eaeaef',
                    borderRadius: '10px',
                    padding: '14px',
                    cursor: 'pointer',
                    backgroundColor: '#fafafb',
                    transition: 'all 0.15s ease',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                  }}
                >
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '4px' }}>
                      <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: item.foodType === 'veg' ? '#10b981' : '#ef4444' }} />
                      <span style={{ fontSize: '11px', textTransform: 'uppercase', color: '#8e8ea9', fontWeight: '600' }}>{item.foodType}</span>
                    </div>
                    <h3 style={{ margin: '0 0 6px 0', fontSize: '14px', fontWeight: '600', color: '#212134' }}>{item.name}</h3>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '12px', paddingTop: '8px', borderTop: '1px dashed #eaeaef' }}>
                    <span style={{ fontSize: '15px', fontWeight: '700', color: '#b45309' }}>₹{item.price}</span>
                    <span style={{ fontSize: '11px', backgroundColor: '#e0e7ff', color: '#4338ca', padding: '2px 8px', borderRadius: '4px', fontWeight: '600' }}>+ Add</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Current Bill / Cart Checkout Panel */}
          <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '20px', boxShadow: '0 1px 4px rgba(0,0,0,0.06)', display: 'flex', flexDirection: 'column', maxHeight: '800px' }}>
            <h2 style={{ margin: '0 0 16px 0', fontSize: '16px', fontWeight: '700' }}>Current Order</h2>

            {/* Order Type & Table */}
            <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
              <button
                onClick={() => setOrderType('dine_in')}
                style={{
                  flex: 1,
                  padding: '8px',
                  borderRadius: '6px',
                  border: '1px solid #dcdce4',
                  backgroundColor: orderType === 'dine_in' ? '#212134' : '#ffffff',
                  color: orderType === 'dine_in' ? '#ffffff' : '#4a4a6a',
                  fontSize: '12px',
                  fontWeight: '600',
                  cursor: 'pointer',
                }}
              >
                Dine-In
              </button>
              <button
                onClick={() => setOrderType('takeaway')}
                style={{
                  flex: 1,
                  padding: '8px',
                  borderRadius: '6px',
                  border: '1px solid #dcdce4',
                  backgroundColor: orderType === 'takeaway' ? '#212134' : '#ffffff',
                  color: orderType === 'takeaway' ? '#ffffff' : '#4a4a6a',
                  fontSize: '12px',
                  fontWeight: '600',
                  cursor: 'pointer',
                }}
              >
                Takeaway
              </button>
            </div>

            {orderType === 'dine_in' && (
              <input
                type="text"
                placeholder="Table Number (e.g. Table 4)"
                value={tableNumber}
                onChange={(e) => setTableNumber(e.target.value)}
                style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #dcdce4', fontSize: '13px', marginBottom: '12px' }}
              />
            )}

            {/* Customer Details */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '14px' }}>
              <input
                type="text"
                placeholder="Customer Phone"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                style={{ padding: '8px 10px', borderRadius: '6px', border: '1px solid #dcdce4', fontSize: '12px' }}
              />
              <input
                type="text"
                placeholder="Customer Name"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                style={{ padding: '8px 10px', borderRadius: '6px', border: '1px solid #dcdce4', fontSize: '12px' }}
              />
            </div>

            {/* Cart Items List */}
            <div style={{ flex: 1, overflowY: 'auto', borderTop: '1px solid #eaeaef', borderBottom: '1px solid #eaeaef', padding: '12px 0' }}>
              {cart.length === 0 ? (
                <p style={{ textAlign: 'center', color: '#8e8ea9', fontSize: '13px', margin: '30px 0' }}>No items in cart</p>
              ) : (
                cart.map((item) => (
                  <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                    <div style={{ flex: 1, paddingRight: '8px' }}>
                      <div style={{ fontSize: '13px', fontWeight: '600' }}>{item.name}</div>
                      <div style={{ fontSize: '11px', color: '#666687' }}>₹{item.unitPrice} each</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <button onClick={() => updateQuantity(item.id, -1)} style={{ width: '24px', height: '24px', borderRadius: '4px', border: '1px solid #dcdce4', backgroundColor: '#ffffff', cursor: 'pointer' }}>-</button>
                      <span style={{ fontSize: '13px', fontWeight: '600', minWidth: '18px', textAlign: 'center' }}>{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.id, 1)} style={{ width: '24px', height: '24px', borderRadius: '4px', border: '1px solid #dcdce4', backgroundColor: '#ffffff', cursor: 'pointer' }}>+</button>
                    </div>
                    <div style={{ width: '60px', textAlign: 'right', fontWeight: '700', fontSize: '13px' }}>
                      ₹{item.unitPrice * item.quantity}
                    </div>
                    <button onClick={() => removeFromCart(item.id)} style={{ border: 'none', background: 'none', color: '#ef4444', cursor: 'pointer', padding: '4px' }}>✕</button>
                  </div>
                ))
              )}
            </div>

            {/* Totals Breakdown */}
            <div style={{ padding: '12px 0', fontSize: '13px', spaceY: '6px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                <span style={{ color: '#666687' }}>Subtotal</span>
                <span>₹{subtotal.toFixed(2)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                <span style={{ color: '#666687' }}>Discount (₹)</span>
                <input
                  type="number"
                  min="0"
                  max={subtotal}
                  value={discountAmount}
                  onChange={(e) => setDiscountAmount(e.target.value)}
                  style={{ width: '80px', padding: '4px 8px', borderRadius: '4px', border: '1px solid #dcdce4', textAlign: 'right', fontSize: '12px' }}
                />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                <span style={{ color: '#666687' }}>GST / Tax ({taxRate}%)</span>
                <span>₹{taxAmount.toFixed(2)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '16px', fontWeight: '700', color: '#212134', paddingTop: '8px', borderTop: '1px dashed #dcdce4' }}>
                <span>Grand Total</span>
                <span style={{ color: '#b45309' }}>₹{grandTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* Payment Recording */}
            <div style={{ backgroundColor: '#fafafb', padding: '12px', borderRadius: '8px', marginBottom: '14px' }}>
              <label style={{ fontSize: '12px', fontWeight: '600', color: '#4a4a6a', display: 'block', marginBottom: '6px' }}>Payment Mode</label>
              <div style={{ display: 'flex', gap: '6px', marginBottom: '8px' }}>
                {['cash', 'upi', 'card'].map((m) => (
                  <button
                    key={m}
                    onClick={() => setPaymentMethod(m)}
                    style={{
                      flex: 1,
                      padding: '6px',
                      borderRadius: '4px',
                      border: '1px solid #dcdce4',
                      backgroundColor: paymentMethod === m ? '#f59e0b' : '#ffffff',
                      color: paymentMethod === m ? '#ffffff' : '#212134',
                      fontSize: '11px',
                      fontWeight: '700',
                      textTransform: 'uppercase',
                      cursor: 'pointer',
                    }}
                  >
                    {m}
                  </button>
                ))}
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '12px', color: '#666687' }}>Paid Amount:</span>
                <input
                  type="number"
                  min="0"
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(e.target.value)}
                  style={{ width: '100px', padding: '4px 8px', borderRadius: '4px', border: '1px solid #dcdce4', textAlign: 'right', fontSize: '12px' }}
                />
              </div>
            </div>

            {/* Action Checkout Button */}
            <button
              onClick={handleCreateBill}
              disabled={loading || cart.length === 0}
              style={{
                width: '100%',
                padding: '14px',
                borderRadius: '8px',
                backgroundColor: cart.length === 0 ? '#dcdce4' : '#10b981',
                color: '#ffffff',
                border: 'none',
                fontWeight: '700',
                fontSize: '14px',
                cursor: cart.length === 0 ? 'not-allowed' : 'pointer',
                boxShadow: '0 2px 6px rgba(16, 185, 129, 0.2)',
              }}
            >
              {loading ? 'Processing Bill...' : `Save & Print Bill (₹${grandTotal.toFixed(2)})`}
            </button>
          </div>
        </div>
      )}

      {/* TAB 2: BILL HISTORY */}
      {activeTab === 'history' && (
        <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '24px', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <h2 style={{ margin: 0, fontSize: '18px', fontWeight: '700' }}>Bill Invoices & History</h2>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button
                onClick={() => window.open('/restaurant-pos/reports/export-csv')}
                style={{ padding: '8px 16px', borderRadius: '6px', border: '1px solid #dcdce4', backgroundColor: '#ffffff', cursor: 'pointer', fontSize: '13px', fontWeight: '600' }}
              >
                Export CSV 📥
              </button>
              <button
                onClick={fetchBills}
                style={{ padding: '8px 16px', borderRadius: '6px', backgroundColor: '#212134', color: '#ffffff', border: 'none', cursor: 'pointer', fontSize: '13px', fontWeight: '600' }}
              >
                Refresh
              </button>
            </div>
          </div>

          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #eaeaef', textAlign: 'left', color: '#666687' }}>
                <th style={{ padding: '12px 8px' }}>Invoice #</th>
                <th style={{ padding: '12px 8px' }}>Date</th>
                <th style={{ padding: '12px 8px' }}>Type</th>
                <th style={{ padding: '12px 8px' }}>Customer</th>
                <th style={{ padding: '12px 8px' }}>Grand Total</th>
                <th style={{ padding: '12px 8px' }}>Paid</th>
                <th style={{ padding: '12px 8px' }}>Balance</th>
                <th style={{ padding: '12px 8px' }}>Status</th>
                <th style={{ padding: '12px 8px', textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {bills.map((b) => (
                <tr key={b.id} style={{ borderBottom: '1px solid #eaeaef' }}>
                  <td style={{ padding: '12px 8px', fontWeight: '700' }}>{b.invoiceNumber}</td>
                  <td style={{ padding: '12px 8px', color: '#666687' }}>{b.businessDate}</td>
                  <td style={{ padding: '12px 8px', textTransform: 'capitalize' }}>{b.orderType} {b.tableNumber ? `(${b.tableNumber})` : ''}</td>
                  <td style={{ padding: '12px 8px' }}>{b.customerName || 'Guest'} <br/><span style={{ fontSize: '11px', color: '#8e8ea9' }}>{b.customerPhone || ''}</span></td>
                  <td style={{ padding: '12px 8px', fontWeight: '700' }}>₹{b.grandTotal}</td>
                  <td style={{ padding: '12px 8px', color: '#166534' }}>₹{b.paidAmount}</td>
                  <td style={{ padding: '12px 8px', color: b.balanceAmount > 0 ? '#b45309' : '#666687' }}>₹{b.balanceAmount}</td>
                  <td style={{ padding: '12px 8px' }}>
                    <span style={{
                      padding: '3px 8px',
                      borderRadius: '4px',
                      fontSize: '11px',
                      fontWeight: '700',
                      textTransform: 'uppercase',
                      backgroundColor: b.status === 'paid' ? '#dcfce7' : b.status === 'cancelled' ? '#fee2e2' : '#fef3c7',
                      color: b.status === 'paid' ? '#166534' : b.status === 'cancelled' ? '#991b1b' : '#92400e',
                    }}>
                      {b.status}
                    </span>
                  </td>
                  <td style={{ padding: '12px 8px', textAlign: 'right', spaceX: '6px' }}>
                    <button
                      onClick={() => setPrintBill(b)}
                      style={{ padding: '4px 8px', borderRadius: '4px', border: '1px solid #dcdce4', backgroundColor: '#ffffff', cursor: 'pointer', fontSize: '11px', marginRight: '4px' }}
                    >
                      Print
                    </button>
                    {b.balanceAmount > 0 && b.status !== 'cancelled' && (
                      <button
                        onClick={() => {
                          setPayModalBill(b);
                          setPayModalAmount(b.balanceAmount);
                        }}
                        style={{ padding: '4px 8px', borderRadius: '4px', border: '1px solid #10b981', backgroundColor: '#ecfdf5', color: '#047857', cursor: 'pointer', fontSize: '11px', marginRight: '4px' }}
                      >
                        + Pay
                      </button>
                    )}
                    {b.status !== 'cancelled' && (
                      <button
                        onClick={() => setCancelModalBill(b)}
                        style={{ padding: '4px 8px', borderRadius: '4px', border: '1px solid #ef4444', backgroundColor: '#fef2f2', color: '#b91c1c', cursor: 'pointer', fontSize: '11px' }}
                      >
                        Cancel
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* TAB 3: DAILY BUSINESS SUMMARY & REPORTS */}
      {activeTab === 'reports' && (
        <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '24px', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
            <h2 style={{ margin: 0, fontSize: '18px', fontWeight: '700' }}>Daily Sales & Collections Summary</h2>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <label style={{ fontSize: '13px', color: '#666687' }}>Select Date:</label>
              <input
                type="date"
                value={reportsDate}
                onChange={(e) => {
                  setReportsDate(e.target.value);
                  fetchDailySummary(e.target.value);
                }}
                style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #dcdce4', fontSize: '13px' }}
              />
            </div>
          </div>

          {dailySummary ? (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '24px' }}>
              <div style={{ backgroundColor: '#fafafb', padding: '16px', borderRadius: '8px', border: '1px solid #eaeaef' }}>
                <span style={{ fontSize: '12px', color: '#666687' }}>Gross Sales</span>
                <h3 style={{ margin: '6px 0 0 0', fontSize: '20px', fontWeight: '700' }}>₹{dailySummary.grossSales}</h3>
              </div>
              <div style={{ backgroundColor: '#fafafb', padding: '16px', borderRadius: '8px', border: '1px solid #eaeaef' }}>
                <span style={{ fontSize: '12px', color: '#666687' }}>Discounts</span>
                <h3 style={{ margin: '6px 0 0 0', fontSize: '20px', fontWeight: '700', color: '#b45309' }}>-₹{dailySummary.totalDiscount}</h3>
              </div>
              <div style={{ backgroundColor: '#fafafb', padding: '16px', borderRadius: '8px', border: '1px solid #eaeaef' }}>
                <span style={{ fontSize: '12px', color: '#666687' }}>Taxes Collected</span>
                <h3 style={{ margin: '6px 0 0 0', fontSize: '20px', fontWeight: '700' }}>₹{dailySummary.totalTax}</h3>
              </div>
              <div style={{ backgroundColor: '#fafafb', padding: '16px', borderRadius: '8px', border: '1px solid #eaeaef' }}>
                <span style={{ fontSize: '12px', color: '#666687' }}>Net Sales</span>
                <h3 style={{ margin: '6px 0 0 0', fontSize: '20px', fontWeight: '700', color: '#10b981' }}>₹{dailySummary.netSales}</h3>
              </div>

              {/* Collections Breakdown Card */}
              <div style={{ gridColumn: 'span 2', backgroundColor: '#f0fdf4', padding: '16px', borderRadius: '8px', border: '1px solid #bbf7d0' }}>
                <h4 style={{ margin: '0 0 12px 0', fontSize: '14px', fontWeight: '700', color: '#166534' }}>Actual Payment Collections</h4>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '6px' }}>
                  <span>Cash Collection:</span>
                  <strong>₹{dailySummary.collections.cash}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '6px' }}>
                  <span>UPI Collection:</span>
                  <strong>₹{dailySummary.collections.upi}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '6px' }}>
                  <span>Card Collection:</span>
                  <strong>₹{dailySummary.collections.card}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', fontWeight: '700', paddingTop: '6px', borderTop: '1px solid #bbf7d0' }}>
                  <span>Total Collected:</span>
                  <strong style={{ color: '#166534' }}>₹{dailySummary.collections.total}</strong>
                </div>
              </div>

              {/* Bills Status Breakdown Card */}
              <div style={{ gridColumn: 'span 2', backgroundColor: '#f8fafc', padding: '16px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                <h4 style={{ margin: '0 0 12px 0', fontSize: '14px', fontWeight: '700', color: '#1e293b' }}>Bill Reconciliation</h4>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '6px' }}>
                  <span>Fully Paid Invoices:</span>
                  <strong>{dailySummary.statusCounts.paid}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '6px' }}>
                  <span>Partially Paid Invoices:</span>
                  <strong>{dailySummary.statusCounts.partiallyPaid}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '6px' }}>
                  <span>Unpaid Invoices:</span>
                  <strong>{dailySummary.statusCounts.unpaid}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#ef4444' }}>
                  <span>Cancelled Invoices:</span>
                  <strong>{dailySummary.statusCounts.cancelled}</strong>
                </div>
              </div>
            </div>
          ) : (
            <p>Loading summary data...</p>
          )}
        </div>
      )}

      {/* TAB 4: CUSTOMERS DIRECTORY */}
      {activeTab === 'customers' && (
        <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '24px', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
          <h2 style={{ margin: '0 0 20px 0', fontSize: '18px', fontWeight: '700' }}>Customer Profiles & Spending Metrics</h2>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #eaeaef', textAlign: 'left', color: '#666687' }}>
                <th style={{ padding: '12px 8px' }}>Name</th>
                <th style={{ padding: '12px 8px' }}>Phone</th>
                <th style={{ padding: '12px 8px' }}>Total Invoices</th>
                <th style={{ padding: '12px 8px' }}>Lifetime Spend</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((c) => (
                <tr key={c.id} style={{ borderBottom: '1px solid #eaeaef' }}>
                  <td style={{ padding: '12px 8px', fontWeight: '600' }}>{c.name}</td>
                  <td style={{ padding: '12px 8px', color: '#666687' }}>{c.phone}</td>
                  <td style={{ padding: '12px 8px' }}>{c.totalBillsCount} bills</td>
                  <td style={{ padding: '12px 8px', fontWeight: '700', color: '#166534' }}>₹{c.totalSpent}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* TAB 5: AUDIT LOGS */}
      {activeTab === 'logs' && (
        <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', padding: '24px', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
          <h2 style={{ margin: '0 0 20px 0', fontSize: '18px', fontWeight: '700' }}>System Activity Audit Trail</h2>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #eaeaef', textAlign: 'left', color: '#666687' }}>
                <th style={{ padding: '12px 8px' }}>Timestamp</th>
                <th style={{ padding: '12px 8px' }}>Admin</th>
                <th style={{ padding: '12px 8px' }}>Module</th>
                <th style={{ padding: '12px 8px' }}>Action</th>
                <th style={{ padding: '12px 8px' }}>Reference</th>
              </tr>
            </thead>
            <tbody>
              {activityLogs.map((log) => (
                <tr key={log.id} style={{ borderBottom: '1px solid #eaeaef' }}>
                  <td style={{ padding: '12px 8px', color: '#666687' }}>{new Date(log.timestamp).toLocaleString()}</td>
                  <td style={{ padding: '12px 8px', fontWeight: '500' }}>{log.adminEmail}</td>
                  <td style={{ padding: '12px 8px' }}>
                    <span style={{ backgroundColor: '#e0e7ff', color: '#4338ca', padding: '2px 8px', borderRadius: '4px', fontSize: '11px', fontWeight: '700' }}>
                      {log.module}
                    </span>
                  </td>
                  <td style={{ padding: '12px 8px', fontWeight: '600' }}>{log.action}</td>
                  <td style={{ padding: '12px 8px', fontFamily: 'monospace' }}>{log.recordRef}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* PRINT RECEIPT MODAL */}
      {printBill && (
        <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', width: printFormat === 'a4' ? '600px' : '360px', padding: '24px', maxHeight: '90vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div style={{ display: 'flex', gap: '6px' }}>
                <button
                  onClick={() => setPrintFormat('thermal80')}
                  style={{ padding: '4px 8px', fontSize: '11px', borderRadius: '4px', border: '1px solid #dcdce4', backgroundColor: printFormat === 'thermal80' ? '#212134' : '#fff', color: printFormat === 'thermal80' ? '#fff' : '#212134' }}
                >
                  80mm
                </button>
                <button
                  onClick={() => setPrintFormat('thermal58')}
                  style={{ padding: '4px 8px', fontSize: '11px', borderRadius: '4px', border: '1px solid #dcdce4', backgroundColor: printFormat === 'thermal58' ? '#212134' : '#fff', color: printFormat === 'thermal58' ? '#fff' : '#212134' }}
                >
                  58mm
                </button>
                <button
                  onClick={() => setPrintFormat('a4')}
                  style={{ padding: '4px 8px', fontSize: '11px', borderRadius: '4px', border: '1px solid #dcdce4', backgroundColor: printFormat === 'a4' ? '#212134' : '#fff', color: printFormat === 'a4' ? '#fff' : '#212134' }}
                >
                  A4
                </button>
              </div>
              <button onClick={() => setPrintBill(null)} style={{ border: 'none', background: 'none', fontSize: '18px', cursor: 'pointer' }}>✕</button>
            </div>

            {/* Printable Receipt Canvas */}
            <div id="printable-receipt" style={{ border: '1px dashed #dcdce4', padding: '16px', fontFamily: 'monospace', fontSize: '12px' }}>
              <div style={{ textAlign: 'center', marginBottom: '12px' }}>
                <h3 style={{ margin: 0, fontSize: '16px', fontFamily: 'serif' }}>AURA CULINARY & BISTRO</h3>
                <p style={{ margin: '2px 0', fontSize: '10px' }}>42 Gourmet Boulevard, High Street, Mumbai</p>
                <p style={{ margin: '2px 0', fontSize: '10px' }}>Tel: +91 98765 43210</p>
                <div style={{ borderBottom: '1px dashed #000', margin: '8px 0' }} />
                <p style={{ margin: '2px 0', fontWeight: 'bold' }}>TAX INVOICE: {printBill.invoiceNumber}</p>
                <p style={{ margin: '2px 0', fontSize: '10px' }}>Date: {printBill.businessDate} | Mode: {printBill.orderType.toUpperCase()}</p>
                {printBill.tableNumber && <p style={{ margin: '2px 0', fontSize: '10px' }}>Table: {printBill.tableNumber}</p>}
                {printBill.customerName && <p style={{ margin: '2px 0', fontSize: '10px' }}>Customer: {printBill.customerName} ({printBill.customerPhone})</p>}
                <div style={{ borderBottom: '1px dashed #000', margin: '8px 0' }} />
              </div>

              {/* Items */}
              <div style={{ marginBottom: '12px' }}>
                {(printBill.items || []).map((it, idx) => (
                  <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                    <span>{it.quantity}x {it.name}</span>
                    <span>₹{it.subtotal}</span>
                  </div>
                ))}
              </div>

              <div style={{ borderBottom: '1px dashed #000', margin: '8px 0' }} />

              <div style={{ spaceY: '4px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Subtotal:</span>
                  <span>₹{printBill.subtotal}</span>
                </div>
                {printBill.discountAmount > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>Discount:</span>
                    <span>-₹{printBill.discountAmount}</span>
                  </div>
                )}
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Tax ({printBill.taxRate}%):</span>
                  <span>₹{printBill.taxAmount}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', fontSize: '14px', margin: '6px 0' }}>
                  <span>GRAND TOTAL:</span>
                  <span>₹{printBill.grandTotal}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Paid Amount:</span>
                  <span>₹{printBill.paidAmount}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Balance Due:</span>
                  <span>₹{printBill.balanceAmount}</span>
                </div>
              </div>

              <div style={{ borderBottom: '1px dashed #000', margin: '12px 0' }} />
              <div style={{ textAlign: 'center', fontSize: '10px' }}>
                <p style={{ margin: '2px 0' }}>Thank you for dining with us!</p>
                <p style={{ margin: '2px 0' }}>GST Inclusive • Aura Restaurant</p>
              </div>
            </div>

            <button
              onClick={() => window.print()}
              style={{ width: '100%', marginTop: '16px', padding: '12px', borderRadius: '8px', backgroundColor: '#212134', color: '#ffffff', border: 'none', fontWeight: '700', cursor: 'pointer' }}
            >
              Print Document 🖨️
            </button>
          </div>
        </div>
      )}

      {/* CANCEL MODAL */}
      {cancelModalBill && (
        <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', width: '400px', padding: '24px' }}>
            <h3 style={{ margin: '0 0 12px 0', color: '#991b1b' }}>Cancel Invoice #{cancelModalBill.invoiceNumber}</h3>
            <p style={{ fontSize: '13px', color: '#666687' }}>Cancelled bills are permanently preserved in audit history and accounted in daily reconciliations.</p>
            <label style={{ fontSize: '12px', fontWeight: '600', display: 'block', marginBottom: '6px' }}>Reason for Cancellation</label>
            <textarea
              rows="3"
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              placeholder="e.g. Order entered in error, customer requested cancellation..."
              style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #dcdce4', fontSize: '13px', marginBottom: '16px' }}
            />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
              <button onClick={() => setCancelModalBill(null)} style={{ padding: '8px 16px', borderRadius: '6px', border: '1px solid #dcdce4', background: '#fff', cursor: 'pointer' }}>Back</button>
              <button onClick={handleCancelBill} style={{ padding: '8px 16px', borderRadius: '6px', border: 'none', background: '#ef4444', color: '#fff', fontWeight: '700', cursor: 'pointer' }}>Confirm Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* RECORD PAYMENT MODAL */}
      {payModalBill && (
        <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ backgroundColor: '#ffffff', borderRadius: '12px', width: '380px', padding: '24px' }}>
            <h3 style={{ margin: '0 0 12px 0' }}>Record Payment: #{payModalBill.invoiceNumber}</h3>
            <p style={{ fontSize: '13px', color: '#666687' }}>Remaining Balance: <strong>₹{payModalBill.balanceAmount}</strong></p>
            <div style={{ marginBottom: '12px' }}>
              <label style={{ fontSize: '12px', fontWeight: '600', display: 'block', marginBottom: '6px' }}>Payment Method</label>
              <select
                value={payModalMethod}
                onChange={(e) => setPayModalMethod(e.target.value)}
                style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #dcdce4', fontSize: '13px' }}
              >
                <option value="cash">Cash</option>
                <option value="upi">UPI</option>
                <option value="card">Card</option>
              </select>
            </div>
            <div style={{ marginBottom: '16px' }}>
              <label style={{ fontSize: '12px', fontWeight: '600', display: 'block', marginBottom: '6px' }}>Amount to Pay (₹)</label>
              <input
                type="number"
                min="1"
                max={payModalBill.balanceAmount}
                value={payModalAmount}
                onChange={(e) => setPayModalAmount(e.target.value)}
                style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #dcdce4', fontSize: '13px' }}
              />
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
              <button onClick={() => setPayModalBill(null)} style={{ padding: '8px 16px', borderRadius: '6px', border: '1px solid #dcdce4', background: '#fff', cursor: 'pointer' }}>Cancel</button>
              <button onClick={handleRecordPayment} style={{ padding: '8px 16px', borderRadius: '6px', border: 'none', background: '#10b981', color: '#fff', fontWeight: '700', cursor: 'pointer' }}>Record Payment</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

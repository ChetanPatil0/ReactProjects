'use strict';

module.exports = ({ strapi }) => ({
  /**
   * Generates business day summary distinguishing gross sales from actual payment collections
   */
  async getDailySummary(dateString) {
    const targetDate = dateString || new Date().toISOString().split('T')[0];

    const bills = await strapi.db.query('plugin::restaurant-pos.bill').findMany({
      where: { businessDate: targetDate },
    });

    let grossSales = 0;
    let totalDiscount = 0;
    let totalTax = 0;
    let netSales = 0;

    let totalPaidBills = 0;
    let totalUnpaidBills = 0;
    let totalPartiallyPaidBills = 0;
    let totalCancelledBills = 0;

    let cashCollection = 0;
    let upiCollection = 0;
    let cardCollection = 0;

    bills.forEach((bill) => {
      if (bill.status === 'cancelled') {
        totalCancelledBills++;
        return; // Exclude cancelled bills from valid sales
      }

      grossSales += parseFloat(bill.subtotal) || 0;
      totalDiscount += parseFloat(bill.discountAmount) || 0;
      totalTax += parseFloat(bill.taxAmount) || 0;
      netSales += parseFloat(bill.grandTotal) || 0;

      if (bill.status === 'paid') totalPaidBills++;
      else if (bill.status === 'partially_paid') totalPartiallyPaidBills++;
      else if (bill.status === 'unpaid') totalUnpaidBills++;

      // Sum payment method collections
      if (Array.isArray(bill.payments)) {
        bill.payments.forEach((p) => {
          const amt = parseFloat(p.amount) || 0;
          if (p.method === 'cash') cashCollection += amt;
          else if (p.method === 'upi') upiCollection += amt;
          else if (p.method === 'card') cardCollection += amt;
        });
      }
    });

    // Refund totals for the target date
    const refunds = await strapi.db.query('plugin::restaurant-pos.refund-record').findMany();
    const dayRefunds = refunds.filter((r) => {
      const rDate = new Date(r.processedAt).toISOString().split('T')[0];
      return rDate === targetDate;
    });
    const totalRefunds = dayRefunds.reduce((sum, r) => sum + (parseFloat(r.amount) || 0), 0);

    const totalCollected = cashCollection + upiCollection + cardCollection;

    return {
      businessDate: targetDate,
      totalBills: bills.length,
      activeBills: bills.length - totalCancelledBills,
      grossSales: Math.round(grossSales * 100) / 100,
      totalDiscount: Math.round(totalDiscount * 100) / 100,
      totalTax: Math.round(totalTax * 100) / 100,
      netSales: Math.round(netSales * 100) / 100,
      collections: {
        cash: Math.round(cashCollection * 100) / 100,
        upi: Math.round(upiCollection * 100) / 100,
        card: Math.round(cardCollection * 100) / 100,
        total: Math.round(totalCollected * 100) / 100,
      },
      statusCounts: {
        paid: totalPaidBills,
        partiallyPaid: totalPartiallyPaidBills,
        unpaid: totalUnpaidBills,
        cancelled: totalCancelledBills,
      },
      refunds: {
        count: dayRefunds.length,
        totalAmount: Math.round(totalRefunds * 100) / 100,
      },
    };
  },

  /**
   * Generates CSV string of bills for financial reporting
   */
  async exportBillsCsv(query = {}) {
    const where = {};
    if (query.date) where.businessDate = query.date;
    if (query.status && query.status !== 'all') where.status = query.status;

    const bills = await strapi.db.query('plugin::restaurant-pos.bill').findMany({
      where,
      orderBy: { id: 'desc' },
    });

    const headers = [
      'Invoice Number',
      'Date',
      'Order Type',
      'Table',
      'Customer Name',
      'Customer Phone',
      'Subtotal (INR)',
      'Discount (INR)',
      'Tax (INR)',
      'Grand Total (INR)',
      'Paid (INR)',
      'Balance (INR)',
      'Status',
    ];

    const rows = bills.map((b) => [
      `"${b.invoiceNumber}"`,
      `"${b.businessDate}"`,
      `"${b.orderType}"`,
      `"${b.tableNumber || '-'}"`,
      `"${(b.customerName || 'Guest').replace(/"/g, '""')}"`,
      `"${b.customerPhone || '-'}"`,
      b.subtotal,
      b.discountAmount,
      b.taxAmount,
      b.grandTotal,
      b.paidAmount,
      b.balanceAmount,
      `"${b.status}"`,
    ]);

    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  },
});

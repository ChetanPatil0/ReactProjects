'use strict';

module.exports = {
  type: 'admin',
  routes: [
    {
      method: 'GET',
      path: '/pos/menu',
      handler: 'billing.getPosMenu',
      config: { policies: [] },
    },
    {
      method: 'POST',
      path: '/pos/calculate',
      handler: 'billing.calculate',
      config: { policies: [] },
    },
    {
      method: 'POST',
      path: '/bills',
      handler: 'billing.createBill',
      config: { policies: [] },
    },
    {
      method: 'GET',
      path: '/bills',
      handler: 'billing.getBills',
      config: { policies: [] },
    },
    {
      method: 'GET',
      path: '/bills/:id',
      handler: 'billing.getBill',
      config: { policies: [] },
    },
    {
      method: 'POST',
      path: '/bills/:id/payments',
      handler: 'billing.recordPayment',
      config: { policies: [] },
    },
    {
      method: 'POST',
      path: '/bills/:id/cancel',
      handler: 'billing.cancelBill',
      config: { policies: [] },
    },
    {
      method: 'POST',
      path: '/bills/:id/refund',
      handler: 'billing.refundBill',
      config: { policies: [] },
    },
    {
      method: 'GET',
      path: '/reports/daily-summary',
      handler: 'reports.getDailySummary',
      config: { policies: [] },
    },
    {
      method: 'GET',
      path: '/reports/export-csv',
      handler: 'reports.exportCsv',
      config: { policies: [] },
    },
    {
      method: 'GET',
      path: '/customers',
      handler: 'customers.getCustomers',
      config: { policies: [] },
    },
    {
      method: 'GET',
      path: '/customers/:phone',
      handler: 'customers.getCustomerByPhone',
      config: { policies: [] },
    },
    {
      method: 'GET',
      path: '/customers/:phone/history',
      handler: 'customers.getCustomerHistory',
      config: { policies: [] },
    },
    {
      method: 'GET',
      path: '/activity-logs',
      handler: 'activity.getLogs',
      config: { policies: [] },
    },
  ],
};

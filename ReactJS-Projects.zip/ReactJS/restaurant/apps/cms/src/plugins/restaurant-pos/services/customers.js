'use strict';

module.exports = ({ strapi }) => ({
  async getCustomers(query = {}) {
    const where = {};
    if (query.search) {
      where.$or = [
        { name: { $containsi: query.search } },
        { phone: { $containsi: query.search } },
      ];
    }

    const customers = await strapi.db.query('plugin::restaurant-pos.customer').findMany({
      where,
      orderBy: { totalSpent: 'desc' },
      limit: parseInt(query.limit, 10) || 50,
    });

    const total = await strapi.db.query('plugin::restaurant-pos.customer').count({ where });

    return { data: customers, total };
  },

  async getCustomerByPhone(phone) {
    if (!phone) return null;
    return strapi.db.query('plugin::restaurant-pos.customer').findOne({
      where: { phone: String(phone).trim() },
    });
  },

  async getCustomerHistory(phone) {
    if (!phone) return [];
    return strapi.db.query('plugin::restaurant-pos.bill').findMany({
      where: { customerPhone: String(phone).trim() },
      orderBy: { id: 'desc' },
    });
  },
});

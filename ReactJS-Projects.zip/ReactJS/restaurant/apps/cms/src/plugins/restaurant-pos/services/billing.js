'use strict';

module.exports = ({ strapi }) => ({
  /**
   * Generates a unique sequential invoice number based on restaurant settings
   */
  async generateInvoiceNumber() {
    const settings = await strapi.db.query('api::restaurant-setting.restaurant-setting').findOne();
    const prefix = settings?.invoicePrefix || 'INV-2026-';
    const padding = settings?.invoicePadding || 4;

    const count = await strapi.db.query('plugin::restaurant-pos.bill').count();
    const nextSeq = count + 1;
    const formattedNum = String(nextSeq).padStart(padding, '0');

    return `${prefix}${formattedNum}`;
  },

  /**
   * Calculates totals server-side with currency rounding
   */
  calculateTotals({ items, discountAmount = 0, taxRate = 5.0 }) {
    let subtotal = 0;
    const validatedItems = items.map((item) => {
      const qty = Math.max(1, parseInt(item.quantity, 10) || 1);
      const price = Math.max(0, parseFloat(item.unitPrice || item.price) || 0);
      const lineTotal = Math.round(qty * price * 100) / 100;
      subtotal += lineTotal;

      return {
        menuItemId: item.menuItemId || item.id || null,
        name: String(item.name || 'Custom Item'),
        unitPrice: price,
        quantity: qty,
        foodType: item.foodType === 'non-veg' ? 'non-veg' : 'veg',
        subtotal: lineTotal,
      };
    });

    subtotal = Math.round(subtotal * 100) / 100;
    const discount = Math.min(subtotal, Math.max(0, parseFloat(discountAmount) || 0));
    const taxableAmount = Math.max(0, subtotal - discount);
    const tax = Math.round(((taxableAmount * taxRate) / 100) * 100) / 100;
    const grandTotal = Math.round((taxableAmount + tax) * 100) / 100;

    return {
      items: validatedItems,
      subtotal,
      discountAmount: discount,
      taxRate,
      taxAmount: tax,
      grandTotal,
    };
  },

  /**
   * Creates a new bill with historical snapshot and sequential invoice number
   */
  async createBill(payload, adminUser) {
    const settings = await strapi.db.query('api::restaurant-setting.restaurant-setting').findOne();
    const taxRate = parseFloat(settings?.taxRate) || 5.0;

    const totals = this.calculateTotals({
      items: payload.items || [],
      discountAmount: payload.discountAmount,
      taxRate,
    });

    const invoiceNumber = await this.generateInvoiceNumber();
    const today = new Date().toISOString().split('T')[0];

    // Initial payment if supplied
    let initialPayments = [];
    let initialPaid = 0;
    if (payload.paymentMethod && payload.paymentAmount > 0) {
      const amt = Math.min(totals.grandTotal, Math.max(0, parseFloat(payload.paymentAmount)));
      initialPaid = Math.round(amt * 100) / 100;
      initialPayments.push({
        id: `PAY-${Date.now()}-1`,
        method: payload.paymentMethod, // 'cash' | 'upi' | 'card'
        amount: initialPaid,
        recordedAt: new Date().toISOString(),
        recordedBy: adminUser?.email || 'admin',
        notes: payload.paymentNotes || 'Initial payment',
      });
    }

    const balanceAmount = Math.max(0, Math.round((totals.grandTotal - initialPaid) * 100) / 100);
    let status = 'unpaid';
    if (balanceAmount <= 0) {
      status = 'paid';
    } else if (initialPaid > 0) {
      status = 'partially_paid';
    }

    const bill = await strapi.db.query('plugin::restaurant-pos.bill').create({
      data: {
        invoiceNumber,
        orderType: payload.orderType === 'takeaway' ? 'takeaway' : 'dine_in',
        tableNumber: payload.tableNumber ? String(payload.tableNumber) : null,
        customerName: payload.customerName ? String(payload.customerName).trim() : null,
        customerPhone: payload.customerPhone ? String(payload.customerPhone).trim() : null,
        items: totals.items,
        subtotal: totals.subtotal,
        discountAmount: totals.discountAmount,
        discountReason: payload.discountReason ? String(payload.discountReason) : null,
        taxRate: totals.taxRate,
        taxAmount: totals.taxAmount,
        grandTotal: totals.grandTotal,
        paidAmount: initialPaid,
        balanceAmount,
        status,
        payments: initialPayments,
        businessDate: today,
        notes: payload.notes ? String(payload.notes) : null,
      },
    });

    // Update or create Customer lifetime metrics if customerPhone is present
    if (payload.customerPhone) {
      const phone = String(payload.customerPhone).trim();
      const existingCustomer = await strapi.db.query('plugin::restaurant-pos.customer').findOne({
        where: { phone },
      });

      if (existingCustomer) {
        await strapi.db.query('plugin::restaurant-pos.customer').update({
          where: { id: existingCustomer.id },
          data: {
            name: payload.customerName || existingCustomer.name,
            totalSpent: Math.round(((parseFloat(existingCustomer.totalSpent) || 0) + initialPaid) * 100) / 100,
            totalBillsCount: (existingCustomer.totalBillsCount || 0) + 1,
          },
        });
      } else {
        await strapi.db.query('plugin::restaurant-pos.customer').create({
          data: {
            name: payload.customerName || 'Guest Customer',
            phone,
            totalSpent: initialPaid,
            totalBillsCount: 1,
          },
        });
      }
    }

    // Log Activity
    await strapi.plugin('restaurant-pos').service('audit').log({
      adminUser,
      action: 'BILL_CREATED',
      module: 'BILLING',
      recordRef: invoiceNumber,
      metadata: {
        grandTotal: totals.grandTotal,
        paidAmount: initialPaid,
        orderType: payload.orderType,
        status,
      },
    });

    return bill;
  },

  /**
   * Retrieves historical bills with filtering and pagination
   */
  async getBills(query = {}) {
    const where = {};

    if (query.status && query.status !== 'all') {
      where.status = query.status;
    }

    if (query.date) {
      where.businessDate = query.date;
    }

    if (query.search) {
      where.$or = [
        { invoiceNumber: { $containsi: query.search } },
        { customerPhone: { $containsi: query.search } },
        { customerName: { $containsi: query.search } },
      ];
    }

    const bills = await strapi.db.query('plugin::restaurant-pos.bill').findMany({
      where,
      orderBy: { id: 'desc' },
      limit: parseInt(query.limit, 10) || 50,
      offset: parseInt(query.offset, 10) || 0,
    });

    const total = await strapi.db.query('plugin::restaurant-pos.bill').count({ where });

    return { data: bills, total };
  },

  /**
   * Retrieves a single bill by ID
   */
  async getBillById(id) {
    return strapi.db.query('plugin::restaurant-pos.bill').findOne({
      where: { id },
    });
  },

  /**
   * Records payment against an existing bill
   */
  async recordPayment(billId, payload, adminUser) {
    const bill = await strapi.db.query('plugin::restaurant-pos.bill').findOne({
      where: { id: billId },
    });

    if (!bill) {
      throw new Error('Bill not found');
    }

    if (bill.status === 'cancelled') {
      throw new Error('Cannot add payments to a cancelled bill');
    }

    const paymentAmount = Math.max(0, parseFloat(payload.amount) || 0);
    if (paymentAmount <= 0) {
      throw new Error('Payment amount must be greater than zero');
    }

    if (paymentAmount > bill.balanceAmount) {
      throw new Error(`Payment cannot exceed the remaining balance of ₹${bill.balanceAmount}`);
    }

    const payments = Array.isArray(bill.payments) ? [...bill.payments] : [];
    const newPayment = {
      id: `PAY-${Date.now()}-${payments.length + 1}`,
      method: payload.method || 'cash',
      amount: paymentAmount,
      recordedAt: new Date().toISOString(),
      recordedBy: adminUser?.email || 'admin',
      notes: payload.notes || 'Subsequent payment',
    };
    payments.push(newPayment);

    const newPaid = Math.round(((parseFloat(bill.paidAmount) || 0) + paymentAmount) * 100) / 100;
    const newBalance = Math.max(0, Math.round(((parseFloat(bill.grandTotal) || 0) - newPaid) * 100) / 100);
    const newStatus = newBalance <= 0 ? 'paid' : 'partially_paid';

    const updated = await strapi.db.query('plugin::restaurant-pos.bill').update({
      where: { id: billId },
      data: {
        paidAmount: newPaid,
        balanceAmount: newBalance,
        status: newStatus,
        payments,
      },
    });

    // Update Customer spending
    if (bill.customerPhone) {
      const customer = await strapi.db.query('plugin::restaurant-pos.customer').findOne({
        where: { phone: bill.customerPhone },
      });
      if (customer) {
        await strapi.db.query('plugin::restaurant-pos.customer').update({
          where: { id: customer.id },
          data: {
            totalSpent: Math.round(((parseFloat(customer.totalSpent) || 0) + paymentAmount) * 100) / 100,
          },
        });
      }
    }

    // Log Activity
    await strapi.plugin('restaurant-pos').service('audit').log({
      adminUser,
      action: 'PAYMENT_RECORDED',
      module: 'BILLING',
      recordRef: bill.invoiceNumber,
      metadata: {
        paymentAmount,
        method: payload.method,
        newStatus,
      },
    });

    return updated;
  },

  /**
   * Cancels a bill with reason tracking without destroying historical record
   */
  async cancelBill(billId, payload, adminUser) {
    const bill = await strapi.db.query('plugin::restaurant-pos.bill').findOne({
      where: { id: billId },
    });

    if (!bill) {
      throw new Error('Bill not found');
    }

    if (bill.status === 'cancelled') {
      throw new Error('Bill is already cancelled');
    }

    if (!payload.reason || !payload.reason.trim()) {
      throw new Error('Cancellation reason is required');
    }

    const updated = await strapi.db.query('plugin::restaurant-pos.bill').update({
      where: { id: billId },
      data: {
        status: 'cancelled',
        cancellationReason: payload.reason.trim(),
        cancelledAt: new Date(),
        cancelledBy: adminUser?.email || 'admin',
      },
    });

    // Log Activity
    await strapi.plugin('restaurant-pos').service('audit').log({
      adminUser,
      action: 'BILL_CANCELLED',
      module: 'BILLING',
      recordRef: bill.invoiceNumber,
      metadata: {
        reason: payload.reason,
        originalGrandTotal: bill.grandTotal,
      },
    });

    return updated;
  },

  /**
   * Issues refund with validation against paid amount
   */
  async refundBill(billId, payload, adminUser) {
    const bill = await strapi.db.query('plugin::restaurant-pos.bill').findOne({
      where: { id: billId },
    });

    if (!bill) {
      throw new Error('Bill not found');
    }

    const refundAmount = Math.max(0, parseFloat(payload.amount) || 0);
    if (refundAmount <= 0) {
      throw new Error('Refund amount must be greater than zero');
    }

    // Check existing refunds
    const existingRefunds = await strapi.db.query('plugin::restaurant-pos.refund-record').findMany({
      where: { billId: bill.id },
    });
    const alreadyRefunded = existingRefunds.reduce((sum, r) => sum + (parseFloat(r.amount) || 0), 0);
    const maxRefundable = (parseFloat(bill.paidAmount) || 0) - alreadyRefunded;

    if (refundAmount > maxRefundable) {
      throw new Error(`Refund cannot exceed refundable paid balance of ₹${maxRefundable.toFixed(2)}`);
    }

    const refund = await strapi.db.query('plugin::restaurant-pos.refund-record').create({
      data: {
        billInvoiceNumber: bill.invoiceNumber,
        billId: bill.id,
        amount: refundAmount,
        reason: payload.reason || 'Customer requested refund',
        method: payload.method || 'cash',
        processedBy: adminUser?.email || 'admin',
        processedAt: new Date(),
      },
    });

    // Log Activity
    await strapi.plugin('restaurant-pos').service('audit').log({
      adminUser,
      action: 'REFUND_ISSUED',
      module: 'REFUNDS',
      recordRef: bill.invoiceNumber,
      metadata: {
        refundAmount,
        method: payload.method,
        reason: payload.reason,
      },
    });

    return refund;
  },
});

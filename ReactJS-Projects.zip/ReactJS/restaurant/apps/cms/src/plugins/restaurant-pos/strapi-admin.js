import { PosApp } from './admin/src/pages/PosApp.jsx';

const plugin = {
  register(app) {
    if (app.addMenuLink) {
      app.addMenuLink({
        to: 'plugins/restaurant-pos',
        icon: () => '🍽',
        intlLabel: {
          id: 'restaurant-pos.menu.title',
          defaultMessage: 'Billing & POS',
        },
        Component: () => PosApp,
        permissions: [],
      });
    }
  },
  bootstrap(app) {},
};

export default plugin;

'use strict';

module.exports = ({ strapi }) => ({
  async getLogs(ctx) {
    const logs = await strapi.db.query('plugin::restaurant-pos.activity-log').findMany({
      orderBy: { id: 'desc' },
      limit: parseInt(ctx.query.limit, 10) || 50,
      offset: parseInt(ctx.query.offset, 10) || 0,
    });
    const total = await strapi.db.query('plugin::restaurant-pos.activity-log').count();
    ctx.body = { data: logs, total };
  },
});

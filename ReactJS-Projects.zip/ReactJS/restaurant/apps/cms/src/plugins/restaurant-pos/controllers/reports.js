'use strict';

module.exports = ({ strapi }) => ({
  async getDailySummary(ctx) {
    const { date } = ctx.query;
    const summary = await strapi.plugin('restaurant-pos').service('reports').getDailySummary(date);
    ctx.body = summary;
  },

  async exportCsv(ctx) {
    const csvData = await strapi.plugin('restaurant-pos').service('reports').exportBillsCsv(ctx.query);
    ctx.set('Content-Type', 'text/csv');
    ctx.set('Content-Disposition', `attachment; filename="bills-export-${Date.now()}.csv"`);
    ctx.body = csvData;
  },
});

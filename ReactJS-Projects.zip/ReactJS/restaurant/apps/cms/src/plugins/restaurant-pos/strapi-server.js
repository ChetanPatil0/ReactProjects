'use strict';

const billSchema = require('./content-types/bill/schema.json');
const customerSchema = require('./content-types/customer/schema.json');
const refundRecordSchema = require('./content-types/refund-record/schema.json');
const activityLogSchema = require('./content-types/activity-log/schema.json');

const billingController = require('./controllers/billing');
const reportsController = require('./controllers/reports');
const customersController = require('./controllers/customers');
const activityController = require('./controllers/activity');

const billingService = require('./services/billing');
const reportsService = require('./services/reports');
const customersService = require('./services/customers');
const auditService = require('./services/audit');

const adminRoutes = require('./routes/admin');

module.exports = {
  async register({ strapi }) {
    const actionProvider = strapi.service('admin::permission')?.actionProvider;
    if (actionProvider) {
      await actionProvider.registerMany([
        {
          section: 'plugins',
          displayName: 'Access Billing / POS',
          uid: 'billing.access',
          pluginName: 'restaurant-pos',
        },
        {
          section: 'plugins',
          displayName: 'Create Bills',
          uid: 'billing.create',
          pluginName: 'restaurant-pos',
        },
        {
          section: 'plugins',
          displayName: 'Record Payments',
          uid: 'billing.payment',
          pluginName: 'restaurant-pos',
        },
        {
          section: 'plugins',
          displayName: 'Cancel Bills',
          uid: 'billing.cancel',
          pluginName: 'restaurant-pos',
        },
        {
          section: 'plugins',
          displayName: 'Issue Refunds',
          uid: 'billing.refund',
          pluginName: 'restaurant-pos',
        },
        {
          section: 'plugins',
          displayName: 'Manage Customers',
          uid: 'customers.manage',
          pluginName: 'restaurant-pos',
        },
        {
          section: 'plugins',
          displayName: 'View Reports & Business Summaries',
          uid: 'reports.read',
          pluginName: 'restaurant-pos',
        },
        {
          section: 'plugins',
          displayName: 'Export Reports (CSV)',
          uid: 'reports.export',
          pluginName: 'restaurant-pos',
        },
        {
          section: 'plugins',
          displayName: 'View Activity Log',
          uid: 'activity-log.read',
          pluginName: 'restaurant-pos',
        },
        {
          section: 'plugins',
          displayName: 'Manage Settings & Print Config',
          uid: 'settings.manage',
          pluginName: 'restaurant-pos',
        },
        {
          section: 'plugins',
          displayName: 'Manage Backup & Restore',
          uid: 'backup.manage',
          pluginName: 'restaurant-pos',
        },
      ]);
    }
  },

  bootstrap({ strapi }) {},

  routes: {
    admin: adminRoutes,
  },

  controllers: {
    billing: billingController,
    reports: reportsController,
    customers: customersController,
    activity: activityController,
  },

  services: {
    billing: billingService,
    reports: reportsService,
    customers: customersService,
    audit: auditService,
  },

  contentTypes: {
    bill: { schema: billSchema },
    customer: { schema: customerSchema },
    'refund-record': { schema: refundRecordSchema },
    'activity-log': { schema: activityLogSchema },
  },
};

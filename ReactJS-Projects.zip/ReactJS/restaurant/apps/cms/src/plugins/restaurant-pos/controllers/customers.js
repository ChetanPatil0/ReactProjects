'use strict';

module.exports = ({ strapi }) => ({
  async getCustomers(ctx) {
    const result = await strapi.plugin('restaurant-pos').service('customers').getCustomers(ctx.query);
    ctx.body = result;
  },

  async getCustomerByPhone(ctx) {
    const { phone } = ctx.params;
    const customer = await strapi.plugin('restaurant-pos').service('customers').getCustomerByPhone(phone);
    if (!customer) {
      return ctx.notFound('Customer not found');
    }
    ctx.body = customer;
  },

  async getCustomerHistory(ctx) {
    const { phone } = ctx.params;
    const history = await strapi.plugin('restaurant-pos').service('customers').getCustomerHistory(phone);
    ctx.body = history;
  },
});

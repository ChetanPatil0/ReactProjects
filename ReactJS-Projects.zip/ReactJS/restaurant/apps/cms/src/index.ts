import type { Core } from '@strapi/strapi';

export default {
  register({ strapi }: { strapi: Core.Strapi }) {},

  async bootstrap({ strapi }: { strapi: Core.Strapi }) {
    try {
      // ========================================================
      // 1. Configure Public Role Permissions for website consumption
      // ========================================================
      const publicRole = await strapi.db.query('plugin::users-permissions.role').findOne({
        where: { type: 'public' },
      });

      if (publicRole) {
        const publicActions = [
          'api::menu-category.menu-category.find',
          'api::menu-category.menu-category.findOne',
          'api::menu-item.menu-item.find',
          'api::menu-item.menu-item.findOne',
          'api::homepage.homepage.find',
          'api::about.about.find',
          'api::gallery.gallery.find',
          'api::gallery.gallery.findOne',
          'api::offer.offer.find',
          'api::offer.offer.findOne',
          'api::contact.contact.find',
          'api::restaurant-setting.restaurant-setting.find',
        ];

        for (const action of publicActions) {
          const existing = await strapi.db.query('plugin::users-permissions.permission').findOne({
            where: { action, role: publicRole.id },
          });

          if (!existing) {
            await strapi.db.query('plugin::users-permissions.permission').create({
              data: { action, role: publicRole.id },
            });
          }
        }
      }

      // ========================================================
      // 2. Default Administrator Role Templates
      // ========================================================
      const adminRoleService = strapi.service('admin::role');
      if (adminRoleService) {
        const roleTemplates = [
          {
            name: 'Owner',
            code: 'restaurant-owner',
            description: 'Full restaurant management: website, menu, staff, billing, reports, and settings.',
          },
          {
            name: 'Manager',
            code: 'restaurant-manager',
            description: 'Day-to-day operations: website, menu, billing, customers, and reports viewing.',
          },
          {
            name: 'Content Editor',
            code: 'restaurant-content-editor',
            description: 'Digital presence: website content, menu details and photos, gallery, and offers.',
          },
          {
            name: 'Cashier',
            code: 'restaurant-cashier',
            description: 'Front-desk point of sale: create bills, record payments, and print receipts.',
          },
          {
            name: 'Reports Viewer',
            code: 'restaurant-reports-viewer',
            description: 'Auditor & accountant: read-only access to sales, payments, and business summaries.',
          },
        ];

        for (const template of roleTemplates) {
          const existingRole = await strapi.db.query('admin::role').findOne({
            where: { code: template.code },
          });

          if (!existingRole) {
            await strapi.db.query('admin::role').create({
              data: template,
            });
            strapi.log.info(`Initialized role template: ${template.name}`);
          }
        }
      }

      // ========================================================
      // 3. Super Admin Deletion / Demotion Protection
      // ========================================================
      strapi.db.lifecycles.subscribe({
        models: ['admin::user'],
        async beforeDelete(event) {
          const { where } = event.params;
          const userToDelete = await strapi.db.query('admin::user').findOne({
            where,
            populate: ['roles'],
          });

          if (userToDelete?.roles?.some((r: any) => r.code === 'strapi-super-admin')) {
            const superAdmins = await strapi.db.query('admin::user').findMany({
              where: { isActive: true },
              populate: ['roles'],
            });

            const superAdminCount = superAdmins.filter((u: any) =>
              u.roles?.some((r: any) => r.code === 'strapi-super-admin')
            ).length;

            if (superAdminCount <= 1) {
              throw new Error('Security Violation: The last active Super Admin account cannot be deleted.');
            }
          }
        },
        async beforeUpdate(event) {
          const { where, data } = event.params;
          if (data && (data.isActive === false || data.roles)) {
            const userToUpdate = await strapi.db.query('admin::user').findOne({
              where,
              populate: ['roles'],
            });

            if (userToUpdate?.roles?.some((r: any) => r.code === 'strapi-super-admin')) {
              const willRemainSuperAdmin =
                data.isActive !== false &&
                (!data.roles || data.roles.some((r: any) => r === 1 || r.code === 'strapi-super-admin'));

              if (!willRemainSuperAdmin) {
                const activeSuperAdmins = await strapi.db.query('admin::user').findMany({
                  where: { isActive: true },
                  populate: ['roles'],
                });

                const count = activeSuperAdmins.filter(
                  (u: any) => u.id !== userToUpdate.id && u.roles?.some((r: any) => r.code === 'strapi-super-admin')
                ).length;

                if (count < 1) {
                  throw new Error('Security Violation: The last active Super Admin account cannot be demoted or deactivated.');
                }
              }
            }
          }
        },
      });

      // ========================================================
      // 4. Seed Default Restaurant Settings if empty
      // ========================================================
      const existingSettings = await strapi.db.query('api::restaurant-setting.restaurant-setting').findOne();
      if (!existingSettings) {
        await strapi.db.query('api::restaurant-setting.restaurant-setting').create({
          data: {
            restaurantName: 'Aura Culinary & Bistro',
            tagline: 'Fine Dining & Artisanal Hospitality',
            address: '42 Gourmet Boulevard, High Street, Mumbai, 400001',
            contactNumber: '+91 98765 43210',
            contactEmail: 'reservations@aurabistro.com',
            currency: 'INR',
            currencySymbol: '₹',
            taxRate: 5.0,
            invoicePrefix: 'INV-2026-',
            invoicePadding: 4,
            invoiceFooter: 'Thank you for dining with us! Please visit again.',
            timezone: 'Asia/Kolkata',
            primaryThemeColor: '#f59e0b',
          },
        });
      }

      // ========================================================
      // 5. Seed Homepage content if empty
      // ========================================================
      const existingHomepage = await strapi.db.query('api::homepage.homepage').findOne();
      if (!existingHomepage) {
        await strapi.db.query('api::homepage.homepage').create({
          data: {
            announcement: 'Chef Tasting Menu Available Every Weekend — Reserve Your Table Early',
            heroTitle: 'A Symphony of Flavors, Crafted with Passion & Precision.',
            heroSubtitle: 'Step into an intimate sanctuary of artisanal gastronomy, seasonal ingredients, and refined dining hospitality.',
            introTitle: 'Culinary Excellence Since 2018',
            introDescription: 'At Aura, every dish is conceived as a work of edible art. Rooted in traditional techniques and elevated by contemporary innovation, our seasonal menus honor fresh produce and heritage flavors.',
            openingHoursPreview: 'Mon - Sun: 12:00 PM – 11:30 PM',
            locationHighlight: '42 Gourmet Boulevard, High Street, Mumbai',
          },
        });
      }

      // ========================================================
      // 6. Seed About content if empty
      // ========================================================
      const existingAbout = await strapi.db.query('api::about.about').findOne();
      if (!existingAbout) {
        await strapi.db.query('api::about.about').create({
          data: {
            title: 'The Aura Heritage',
            story: 'Founded with a vision to redefine gastronomy, Aura merges heritage cooking methods with contemporary culinary artistry. Our ingredients are sourced directly from ethical organic farms.',
            mission: 'To create unforgettable dining moments that inspire the senses, foster togetherness, and celebrate the richness of authentic food craft.',
            philosophy: 'Pure ingredients, zero shortcuts, deep flavor profiles, and attentive warmth.',
            chefName: 'Chef Marc Renoir',
            chefBio: 'Executive Chef Marc Renoir brings over 18 years of Michelin-starred European and modern fusion culinary mastery, curated specifically for the discerning palate.',
          },
        });
      }

      // ========================================================
      // 7. Seed Contact content if empty
      // ========================================================
      const existingContact = await strapi.db.query('api::contact.contact').findOne();
      if (!existingContact) {
        await strapi.db.query('api::contact.contact').create({
          data: {
            address: '42 Gourmet Boulevard, High Street, Mumbai, 400001',
            phone: '+91 98765 43210',
            email: 'reservations@aurabistro.com',
            openingHours: 'Lunch: 12:00 PM - 3:30 PM | Dinner: 7:00 PM - 11:30 PM',
            instagramUrl: 'https://instagram.com/aura_culinary',
            facebookUrl: 'https://facebook.com/aurabistro',
            googleMapsEmbedUrl: 'https://maps.google.com',
          },
        });
      }
    } catch (err) {
      strapi.log.error('Bootstrap seeding error:', err);
    }
  },
};

import type { Metadata } from "next";
import { Playfair_Display, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { WebsiteShell } from "@/components/layout/WebsiteShell";
import { ThemeProvider } from "@/components/theme/ThemeProvider";
import { getRestaurantSettings, getHomepageData, getContactData } from "@/lib/api/restaurant";

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-serif",
  display: "swap",
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getRestaurantSettings();
  return {
    title: {
      default: `${settings.restaurantName} — Haute Cuisine & Artisanal Hospitality`,
      template: `%s | ${settings.restaurantName}`,
    },
    description: `Immerse yourself in exceptional culinary artistry, Michelin-inspired seasonal tasting menus, and timeless ambiance at ${settings.restaurantName}.`,
    metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"),
    openGraph: {
      title: `${settings.restaurantName} — Haute Cuisine & Artisanal Hospitality`,
      description: `Immerse yourself in exceptional culinary artistry, Michelin-inspired seasonal tasting menus, and timeless ambiance at ${settings.restaurantName}.`,
      type: "website",
      locale: "en_US",
    },
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const settings = await getRestaurantSettings();
  const homepage = await getHomepageData();
  const contact = await getContactData();

  return (
    <html lang="en" suppressHydrationWarning className={`${playfair.variable} ${jakarta.variable} scroll-smooth`}>
      <body className="min-h-screen flex flex-col font-sans antialiased selection:bg-amber-500 selection:text-black">
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange={false}
        >
          <WebsiteShell
            settings={settings}
            announcement={homepage.announcement}
            contact={contact}
          >
            {children}
          </WebsiteShell>
        </ThemeProvider>
      </body>
    </html>
  );
}

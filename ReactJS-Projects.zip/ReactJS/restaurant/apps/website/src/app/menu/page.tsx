import type { Metadata } from "next";
import { Sparkles } from "lucide-react";
import { getMenuCategories, getMenuItems, getRestaurantSettings } from "@/lib/api/restaurant";
import { MenuClientView } from "@/components/menu/MenuClientView";

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: "Royal Awadhi & Mughlai Menu | Zaffran Haveli",
  description: "Explore our slow-simmered Awadhi Dum Pukht curries, Galouti kebabs, fragrant saffron biryanis, and royal dastarkhwan desserts.",
};

interface MenuPageProps {
  searchParams?: {
    category?: string;
  };
}

export default async function MenuPage({ searchParams }: MenuPageProps) {
  const [categories, items, settings] = await Promise.all([
    getMenuCategories(),
    getMenuItems(),
    getRestaurantSettings(),
  ]);

  return (
    <div className="pt-6 sm:pt-10 pb-16 sm:pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-amber-500/30 bg-amber-500/10 text-amber-400 text-xs tracking-widest uppercase font-medium">
          <Sparkles className="w-3.5 h-3.5" />
          <span>The Royal Dastarkhwan Experience</span>
        </div>
        <h1 className="text-4xl sm:text-6xl font-serif font-light text-stone-900 dark:text-stone-100 tracking-tight">
          Imperial Culinary Delicacies
        </h1>
        <p className="text-stone-600 dark:text-stone-400 text-sm sm:text-base font-light max-w-2xl mx-auto leading-relaxed">
          Centuries-old slow charcoal Dum Pukht traditions, hand-pounded spice terroir, and royal court delicacies crafted with reverence at {settings.restaurantName}.
        </p>
      </div>

      {/* Interactive Client Component with Filters & Sorting */}
      <MenuClientView
        categories={categories}
        items={items}
        settings={settings}
        initialCategory={searchParams?.category}
      />
    </div>
  );
}

import type { Metadata } from 'next';
import { Sparkles, MapPin, Phone, Mail, Clock, ShieldCheck } from 'lucide-react';
import { getContactData, getRestaurantSettings } from '@/lib/api/restaurant';
import { ReservationForm } from '@/components/common/ReservationForm';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Table Reservations & Concierge Inquiries',
  description: 'Reserve a dining table, inquire about private wine tastings, or reach out to our hospitality desk.',
};

export default async function ContactPage() {
  const [contact, settings] = await Promise.all([getContactData(), getRestaurantSettings()]);

  return (
    <div className="pt-6 sm:pt-10 pb-16 sm:pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-16">
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-[#d4af37]/30 bg-[#d4af37]/10 text-[#e5c378] text-xs tracking-[0.2em] uppercase font-semibold">
          <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>Concierge & Hospitality Desk</span>
        </div>
        <h1 className="text-4xl sm:text-6xl font-serif font-light text-stone-900 dark:text-[#fcfbf9] tracking-tight">
          Reservations & Inquiries
        </h1>
        <p className="text-stone-600 dark:text-stone-400 text-sm sm:text-base font-light">
          We welcome reservations up to 60 days in advance at {settings.restaurantName}. For large banquet tastings and private salons, please connect directly.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        {/* Left Column: Form (7 cols) */}
        <div className="lg:col-span-7">
          <ReservationForm />
        </div>

        {/* Right Column: Contact info & Hours (5 cols) */}
        <div className="lg:col-span-5 space-y-8">
          <div className="p-8 rounded-3xl bg-white dark:bg-[#12141e]/90 border border-stone-200 dark:border-[#d4af37]/25 space-y-6 shadow-md dark:shadow-2xl">
            <h2 className="text-2xl font-serif text-stone-900 dark:text-[#fcfbf9]">{settings.restaurantName} Concierge</h2>

            <div className="space-y-4 text-xs font-light text-stone-600 dark:text-stone-300">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-amber-600 dark:text-[#d4af37] shrink-0 mt-0.5" />
                <div>
                  <p className="text-stone-400 text-[10px] uppercase tracking-wider font-semibold">Address</p>
                  <p className="text-stone-800 dark:text-stone-100 mt-0.5 leading-relaxed">{settings.address || contact.address}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                <div>
                  <p className="text-stone-400 text-[10px] uppercase tracking-wider font-semibold">Direct Telephone</p>
                  <a
                    href={`tel:${settings.contactNumber || contact.phone}`}
                    className="text-stone-100 hover:text-[#d4af37] transition-colors mt-0.5 block font-mono"
                  >
                    {settings.contactNumber || contact.phone}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                <div>
                  <p className="text-stone-400 text-[10px] uppercase tracking-wider font-semibold">Email Desk</p>
                  <a
                    href={`mailto:${settings.contactEmail || contact.email}`}
                    className="text-stone-100 hover:text-[#d4af37] transition-colors mt-0.5 block font-mono"
                  >
                    {settings.contactEmail || contact.email}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                <div>
                  <p className="text-stone-400 text-[10px] uppercase tracking-wider font-semibold">Dining Schedule</p>
                  <p className="text-stone-100 mt-0.5">{contact.openingHours}</p>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#090a0e] border border-white/5 space-y-1.5">
              <span className="text-[10px] font-semibold text-[#d4af37] uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                Valet & Parking Porte-Cochère
              </span>
              <p className="text-[11px] text-stone-400 leading-relaxed font-light">
                Complimentary curbside valet service is provided directly at the front entrance upon your vehicle arrival.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

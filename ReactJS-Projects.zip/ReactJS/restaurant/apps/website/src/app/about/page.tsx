import type { Metadata } from "next";
import { getAboutData, getRestaurantSettings } from "@/lib/api/restaurant";
import { AboutClientView } from "@/components/about/AboutClientView";

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: "Our Heritage & Story",
  description: "Learn about our culinary roots, passion for ethical ingredients, and commitment to hospitality.",
};

export default async function AboutPage() {
  const [about, settings] = await Promise.all([getAboutData(), getRestaurantSettings()]);

  return <AboutClientView about={about} settings={settings} />;
}

import Link from "next/link";
import { Utensils } from "lucide-react";

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-4 text-center bg-stone-950 text-stone-100">
      <div className="p-4 rounded-full bg-amber-500/10 text-amber-500 mb-6">
        <Utensils className="w-10 h-10" />
      </div>
      <h1 className="text-4xl font-serif text-white mb-2">404 - Page Not Found</h1>
      <p className="text-stone-400 max-w-md mb-8">
        The culinary delicacy or page you are looking for does not exist or has been moved.
      </p>
      <Link
        href="/"
        className="px-6 py-3 rounded-full bg-amber-500 text-stone-950 font-medium hover:bg-amber-400 transition-colors"
      >
        Return to Home
      </Link>
    </div>
  );
}

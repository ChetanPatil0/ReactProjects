import type { Metadata } from "next";
import { Sparkles } from "lucide-react";
import { getGalleryItems, getRestaurantSettings } from "@/lib/api/restaurant";
import { GalleryClientView } from "@/components/gallery/GalleryClientView";

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: "Dining Ambiance & Visual Gallery",
  description: "Browse photographs of intimate dining ambiance, culinary craft, and bar.",
};

export default async function GalleryPage() {
  const [items, settings] = await Promise.all([getGalleryItems(), getRestaurantSettings()]);

  return (
    <div className="pt-6 sm:pt-10 pb-16 sm:pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-12">
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-amber-500/30 bg-amber-500/10 text-amber-400 text-xs tracking-wider uppercase">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Visual Ambiance</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-serif font-light text-stone-900 dark:text-stone-100">
          {settings.restaurantName} Visual Gallery
        </h1>
        <p className="text-stone-600 dark:text-stone-400 text-base font-light">
          An intimate look at our candlelight settings, private dining chambers, and culinary plating.
        </p>
      </div>

      <GalleryClientView items={items} />
    </div>
  );
}

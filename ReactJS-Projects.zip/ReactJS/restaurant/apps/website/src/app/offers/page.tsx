import type { Metadata } from 'next';
import Link from 'next/link';
import { Sparkles, Tag, Calendar, ArrowRight, ShieldCheck } from 'lucide-react';
import { getOffers, getRestaurantSettings } from '@/lib/api/restaurant';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Special Offers & Tasting Privileges',
  description: 'Exclusive seasonal degustation perks, wine pairings, and celebratory dining experiences.',
};

export default async function OffersPage() {
  const [offers, settings] = await Promise.all([getOffers(), getRestaurantSettings()]);

  return (
    <div className="py-16 sm:py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-14">
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-[#d4af37]/30 bg-[#d4af37]/10 text-[#e5c378] text-xs tracking-[0.2em] uppercase font-semibold">
          <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>Exclusive Seasonal Privileges</span>
        </div>
        <h1 className="text-4xl sm:text-6xl font-serif font-light text-[#fcfbf9] tracking-tight">
          Curated Tasting Privileges
        </h1>
        <p className="text-stone-400 text-sm sm:text-base font-light">
          Enjoy chef complimentary pairings, sommelier library pours, and celebratory degustations at {settings.restaurantName}.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {offers.map((offer) => (
          <div
            key={offer.id}
            className="p-8 sm:p-10 rounded-3xl bg-[#12141e]/90 border border-[#d4af37]/25 flex flex-col justify-between hover:border-[#d4af37]/60 transition-all duration-300 shadow-2xl relative overflow-hidden"
          >
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#d4af37]/15 border border-[#d4af37]/40 text-[#e5c378] text-xs font-semibold uppercase tracking-wider">
                <Tag className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>{offer.discountValue || offer.discount || 'Special Tasting Privilege'}</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-serif text-[#fcfbf9] font-normal">{offer.title}</h2>
              <p className="text-stone-300 text-sm font-light leading-relaxed">
                {offer.description}
              </p>
            </div>

            <div className="pt-8 mt-8 border-t border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-xs text-stone-400">
                <Calendar className="w-4 h-4 text-[#d4af37]" />
                <span className="font-mono">
                  {offer.code ? `Promo Code: ${offer.code}` : 'Valid Throughout Autumn Season'}
                </span>
              </div>
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-linear-to-r from-[#d4af37] via-[#f7e6c4] to-[#d4af37] text-stone-950 text-xs font-bold uppercase tracking-wider hover:scale-105 active:scale-95 transition-all shadow-md shadow-[#d4af37]/20"
              >
                <span>Reserve Table</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

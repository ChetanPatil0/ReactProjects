import {
  getHomepageData,
  getMenuCategories,
  getMenuItems,
  getGalleryItems,
  getRestaurantSettings,
  getAboutData,
} from "@/lib/api/restaurant";
import { HeroSection } from "@/components/home/HeroSection";
import { ChefStorySection } from "@/components/home/ChefStorySection";
import { SignatureDishesSlider } from "@/components/home/SignatureDishesSlider";
import { FeaturedMenuSection } from "@/components/home/FeaturedMenuSection";
import { CellarExperienceSection } from "@/components/home/CellarExperienceSection";
import { AmbiancePreviewSection } from "@/components/home/AmbiancePreviewSection";
import { PressReviewsSection } from "@/components/home/PressReviewsSection";
import { ReservationCalloutSection } from "@/components/home/ReservationCalloutSection";

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const [homepage, categories, menuItems, galleryItems, settings, about] =
    await Promise.all([
      getHomepageData(),
      getMenuCategories(),
      getMenuItems(),
      getGalleryItems(),
      getRestaurantSettings(),
      getAboutData(),
    ]);

  return (
    <div className="flex flex-col bg-[#07080a]">
      {/* 1. Multi-Scene Hero Slider with Table Booker */}
      <HeroSection
        homepage={homepage}
        settings={settings}
      />

      {/* 2. Executive Chef Atelier & The 3 Pillars of Gastronomy */}
      <ChefStorySection about={about} settings={settings} />

      {/* 3. Interactive Signature Culinary Creations Carousel Slider */}
      <SignatureDishesSlider
        items={menuItems}
        currencySymbol={settings.currencySymbol || '$'}
      />

      {/* 4. Curated Degustation Tasting Menu Selection */}
      <FeaturedMenuSection
        categories={categories}
        items={menuItems}
        settings={settings}
      />

      {/* 5. Subterranean Wine Vault & Mixology Atelier */}
      <CellarExperienceSection />

      {/* 6. Dining Rooms & Private Salons Carousel Slider */}
      <AmbiancePreviewSection galleryItems={galleryItems} />

      {/* 7. Michelin & Global Critics Accolades Slider */}
      <PressReviewsSection />

      {/* 8. Table Reservation & Concierge Desk Invitation */}
      <ReservationCalloutSection settings={settings} />
    </div>
  );
}

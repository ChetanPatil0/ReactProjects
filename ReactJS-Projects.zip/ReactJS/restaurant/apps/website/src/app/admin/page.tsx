import React from 'react';
import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import prisma from '@/lib/prisma';
import {
  DollarSign,
  Receipt,
  UtensilsCrossed,
  Users,
  ArrowUpRight,
  Plus,
  Clock,
  CreditCard,
  Banknote,
  QrCode,
  Sparkles,
  TrendingUp,
  Award,
} from 'lucide-react';

export const dynamic = 'force-dynamic';

export default async function AdminDashboardPage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect('/admin/login');
  }

  // Fetch real-time dashboard data
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [
    todayBills,
    totalMenuItems,
    totalCustomers,
    recentBills,
    settings,
  ] = await Promise.all([
    prisma.bill.findMany({
      where: {
        createdAt: { gte: today },
        status: { not: 'CANCELLED' },
      },
      select: {
        totalAmount: true,
        paidAmount: true,
        paymentMethod: true,
        orderType: true,
      },
    }),
    prisma.menuItem.count({ where: { isAvailable: true } }),
    prisma.customer.count(),
    prisma.bill.findMany({
      orderBy: { createdAt: 'desc' },
      take: 6,
      include: {
        customer: true,
        createdBy: { select: { firstName: true, lastName: true } },
      },
    }),
    prisma.restaurantSetting.findFirst(),
  ]);

  const currency = settings?.currency || '$';

  let todaySales = 0;
  let cashSales = 0;
  let cardSales = 0;
  let upiSales = 0;

  let dineInOrders = 0;
  let takeawayOrders = 0;
  let deliveryOrders = 0;

  for (const b of todayBills) {
    todaySales += b.totalAmount;
    if (b.paymentMethod === 'CASH') cashSales += b.paidAmount;
    else if (b.paymentMethod === 'CARD') cardSales += b.paidAmount;
    else if (b.paymentMethod === 'UPI') upiSales += b.paidAmount;

    if (b.orderType === 'DINE_IN') dineInOrders++;
    else if (b.orderType === 'TAKEAWAY') takeawayOrders++;
    else if (b.orderType === 'DELIVERY') deliveryOrders++;
  }

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl bg-[#0c0e14] min-h-screen">
      {/* Top Welcome Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-zinc-800/80">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-[10px] uppercase font-bold tracking-widest text-[#d4af37]">
              Live Restaurant Console
            </span>
          </div>
          <h1 className="font-semibold text-xl md:text-2xl text-zinc-100 tracking-tight">
            Welcome back, {user.firstName}
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Real-time sales reconciliation & operational overview for {settings?.name || "L'Étoile Atelier"}.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/admin/pos"
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-linear-to-r from-[#d4af37] via-[#f7e6c4] to-[#d4af37] text-stone-950 font-bold text-xs tracking-wider uppercase transition shadow-lg shadow-[#d4af37]/25 hover:scale-105 active:scale-95"
          >
            <Receipt className="w-4 h-4" />
            <span>Launch POS Terminal</span>
          </Link>
          <Link
            href="/admin/menu"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 font-semibold text-xs transition border border-zinc-700"
          >
            <Plus className="w-4 h-4 text-[#d4af37]" />
            <span>Add Menu Dish</span>
          </Link>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Today's Sales */}
        <div className="p-5 rounded-2xl bg-[#12141d] border border-zinc-800/80 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">Today's Gross Sales</span>
            <div className="p-2.5 rounded-xl bg-[#d4af37]/15 text-[#e5c378] border border-[#d4af37]/30">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <p className="text-2xl font-bold text-[#fcfbf9]">
              {currency}
              {todaySales.toFixed(2)}
            </p>
            <p className="text-[11px] text-zinc-500 mt-1">From {todayBills.length} orders today</p>
          </div>
        </div>

        {/* Orders Today */}
        <div className="p-5 rounded-2xl bg-[#12141d] border border-zinc-800/80 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">Orders Serviced</span>
            <div className="p-2.5 rounded-xl bg-blue-500/15 text-blue-400 border border-blue-500/30">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <p className="text-2xl font-bold text-zinc-100">{todayBills.length}</p>
            <p className="text-[11px] text-zinc-500 mt-1">
              {dineInOrders} Dine-in • {takeawayOrders} Takeaway • {deliveryOrders} Delivery
            </p>
          </div>
        </div>

        {/* Active Menu Items */}
        <div className="p-5 rounded-2xl bg-[#12141d] border border-zinc-800/80 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">Active Dishes</span>
            <div className="p-2.5 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
              <UtensilsCrossed className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <p className="text-2xl font-bold text-zinc-100">{totalMenuItems}</p>
            <p className="text-[11px] text-zinc-500 mt-1">Dishes currently live on public carte</p>
          </div>
        </div>

        {/* Total Customers */}
        <div className="p-5 rounded-2xl bg-[#12141d] border border-zinc-800/80 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">Patron Profiles</span>
            <div className="p-2.5 rounded-xl bg-purple-500/15 text-purple-400 border border-purple-500/30">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <p className="text-2xl font-bold text-zinc-100">{totalCustomers}</p>
            <p className="text-[11px] text-zinc-500 mt-1">Guest database & dining records</p>
          </div>
        </div>
      </div>

      {/* Payment Modes Today Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-[#12141d] border border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
              <Banknote className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[11px] font-semibold text-zinc-400 uppercase">Cash In Register</p>
              <p className="text-base font-bold text-zinc-100 font-mono">
                {currency}
                {cashSales.toFixed(2)}
              </p>
            </div>
          </div>
          <span className="text-[10px] text-zinc-500 font-mono">
            {todaySales > 0 ? Math.round((cashSales / todaySales) * 100) : 0}%
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-[#12141d] border border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/15 text-blue-400 border border-blue-500/30">
              <CreditCard className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[11px] font-semibold text-zinc-400 uppercase">Credit / Debit Card</p>
              <p className="text-base font-bold text-zinc-100 font-mono">
                {currency}
                {cardSales.toFixed(2)}
              </p>
            </div>
          </div>
          <span className="text-[10px] text-zinc-500 font-mono">
            {todaySales > 0 ? Math.round((cardSales / todaySales) * 100) : 0}%
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-[#12141d] border border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#d4af37]/20 text-[#e5c378] border border-[#d4af37]/35">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[11px] font-semibold text-zinc-400 uppercase">UPI / QR Collections</p>
              <p className="text-base font-bold text-zinc-100 font-mono">
                {currency}
                {upiSales.toFixed(2)}
              </p>
            </div>
          </div>
          <span className="text-[10px] text-zinc-500 font-mono">
            {todaySales > 0 ? Math.round((upiSales / todaySales) * 100) : 0}%
          </span>
        </div>
      </div>

      {/* Recent Orders Table */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-semibold text-base text-zinc-100">Recent Service Invoices</h2>
            <p className="text-xs text-zinc-400">Live order flow and settlement status.</p>
          </div>
          <Link
            href="/admin/bills"
            className="text-xs font-semibold uppercase tracking-wider text-[#d4af37] hover:underline flex items-center gap-1"
          >
            <span>View All Ledger</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="bg-[#12141d] border border-zinc-800/80 rounded-2xl overflow-hidden shadow-xl">
          {recentBills.length === 0 ? (
            <div className="p-12 text-center text-zinc-500 text-xs">
              No bills recorded yet. Use the POS Terminal to dispatch your first order.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-400 font-semibold uppercase tracking-wider text-[10px] bg-zinc-900/60">
                    <th className="py-3 px-4">Bill Number</th>
                    <th className="py-3 px-4">Time</th>
                    <th className="py-3 px-4">Type</th>
                    <th className="py-3 px-4">Table / Guest</th>
                    <th className="py-3 px-4">Total</th>
                    <th className="py-3 px-4">Paid</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/50">
                  {recentBills.map((b) => (
                    <tr key={b.id} className="hover:bg-zinc-800/40 transition">
                      <td className="py-3.5 px-4 font-mono font-semibold text-[#e5c378]">
                        {b.billNumber}
                      </td>
                      <td className="py-3.5 px-4 text-zinc-400">
                        {new Date(b.createdAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-zinc-800 text-zinc-300">
                          {b.orderType.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-zinc-300">
                        {b.tableNumber || b.customer?.name || 'Walk-in'}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-zinc-100 font-mono">
                        {currency}
                        {b.totalAmount.toFixed(2)}
                      </td>
                      <td className="py-3.5 px-4 font-medium text-emerald-400 font-mono">
                        {currency}
                        {b.paidAmount.toFixed(2)}
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            b.status === 'PAID'
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                              : b.status === 'PARTIAL'
                              ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                              : 'bg-red-500/15 text-red-400 border border-red-500/30'
                          }`}
                        >
                          {b.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <Link
                          href="/admin/bills"
                          className="text-[#d4af37] hover:underline font-semibold text-xs"
                        >
                          View
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

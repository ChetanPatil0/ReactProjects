import React from 'react';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { ReportsView } from './ReportsView';

export const dynamic = 'force-dynamic';

export default async function AdminReportsPage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect('/admin/login');
  }

  const settings = await prisma.restaurantSetting.findFirst();

  return <ReportsView currency={settings?.currency || '$'} />;
}

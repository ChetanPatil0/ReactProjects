'use client';

import React, { useState } from 'react';
import {
  Users,
  Plus,
  ShieldCheck,
  X,
  Loader2,
  CheckCircle2,
  UserX,
  AlertCircle,
  Mail,
  Lock,
  User,
  ShieldAlert,
} from 'lucide-react';
import { useToast } from '@/context/ToastContext';

interface StaffUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  isActive: boolean;
  createdAt: string;
}

interface StaffManagerProps {
  initialStaff: StaffUser[];
  currentUserRole: string;
}

export function StaffManager({ initialStaff, currentUserRole }: StaffManagerProps) {
  const toast = useToast();
  const [staff, setStaff] = useState<StaffUser[]>(initialStaff);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    role: 'CASHIER',
  });
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  // Field validation rules
  const validateField = (field: string, value: string): string => {
    switch (field) {
      case 'firstName':
        if (!value.trim()) return 'First name is required.';
        if (value.trim().length < 2) return 'First name must be at least 2 characters.';
        if (value.trim().length > 30) return 'First name cannot exceed 30 characters.';
        return '';
      case 'lastName':
        if (!value.trim()) return 'Last name is required.';
        if (value.trim().length < 2) return 'Last name must be at least 2 characters.';
        if (value.trim().length > 30) return 'Last name cannot exceed 30 characters.';
        return '';
      case 'email':
        if (!value.trim()) return 'Email address is required.';
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value.trim())) return 'Please provide a valid email address.';
        if (value.trim().length > 80) return 'Email cannot exceed 80 characters.';
        return '';
      case 'password':
        if (!value) return 'Password is required.';
        if (value.length < 8) return 'Password must be at least 8 characters long.';
        if (value.length > 50) return 'Password cannot exceed 50 characters.';
        return '';
      default:
        return '';
    }
  };

  const validateAll = (data: typeof form) => {
    const errs: Record<string, string> = {
      firstName: validateField('firstName', data.firstName),
      lastName: validateField('lastName', data.lastName),
      email: validateField('email', data.email),
      password: validateField('password', data.password),
    };
    Object.keys(errs).forEach((k) => !errs[k] && delete errs[k]);
    return errs;
  };

  const handleChange = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    const err = validateField(field, value);
    setErrors((prev) => ({ ...prev, [field]: err }));
  };

  const handleBlur = (field: string) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
    const err = validateField(field, (form as any)[field]);
    setErrors((prev) => ({ ...prev, [field]: err }));
  };

  const handleOpenModal = () => {
    setForm({ firstName: '', lastName: '', email: '', password: '', role: 'CASHIER' });
    setTouched({});
    setErrors({});
    setIsModalOpen(true);
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();

    setTouched({ firstName: true, lastName: true, email: true, password: true });
    const errs = validateAll(form);
    setErrors(errs);

    if (Object.keys(errs).length > 0) {
      toast.error('Please resolve the required field validations.', 'Form Incomplete');
      return;
    }

    setSubmitting(true);

    try {
      const res = await fetch('/api/admin/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create staff member');

      setStaff((prev) => [data.data, ...prev]);
      setIsModalOpen(false);
      toast.success(
        `Staff account created for ${data.data.firstName} ${data.data.lastName} (${data.data.role}).`,
        'Account Created'
      );
    } catch (err: any) {
      toast.error(err.message, 'Creation Failed');
    } finally {
      setSubmitting(false);
    }
  };

  const toggleStatus = async (user: StaffUser) => {
    const updatedStatus = !user.isActive;
    try {
      const res = await fetch('/api/admin/staff', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: user.id, isActive: updatedStatus }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update status');

      setStaff((prev) => prev.map((s) => (s.id === user.id ? { ...s, isActive: updatedStatus } : s)));
      toast.info(
        `Staff account for ${user.firstName} is now ${updatedStatus ? 'Active' : 'Suspended'}.`,
        'Status Changed'
      );
    } catch (err: any) {
      toast.error(err.message, 'Update Failed');
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-5xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800/80">
        <div>
          <h1 className="font-semibold text-xl text-zinc-100 flex items-center gap-2">
            <span>Staff Management & Role Access</span>
            <span className="text-[10px] uppercase font-bold tracking-widest px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
              Argon2 Security
            </span>
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            Role-based authentication, granular permissions, and operational access controls.
          </p>
        </div>

        <button
          onClick={handleOpenModal}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold text-xs tracking-wider uppercase transition shadow-md shadow-amber-400/20 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Staff Member</span>
        </button>
      </div>

      {/* Staff Table */}
      <div className="bg-[#10131a] border border-zinc-800/80 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-400 font-semibold uppercase tracking-wider text-[10px] bg-zinc-900/40">
                <th className="py-3 px-4">Staff Member</th>
                <th className="py-3 px-4">Email</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/50">
              {staff.map((u) => (
                <tr key={u.id} className="hover:bg-zinc-800/30 transition">
                  <td className="py-3.5 px-4 font-semibold text-zinc-100">
                    {u.firstName} {u.lastName}
                  </td>
                  <td className="py-3.5 px-4 text-zinc-400">{u.email}</td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase bg-zinc-800 text-amber-400 border border-amber-500/20">
                      {u.role}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        u.isActive
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-red-500/10 text-red-400 border border-red-500/20'
                      }`}
                    >
                      {u.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => toggleStatus(u)}
                      className="text-[11px] text-zinc-400 hover:text-amber-300 transition font-medium cursor-pointer"
                    >
                      {u.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Staff Modal with Live Below-Field Validation */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#12151d]/90 backdrop-blur-2xl border border-zinc-700/60 rounded-2xl w-full max-w-md p-6 space-y-4 text-xs shadow-2xl shadow-black/50">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="font-semibold text-sm text-zinc-100 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>Create New Staff Account</span>
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-zinc-500 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreate} noValidate className="space-y-3.5">
              {/* First & Last Name */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-medium text-zinc-300">
                      First Name <span className="text-rose-500 font-bold ml-0.5">*</span>
                    </label>
                  </div>
                  <input
                    type="text"
                    maxLength={30}
                    value={form.firstName}
                    onChange={(e) => handleChange('firstName', e.target.value)}
                    onBlur={() => handleBlur('firstName')}
                    placeholder="e.g. Rohan"
                    className={`w-full px-3 py-2 rounded-xl bg-zinc-900 border text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition ${
                      touched.firstName && errors.firstName
                        ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                        : 'border-zinc-800 focus:border-amber-500/60'
                    }`}
                  />
                  {touched.firstName && errors.firstName && (
                    <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{errors.firstName}</span>
                    </p>
                  )}
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-medium text-zinc-300">
                      Last Name <span className="text-rose-500 font-bold ml-0.5">*</span>
                    </label>
                  </div>
                  <input
                    type="text"
                    maxLength={30}
                    value={form.lastName}
                    onChange={(e) => handleChange('lastName', e.target.value)}
                    onBlur={() => handleBlur('lastName')}
                    placeholder="e.g. Verma"
                    className={`w-full px-3 py-2 rounded-xl bg-zinc-900 border text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition ${
                      touched.lastName && errors.lastName
                        ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                        : 'border-zinc-800 focus:border-amber-500/60'
                    }`}
                  />
                  {touched.lastName && errors.lastName && (
                    <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{errors.lastName}</span>
                    </p>
                  )}
                </div>
              </div>

              {/* Email */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-medium text-zinc-300">
                    Email Address <span className="text-rose-500 font-bold ml-0.5">*</span>
                  </label>
                  <span className="text-[10px] text-zinc-500">Max 80 chars</span>
                </div>
                <input
                  type="email"
                  maxLength={80}
                  value={form.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  onBlur={() => handleBlur('email')}
                  placeholder="e.g. rohan.verma@zaffranhaveli.com"
                  className={`w-full px-3 py-2 rounded-xl bg-zinc-900 border text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition ${
                    touched.email && errors.email
                      ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                      : 'border-zinc-800 focus:border-amber-500/60'
                  }`}
                />
                {touched.email && errors.email && (
                  <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.email}</span>
                  </p>
                )}
              </div>

              {/* Password */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-medium text-zinc-300">
                    Password <span className="text-rose-500 font-bold ml-0.5">*</span>
                  </label>
                  <span className="text-[10px] text-zinc-500">Min 8 • Max 50 chars</span>
                </div>
                <input
                  type="password"
                  maxLength={50}
                  value={form.password}
                  onChange={(e) => handleChange('password', e.target.value)}
                  onBlur={() => handleBlur('password')}
                  placeholder="••••••••••••"
                  className={`w-full px-3 py-2 rounded-xl bg-zinc-900 border text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition ${
                    touched.password && errors.password
                      ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                      : 'border-zinc-800 focus:border-amber-500/60'
                  }`}
                />
                {touched.password && errors.password && (
                  <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.password}</span>
                  </p>
                )}
              </div>

              {/* Role */}
              <div>
                <label className="block font-medium text-zinc-300 mb-1">
                  Access Level / Role <span className="text-rose-500 font-bold ml-0.5">*</span>
                </label>
                <select
                  value={form.role}
                  onChange={(e) => setForm({ ...form, role: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60 transition"
                >
                  <option value="CASHIER">CASHIER (POS Register & Billing)</option>
                  <option value="MANAGER">MANAGER (Menu, Reservations & Reports)</option>
                  <option value="SUPER_ADMIN">SUPER_ADMIN (Full Architectural Control)</option>
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-medium transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold transition disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-amber-400/20"
                >
                  {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

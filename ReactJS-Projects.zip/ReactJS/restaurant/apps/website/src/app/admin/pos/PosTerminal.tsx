'use client';

import React, { useState, useEffect, useMemo } from 'react';
import {
  Search,
  Plus,
  Minus,
  Trash2,
  Receipt,
  Printer,
  CheckCircle,
  CreditCard,
  Banknote,
  User,
  Hash,
  X,
  Loader2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  ChevronDown,
  Percent,
  Coins,
  Code,
  RefreshCw,
  Clock,
  Users,
  CheckCircle2,
  UtensilsCrossed,
  AlertCircle,
  CalendarDays,
} from 'lucide-react';
import { renderReceiptHtml, ReceiptData } from '@/lib/receiptTemplate';
import { useToast } from '@/context/ToastContext';

interface MenuItem {
  id: string;
  name: string;
  price: number;
  isVeg: boolean;
  imageUrl?: string | null;
  categoryId: string;
}

interface MenuCategory {
  id: string;
  name: string;
  slug: string;
}

interface CartItem {
  menuItemId: string;
  name: string;
  price: number;
  quantity: number;
  notes?: string;
}

interface PosTerminalProps {
  initialCategories: MenuCategory[];
  initialItems: MenuItem[];
  currency: string;
  taxRate: number;
  restaurantName: string;
  restaurantSettings?: any;
  cashierName?: string;
}

const DINE_IN_TABLES = [
  'Table 1',
  'Table 2',
  'Table 3',
  'Table 4',
  'Table 5',
  'Table 6',
  'Table 7',
  'Table 8',
  'Table 9',
  'Table 10',
  'Table 11',
  'Table 12',
  'Salon A (Private)',
  'Salon B (Royal)',
  'Chef Counter 1',
  'Chef Counter 2',
  'Terrace T1',
  'Wine Vault',
];

const CASH_DENOMINATIONS = [50, 100, 200, 500, 2000];

export function PosTerminal({
  initialCategories,
  initialItems,
  currency = '₹',
  taxRate: defaultTaxRate,
  restaurantName,
  restaurantSettings,
  cashierName = 'Register #01',
}: PosTerminalProps) {
  const toast = useToast();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orderType, setOrderType] = useState<'DINE_IN' | 'TAKEAWAY' | 'DELIVERY'>('DINE_IN');
  const [tableNumber, setTableNumber] = useState('Table 1');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<'CASH' | 'CARD' | 'UPI'>('CASH');
  const [isPartialPayment, setIsPartialPayment] = useState(false);
  const [customPaidAmount, setCustomPaidAmount] = useState<number>(0);
  const [cashTendered, setCashTendered] = useState<number>(0);
  const [submitting, setSubmitting] = useState(false);
  const [completedBill, setCompletedBill] = useState<any>(null);
  const [receiptFormat, setReceiptFormat] = useState<'custom' | 'thermal' | 'a4' | 'kot'>('custom');
  const [isTableModalOpen, setIsTableModalOpen] = useState(false);
  const [transactionRef, setTransactionRef] = useState('');

  // Live Table Occupancy & Running Tabs State
  const [tableOccupancy, setTableOccupancy] = useState<Record<string, any>>({});
  const [tablesLoading, setTablesLoading] = useState(false);
  const [tableFilter, setTableFilter] = useState<'ALL' | 'AVAILABLE' | 'OCCUPIED' | 'RESERVED'>('ALL');
  const [isSettleModalOpen, setIsSettleModalOpen] = useState(false);
  const [settleMethod, setSettleMethod] = useState<'CASH' | 'CARD' | 'UPI'>('CASH');
  const [settleCashTendered, setSettleCashTendered] = useState<number>(0);
  const [settling, setSettling] = useState(false);
  const [appendingItems, setAppendingItems] = useState(false);
  const [showTabDetailsModal, setShowTabDetailsModal] = useState(false);

  // Fetch live table occupancy
  const fetchTables = async () => {
    try {
      setTablesLoading(true);
      const res = await fetch('/api/admin/pos/tables');
      const json = await res.json();
      if (json.success && json.data?.tables) {
        setTableOccupancy(json.data.tables);
      }
    } catch (err) {
      console.error('Failed to load table occupancy:', err);
    } finally {
      setTablesLoading(false);
    }
  };

  useEffect(() => {
    fetchTables();
    const interval = setInterval(fetchTables, 12000);
    return () => clearInterval(interval);
  }, []);

  // Current table occupancy information
  const currentTableData = tableOccupancy[tableNumber];
  const activeBill = currentTableData?.bill;

  // Filter items
  const filteredItems = initialItems.filter((item) => {
    const matchesCategory = selectedCategory === 'all' || item.categoryId === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Cart operations
  const addToCart = (item: MenuItem) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.menuItemId === item.id);
      if (existing) {
        return prev.map((i) =>
          i.menuItemId === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { menuItemId: item.id, name: item.name, price: item.price, quantity: 1 }];
    });
  };

  const updateQuantity = (menuItemId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((i) => {
          if (i.menuItemId === menuItemId) {
            const newQty = i.quantity + delta;
            return newQty > 0 ? { ...i, quantity: newQty } : null;
          }
          return i;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const removeFromCart = (menuItemId: string) => {
    setCart((prev) => prev.filter((i) => i.menuItemId !== menuItemId));
  };

  const clearCart = () => {
    setCart([]);
    setDiscountAmount(0);
    setCustomerPhone('');
    setCustomerName('');
    setIsPartialPayment(false);
    setCustomPaidAmount(0);
    setCashTendered(0);
  };

  // Calculations
  const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const effectiveDiscount = Math.min(subtotal, Math.max(0, discountAmount || 0));
  const taxableAmount = Math.max(0, subtotal - effectiveDiscount);
  const taxAmount = (taxableAmount * defaultTaxRate) / 100;
  const totalAmount = taxableAmount + taxAmount;
  const paidAmount = isPartialPayment
    ? Math.min(totalAmount, Math.max(0, customPaidAmount || 0))
    : totalAmount;
  const balanceAmount = Math.max(0, totalAmount - paidAmount);

  // Tender change calculation for cash
  const changeDue = Math.max(0, cashTendered - paidAmount);

  // Submit Order
  const handleCheckout = async () => {
    if (cart.length === 0) return;
    setSubmitting(true);

    try {
      const res = await fetch('/api/admin/pos/bills', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderType,
          tableNumber: orderType === 'DINE_IN' ? tableNumber : null,
          customerPhone: customerPhone || null,
          customerName: customerName || null,
          items: cart.map((i) => ({
            menuItemId: i.menuItemId,
            itemName: i.name,
            unitPrice: i.price,
            quantity: i.quantity,
          })),
          discountAmount: effectiveDiscount,
          taxRate: defaultTaxRate,
          paidAmount,
          paymentMethod,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate bill');
      }

      setCompletedBill(data.data);
      toast.success(`Invoice ${data.data.billNumber} created successfully.`, 'Bill Generated');
      clearCart();
      await fetchTables();
    } catch (err: any) {
      toast.error(err.message || 'Error creating bill', 'Checkout Failed');
    } finally {
      setSubmitting(false);
    }
  };

  // Open / Hold Tab for a table (Status PARTIAL, paidAmount 0, generates KOT for kitchen)
  const handleHoldTab = async () => {
    if (cart.length === 0) {
      toast.warning('Please add culinary items to open a table tab.', 'Cart Empty');
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch('/api/admin/pos/bills', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderType,
          tableNumber: orderType === 'DINE_IN' ? tableNumber : null,
          customerPhone: customerPhone || null,
          customerName: customerName || null,
          items: cart.map((i) => ({
            menuItemId: i.menuItemId,
            itemName: i.name,
            unitPrice: i.price,
            quantity: i.quantity,
          })),
          discountAmount: effectiveDiscount,
          taxRate: defaultTaxRate,
          paidAmount: 0,
          paymentMethod: 'CASH',
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to hold tab');
      }

      setReceiptFormat('kot');
      setCompletedBill(data.data);
      toast.success(`${tableNumber} tab opened (${data.data.billNumber}). KOT dispatched to Kitchen Atelier.`, 'Running Tab Active');
      clearCart();
      await fetchTables();
    } catch (err: any) {
      toast.error(err.message || 'Error opening tab', 'Hold Tab Failed');
    } finally {
      setSubmitting(false);
    }
  };

  // Append items to active running tab
  const handleAppendToTab = async () => {
    if (!activeBill) return;
    if (cart.length === 0) {
      toast.warning('Please add new dishes from the menu to append to this tab.', 'Cart Empty');
      return;
    }
    setAppendingItems(true);
    try {
      const res = await fetch(`/api/admin/pos/bills/${activeBill.id}/items`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cart.map((i) => ({
            menuItemId: i.menuItemId,
            itemName: i.name,
            unitPrice: i.price,
            quantity: i.quantity,
          })),
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to add items to tab');

      // Create an add-on KOT ticket showing only the newly appended dishes for the kitchen
      const addOnKot = {
        ...data.data,
        items: data.newItems,
        billNumber: `${data.data.billNumber}-ADD`,
      };
      setReceiptFormat('kot');
      setCompletedBill(addOnKot);

      toast.success(`Appended ${cart.length} dish(es) to ${tableNumber} tab. Kitchen KOT ready.`, 'Tab Updated');
      clearCart();
      await fetchTables();
    } catch (err: any) {
      toast.error(err.message || 'Error adding items to tab', 'Update Failed');
    } finally {
      setAppendingItems(false);
    }
  };

  // Settle active running tab in full
  const handleSettleTab = async () => {
    if (!activeBill) return;
    setSettling(true);
    try {
      const res = await fetch(`/api/admin/pos/bills/${activeBill.id}/payment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: activeBill.balanceAmount,
          paymentMethod: settleMethod,
          note: `Settled tab at POS via ${settleMethod}`,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to settle bill');

      setIsSettleModalOpen(false);
      setReceiptFormat('custom');
      setCompletedBill(data.data);
      toast.success(`Bill ${activeBill.billNumber} settled in full (${currency}${activeBill.balanceAmount.toFixed(2)}). Table is now vacant!`, 'Tab Closed & Freed');
      await fetchTables();
    } catch (err: any) {
      toast.error(err.message || 'Error settling bill', 'Settlement Failed');
    } finally {
      setSettling(false);
    }
  };

  // Render HTML receipt from dynamic template
  const renderedCustomReceiptHtml = useMemo(() => {
    if (!completedBill) return '';

    const receiptPayload: ReceiptData = {
      restaurantName: restaurantSettings?.name || restaurantName,
      tagline: restaurantSettings?.tagline,
      logoUrl: restaurantSettings?.logoUrl,
      address: restaurantSettings?.address,
      phone: restaurantSettings?.phone,
      email: restaurantSettings?.email,
      openingHours: restaurantSettings?.openingHours,
      receiptHeader: restaurantSettings?.receiptHeader,
      receiptFooter: restaurantSettings?.receiptFooter,
      currency: currency,
      billNumber: completedBill.billNumber,
      orderType: completedBill.orderType,
      tableNumber: completedBill.tableNumber,
      createdAt: completedBill.createdAt,
      customerName: completedBill.customer?.name || customerName,
      customerPhone: completedBill.customer?.phone || customerPhone,
      cashierName: cashierName,
      items: completedBill.items || [],
      subtotal: completedBill.subtotal || 0,
      discountAmount: completedBill.discountAmount || 0,
      taxRate: completedBill.taxRate || defaultTaxRate,
      taxAmount: completedBill.taxAmount || 0,
      totalAmount: completedBill.totalAmount || 0,
      paidAmount: completedBill.paidAmount || 0,
      balanceAmount: completedBill.balanceAmount || 0,
      paymentMethod: completedBill.paymentMethod || paymentMethod,
    };

    return renderReceiptHtml(restaurantSettings?.receiptTemplate, receiptPayload);
  }, [completedBill, restaurantSettings, restaurantName, currency, defaultTaxRate, cashierName, customerName, customerPhone, paymentMethod]);

  // Print function
  const handlePrint = () => {
    if (receiptFormat === 'custom') {
      const printWin = window.open('', '_blank', 'width=450,height=750');
      if (printWin) {
        printWin.document.write(renderedCustomReceiptHtml);
        printWin.document.close();
        printWin.focus();
        setTimeout(() => printWin.print(), 350);
      }
    } else {
      window.print();
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-full min-h-[calc(100vh-2rem)] gap-4 p-4 md:p-6 bg-[#0c0e14]">
      {/* LEFT: Menu Selector & Table Controls (62%) */}
      <div className="flex-1 flex flex-col bg-[#12141d] border border-zinc-800/80 rounded-2xl overflow-hidden shadow-xl">
        {/* Top Header & Table Status Pill */}
        <div className="p-4 border-b border-zinc-800/80 flex flex-wrap items-center justify-between gap-3 bg-[#151822]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-[#d4af37]/15 border border-[#d4af37]/30 flex items-center justify-center text-[#d4af37]">
              <Receipt className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
                <span>Restaurant POS Terminal</span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  Register Live
                </span>
              </h2>
              <p className="text-[11px] text-zinc-400">Order placement & immediate invoice dispatch</p>
            </div>
          </div>

          {/* Quick Table Switcher with Live Status Indicator */}
          {orderType === 'DINE_IN' && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsTableModalOpen(true)}
                className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-2 transition cursor-pointer shadow-sm ${
                  currentTableData?.status === 'OCCUPIED'
                    ? 'bg-rose-950/40 border-rose-500/50 text-rose-300 hover:border-rose-400'
                    : currentTableData?.status === 'RESERVED'
                    ? 'bg-purple-950/40 border-purple-500/50 text-purple-300 hover:border-purple-400'
                    : 'bg-zinc-900 border-[#d4af37]/40 text-[#e5c378] hover:border-[#d4af37]'
                }`}
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    currentTableData?.status === 'OCCUPIED'
                      ? 'bg-rose-500 animate-pulse'
                      : currentTableData?.status === 'RESERVED'
                      ? 'bg-purple-400'
                      : 'bg-emerald-400'
                  }`}
                />
                <span>{tableNumber}</span>
                {currentTableData?.status === 'OCCUPIED' && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-rose-500/20 text-rose-300 font-mono font-bold">
                    {currency}{activeBill?.balanceAmount?.toFixed(2)}
                  </span>
                )}
                {currentTableData?.status === 'RESERVED' && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-purple-500/20 text-purple-300 font-semibold truncate max-w-[90px]">
                    {currentTableData.reservation?.guestName}
                  </span>
                )}
                <ChevronDown className="w-3.5 h-3.5 opacity-60" />
              </button>

              <button
                type="button"
                onClick={fetchTables}
                disabled={tablesLoading}
                title="Refresh table occupancy"
                className="p-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700 transition cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${tablesLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          )}
        </div>

        {/* Search & Categories Bar */}
        <div className="p-4 border-b border-zinc-800/80 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search dishes, drinks, tasting courses..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-100 placeholder:text-zinc-600 focus:outline-hidden focus:border-[#d4af37] transition"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                selectedCategory === 'all'
                  ? 'bg-[#d4af37] text-black shadow-md shadow-[#d4af37]/20 font-bold'
                  : 'bg-zinc-900/80 text-zinc-400 hover:text-white hover:bg-zinc-800'
              }`}
            >
              All Items ({initialItems.length})
            </button>
            {initialCategories.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCategory(c.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                  selectedCategory === c.id
                    ? 'bg-[#d4af37] text-black shadow-md shadow-[#d4af37]/20 font-bold'
                    : 'bg-zinc-900/80 text-zinc-400 hover:text-white hover:bg-zinc-800'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {/* Menu Items Grid */}
        <div className="flex-1 p-4 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
          {filteredItems.map((item) => (
            <button
              key={item.id}
              onClick={() => addToCart(item)}
              className="p-3.5 rounded-2xl bg-zinc-900/70 hover:bg-zinc-800/90 border border-zinc-800/80 hover:border-[#d4af37]/50 transition-all text-left flex flex-col justify-between group h-36 relative overflow-hidden shadow-sm hover:shadow-md cursor-pointer"
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span
                    className={`w-2.5 h-2.5 rounded-full ${
                      item.isVeg ? 'bg-emerald-400' : 'bg-red-400'
                    }`}
                    title={item.isVeg ? 'Vegetarian' : 'Non-Vegetarian'}
                  />
                  <span className="text-xs font-bold text-[#e5c378] font-mono">
                    {currency}
                    {item.price.toFixed(2)}
                  </span>
                </div>
                <h3 className="text-xs font-semibold text-zinc-200 line-clamp-2 group-hover:text-[#f7e6c4] transition-colors leading-snug">
                  {item.name}
                </h3>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-zinc-800/60 text-[11px] text-zinc-500">
                <span>Tap to add</span>
                <div className="w-6 h-6 rounded-lg bg-zinc-800 group-hover:bg-[#d4af37] group-hover:text-black flex items-center justify-center transition-colors">
                  <Plus className="w-3.5 h-3.5" />
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* RIGHT: Live Bill & Checkout (38%) */}
      <div className="w-full lg:w-96 flex flex-col bg-[#12141d] border border-zinc-800/80 rounded-2xl overflow-hidden shrink-0 shadow-2xl">
        {/* Order Meta Bar */}
        <div className="p-4 border-b border-zinc-800/80 space-y-3 bg-[#151822]">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-sm text-zinc-100 flex items-center gap-2">
              <Receipt className="w-4 h-4 text-[#d4af37]" />
              <span>Current Order Register</span>
            </h2>
            {cart.length > 0 && (
              <button
                onClick={clearCart}
                className="text-[11px] text-red-400 hover:text-red-300 transition cursor-pointer"
              >
                Clear Cart
              </button>
            )}
          </div>

          {/* Order Type Toggle */}
          <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-zinc-900 border border-zinc-800">
            {(['DINE_IN', 'TAKEAWAY', 'DELIVERY'] as const).map((type) => (
              <button
                key={type}
                onClick={() => setOrderType(type)}
                className={`py-1.5 text-[10px] font-semibold uppercase tracking-wider rounded-lg transition cursor-pointer ${
                  orderType === type
                    ? 'bg-[#d4af37] text-black font-bold shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {type.replace('_', ' ')}
              </button>
            ))}
          </div>

          {/* Customer Details */}
          <div className="grid grid-cols-2 gap-2">
            <input
              type="text"
              placeholder="Guest Name (Optional)"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-hidden focus:border-[#d4af37]"
            />
            <input
              type="tel"
              placeholder="Phone (SMS Receipt)"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-hidden focus:border-[#d4af37]"
            />
          </div>
        </div>

        {/* Active Running Tab Notification Banner */}
        {orderType === 'DINE_IN' && activeBill && (
          <div className="mx-4 mt-3 p-3.5 rounded-2xl bg-gradient-to-r from-rose-950/40 via-zinc-900/80 to-zinc-900/90 border border-rose-500/40 space-y-2.5 shadow-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                <span className="text-xs font-bold text-rose-300 uppercase tracking-wider">
                  Running Tab Active
                </span>
              </div>
              <span className="text-[10px] font-mono text-zinc-400 bg-zinc-800/80 px-2 py-0.5 rounded-md">
                {activeBill.billNumber}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs pt-1 border-t border-rose-500/20">
              <div>
                <p className="text-[11px] text-zinc-300 font-medium">
                  {activeBill.items?.length || 0} dish(es) currently on tab
                </p>
                {activeBill.customerName && (
                  <p className="text-[10px] text-zinc-400">Patron: {activeBill.customerName}</p>
                )}
                <p className="text-[10px] text-zinc-500">
                  Opened {new Date(activeBill.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-zinc-400 uppercase tracking-wider">Tab Balance</span>
                <p className="text-base font-bold text-rose-400 font-mono">
                  {currency}{activeBill.balanceAmount?.toFixed(2)}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowTabDetailsModal(true)}
                className="flex-1 py-1.5 px-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-700/80 text-zinc-300 text-[11px] font-medium transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                <UtensilsCrossed className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>View Placed Dishes</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setSettleCashTendered(activeBill.balanceAmount);
                  setIsSettleModalOpen(true);
                }}
                className="flex-1 py-1.5 px-2 rounded-xl bg-linear-to-r from-emerald-500 to-teal-500 text-stone-950 text-[11px] font-bold shadow-md shadow-emerald-500/20 hover:brightness-110 transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>Settle Tab & Free</span>
              </button>
            </div>
          </div>
        )}

        {/* Cart Items List */}
        <div className="flex-1 p-4 overflow-y-auto space-y-2">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-zinc-500 text-xs space-y-2">
              <Receipt className="w-8 h-8 stroke-1 text-zinc-600" />
              <span>Cart is empty</span>
              <span className="text-[11px] text-zinc-600">Select items from the menu to build the invoice</span>
            </div>
          ) : (
            cart.map((item) => (
              <div
                key={item.menuItemId}
                className="p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800/80 flex items-center justify-between text-xs"
              >
                <div className="flex-1 pr-2">
                  <h4 className="font-medium text-zinc-200 truncate">{item.name}</h4>
                  <p className="text-[11px] text-zinc-500 font-mono">
                    {currency}
                    {item.price.toFixed(2)} × {item.quantity} ={' '}
                    <span className="text-zinc-300 font-semibold">
                      {currency}
                      {(item.price * item.quantity).toFixed(2)}
                    </span>
                  </p>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => updateQuantity(item.menuItemId, -1)}
                    className="p-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="w-6 text-center font-bold text-zinc-100 font-mono">
                    {item.quantity}
                  </span>
                  <button
                    onClick={() => updateQuantity(item.menuItemId, 1)}
                    className="p-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => removeFromCart(item.menuItemId)}
                    className="p-1 ml-1 text-red-400 hover:text-red-300 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Financial Totals & Payment Section */}
        <div className="p-4 border-t border-zinc-800/80 space-y-3 bg-[#151822]">
          {/* Discount input */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-zinc-400 flex items-center gap-1">
              <Percent className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>Discount ({currency}):</span>
            </span>
            <input
              type="number"
              min="0"
              step="any"
              value={discountAmount || ''}
              onChange={(e) => setDiscountAmount(parseFloat(e.target.value) || 0)}
              placeholder="0.00"
              className="w-24 px-2 py-1 rounded bg-zinc-900 border border-zinc-800 text-right text-xs text-zinc-200 focus:outline-hidden focus:border-[#d4af37]"
            />
          </div>

          {/* Breakdown */}
          <div className="space-y-1.5 text-xs text-zinc-400 pt-1 border-t border-zinc-800/60">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span className="font-mono text-zinc-200">
                {currency}
                {subtotal.toFixed(2)}
              </span>
            </div>
            {effectiveDiscount > 0 && (
              <div className="flex justify-between text-emerald-400">
                <span>Discount Applied:</span>
                <span className="font-mono">
                  -{currency}
                  {effectiveDiscount.toFixed(2)}
                </span>
              </div>
            )}
            <div className="flex justify-between">
              <span>GST/VAT Tax ({defaultTaxRate}%):</span>
              <span className="font-mono text-zinc-200">
                {currency}
                {taxAmount.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between text-sm font-bold text-zinc-100 pt-1.5 border-t border-zinc-800">
              <span>Grand Total:</span>
              <span className="font-mono text-[#e5c378] text-base">
                {currency}
                {totalAmount.toFixed(2)}
              </span>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div className="grid grid-cols-3 gap-1.5 pt-1">
            <button
              onClick={() => setPaymentMethod('CASH')}
              className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition cursor-pointer ${
                paymentMethod === 'CASH'
                  ? 'bg-emerald-500/15 border-emerald-500/50 text-emerald-300 font-bold'
                  : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              <Banknote className="w-3.5 h-3.5" />
              <span>Cash</span>
            </button>

            <button
              onClick={() => setPaymentMethod('CARD')}
              className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition cursor-pointer ${
                paymentMethod === 'CARD'
                  ? 'bg-blue-500/15 border-blue-500/50 text-blue-300 font-bold'
                  : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Card</span>
            </button>

            <button
              onClick={() => setPaymentMethod('UPI')}
              className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition cursor-pointer ${
                paymentMethod === 'UPI'
                  ? 'bg-[#c5a059]/20 border-[#c5a059] text-[#e5c378] font-bold'
                  : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>UPI / Transfer</span>
            </button>
          </div>

          {/* Manual Transaction Reference for Card / UPI */}
          {(paymentMethod === 'UPI' || paymentMethod === 'CARD') && (
            <div className="p-2.5 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-1 text-xs">
              <span className="text-[11px] text-zinc-400 font-medium">
                {paymentMethod === 'UPI' ? 'UPI / UTR Transaction ID (Manual):' : 'Card Auth / Ref Number (Manual):'}
              </span>
              <input
                type="text"
                value={transactionRef}
                onChange={(e) => setTransactionRef(e.target.value)}
                placeholder={paymentMethod === 'UPI' ? 'e.g. UTR-902188412' : 'e.g. Card Ref #9921'}
                className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-zinc-200 text-xs focus:outline-hidden focus:border-[#c5a059]"
              />
            </div>
          )}

          {/* Cash Tendered Calculator (Instant Change Calculator) */}
          {paymentMethod === 'CASH' && (
            <div className="p-3 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-zinc-400 flex items-center gap-1">
                  <Coins className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Cash Tendered:</span>
                </span>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={cashTendered || ''}
                  onChange={(e) => setCashTendered(parseFloat(e.target.value) || 0)}
                  placeholder="e.g. 150.00"
                  className="w-24 px-2 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-right text-xs text-emerald-400 font-mono focus:outline-hidden"
                />
              </div>

              {/* Quick Cash Buttons */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {CASH_DENOMINATIONS.map((amt) => (
                  <button
                    type="button"
                    key={amt}
                    onClick={() => setCashTendered(amt)}
                    className="px-2 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[10px] font-mono shrink-0 cursor-pointer"
                  >
                    +{currency}{amt}
                  </button>
                ))}
              </div>

              {cashTendered > 0 && (
                <div className="flex items-center justify-between pt-1 border-t border-zinc-800 text-xs">
                  <span className="font-semibold text-zinc-300">Change Return:</span>
                  <span className={`font-mono font-bold ${changeDue >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {currency}{changeDue.toFixed(2)}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Partial Payment Toggle */}
          <div className="flex items-center justify-between text-xs pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-zinc-400">
              <input
                type="checkbox"
                checked={isPartialPayment}
                onChange={(e) => setIsPartialPayment(e.target.checked)}
                className="rounded bg-zinc-900 border-zinc-700 text-[#d4af37] focus:ring-0"
              />
              <span>Record Partial Payment</span>
            </label>
            {isPartialPayment && (
              <input
                type="number"
                min="0"
                step="any"
                value={customPaidAmount || ''}
                onChange={(e) => setCustomPaidAmount(parseFloat(e.target.value) || 0)}
                placeholder="Paid amt"
                className="w-24 px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-right text-xs text-[#e5c378] font-mono focus:outline-hidden"
              />
            )}
          </div>

          {/* Action Buttons: Hold Tab, Append to Tab, or Checkout */}
          {orderType === 'DINE_IN' && activeBill ? (
            <div className="space-y-2">
              {cart.length > 0 ? (
                <button
                  onClick={handleAppendToTab}
                  disabled={appendingItems}
                  className="w-full py-3 px-4 rounded-xl bg-linear-to-r from-amber-500 via-orange-400 to-amber-500 text-stone-950 font-bold text-xs tracking-wider uppercase transition shadow-lg shadow-amber-500/20 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
                >
                  {appendingItems ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Appending Dishes to Kitchen...</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4" />
                      <span>Append {cart.length} Dishes to Tab & Print KOT (+{currency}{totalAmount.toFixed(2)})</span>
                    </>
                  )}
                </button>
              ) : (
                <button
                  onClick={() => {
                    setSettleCashTendered(activeBill.balanceAmount);
                    setIsSettleModalOpen(true);
                  }}
                  className="w-full py-3 px-4 rounded-xl bg-linear-to-r from-emerald-500 to-teal-500 text-stone-950 font-bold text-xs tracking-wider uppercase transition shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Receipt className="w-4 h-4" />
                  <span>Settle Table {tableNumber} Tab ({currency}{activeBill.balanceAmount.toFixed(2)})</span>
                </button>
              )}
            </div>
          ) : orderType === 'DINE_IN' ? (
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleHoldTab}
                  disabled={cart.length === 0 || submitting}
                  className="py-3 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-amber-300 border border-amber-500/40 font-bold text-xs tracking-wider uppercase transition disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                  title="Open a running tab and send kitchen order ticket"
                >
                  <UtensilsCrossed className="w-4 h-4 text-amber-400" />
                  <span>Hold Tab & KOT</span>
                </button>
                <button
                  onClick={handleCheckout}
                  disabled={cart.length === 0 || submitting}
                  className="py-3 px-3 rounded-xl bg-linear-to-r from-[#d4af37] via-[#f7e6c4] to-[#d4af37] text-stone-950 font-bold text-xs tracking-wider uppercase transition shadow-lg shadow-[#d4af37]/20 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {submitting ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Receipt className="w-4 h-4" />
                  )}
                  <span>Pay {currency}{paidAmount.toFixed(2)}</span>
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={handleCheckout}
              disabled={cart.length === 0 || submitting}
              className="w-full py-3 px-4 rounded-xl bg-linear-to-r from-[#d4af37] via-[#f7e6c4] to-[#d4af37] text-stone-950 font-bold text-xs tracking-wider uppercase transition shadow-lg shadow-[#d4af37]/20 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing Transaction...</span>
                </>
              ) : (
                <>
                  <Receipt className="w-4 h-4" />
                  <span>Dispatch Bill & Collect {currency}{paidAmount.toFixed(2)}</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* ENHANCED LIVE TABLE SELECTOR MODAL */}
      {isTableModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#12141d]/90 backdrop-blur-2xl border border-zinc-700/60 rounded-3xl w-full max-w-2xl p-6 space-y-4 shadow-2xl shadow-black/50 flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <div>
                <h3 className="font-semibold text-base text-zinc-100 flex items-center gap-2">
                  <UtensilsCrossed className="w-4 h-4 text-[#d4af37]" />
                  <span>Live Dining Table Floor Plan</span>
                </h3>
                <p className="text-[11px] text-zinc-400">
                  Select a table to open order, view active tab, or settle guest bill
                </p>
              </div>
              <button
                onClick={() => setIsTableModalOpen(false)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Status Filter Tabs */}
            <div className="flex items-center gap-2 shrink-0 overflow-x-auto pb-1 text-xs">
              <button
                onClick={() => setTableFilter('ALL')}
                className={`px-3 py-1.5 rounded-xl font-medium transition cursor-pointer ${
                  tableFilter === 'ALL'
                    ? 'bg-[#d4af37] text-black font-bold'
                    : 'bg-zinc-900 text-zinc-400 hover:text-white'
                }`}
              >
                All Tables ({DINE_IN_TABLES.length})
              </button>
              <button
                onClick={() => setTableFilter('AVAILABLE')}
                className={`px-3 py-1.5 rounded-xl font-medium flex items-center gap-1.5 transition cursor-pointer ${
                  tableFilter === 'AVAILABLE'
                    ? 'bg-emerald-500 text-black font-bold'
                    : 'bg-zinc-900 text-emerald-400 hover:bg-zinc-800'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span>Available</span>
              </button>
              <button
                onClick={() => setTableFilter('OCCUPIED')}
                className={`px-3 py-1.5 rounded-xl font-medium flex items-center gap-1.5 transition cursor-pointer ${
                  tableFilter === 'OCCUPIED'
                    ? 'bg-rose-500 text-white font-bold'
                    : 'bg-zinc-900 text-rose-400 hover:bg-zinc-800'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                <span>Occupied Tabs</span>
              </button>
              <button
                onClick={() => setTableFilter('RESERVED')}
                className={`px-3 py-1.5 rounded-xl font-medium flex items-center gap-1.5 transition cursor-pointer ${
                  tableFilter === 'RESERVED'
                    ? 'bg-purple-600 text-white font-bold'
                    : 'bg-zinc-900 text-purple-400 hover:bg-zinc-800'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-purple-400" />
                <span>Seated Bookings</span>
              </button>
            </div>

            {/* Tables Grid */}
            <div className="flex-1 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 gap-3 pr-1">
              {DINE_IN_TABLES.filter((t) => {
                const data = tableOccupancy[t];
                if (tableFilter === 'AVAILABLE') return !data || data.status === 'AVAILABLE';
                if (tableFilter === 'OCCUPIED') return data?.status === 'OCCUPIED';
                if (tableFilter === 'RESERVED') return data?.status === 'RESERVED';
                return true;
              }).map((t) => {
                const data = tableOccupancy[t];
                const isOccupied = data?.status === 'OCCUPIED';
                const isReserved = data?.status === 'RESERVED';
                const isSelected = tableNumber === t;

                return (
                  <button
                    key={t}
                    type="button"
                    onClick={() => {
                      setTableNumber(t);
                      setIsTableModalOpen(false);
                    }}
                    className={`p-3.5 rounded-2xl border text-left transition flex flex-col justify-between h-28 relative cursor-pointer ${
                      isSelected
                        ? 'border-[#d4af37] bg-[#d4af37]/10 ring-1 ring-[#d4af37]/50'
                        : isOccupied
                        ? 'border-rose-500/40 bg-rose-950/20 hover:border-rose-500/80 hover:bg-rose-950/30'
                        : isReserved
                        ? 'border-purple-500/40 bg-purple-950/20 hover:border-purple-500/80 hover:bg-purple-950/30'
                        : 'border-zinc-800/80 bg-zinc-900/60 hover:border-emerald-500/40 hover:bg-zinc-850'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="font-semibold text-xs text-zinc-100">{t}</span>
                      <span
                        className={`text-[9px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                          isOccupied
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : isReserved
                            ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                            : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            isOccupied
                              ? 'bg-rose-500 animate-pulse'
                              : isReserved
                              ? 'bg-purple-400'
                              : 'bg-emerald-400'
                          }`}
                        />
                        {isOccupied ? 'Occupied' : isReserved ? 'Seated' : 'Available'}
                      </span>
                    </div>

                    {isOccupied && data?.bill && (
                      <div className="mt-auto space-y-0.5">
                        <p className="text-[10px] text-zinc-400 truncate">
                          {data.bill.items?.length || 0} items
                          {data.bill.customerName ? ` • ${data.bill.customerName}` : ''}
                        </p>
                        <p className="text-xs font-bold text-rose-400 font-mono">
                          {currency}{data.bill.balanceAmount?.toFixed(2)}
                        </p>
                      </div>
                    )}

                    {isReserved && data?.reservation && (
                      <div className="mt-auto space-y-0.5">
                        <p className="text-[10px] text-purple-300 font-medium truncate">
                          {data.reservation.guestName} ({data.reservation.guests}p)
                        </p>
                        <p className="text-[10px] text-zinc-400 font-mono">
                          Time: {data.reservation.time}
                        </p>
                      </div>
                    )}

                    {!isOccupied && !isReserved && (
                      <div className="mt-auto">
                        <span className="text-[11px] text-emerald-400/80 font-medium">Ready for Guests</span>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Custom table number input */}
            <div className="pt-2 border-t border-zinc-800 shrink-0">
              <input
                type="text"
                placeholder="Or type custom table/seat token (e.g. VIP-1, Terrace Bar)..."
                value={tableNumber}
                onChange={(e) => setTableNumber(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-100 focus:outline-hidden focus:border-[#d4af37]"
              />
            </div>
          </div>
        </div>
      )}

      {/* VIEW PLACED DISHES MODAL */}
      {showTabDetailsModal && activeBill && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#12141d]/90 backdrop-blur-2xl border border-zinc-700/60 rounded-3xl w-full max-w-lg p-6 space-y-4 shadow-2xl shadow-black/50 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div>
                <h3 className="font-semibold text-sm text-zinc-100 flex items-center gap-2">
                  <UtensilsCrossed className="w-4 h-4 text-[#d4af37]" />
                  <span>Placed Dishes for {tableNumber}</span>
                </h3>
                <p className="text-[11px] text-zinc-400 font-mono">
                  Bill #{activeBill.billNumber}
                </p>
              </div>
              <button
                onClick={() => setShowTabDetailsModal(false)}
                className="p-1 text-zinc-400 hover:text-white rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-zinc-800/80 pr-1">
              {activeBill.items?.map((it: any, i: number) => (
                <div key={i} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="space-y-0.5">
                    <p className="font-medium text-zinc-200">{it.itemName}</p>
                    <p className="text-[11px] text-zinc-400 font-mono">
                      {currency}{it.unitPrice.toFixed(2)} × {it.quantity}
                    </p>
                  </div>
                  <span className="font-mono font-bold text-zinc-200">
                    {currency}{(it.unitPrice * it.quantity).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-zinc-800 space-y-1.5 text-xs">
              <div className="flex justify-between text-zinc-400">
                <span>Subtotal:</span>
                <span className="font-mono">{currency}{activeBill.subtotal?.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Tax:</span>
                <span className="font-mono">{currency}{activeBill.taxAmount?.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-sm text-rose-400 pt-1 border-t border-zinc-800">
                <span>Balance Due:</span>
                <span className="font-mono">{currency}{activeBill.balanceAmount?.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowTabDetailsModal(false)}
                className="flex-1 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowTabDetailsModal(false);
                  setSettleCashTendered(activeBill.balanceAmount);
                  setIsSettleModalOpen(true);
                }}
                className="flex-1 py-2 rounded-xl bg-linear-to-r from-emerald-500 to-teal-500 text-stone-950 text-xs font-bold shadow-md shadow-emerald-500/20"
              >
                Proceed to Settle
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QUICK SETTLE TAB MODAL */}
      {isSettleModalOpen && activeBill && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#12141d]/90 backdrop-blur-2xl border border-zinc-700/60 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl shadow-black/50">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div>
                <h3 className="font-semibold text-sm text-zinc-100 flex items-center gap-2">
                  <Receipt className="w-4 h-4 text-emerald-400" />
                  <span>Settle Running Tab & Free {tableNumber}</span>
                </h3>
                <p className="text-[11px] text-zinc-400 font-mono">
                  Invoice {activeBill.billNumber}
                </p>
              </div>
              <button
                onClick={() => setIsSettleModalOpen(false)}
                className="p-1 text-zinc-400 hover:text-white rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Amount Due Box */}
            <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800 text-center space-y-1">
              <span className="text-[11px] uppercase tracking-wider text-zinc-400">Final Settlement Balance</span>
              <p className="text-2xl font-bold font-mono text-emerald-400">
                {currency}{activeBill.balanceAmount?.toFixed(2)}
              </p>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-zinc-300">Payment Tender:</label>
              <div className="grid grid-cols-3 gap-2">
                {(['CASH', 'CARD', 'UPI'] as const).map((method) => (
                  <button
                    key={method}
                    type="button"
                    onClick={() => setSettleMethod(method)}
                    className={`py-2 rounded-xl text-xs font-semibold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                      settleMethod === method
                        ? 'bg-[#d4af37] text-black font-bold shadow-md shadow-[#d4af37]/20'
                        : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {method === 'CASH' && <Banknote className="w-3.5 h-3.5" />}
                    {method === 'CARD' && <CreditCard className="w-3.5 h-3.5" />}
                    {method === 'UPI' && <Coins className="w-3.5 h-3.5" />}
                    <span>{method}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* If Cash: Denominations & Change calculation */}
            {settleMethod === 'CASH' && (
              <div className="space-y-2 p-3 rounded-xl bg-zinc-900/50 border border-zinc-800/80">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-400">Cash Received:</span>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={settleCashTendered || ''}
                    onChange={(e) => setSettleCashTendered(parseFloat(e.target.value) || 0)}
                    placeholder="Amt"
                    className="w-28 px-2 py-1 rounded-lg bg-zinc-900 border border-zinc-700 text-right text-xs text-emerald-400 font-mono font-bold"
                  />
                </div>
                <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
                  {CASH_DENOMINATIONS.map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setSettleCashTendered((prev) => prev + amt)}
                      className="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[10px] font-mono shrink-0 cursor-pointer"
                    >
                      +{currency}{amt}
                    </button>
                  ))}
                </div>
                {settleCashTendered > 0 && (
                  <div className="flex items-center justify-between pt-1 border-t border-zinc-800 text-xs">
                    <span className="text-zinc-300">Change Due:</span>
                    <span className={`font-mono font-bold ${settleCashTendered >= activeBill.balanceAmount ? 'text-emerald-400' : 'text-red-400'}`}>
                      {currency}{Math.max(0, settleCashTendered - activeBill.balanceAmount).toFixed(2)}
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* Settle Action Button */}
            <button
              onClick={handleSettleTab}
              disabled={settling}
              className="w-full py-3 px-4 rounded-xl bg-linear-to-r from-emerald-500 via-teal-400 to-emerald-500 text-stone-950 font-bold text-xs tracking-wider uppercase transition shadow-lg shadow-emerald-500/20 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
            >
              {settling ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Recording Settlement...</span>
                </>
              ) : (
                <>
                  <Receipt className="w-4 h-4" />
                  <span>Confirm Settlement & Free {tableNumber}</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}



      {/* RECEIPT / INVOICE MODAL & PRINT VIEW */}
      {completedBill && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4 print:p-0 print:bg-white print:static print:z-auto">
          <div className="bg-[#12141d]/90 backdrop-blur-2xl border border-zinc-700/60 rounded-3xl w-full max-w-xl p-6 max-h-[92vh] overflow-y-auto flex flex-col space-y-4 shadow-2xl shadow-black/50 print:bg-white print:border-none print:shadow-none print:p-0">
            {/* Modal Header (Hidden during print) */}
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 print:hidden">
              <div className="flex items-center gap-2 text-emerald-400">
                <CheckCircle className="w-5 h-5" />
                <span className="font-semibold text-sm">Invoice Successfully Created</span>
              </div>
              <button
                onClick={() => setCompletedBill(null)}
                className="p-1 text-zinc-400 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Print Format Tabs (Hidden during print) */}
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-zinc-900 border border-zinc-800 print:hidden text-xs">
              <button
                onClick={() => setReceiptFormat('custom')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition cursor-pointer ${
                  receiptFormat === 'custom'
                    ? 'bg-[#d4af37] text-black font-bold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Custom HTML
              </button>
              <button
                onClick={() => setReceiptFormat('thermal')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition cursor-pointer ${
                  receiptFormat === 'thermal'
                    ? 'bg-[#d4af37] text-black font-bold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Thermal (80mm)
              </button>
              <button
                onClick={() => setReceiptFormat('a4')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition cursor-pointer ${
                  receiptFormat === 'a4'
                    ? 'bg-[#d4af37] text-black font-bold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                A4 Tax Invoice
              </button>
              <button
                onClick={() => setReceiptFormat('kot')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition cursor-pointer ${
                  receiptFormat === 'kot'
                    ? 'bg-amber-400 text-black font-bold'
                    : 'text-amber-400/80 hover:text-white bg-amber-500/10'
                }`}
              >
                Chef KOT
              </button>
            </div>

            {/* RECEIPT CONTAINER */}
            <div className="flex-1 flex justify-center py-2">
              {receiptFormat === 'custom' ? (
                /* CUSTOM HTML DESIGNER TEMPLATE RENDER */
                <div
                  id="printable-receipt"
                  className="w-full h-[520px] bg-white rounded-xl shadow-md overflow-hidden"
                >
                  <iframe
                    srcDoc={renderedCustomReceiptHtml}
                    title="Invoice"
                    className="w-full h-full border-0 bg-white"
                  />
                </div>
              ) : receiptFormat === 'kot' ? (
                /* CHEF KITCHEN ORDER TICKET (KOT) FORMAT */
                <div
                  id="printable-receipt"
                  className="w-72 bg-white text-black p-4 rounded shadow-md font-mono text-[11px] leading-tight space-y-3 print:w-full print:shadow-none"
                >
                  <div className="text-center space-y-1 pb-2 border-b-2 border-black border-dashed">
                    <span className="inline-block px-2 py-0.5 rounded bg-black text-white text-[10px] font-bold uppercase tracking-wider">
                      *** KITCHEN ORDER TICKET (KOT) ***
                    </span>
                    <h3 className="font-bold text-base uppercase tracking-tight">{restaurantSettings?.name || restaurantName}</h3>
                    <div className="text-xl font-black py-1 px-3 border-2 border-black rounded inline-block my-1 bg-amber-50">
                      {completedBill.tableNumber || 'TAKEAWAY COUNTER'}
                    </div>
                  </div>

                  <div className="text-[10px] space-y-0.5 pb-2 border-b border-black border-dashed">
                    <div className="flex justify-between font-bold">
                      <span>ORDER TYPE:</span>
                      <span>{completedBill.orderType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>TOKEN / BILL #:</span>
                      <span className="font-bold">{completedBill.billNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>STEWARD / CASHIER:</span>
                      <span>{cashierName}</span>
                    </div>
                    <div className="flex justify-between text-[9px] text-gray-600">
                      <span>TIME: {new Date(completedBill.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
                      <span>{new Date(completedBill.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>

                  {/* KOT Items List */}
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b-2 border-black border-dashed font-bold">
                        <th className="py-1 text-center w-8">QTY</th>
                        <th className="py-1">CULINARY ITEM</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-300">
                      {completedBill.items?.map((it: any, i: number) => (
                        <tr key={i} className="font-semibold">
                          <td className="py-1.5 text-center text-sm font-black text-black">
                            [{it.quantity}]
                          </td>
                          <td className="py-1.5 pl-2 text-xs">
                            <span className="block font-bold">{it.itemName}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  <div className="text-center pt-3 border-t-2 border-black border-dashed text-[9px] font-bold uppercase tracking-widest text-gray-700">
                    -- DISPATCHED TO KITCHEN ATELIER --
                  </div>
                </div>
              ) : receiptFormat === 'thermal' ? (
                /* 80mm THERMAL RECEIPT */
                <div
                  id="printable-receipt"
                  className="w-72 bg-white text-black p-4 rounded shadow-md font-mono text-[11px] leading-tight space-y-3 print:w-full print:shadow-none"
                >
                  <div className="text-center space-y-1 pb-2 border-b border-black border-dashed">
                    {restaurantSettings?.logoUrl && (
                      <img src={restaurantSettings.logoUrl} alt="Logo" className="h-10 mx-auto object-contain mb-1" />
                    )}
                    <h3 className="font-bold text-sm uppercase">{restaurantSettings?.name || restaurantName}</h3>
                    <p className="text-[10px]">{restaurantSettings?.tagline || 'Royal Awadhi & Mughlai Culinary Atelier'}</p>
                    <p className="text-[9px]">{restaurantSettings?.address || 'Heritage Grand Haveli, Colaba Causeway, Mumbai, Maharashtra 400001'}</p>
                    <p className="text-[9px]">Tel: {restaurantSettings?.phone || '+91 98201 23456'}</p>
                  </div>

                  <div className="text-[10px] space-y-0.5 pb-2 border-b border-black border-dashed">
                    <div className="flex justify-between">
                      <span>BILL #: {completedBill.billNumber}</span>
                      <span>{completedBill.orderType}</span>
                    </div>
                    {completedBill.tableNumber && (
                      <div className="flex justify-between font-bold">
                        <span>TABLE: {completedBill.tableNumber}</span>
                        <span>CASHIER: {cashierName}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-[9px] text-gray-600">
                      <span>
                        {new Date(completedBill.createdAt).toLocaleDateString()}{' '}
                        {new Date(completedBill.createdAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                  </div>

                  {/* Items list */}
                  <table className="w-full text-left text-[10px]">
                    <thead>
                      <tr className="border-b border-black border-dashed">
                        <th className="py-1">ITEM</th>
                        <th className="py-1 text-center">QTY</th>
                        <th className="py-1 text-right">AMT</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {completedBill.items?.map((it: any, i: number) => (
                        <tr key={i}>
                          <td className="py-1 pr-1">{it.itemName}</td>
                          <td className="py-1 text-center">{it.quantity}</td>
                          <td className="py-1 text-right font-mono">
                            {currency}{(it.unitPrice * it.quantity).toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  {/* Totals */}
                  <div className="border-t border-black border-dashed pt-2 space-y-1 text-[10px]">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>{currency}{completedBill.subtotal?.toFixed(2)}</span>
                    </div>
                    {completedBill.discountAmount > 0 && (
                      <div className="flex justify-between text-gray-700">
                        <span>Discount:</span>
                        <span>-{currency}{completedBill.discountAmount?.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>Tax ({completedBill.taxRate || defaultTaxRate}%):</span>
                      <span>{currency}{completedBill.taxAmount?.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-xs pt-1 border-t border-black">
                      <span>GRAND TOTAL:</span>
                      <span>{currency}{completedBill.totalAmount?.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between pt-1 font-semibold">
                      <span>PAID ({completedBill.paymentMethod}):</span>
                      <span>{currency}{completedBill.paidAmount?.toFixed(2)}</span>
                    </div>
                    {completedBill.balanceAmount > 0 && (
                      <div className="flex justify-between text-red-600 font-bold">
                        <span>BALANCE DUE:</span>
                        <span>{currency}{completedBill.balanceAmount?.toFixed(2)}</span>
                      </div>
                    )}
                  </div>

                  <div className="text-center pt-2 border-t border-black border-dashed text-[9px] space-y-0.5">
                    <p className="font-semibold">{restaurantSettings?.receiptHeader || 'THANK YOU FOR GRACING OUR TABLE'}</p>
                    <p className="text-gray-600">{restaurantSettings?.receiptFooter || 'Please visit again soon.'}</p>
                  </div>
                </div>
              ) : (
                /* A4 TAX INVOICE FORMAT */
                <div
                  id="printable-receipt"
                  className="w-full bg-white text-black p-6 rounded-xl font-sans text-xs space-y-4 shadow-md print:w-full print:shadow-none"
                >
                  <div className="flex items-start justify-between pb-4 border-b border-gray-300">
                    <div>
                      {restaurantSettings?.logoUrl && (
                        <img src={restaurantSettings.logoUrl} alt="Logo" className="h-10 object-contain mb-2" />
                      )}
                      <h2 className="text-base font-bold text-gray-900">{restaurantSettings?.name || restaurantName}</h2>
                      <p className="text-gray-600 text-xs">{restaurantSettings?.tagline || 'Royal Awadhi & Mughlai Culinary Atelier'}</p>
                      <p className="text-gray-500 text-[11px]">{restaurantSettings?.address || 'Heritage Grand Haveli, Colaba Causeway, Mumbai, Maharashtra 400001'}</p>
                      <p className="text-gray-500 text-[11px]">Tel: {restaurantSettings?.phone || '+91 98201 23456'}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-xs uppercase font-bold text-gray-400 tracking-wider">TAX INVOICE</span>
                      <p className="text-base font-mono font-bold text-gray-900">{completedBill.billNumber}</p>
                      <p className="text-gray-600 text-[11px]">
                        Date: {new Date(completedBill.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-gray-400 font-semibold uppercase text-[10px]">Billed To:</span>
                      <p className="font-medium text-gray-800">
                        {completedBill.customer?.name || 'Valued Restaurant Patron'}
                      </p>
                      {completedBill.customer?.phone && (
                        <p className="text-gray-600">{completedBill.customer.phone}</p>
                      )}
                    </div>
                    <div className="text-right">
                      <span className="text-gray-400 font-semibold uppercase text-[10px]">Service Details:</span>
                      <p className="font-medium text-gray-800">
                        {completedBill.orderType} • {completedBill.tableNumber || 'Walk-in'}
                      </p>
                    </div>
                  </div>

                  <table className="w-full text-left text-xs border border-gray-200">
                    <thead className="bg-gray-100 text-gray-700 font-semibold uppercase text-[10px]">
                      <tr>
                        <th className="p-2 border-b">Item Description</th>
                        <th className="p-2 border-b text-center">Unit Price</th>
                        <th className="p-2 border-b text-center">Qty</th>
                        <th className="p-2 border-b text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {completedBill.items?.map((it: any, i: number) => (
                        <tr key={i}>
                          <td className="p-2">{it.itemName}</td>
                          <td className="p-2 text-center font-mono">{currency}{it.unitPrice.toFixed(2)}</td>
                          <td className="p-2 text-center">{it.quantity}</td>
                          <td className="p-2 text-right font-mono">
                            {currency}{(it.unitPrice * it.quantity).toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  <div className="flex justify-end">
                    <div className="w-64 space-y-1 text-xs">
                      <div className="flex justify-between text-gray-600">
                        <span>Subtotal:</span>
                        <span>{currency}{completedBill.subtotal?.toFixed(2)}</span>
                      </div>
                      {completedBill.discountAmount > 0 && (
                        <div className="flex justify-between text-emerald-600">
                          <span>Discount:</span>
                          <span>-{currency}{completedBill.discountAmount?.toFixed(2)}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-gray-600">
                        <span>Local Sales Tax ({completedBill.taxRate || defaultTaxRate}%):</span>
                        <span>{currency}{completedBill.taxAmount?.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between font-bold text-sm text-gray-900 pt-2 border-t border-gray-300">
                        <span>Invoice Total:</span>
                        <span>{currency}{completedBill.totalAmount?.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-gray-700 font-medium">
                        <span>Paid via {completedBill.paymentMethod}:</span>
                        <span>{currency}{completedBill.paidAmount?.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-200 text-center text-[10px] text-gray-500">
                    {restaurantSettings?.receiptFooter || 'All prices inclusive of applicable local taxes. Thank you for dining with us.'}
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons (Hidden during print) */}
            <div className="flex items-center justify-between pt-3 border-t border-zinc-800 print:hidden">
              <button
                onClick={() => setCompletedBill(null)}
                className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
              >
                Done / Next Order
              </button>

              <button
                onClick={handlePrint}
                className="px-6 py-2 rounded-xl bg-[#d4af37] text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-[#d4af37]/25 hover:bg-[#e5c378] transition"
              >
                <Printer className="w-4 h-4" />
                <span>Print Document</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import React from 'react';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { PosTerminal } from './PosTerminal';

export const dynamic = 'force-dynamic';

export default async function AdminPosPage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect('/admin/login');
  }

  const [categories, items, settings] = await Promise.all([
    prisma.menuCategory.findMany({
      where: { isActive: true },
      orderBy: { displayOrder: 'asc' },
      select: { id: true, name: true, slug: true },
    }),
    prisma.menuItem.findMany({
      where: { isAvailable: true },
      orderBy: { displayOrder: 'asc' },
      select: {
        id: true,
        name: true,
        price: true,
        isVeg: true,
        imageUrl: true,
        categoryId: true,
      },
    }),
    prisma.restaurantSetting.findFirst(),
  ]);

  return (
    <div className="h-full">
      <PosTerminal
        initialCategories={categories}
        initialItems={items}
        currency={settings?.currency || '$'}
        taxRate={settings?.taxRate ?? 5.0}
        restaurantName={settings?.name || "L'Étoile Sanctuary"}
        restaurantSettings={settings}
        cashierName={`${user.firstName} ${user.lastName}`}
      />
    </div>
  );
}

import React from 'react';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { BillsManager } from './BillsManager';

export const dynamic = 'force-dynamic';

export default async function AdminBillsPage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect('/admin/login');
  }

  const [bills, settings] = await Promise.all([
    prisma.bill.findMany({
      orderBy: { createdAt: 'desc' },
      take: 100,
      include: {
        customer: true,
        items: true,
        payments: true,
        createdBy: { select: { firstName: true, lastName: true } },
      },
    }),
    prisma.restaurantSetting.findFirst(),
  ]);

  // Format bills for client
  const formattedBills = bills.map((b) => ({
    ...b,
    createdAt: b.createdAt.toISOString(),
    payments: b.payments.map((p) => ({
      ...p,
      createdAt: p.createdAt.toISOString(),
    })),
  }));

  return (
    <BillsManager
      initialBills={formattedBills}
      currency={settings?.currency || '$'}
      restaurantName={settings?.name || "L'Étoile Sanctuary"}
      restaurantSettings={settings}
    />
  );
}

import React from 'react';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { StaffManager } from './StaffManager';

export const dynamic = 'force-dynamic';

export default async function AdminStaffPage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect('/admin/login');
  }

  if (user.role !== 'SUPER_ADMIN' && user.role !== 'OWNER' && user.role !== 'MANAGER') {
    redirect('/admin');
  }

  const staff = await prisma.user.findMany({
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      email: true,
      firstName: true,
      lastName: true,
      role: true,
      isActive: true,
      createdAt: true,
    },
  });

  const formattedStaff = staff.map((s) => ({
    ...s,
    createdAt: s.createdAt.toISOString(),
  }));

  return <StaffManager initialStaff={formattedStaff} currentUserRole={user.role} />;
}

'use client';

import React, { useState, useEffect, useMemo } from 'react';
import {
  CalendarDays,
  Clock,
  Users,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Plus,
  Phone,
  Mail,
  MapPin,
  UtensilsCrossed,
  Sparkles,
  ChevronDown,
  X,
  RotateCcw,
  UserCheck,
  Check,
  Trash2,
  MessageSquare,
} from 'lucide-react';
import { useToast } from '@/context/ToastContext';

interface Reservation {
  id: string;
  reference: string;
  guestName: string;
  phone: string;
  email?: string | null;
  date: string;
  time: string;
  guests: number;
  area: string;
  occasion?: string | null;
  specialRequests?: string | null;
  status: 'PENDING' | 'CONFIRMED' | 'SEATED' | 'COMPLETED' | 'CANCELLED';
  tableNumber?: string | null;
  notes?: string | null;
  createdAt: string;
}

interface Stats {
  total: number;
  pending: number;
  confirmed: number;
  seatedToday: number;
}

const DINING_TABLES = [
  'Table 1', 'Table 2', 'Table 3', 'Table 4',
  'Table 5', 'Table 6', 'Table 7', 'Table 8',
  'Table 9', 'Table 10', 'Table 11', 'Table 12',
  'Salon A (Private)', 'Salon B (Royal)',
];

export function ReservationsManager() {
  const toast = useToast();
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [stats, setStats] = useState<Stats>({ total: 0, pending: 0, confirmed: 0, seatedToday: 0 });
  const [loading, setLoading] = useState(true);

  // Filters
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'tomorrow' | 'upcoming'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [assignTableModal, setAssignTableModal] = useState<Reservation | null>(null);

  // New reservation form state
  const todayStr = new Date().toISOString().split('T')[0];
  const [form, setForm] = useState({
    guestName: '',
    phone: '',
    email: '',
    date: todayStr,
    time: '19:30',
    guests: 2,
    area: 'Main Dining Hall',
    occasion: 'Casual Fine Dining',
    tableNumber: 'Table 1',
    specialRequests: '',
    status: 'CONFIRMED' as const,
  });

  const fetchReservations = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/reservations');
      const json = await res.json();
      if (res.ok) {
        setReservations(json.data || []);
        if (json.stats) setStats(json.stats);
      } else {
        toast.error(json.error || 'Failed to load reservations', 'API Error');
      }
    } catch (err: any) {
      toast.error(err.message || 'Network error fetching reservations', 'Error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReservations();
  }, []);

  // Update Status & Table
  const handleUpdateStatus = async (
    id: string,
    newStatus: 'PENDING' | 'CONFIRMED' | 'SEATED' | 'COMPLETED' | 'CANCELLED',
    tableNumber?: string | null
  ) => {
    try {
      const payload: any = { status: newStatus };
      if (tableNumber !== undefined) payload.tableNumber = tableNumber;

      const res = await fetch(`/api/admin/reservations/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to update');

      toast.success(
        `Reservation updated to ${newStatus}${tableNumber ? ` (${tableNumber})` : ''}`,
        'Status Changed'
      );
      fetchReservations();
    } catch (err: any) {
      toast.error(err.message, 'Update Failed');
    }
  };

  // Delete Reservation
  const handleDelete = async (id: string, ref: string) => {
    if (!confirm(`Are you sure you want to remove reservation #${ref}?`)) return;
    try {
      const res = await fetch(`/api/admin/reservations/${id}`, { method: 'DELETE' });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to delete');

      toast.success(`Reservation #${ref} removed`, 'Deleted');
      fetchReservations();
    } catch (err: any) {
      toast.error(err.message, 'Delete Error');
    }
  };

  // Create Manual Reservation
  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/reservations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to create');

      toast.success(`Booking created for ${form.guestName}`, 'Reservation Booked');
      setIsCreateModalOpen(false);
      setForm({
        guestName: '',
        phone: '',
        email: '',
        date: todayStr,
        time: '19:30',
        guests: 2,
        area: 'Main Dining Hall',
        occasion: 'Casual Fine Dining',
        tableNumber: 'Table 1',
        specialRequests: '',
        status: 'CONFIRMED',
      });
      fetchReservations();
    } catch (err: any) {
      toast.error(err.message, 'Booking Failed');
    }
  };

  // Filtered reservations
  const filteredList = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const tomorrowDate = new Date();
    tomorrowDate.setDate(tomorrowDate.getDate() + 1);
    const tomorrow = tomorrowDate.toISOString().split('T')[0];

    return reservations.filter((r) => {
      // Status filter
      if (statusFilter !== 'ALL' && r.status !== statusFilter) return false;

      // Date filter
      if (dateFilter === 'today' && r.date !== today) return false;
      if (dateFilter === 'tomorrow' && r.date !== tomorrow) return false;
      if (dateFilter === 'upcoming' && r.date < today) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = r.guestName.toLowerCase().includes(q);
        const matchPhone = r.phone.includes(q);
        const matchRef = r.reference.toLowerCase().includes(q);
        if (!matchName && !matchPhone && !matchRef) return false;
      }

      return true;
    });
  }, [reservations, statusFilter, dateFilter, searchQuery]);

  return (
    <div className="space-y-6">
      {/* ============================================================ */}
      {/* 1. TOP HEADER & METRIC CARDS */}
      {/* ============================================================ */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
        <div>
          <h1 className="text-xl font-semibold text-zinc-100 flex items-center gap-2">
            <CalendarDays className="w-5 h-5 text-amber-400" />
            <span>Table Reservations Atelier</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            Manage incoming concierge bookings, verify table availability, and seat arriving patrons.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => fetchReservations()}
            className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition cursor-pointer"
            title="Refresh List"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold text-xs flex items-center gap-2 transition cursor-pointer shadow-md shadow-amber-400/20"
          >
            <Plus className="w-4 h-4" />
            <span>Record Walk-in / Phone Booking</span>
          </button>
        </div>
      </div>

      {/* Pending Approval Attention Banner */}
      {stats.pending > 0 && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-zinc-900 to-zinc-900 border border-amber-500/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
          <div className="flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-amber-400 animate-pulse shrink-0" />
            <div>
              <p className="text-xs font-bold text-amber-300">
                {stats.pending} New Reservation Request{stats.pending > 1 ? 's' : ''} Awaiting Approval
              </p>
              <p className="text-[11px] text-zinc-400">
                Guests submitted table requests from the website. Please review and click &quot;Approve&quot; to confirm their bookings.
              </p>
            </div>
          </div>
          <button
            onClick={() => setStatusFilter('PENDING')}
            className="px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs shrink-0 transition cursor-pointer"
          >
            Filter Pending Requests ({stats.pending})
          </button>
        </div>
      )}

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-[#11141e] border border-zinc-800 space-y-1">
          <span className="text-[11px] font-medium text-zinc-400 uppercase tracking-wider">Total Bookings</span>
          <p className="text-2xl font-bold text-zinc-100 font-mono">{stats.total}</p>
          <span className="text-[10px] text-zinc-500">Historical registrations</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#11141e] border border-amber-500/30 space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-medium text-amber-400 uppercase tracking-wider">Pending Action</span>
            {stats.pending > 0 && <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />}
          </div>
          <p className="text-2xl font-bold text-amber-400 font-mono">{stats.pending}</p>
          <span className="text-[10px] text-zinc-400">Needs staff confirmation</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#11141e] border border-zinc-800 space-y-1">
          <span className="text-[11px] font-medium text-emerald-400 uppercase tracking-wider">Confirmed</span>
          <p className="text-2xl font-bold text-emerald-400 font-mono">{stats.confirmed}</p>
          <span className="text-[10px] text-zinc-500">Tables assigned / guaranteed</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#11141e] border border-zinc-800 space-y-1">
          <span className="text-[11px] font-medium text-blue-400 uppercase tracking-wider">Seated Today</span>
          <p className="text-2xl font-bold text-blue-400 font-mono">{stats.seatedToday}</p>
          <span className="text-[10px] text-zinc-500">Currently dining in salons</span>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 2. TOOLBAR: STATUS TABS, DATE FILTERS & SEARCH */}
      {/* ============================================================ */}
      <div className="p-4 rounded-2xl bg-[#11141e] border border-zinc-800 flex flex-col lg:flex-row gap-3 items-stretch lg:items-center justify-between">
        {/* Status Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl bg-zinc-900 border border-zinc-800 text-xs">
          {[
            { id: 'ALL', label: 'All' },
            { id: 'PENDING', label: `Pending (${stats.pending})` },
            { id: 'CONFIRMED', label: 'Confirmed' },
            { id: 'SEATED', label: 'Seated' },
            { id: 'COMPLETED', label: 'Completed' },
            { id: 'CANCELLED', label: 'Cancelled' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer text-xs ${
                statusFilter === tab.id
                  ? 'bg-amber-400 text-black font-bold shadow-xs'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Date Filter & Search Box */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Date Selector */}
          <div className="flex items-center gap-1 p-1 rounded-xl bg-zinc-900 border border-zinc-800 text-xs">
            {[
              { id: 'all', label: 'All Dates' },
              { id: 'today', label: 'Today' },
              { id: 'tomorrow', label: 'Tomorrow' },
              { id: 'upcoming', label: 'Upcoming' },
            ].map((d) => (
              <button
                key={d.id}
                onClick={() => setDateFilter(d.id as any)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer ${
                  dateFilter === d.id ? 'bg-zinc-800 text-amber-300 font-bold' : 'text-zinc-400 hover:text-white'
                }`}
              >
                {d.label}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative flex-1 sm:w-64">
            <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search guest, phone, ref..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-400 transition"
            />
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 3. RESERVATIONS LIST TABLE */}
      {/* ============================================================ */}
      <div className="rounded-2xl border border-zinc-800 bg-[#11141e] overflow-hidden shadow-xl">
        {loading ? (
          <div className="p-16 text-center text-zinc-500 text-xs">Loading reservation ledger...</div>
        ) : filteredList.length === 0 ? (
          <div className="p-16 text-center space-y-3">
            <UtensilsCrossed className="w-10 h-10 text-zinc-600 mx-auto" />
            <h3 className="text-zinc-200 font-semibold text-sm">No reservations match criteria</h3>
            <p className="text-zinc-500 text-xs max-w-sm mx-auto">
              Try adjusting your status tab, date range, or search keyword.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#141824] text-zinc-400 border-b border-zinc-800 text-[11px] uppercase tracking-wider">
                <tr>
                  <th className="py-3.5 px-4 font-semibold">Reference</th>
                  <th className="py-3.5 px-4 font-semibold">Guest</th>
                  <th className="py-3.5 px-4 font-semibold">Date & Time</th>
                  <th className="py-3.5 px-4 font-semibold text-center">Party</th>
                  <th className="py-3.5 px-4 font-semibold">Seating Area</th>
                  <th className="py-3.5 px-4 font-semibold">Assigned Table</th>
                  <th className="py-3.5 px-4 font-semibold">Status</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/80">
                {filteredList.map((res) => {
                  return (
                    <tr key={res.id} className="hover:bg-[#151926] transition-colors">
                      {/* Ref & Occasion */}
                      <td className="py-3.5 px-4">
                        <span className="font-mono font-bold text-amber-400 block">{res.reference}</span>
                        {res.occasion && (
                          <span className="text-[10px] text-zinc-500 block">{res.occasion}</span>
                        )}
                      </td>

                      {/* Guest Info */}
                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-zinc-200 block">{res.guestName}</span>
                        <div className="flex items-center gap-1.5 text-zinc-400 text-[11px] mt-0.5">
                          <a href={`tel:${res.phone}`} className="hover:text-amber-400 font-mono">
                            {res.phone}
                          </a>
                        </div>
                        {res.specialRequests && (
                          <div className="text-[10px] text-amber-300/80 italic mt-0.5 flex items-center gap-1">
                            <Sparkles className="w-2.5 h-2.5 text-amber-400 shrink-0" />
                            <span className="truncate max-w-[200px]" title={res.specialRequests}>
                              {res.specialRequests}
                            </span>
                          </div>
                        )}
                      </td>

                      {/* Date & Time */}
                      <td className="py-3.5 px-4">
                        <span className="text-zinc-200 font-medium block">{res.date}</span>
                        <span className="text-[11px] text-amber-400 font-mono font-semibold block">{res.time}</span>
                      </td>

                      {/* Party */}
                      <td className="py-3.5 px-4 text-center">
                        <span className="inline-block px-2 py-0.5 rounded-md bg-zinc-900 border border-zinc-800 text-zinc-200 font-mono font-bold">
                          {res.guests}
                        </span>
                      </td>

                      {/* Area */}
                      <td className="py-3.5 px-4 text-zinc-300">
                        <span>{res.area}</span>
                      </td>

                      {/* Assigned Table */}
                      <td className="py-3.5 px-4">
                        <button
                          onClick={() => setAssignTableModal(res)}
                          className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-700 hover:border-amber-400 text-zinc-200 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                        >
                          <span>{res.tableNumber || 'Unassigned'}</span>
                          <ChevronDown className="w-3 h-3 text-zinc-400" />
                        </button>
                      </td>

                      {/* Status Badge */}
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            res.status === 'PENDING'
                              ? 'bg-amber-400/15 text-amber-300 border border-amber-400/30'
                              : res.status === 'CONFIRMED'
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                              : res.status === 'SEATED'
                              ? 'bg-blue-500/15 text-blue-400 border border-blue-500/30'
                              : res.status === 'COMPLETED'
                              ? 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                              : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {res.status === 'PENDING' && (
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                          )}
                          <span>{res.status === 'PENDING' ? 'Awaiting Approval' : res.status}</span>
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Approval actions for pending request */}
                          {res.status === 'PENDING' && (
                            <>
                              <button
                                onClick={() => handleUpdateStatus(res.id, 'CONFIRMED', res.tableNumber || 'Table 1')}
                                className="px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-[11px] transition cursor-pointer flex items-center gap-1 shadow-sm"
                                title="Approve and confirm reservation"
                              >
                                <Check className="w-3 h-3" />
                                <span>Approve</span>
                              </button>
                              <button
                                onClick={() => handleUpdateStatus(res.id, 'CANCELLED')}
                                className="px-2 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 font-medium text-[11px] transition cursor-pointer flex items-center gap-1"
                                title="Decline request"
                              >
                                <XCircle className="w-3 h-3" />
                                <span>Decline</span>
                              </button>
                            </>
                          )}

                          {/* Seat at Table for confirmed */}
                          {res.status === 'CONFIRMED' && (
                            <button
                              onClick={() => handleUpdateStatus(res.id, 'SEATED')}
                              className="px-2.5 py-1 rounded-lg bg-blue-500 hover:bg-blue-400 text-white font-bold text-[11px] transition cursor-pointer flex items-center gap-1"
                              title="Seat patron at table"
                            >
                              <UserCheck className="w-3 h-3" />
                              <span>Seat</span>
                            </button>
                          )}

                          {/* Complete action for seated */}
                          {res.status === 'SEATED' && (
                            <button
                              onClick={() => handleUpdateStatus(res.id, 'COMPLETED')}
                              className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-semibold text-[11px] transition cursor-pointer"
                              title="Mark dining session complete"
                            >
                              Complete
                            </button>
                          )}

                          {/* Cancel button */}
                          {res.status !== 'CANCELLED' && res.status !== 'COMPLETED' && (
                            <button
                              onClick={() => handleUpdateStatus(res.id, 'CANCELLED')}
                              className="p-1 text-zinc-500 hover:text-rose-400 transition cursor-pointer rounded"
                              title="Cancel reservation"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          )}

                          {/* Remove row */}
                          <button
                            onClick={() => handleDelete(res.id, res.reference)}
                            className="p-1 text-zinc-600 hover:text-rose-400 transition cursor-pointer rounded"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ============================================================ */}
      {/* 4. MODAL: CREATE MANUAL WALK-IN / PHONE RESERVATION */}
      {/* ============================================================ */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#12151d]/90 backdrop-blur-2xl border border-zinc-700/60 rounded-3xl w-full max-w-lg p-6 space-y-4 shadow-2xl shadow-black/50 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="font-semibold text-sm text-zinc-100 flex items-center gap-2">
                <CalendarDays className="w-4 h-4 text-amber-400" />
                <span>Record New Reservation</span>
              </h3>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1 text-zinc-400 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-medium text-zinc-300 block mb-1">Guest Full Name *</label>
                  <input
                    type="text"
                    required
                    value={form.guestName}
                    onChange={(e) => setForm({ ...form, guestName: e.target.value })}
                    placeholder="e.g. Maharaja Vikramaditya"
                    className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="font-medium text-zinc-300 block mb-1">Mobile Phone *</label>
                  <input
                    type="tel"
                    required
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="+91 98201 00000"
                    className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 font-mono focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-medium text-zinc-300 block mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="font-medium text-zinc-300 block mb-1">Service Time *</label>
                  <input
                    type="time"
                    required
                    value={form.time}
                    onChange={(e) => setForm({ ...form, time: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs font-mono focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="font-medium text-zinc-300 block mb-1">Guests *</label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={form.guests}
                    onChange={(e) => setForm({ ...form, guests: parseInt(e.target.value, 10) || 1 })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 font-mono text-center focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-medium text-zinc-300 block mb-1">Seating Area</label>
                  <select
                    value={form.area}
                    onChange={(e) => setForm({ ...form, area: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-400"
                  >
                    <option value="Main Dining Hall">Main Dining Hall</option>
                    <option value="Chef's Tasting Counter">Chef's Tasting Counter</option>
                    <option value="Sommelier Wine Vault">Sommelier Wine Vault</option>
                    <option value="Heated Botanical Veranda">Heated Botanical Veranda</option>
                    <option value="Royal Salon (Private)">Royal Salon (Private)</option>
                  </select>
                </div>

                <div>
                  <label className="font-medium text-zinc-300 block mb-1">Assign Table</label>
                  <select
                    value={form.tableNumber}
                    onChange={(e) => setForm({ ...form, tableNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-400"
                  >
                    {DINING_TABLES.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="font-medium text-zinc-300 block mb-1">Dietary & Occasion Notes</label>
                <input
                  type="text"
                  value={form.specialRequests}
                  onChange={(e) => setForm({ ...form, specialRequests: e.target.value })}
                  placeholder="e.g. Vegetarian, Anniversary celebration, Extra spice"
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-bold transition shadow-md shadow-amber-400/20"
                >
                  Save Reservation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 5. MODAL: QUICK TABLE ASSIGNMENT */}
      {/* ============================================================ */}
      {assignTableModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#12151d]/90 backdrop-blur-2xl border border-zinc-700/60 rounded-3xl w-full max-w-sm p-6 space-y-4 shadow-2xl shadow-black/50 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div>
                <h3 className="font-semibold text-sm text-zinc-100">Assign Dining Table</h3>
                <p className="text-[11px] text-zinc-400 font-mono">
                  {assignTableModal.guestName} ({assignTableModal.guests} guests)
                </p>
              </div>
              <button
                onClick={() => setAssignTableModal(null)}
                className="p-1 text-zinc-400 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto">
              {DINING_TABLES.map((table) => {
                const isSelected = assignTableModal.tableNumber === table;
                return (
                  <button
                    key={table}
                    onClick={() => {
                      handleUpdateStatus(assignTableModal.id, assignTableModal.status, table);
                      setAssignTableModal(null);
                    }}
                    className={`p-2.5 rounded-xl border text-left font-medium transition cursor-pointer ${
                      isSelected
                        ? 'bg-amber-400 text-black font-bold border-amber-400 shadow-sm'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700 hover:text-white'
                    }`}
                  >
                    <span>{table}</span>
                  </button>
                );
              })}
            </div>

            <div className="pt-2 border-t border-zinc-800 text-right">
              <button
                onClick={() => setAssignTableModal(null)}
                className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

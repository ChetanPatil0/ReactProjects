'use client';

import React, { useState } from 'react';
import { Sparkles, Home, Info, Phone, Tag, Image as ImageIcon, Plus, Trash2, Loader2, Save } from 'lucide-react';
import { ImageUploader } from '@/components/admin/ImageUploader';

interface ContentManagerProps {
  initialHomepage: any;
  initialAbout: any;
  initialContact: any;
  initialOffers: any[];
  initialGallery: any[];
}

export function ContentManager({
  initialHomepage,
  initialAbout,
  initialContact,
  initialOffers,
  initialGallery,
}: ContentManagerProps) {
  const [tab, setTab] = useState<'home' | 'about' | 'contact' | 'offers' | 'gallery'>('home');

  // Form states
  const [homepage, setHomepage] = useState(initialHomepage || {});
  const [about, setAbout] = useState(initialAbout || {});
  const [contact, setContact] = useState(initialContact || {});
  const [offers, setOffers] = useState<any[]>(initialOffers || []);
  const [gallery, setGallery] = useState<any[]>(initialGallery || []);

  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Gallery New Item State
  const [newGalleryTitle, setNewGalleryTitle] = useState('');
  const [newGalleryUrl, setNewGalleryUrl] = useState<string | null>(null);
  const [newGalleryCategory, setNewGalleryCategory] = useState('ambience');

  // Offer New Item State
  const [isOfferModalOpen, setIsOfferModalOpen] = useState(false);
  const [offerForm, setOfferForm] = useState({
    title: '',
    code: '',
    discount: '',
    description: '',
    badgeText: 'FEATURED',
    imageUrl: null as string | null,
    isActive: true,
  });

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  // Save Homepage
  const saveHomepage = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch('/api/admin/content/homepage', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(homepage),
      });
      if (!res.ok) throw new Error('Failed to update homepage');
      showSuccess('Homepage content updated successfully!');
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSaving(false);
    }
  };

  // Save About
  const saveAbout = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch('/api/admin/content/about', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(about),
      });
      if (!res.ok) throw new Error('Failed to update about page');
      showSuccess('About page updated successfully!');
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSaving(false);
    }
  };

  // Save Contact
  const saveContact = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch('/api/admin/content/contact', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(contact),
      });
      if (!res.ok) throw new Error('Failed to update contact info');
      showSuccess('Contact details updated successfully!');
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSaving(false);
    }
  };

  // Add Gallery Item
  const handleAddGallery = async () => {
    if (!newGalleryUrl) {
      alert('Please upload a photo first');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch('/api/admin/content/gallery', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newGalleryTitle || 'Dining Ambiance',
          category: newGalleryCategory,
          imageUrl: newGalleryUrl,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save gallery item');

      setGallery((prev) => [...prev, data.data]);
      setNewGalleryTitle('');
      setNewGalleryUrl(null);
      showSuccess('Gallery photo published!');
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSaving(false);
    }
  };

  // Delete Gallery Item
  const handleDeleteGallery = async (id: string) => {
    if (!confirm('Delete this photo? Its file will be unlinked from storage.')) return;
    try {
      const res = await fetch(`/api/admin/content/gallery?id=${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Failed to delete photo');
      setGallery((prev) => prev.filter((g) => g.id !== id));
      showSuccess('Photo removed from gallery.');
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Create Offer
  const handleCreateOffer = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch('/api/admin/content/offers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(offerForm),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create offer');

      setOffers((prev) => [data.data, ...prev]);
      setIsOfferModalOpen(false);
      showSuccess('Promotional offer created!');
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSaving(false);
    }
  };

  // Delete Offer
  const handleDeleteOffer = async (id: string) => {
    if (!confirm('Delete this offer banner?')) return;
    try {
      const res = await fetch(`/api/admin/content/offers?id=${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Failed to delete offer');
      setOffers((prev) => prev.filter((o) => o.id !== id));
      showSuccess('Offer deleted.');
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-5xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800/80">
        <div>
          <h1 className="font-semibold text-xl text-zinc-100">Website Content Management</h1>
          <p className="text-xs text-zinc-400 mt-1">Control editorial copy, imagery, offers, and gallery without developer assistance.</p>
        </div>
        {successMsg && (
          <div className="px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold animate-fade-in">
            {successMsg}
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-zinc-800 overflow-x-auto">
        <button
          onClick={() => setTab('home')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition -mb-px whitespace-nowrap ${
            tab === 'home' ? 'border-amber-400 text-amber-400' : 'border-transparent text-zinc-400 hover:text-white'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>Homepage Content</span>
        </button>

        <button
          onClick={() => setTab('about')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition -mb-px whitespace-nowrap ${
            tab === 'about' ? 'border-amber-400 text-amber-400' : 'border-transparent text-zinc-400 hover:text-white'
          }`}
        >
          <Info className="w-4 h-4" />
          <span>About Page</span>
        </button>

        <button
          onClick={() => setTab('contact')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition -mb-px whitespace-nowrap ${
            tab === 'contact' ? 'border-amber-400 text-amber-400' : 'border-transparent text-zinc-400 hover:text-white'
          }`}
        >
          <Phone className="w-4 h-4" />
          <span>Contact & Hours</span>
        </button>

        <button
          onClick={() => setTab('offers')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition -mb-px whitespace-nowrap ${
            tab === 'offers' ? 'border-amber-400 text-amber-400' : 'border-transparent text-zinc-400 hover:text-white'
          }`}
        >
          <Tag className="w-4 h-4" />
          <span>Offers ({offers.length})</span>
        </button>

        <button
          onClick={() => setTab('gallery')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition -mb-px whitespace-nowrap ${
            tab === 'gallery' ? 'border-amber-400 text-amber-400' : 'border-transparent text-zinc-400 hover:text-white'
          }`}
        >
          <ImageIcon className="w-4 h-4" />
          <span>Photo Gallery ({gallery.length})</span>
        </button>
      </div>

      {/* 1. HOMEPAGE EDITOR */}
      {tab === 'home' && (
        <form onSubmit={saveHomepage} className="space-y-6 text-xs bg-[#12151a] p-6 rounded-2xl border border-zinc-800">
          <div>
            <label className="block font-semibold text-zinc-300 mb-1">Top Announcement Ribbon</label>
            <input
              type="text"
              value={homepage.announcement || ''}
              onChange={(e) => setHomepage({ ...homepage, announcement: e.target.value })}
              className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Hero Main Title</label>
              <textarea
                rows={3}
                value={homepage.heroTitle || ''}
                onChange={(e) => setHomepage({ ...homepage, heroTitle: e.target.value })}
                className="w-full p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
              />
            </div>
            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Hero Subtitle</label>
              <textarea
                rows={3}
                value={homepage.heroSubtitle || ''}
                onChange={(e) => setHomepage({ ...homepage, heroSubtitle: e.target.value })}
                className="w-full p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
              />
            </div>
          </div>

          <ImageUploader
            value={homepage.heroImageUrl}
            onChange={(url) => setHomepage({ ...homepage, heroImageUrl: url })}
            label="Hero Background Photography"
            helperText="Replaces existing hero image and cleans up old file."
          />

          <div className="pt-4 border-t border-zinc-800">
            <h3 className="font-semibold text-sm text-zinc-100 mb-3">Introductory Section</h3>
            <div className="space-y-3">
              <div>
                <label className="block font-medium text-zinc-400 mb-1">Intro Heading</label>
                <input
                  type="text"
                  value={homepage.introTitle || ''}
                  onChange={(e) => setHomepage({ ...homepage, introTitle: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
                />
              </div>
              <div>
                <label className="block font-medium text-zinc-400 mb-1">Intro Narrative</label>
                <textarea
                  rows={3}
                  value={homepage.introDescription || ''}
                  onChange={(e) => setHomepage({ ...homepage, introDescription: e.target.value })}
                  className="w-full p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold flex items-center gap-2 transition disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            <span>Save Homepage Changes</span>
          </button>
        </form>
      )}

      {/* 2. ABOUT PAGE EDITOR */}
      {tab === 'about' && (
        <form onSubmit={saveAbout} className="space-y-6 text-xs bg-[#12151a] p-6 rounded-2xl border border-zinc-800">
          <div>
            <label className="block font-semibold text-zinc-300 mb-1">Our Heritage Story Title</label>
            <input
              type="text"
              value={about.storyTitle || ''}
              onChange={(e) => setAbout({ ...about, storyTitle: e.target.value })}
              className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
            />
          </div>

          <div>
            <label className="block font-semibold text-zinc-300 mb-1">Story Content</label>
            <textarea
              rows={4}
              value={about.storyContent || ''}
              onChange={(e) => setAbout({ ...about, storyContent: e.target.value })}
              className="w-full p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
            />
          </div>

          <ImageUploader
            value={about.storyImageUrl}
            onChange={(url) => setAbout({ ...about, storyImageUrl: url })}
            label="Story Atmosphere Photo"
          />

          <div className="pt-4 border-t border-zinc-800 space-y-4">
            <h3 className="font-semibold text-sm text-zinc-100">Executive Chef Profile</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-medium text-zinc-400 mb-1">Chef Name</label>
                <input
                  type="text"
                  value={about.chefName || ''}
                  onChange={(e) => setAbout({ ...about, chefName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
                />
              </div>
              <div>
                <label className="block font-medium text-zinc-400 mb-1">Chef Biography</label>
                <textarea
                  rows={2}
                  value={about.chefBio || ''}
                  onChange={(e) => setAbout({ ...about, chefBio: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
                />
              </div>
            </div>
            <ImageUploader
              value={about.chefImageUrl}
              onChange={(url) => setAbout({ ...about, chefImageUrl: url })}
              label="Chef Portrait Photograph"
            />
          </div>

          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold flex items-center gap-2 transition disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            <span>Save About Page Changes</span>
          </button>
        </form>
      )}

      {/* 3. CONTACT EDITOR */}
      {tab === 'contact' && (
        <form onSubmit={saveContact} className="space-y-4 text-xs bg-[#12151a] p-6 rounded-2xl border border-zinc-800">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Physical Address</label>
              <input
                type="text"
                value={contact.address || ''}
                onChange={(e) => setContact({ ...contact, address: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
              />
            </div>

            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Reservation Phone Number</label>
              <input
                type="text"
                value={contact.phone || ''}
                onChange={(e) => setContact({ ...contact, phone: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
              />
            </div>

            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Email Address</label>
              <input
                type="email"
                value={contact.email || ''}
                onChange={(e) => setContact({ ...contact, email: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
              />
            </div>

            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Opening Hours Schedule</label>
              <input
                type="text"
                value={contact.openingHours || ''}
                onChange={(e) => setContact({ ...contact, openingHours: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold flex items-center gap-2 transition disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            <span>Save Contact Info</span>
          </button>
        </form>
      )}

      {/* 4. OFFERS EDITOR */}
      {tab === 'offers' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button
              onClick={() => setIsOfferModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold text-xs tracking-wider uppercase transition shadow-md shadow-amber-400/20"
            >
              <Plus className="w-4 h-4" />
              <span>Create Offer Banner</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {offers.map((offer) => (
              <div key={offer.id} className="p-5 rounded-2xl bg-[#12151a] border border-zinc-800 relative flex flex-col justify-between space-y-3">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase bg-amber-500/10 text-amber-400 border border-amber-500/20">
                      {offer.badgeText || 'PROMO'}
                    </span>
                    <button
                      onClick={() => handleDeleteOffer(offer.id)}
                      className="p-1 text-zinc-500 hover:text-red-400 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <h3 className="font-semibold text-sm text-zinc-100">{offer.title}</h3>
                  <p className="text-xs font-semibold text-amber-400">{offer.discount}</p>
                  <p className="text-xs text-zinc-400">{offer.description}</p>
                </div>
                {offer.code && (
                  <div className="pt-2 border-t border-zinc-800 text-[11px] font-mono text-zinc-400">
                    Promo Code: <span className="text-zinc-200 font-bold">{offer.code}</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Create Offer Modal */}
          {isOfferModalOpen && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4">
              <div className="bg-[#12151a]/90 backdrop-blur-2xl border border-zinc-700/60 rounded-2xl w-full max-w-md p-6 space-y-4 text-xs shadow-2xl shadow-black/50">
                <h3 className="font-semibold text-sm text-zinc-100">Add Promotional Offer</h3>
                <form onSubmit={handleCreateOffer} className="space-y-3">
                  <div>
                    <label className="block font-medium text-zinc-300 mb-1">Title *</label>
                    <input
                      type="text"
                      required
                      value={offerForm.title}
                      onChange={(e) => setOfferForm({ ...offerForm, title: e.target.value })}
                      placeholder="e.g. Weekend Grand Degustation"
                      className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block font-medium text-zinc-300 mb-1">Discount Tag *</label>
                      <input
                        type="text"
                        required
                        value={offerForm.discount}
                        onChange={(e) => setOfferForm({ ...offerForm, discount: e.target.value })}
                        placeholder="e.g. 20% OFF"
                        className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-medium text-zinc-300 mb-1">Promo Code (Optional)</label>
                      <input
                        type="text"
                        value={offerForm.code}
                        onChange={(e) => setOfferForm({ ...offerForm, code: e.target.value })}
                        placeholder="e.g. DEGUST20"
                        className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block font-medium text-zinc-300 mb-1">Description *</label>
                    <textarea
                      rows={2}
                      required
                      value={offerForm.description}
                      onChange={(e) => setOfferForm({ ...offerForm, description: e.target.value })}
                      className="w-full p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none"
                    />
                  </div>
                  <ImageUploader
                    value={offerForm.imageUrl}
                    onChange={(url) => setOfferForm({ ...offerForm, imageUrl: url })}
                    label="Offer Banner Photo"
                  />
                  <div className="flex gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsOfferModalOpen(false)}
                      className="flex-1 py-2 rounded-xl bg-zinc-800 text-zinc-300 font-medium"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={saving}
                      className="flex-1 py-2 rounded-xl bg-amber-400 text-black font-semibold"
                    >
                      {saving ? 'Saving...' : 'Publish Offer'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 5. GALLERY EDITOR */}
      {tab === 'gallery' && (
        <div className="space-y-6">
          {/* Upload New Photo Card */}
          <div className="p-5 rounded-2xl bg-[#12151a] border border-zinc-800 space-y-4">
            <h3 className="font-semibold text-sm text-zinc-100">Upload New Gallery Photo</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1">Photo Title / Subject</label>
                  <input
                    type="text"
                    value={newGalleryTitle}
                    onChange={(e) => setNewGalleryTitle(e.target.value)}
                    placeholder="e.g. Dining Sanctuary at Dusk"
                    className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-100 focus:outline-none focus:border-amber-500/60"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1">Category</label>
                  <select
                    value={newGalleryCategory}
                    onChange={(e) => setNewGalleryCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-100 focus:outline-none"
                  >
                    <option value="ambience">Ambience & Interiors</option>
                    <option value="culinary">Culinary & Dishes</option>
                    <option value="bar">Bar & Artisanal Spirits</option>
                  </select>
                </div>
                <button
                  onClick={handleAddGallery}
                  disabled={saving || !newGalleryUrl}
                  className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold text-xs tracking-wider uppercase transition disabled:opacity-40"
                >
                  {saving ? 'Publishing...' : 'Add to Gallery'}
                </button>
              </div>

              <div>
                <ImageUploader
                  value={newGalleryUrl}
                  onChange={(url) => setNewGalleryUrl(url)}
                  label="Select Photo"
                  helperText="Photo moves from temp to permanent upon adding."
                />
              </div>
            </div>
          </div>

          {/* Photo Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {gallery.map((item) => (
              <div key={item.id} className="relative group rounded-xl overflow-hidden border border-zinc-800 bg-zinc-900 aspect-square">
                <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-3 flex flex-col justify-end">
                  <p className="text-xs font-semibold text-white truncate">{item.title}</p>
                  <p className="text-[10px] text-amber-400 capitalize">{item.category}</p>
                  <button
                    onClick={() => handleDeleteGallery(item.id)}
                    className="mt-2 p-1.5 bg-red-600/80 hover:bg-red-600 text-white rounded-lg transition self-end"
                    title="Delete photo permanently"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

'use client';

import React, { useState, useEffect } from 'react';
import { BarChart3, DollarSign, Calendar, TrendingUp, CreditCard, Banknote, QrCode, ArrowDownRight, Award, Loader2 } from 'lucide-react';

interface ReportsViewProps {
  currency: string;
}

export function ReportsView({ currency }: ReportsViewProps) {
  const [range, setRange] = useState<'today' | 'week' | 'month' | 'all'>('today');
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);

  const fetchReports = async (selectedRange: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/reports/summary?range=${selectedRange}`);
      const json = await res.json();
      if (res.ok) {
        setData(json.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports(range);
  }, [range]);

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-7xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800/80">
        <div>
          <h1 className="font-semibold text-xl text-zinc-100">Financial Reports & Reconciliation</h1>
          <p className="text-xs text-zinc-400 mt-1">Audit daily register collections, payment modes, and sales volumes.</p>
        </div>

        {/* Range Selector */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-zinc-900 border border-zinc-800">
          {[
            { id: 'today', label: 'Today' },
            { id: 'week', label: 'Past 7 Days' },
            { id: 'month', label: 'This Month' },
            { id: 'all', label: 'All Time' },
          ].map((r) => (
            <button
              key={r.id}
              onClick={() => setRange(r.id as any)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
                range === r.id ? 'bg-amber-400 text-black shadow-md shadow-amber-400/20' : 'text-zinc-400 hover:text-white'
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="p-16 flex flex-col items-center justify-center gap-2 text-zinc-500 text-xs">
          <Loader2 className="w-8 h-8 animate-spin text-amber-400" />
          <span>Aggregating ledger data...</span>
        </div>
      ) : data ? (
        <div className="space-y-6">
          {/* Top Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-[#12151a] border border-zinc-800 space-y-2">
              <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">Gross Sales</span>
              <p className="text-2xl font-bold text-zinc-100">
                {currency}
                {data.grossSales.toFixed(2)}
              </p>
              <p className="text-[11px] text-zinc-500">Before discounts & taxes</p>
            </div>

            <div className="p-5 rounded-2xl bg-[#12151a] border border-zinc-800 space-y-2">
              <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">Net Collections</span>
              <p className="text-2xl font-bold text-emerald-400">
                {currency}
                {data.totalCollected.toFixed(2)}
              </p>
              <p className="text-[11px] text-zinc-500">Actual money in till & accounts</p>
            </div>

            <div className="p-5 rounded-2xl bg-[#12151a] border border-zinc-800 space-y-2">
              <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">Discounts Given</span>
              <p className="text-2xl font-bold text-amber-400">
                {currency}
                {data.totalDiscounts.toFixed(2)}
              </p>
              <p className="text-[11px] text-zinc-500">Promotions & chef comps</p>
            </div>

            <div className="p-5 rounded-2xl bg-[#12151a] border border-zinc-800 space-y-2">
              <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">Taxes Collected</span>
              <p className="text-2xl font-bold text-blue-400">
                {currency}
                {data.totalTaxes.toFixed(2)}
              </p>
              <p className="text-[11px] text-zinc-500">Local & municipal tax liability</p>
            </div>
          </div>

          {/* Payment Method Reconciliation */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-[#12151a] border border-zinc-800 space-y-4">
              <h3 className="font-semibold text-sm text-zinc-100 flex items-center gap-2">
                <Banknote className="w-4 h-4 text-emerald-400" />
                <span>Cash Register</span>
              </h3>
              <div>
                <p className="text-2xl font-bold text-zinc-100">
                  {currency}
                  {(data.paymentModes?.CASH || 0).toFixed(2)}
                </p>
                <p className="text-xs text-zinc-400 mt-1">Physical cash drawer verification</p>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-[#12151a] border border-zinc-800 space-y-4">
              <h3 className="font-semibold text-sm text-zinc-100 flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-blue-400" />
                <span>Card Terminal (EDC)</span>
              </h3>
              <div>
                <p className="text-2xl font-bold text-zinc-100">
                  {currency}
                  {(data.paymentModes?.CARD || 0).toFixed(2)}
                </p>
                <p className="text-xs text-zinc-400 mt-1">Debit & credit card settlement</p>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-[#12151a] border border-zinc-800 space-y-4">
              <h3 className="font-semibold text-sm text-zinc-100 flex items-center gap-2">
                <QrCode className="w-4 h-4 text-amber-400" />
                <span>UPI & Digital Pay</span>
              </h3>
              <div>
                <p className="text-2xl font-bold text-zinc-100">
                  {currency}
                  {(data.paymentModes?.UPI || 0).toFixed(2)}
                </p>
                <p className="text-xs text-zinc-400 mt-1">Instant QR transfer settlement</p>
              </div>
            </div>
          </div>

          {/* Top-Selling Dishes */}
          <div className="p-6 rounded-2xl bg-[#12151a] border border-zinc-800 space-y-4">
            <h3 className="font-semibold text-sm text-zinc-100 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Top-Selling Culinary Dishes</span>
            </h3>

            {data.topSellingDishes?.length === 0 ? (
              <p className="text-xs text-zinc-500 py-4">No dish sales recorded in this period.</p>
            ) : (
              <div className="divide-y divide-zinc-800/60 text-xs">
                {data.topSellingDishes.map((dish: any, idx: number) => (
                  <div key={idx} className="py-3 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-full bg-zinc-800 text-amber-400 font-bold flex items-center justify-center text-xs">
                        #{idx + 1}
                      </span>
                      <div>
                        <p className="font-semibold text-zinc-200">{dish.name}</p>
                        <p className="text-[11px] text-zinc-500">{dish.quantity} orders fulfilled</p>
                      </div>
                    </div>
                    <span className="font-mono font-bold text-amber-400">
                      {currency}
                      {dish.revenue.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}

import React from 'react';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { ContentManager } from './ContentManager';

export const dynamic = 'force-dynamic';

export default async function AdminContentPage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect('/admin/login');
  }

  const [homepage, about, contact, offers, gallery] = await Promise.all([
    prisma.homepageContent.findFirst(),
    prisma.aboutContent.findFirst(),
    prisma.contactContent.findFirst(),
    prisma.offer.findMany({ orderBy: { createdAt: 'desc' } }),
    prisma.galleryItem.findMany({ orderBy: { displayOrder: 'asc' } }),
  ]);

  return (
    <ContentManager
      initialHomepage={homepage}
      initialAbout={about}
      initialContact={contact}
      initialOffers={offers}
      initialGallery={gallery}
    />
  );
}

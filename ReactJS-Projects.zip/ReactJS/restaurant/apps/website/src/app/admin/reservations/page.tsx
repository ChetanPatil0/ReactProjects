import React from 'react';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { ReservationsManager } from './ReservationsManager';

export const dynamic = 'force-dynamic';

export const metadata = {
  title: 'Table Bookings & Reservations | Admin Portal',
};

export default async function AdminReservationsPage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect('/admin/login');
  }

  return <ReservationsManager />;
}

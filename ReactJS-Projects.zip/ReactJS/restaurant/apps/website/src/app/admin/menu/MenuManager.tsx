'use client';

import React, { useState } from 'react';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  UtensilsCrossed,
  Layers,
  X,
  Loader2,
  Check,
  Star,
  AlertCircle,
  Hash,
  IndianRupee,
} from 'lucide-react';
import { ImageUploader } from '@/components/admin/ImageUploader';
import { useToast } from '@/context/ToastContext';

interface MenuCategory {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  imageUrl?: string | null;
  displayOrder: number;
  isActive: boolean;
  _count?: { items: number };
}

interface MenuItem {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  price: number;
  categoryId: string;
  category?: { id: string; name: string };
  isVeg: boolean;
  isAvailable: boolean;
  isSignature: boolean;
  imageUrl?: string | null;
  spicyLevel: number;
  displayOrder: number;
}

interface MenuManagerProps {
  initialCategories: MenuCategory[];
  initialItems: MenuItem[];
  currency: string;
}

export function MenuManager({ initialCategories, initialItems, currency = '₹' }: MenuManagerProps) {
  const toast = useToast();
  const [activeTab, setActiveTab] = useState<'items' | 'categories'>('items');
  const [categories, setCategories] = useState<MenuCategory[]>(initialCategories);
  const [items, setItems] = useState<MenuItem[]>(initialItems);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Item Modal State
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [itemForm, setItemForm] = useState({
    name: '',
    slug: '',
    description: '',
    price: 350,
    categoryId: initialCategories[0]?.id || '',
    isVeg: true,
    isAvailable: true,
    isSignature: false,
    imageUrl: null as string | null,
    spicyLevel: 0,
    displayOrder: 0,
  });
  const [itemTouched, setItemTouched] = useState<Record<string, boolean>>({});
  const [itemErrors, setItemErrors] = useState<Record<string, string>>({});
  const [itemSubmitting, setItemSubmitting] = useState(false);

  // Category Modal State
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<MenuCategory | null>(null);
  const [categoryForm, setCategoryForm] = useState({
    name: '',
    slug: '',
    description: '',
    imageUrl: null as string | null,
    displayOrder: 0,
    isActive: true,
  });
  const [categoryTouched, setCategoryTouched] = useState<Record<string, boolean>>({});
  const [categoryErrors, setCategoryErrors] = useState<Record<string, string>>({});
  const [categorySubmitting, setCategorySubmitting] = useState(false);

  // ==================== VALIDATION LOGIC ====================
  const validateItemField = (field: string, value: any): string => {
    switch (field) {
      case 'name':
        if (!value || !value.trim()) return 'Dish name is required.';
        if (value.trim().length < 2) return 'Dish name must be at least 2 characters.';
        if (value.trim().length > 80) return 'Dish name cannot exceed 80 characters.';
        return '';
      case 'categoryId':
        if (!value) return 'Please select a menu category.';
        return '';
      case 'price':
        const num = Number(value);
        if (value === '' || isNaN(num)) return 'Price must be a valid number.';
        if (num <= 0) return 'Price must be greater than 0.';
        if (num > 100000) return `Price cannot exceed ${currency}1,00,000.`;
        return '';
      case 'description':
        if (value && value.length > 300) return 'Description cannot exceed 300 characters.';
        return '';
      default:
        return '';
    }
  };

  const validateAllItemFields = (formData: typeof itemForm) => {
    const errors: Record<string, string> = {
      name: validateItemField('name', formData.name),
      categoryId: validateItemField('categoryId', formData.categoryId),
      price: validateItemField('price', formData.price),
      description: validateItemField('description', formData.description),
    };
    // remove empty
    Object.keys(errors).forEach((k) => !errors[k] && delete errors[k]);
    return errors;
  };

  const handleItemFieldChange = (field: string, value: any) => {
    const updated = { ...itemForm, [field]: value };
    setItemForm(updated);

    // Live validation on change
    const err = validateItemField(field, value);
    setItemErrors((prev) => ({ ...prev, [field]: err }));
  };

  const handleItemFieldBlur = (field: string) => {
    setItemTouched((prev) => ({ ...prev, [field]: true }));
    const err = validateItemField(field, (itemForm as any)[field]);
    setItemErrors((prev) => ({ ...prev, [field]: err }));
  };

  // Category Validation
  const validateCategoryField = (field: string, value: any): string => {
    switch (field) {
      case 'name':
        if (!value || !value.trim()) return 'Category name is required.';
        if (value.trim().length < 2) return 'Category name must be at least 2 characters.';
        if (value.trim().length > 50) return 'Category name cannot exceed 50 characters.';
        return '';
      case 'description':
        if (value && value.length > 250) return 'Description cannot exceed 250 characters.';
        return '';
      default:
        return '';
    }
  };

  const validateAllCategoryFields = (formData: typeof categoryForm) => {
    const errors: Record<string, string> = {
      name: validateCategoryField('name', formData.name),
      description: validateCategoryField('description', formData.description),
    };
    Object.keys(errors).forEach((k) => !errors[k] && delete errors[k]);
    return errors;
  };

  const handleCategoryFieldChange = (field: string, value: any) => {
    const updated = { ...categoryForm, [field]: value };
    setCategoryForm(updated);
    const err = validateCategoryField(field, value);
    setCategoryErrors((prev) => ({ ...prev, [field]: err }));
  };

  const handleCategoryFieldBlur = (field: string) => {
    setCategoryTouched((prev) => ({ ...prev, [field]: true }));
    const err = validateCategoryField(field, (categoryForm as any)[field]);
    setCategoryErrors((prev) => ({ ...prev, [field]: err }));
  };

  // Filter Items
  const filteredItems = items.filter((i) => {
    const matchesCategory = selectedCategory === 'all' || i.categoryId === selectedCategory;
    const query = search.toLowerCase();
    const matchesSearch =
      i.name.toLowerCase().includes(query) ||
      (i.description && i.description.toLowerCase().includes(query));
    return matchesCategory && matchesSearch;
  });

  // Open Item Modal
  const openAddItemModal = () => {
    setEditingItem(null);
    setItemForm({
      name: '',
      slug: '',
      description: '',
      price: 495,
      categoryId: categories[0]?.id || '',
      isVeg: true,
      isAvailable: true,
      isSignature: false,
      imageUrl: null,
      spicyLevel: 0,
      displayOrder: items.length + 1,
    });
    setItemTouched({});
    setItemErrors({});
    setIsItemModalOpen(true);
  };

  const openEditItemModal = (item: MenuItem) => {
    setEditingItem(item);
    setItemForm({
      name: item.name,
      slug: item.slug,
      description: item.description || '',
      price: item.price,
      categoryId: item.categoryId,
      isVeg: item.isVeg,
      isAvailable: item.isAvailable,
      isSignature: item.isSignature,
      imageUrl: item.imageUrl || null,
      spicyLevel: item.spicyLevel,
      displayOrder: item.displayOrder,
    });
    setItemTouched({});
    setItemErrors({});
    setIsItemModalOpen(true);
  };

  // Submit Item
  const handleItemSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Mark all fields touched and validate
    setItemTouched({
      name: true,
      categoryId: true,
      price: true,
      description: true,
    });
    const errors = validateAllItemFields(itemForm);
    setItemErrors(errors);

    if (Object.keys(errors).length > 0) {
      toast.error('Please resolve the highlighted field errors below.', 'Validation Error');
      return;
    }

    setItemSubmitting(true);

    try {
      const url = '/api/admin/menu/items';
      const method = editingItem ? 'PUT' : 'POST';
      const body = editingItem ? { id: editingItem.id, ...itemForm } : itemForm;

      if (!body.slug) {
        body.slug = body.name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-');
      }

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save menu item');

      if (editingItem) {
        setItems((prev) => prev.map((i) => (i.id === editingItem.id ? data.data : i)));
        toast.success(`"${itemForm.name}" updated successfully.`, 'Dish Updated');
      } else {
        setItems((prev) => [...prev, data.data]);
        toast.success(`"${itemForm.name}" added to menu catalog.`, 'Dish Created');
      }

      setIsItemModalOpen(false);
    } catch (err: any) {
      toast.error(err.message, 'Operation Failed');
    } finally {
      setItemSubmitting(false);
    }
  };

  // Delete Item
  const handleDeleteItem = async (item: MenuItem) => {
    if (!confirm(`Are you sure you want to delete "${item.name}"? This permanently unlinks its record.`)) return;

    try {
      const res = await fetch(`/api/admin/menu/items?id=${item.id}`, { method: 'DELETE' });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to delete dish');
      }
      setItems((prev) => prev.filter((i) => i.id !== item.id));
      toast.success(`"${item.name}" was permanently removed.`, 'Dish Deleted');
    } catch (err: any) {
      toast.error(err.message, 'Delete Failed');
    }
  };

  // Open Category Modal
  const openAddCategoryModal = () => {
    setEditingCategory(null);
    setCategoryForm({
      name: '',
      slug: '',
      description: '',
      imageUrl: null,
      displayOrder: categories.length + 1,
      isActive: true,
    });
    setCategoryTouched({});
    setCategoryErrors({});
    setIsCategoryModalOpen(true);
  };

  const openEditCategoryModal = (cat: MenuCategory) => {
    setEditingCategory(cat);
    setCategoryForm({
      name: cat.name,
      slug: cat.slug,
      description: cat.description || '',
      imageUrl: cat.imageUrl || null,
      displayOrder: cat.displayOrder,
      isActive: cat.isActive,
    });
    setCategoryTouched({});
    setCategoryErrors({});
    setIsCategoryModalOpen(true);
  };

  // Submit Category
  const handleCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setCategoryTouched({ name: true, description: true });
    const errors = validateAllCategoryFields(categoryForm);
    setCategoryErrors(errors);

    if (Object.keys(errors).length > 0) {
      toast.error('Please resolve the category field errors.', 'Validation Error');
      return;
    }

    setCategorySubmitting(true);

    try {
      const url = '/api/admin/menu/categories';
      const method = editingCategory ? 'PUT' : 'POST';
      const body = editingCategory ? { id: editingCategory.id, ...categoryForm } : categoryForm;

      if (!body.slug) {
        body.slug = body.name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-');
      }

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save category');

      if (editingCategory) {
        setCategories((prev) => prev.map((c) => (c.id === editingCategory.id ? data.data : c)));
        toast.success(`Category "${categoryForm.name}" updated.`, 'Category Saved');
      } else {
        setCategories((prev) => [...prev, data.data]);
        toast.success(`Category "${categoryForm.name}" created.`, 'Category Created');
      }

      setIsCategoryModalOpen(false);
    } catch (err: any) {
      toast.error(err.message, 'Operation Failed');
    } finally {
      setCategorySubmitting(false);
    }
  };

  // Delete Category
  const handleDeleteCategory = async (cat: MenuCategory) => {
    if (!confirm(`Are you sure you want to delete category "${cat.name}"? All associated items will be deleted.`)) return;

    try {
      const res = await fetch(`/api/admin/menu/categories?id=${cat.id}`, { method: 'DELETE' });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to delete category');
      }
      setCategories((prev) => prev.filter((c) => c.id !== cat.id));
      setItems((prev) => prev.filter((i) => i.categoryId !== cat.id));
      toast.success(`Category "${cat.name}" deleted.`, 'Category Deleted');
    } catch (err: any) {
      toast.error(err.message, 'Delete Failed');
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-7xl">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800/80">
        <div>
          <h1 className="font-semibold text-xl text-zinc-100 flex items-center gap-2">
            <span>Menu & Culinary Catalog</span>
            <span className="text-[10px] uppercase font-bold tracking-widest px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
              Live Indian Fine-Dining
            </span>
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            Manage royal recipes, pricing in {currency}, dietary tags, and live order catalog.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {activeTab === 'items' ? (
            <button
              onClick={openAddItemModal}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold text-xs tracking-wide uppercase transition shadow-md shadow-amber-400/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Dish</span>
            </button>
          ) : (
            <button
              onClick={openAddCategoryModal}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold text-xs tracking-wide uppercase transition shadow-md shadow-amber-400/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Category</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Tabs */}
      <div className="flex items-center gap-2 border-b border-zinc-800">
        <button
          onClick={() => setActiveTab('items')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition -mb-px cursor-pointer ${
            activeTab === 'items'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-zinc-400 hover:text-white'
          }`}
        >
          <UtensilsCrossed className="w-4 h-4" />
          <span>Dishes & Items ({items.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('categories')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition -mb-px cursor-pointer ${
            activeTab === 'categories'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-zinc-400 hover:text-white'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Categories ({categories.length})</span>
        </button>
      </div>

      {/* TAB 1: ITEMS */}
      {activeTab === 'items' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search dishes by name or description..."
                className="w-full pl-10 pr-4 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500/60 transition"
              />
            </div>

            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-zinc-900 border border-zinc-800 overflow-x-auto">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                  selectedCategory === 'all'
                    ? 'bg-amber-400 text-black font-bold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                All ({items.length})
              </button>
              {categories.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setSelectedCategory(c.id)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                    selectedCategory === c.id
                      ? 'bg-amber-400 text-black font-bold'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          {/* Dishes Table */}
          <div className="bg-[#10131a] border border-zinc-800/80 rounded-2xl overflow-hidden shadow-sm">
            {filteredItems.length === 0 ? (
              <div className="p-12 text-center text-zinc-500 text-xs">
                No menu items found. Click "Add New Dish" to create one.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-zinc-800 text-zinc-400 font-semibold uppercase tracking-wider text-[10px] bg-zinc-900/40">
                      <th className="py-3 px-4">Dish</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4">Price</th>
                      <th className="py-3 px-4">Dietary</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50">
                    {filteredItems.map((item) => (
                      <tr key={item.id} className="hover:bg-zinc-800/30 transition">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg overflow-hidden bg-zinc-800 shrink-0 border border-zinc-700/60">
                              {item.imageUrl ? (
                                <img
                                  src={item.imageUrl}
                                  alt={item.name}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center text-zinc-600">
                                  <UtensilsCrossed className="w-4 h-4" />
                                </div>
                              )}
                            </div>
                            <div className="min-w-0">
                              <p className="font-semibold text-zinc-100 flex items-center gap-1.5">
                                <span>{item.name}</span>
                                {item.isSignature && (
                                  <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                                )}
                              </p>
                              <p className="text-[11px] text-zinc-500 truncate max-w-xs">
                                {item.description || 'No description'}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-zinc-300">
                          {categories.find((c) => c.id === item.categoryId)?.name || '-'}
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-amber-400">
                          {currency}
                          {item.price.toFixed(2)}
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              item.isVeg
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : 'bg-red-500/10 text-red-400 border border-red-500/20'
                            }`}
                          >
                            {item.isVeg ? 'VEG' : 'NON-VEG'}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              item.isAvailable
                                ? 'bg-zinc-800 text-zinc-300'
                                : 'bg-zinc-800 text-zinc-500 line-through'
                            }`}
                          >
                            {item.isAvailable ? 'Available' : 'Sold Out'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right space-x-2">
                          <button
                            onClick={() => openEditItemModal(item)}
                            className="p-1.5 text-zinc-400 hover:text-amber-400 hover:bg-zinc-800 rounded-lg transition cursor-pointer"
                            title="Edit Dish"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteItem(item)}
                            className="p-1.5 text-zinc-400 hover:text-red-400 hover:bg-zinc-800 rounded-lg transition cursor-pointer"
                            title="Delete Dish"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: CATEGORIES */}
      {activeTab === 'categories' && (
        <div className="bg-[#10131a] border border-zinc-800/80 rounded-2xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-400 font-semibold uppercase tracking-wider text-[10px] bg-zinc-900/40">
                  <th className="py-3 px-4">Category Name</th>
                  <th className="py-3 px-4">Slug</th>
                  <th className="py-3 px-4">Display Order</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {categories.map((cat) => (
                  <tr key={cat.id} className="hover:bg-zinc-800/30 transition">
                    <td className="py-3.5 px-4 font-semibold text-zinc-100">{cat.name}</td>
                    <td className="py-3.5 px-4 font-mono text-zinc-400">{cat.slug}</td>
                    <td className="py-3.5 px-4 text-zinc-400">{cat.displayOrder}</td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          cat.isActive
                            ? 'bg-emerald-500/10 text-emerald-400'
                            : 'bg-zinc-800 text-zinc-500'
                        }`}
                      >
                        {cat.isActive ? 'Active' : 'Hidden'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => openEditCategoryModal(cat)}
                        className="p-1.5 text-zinc-400 hover:text-amber-400 hover:bg-zinc-800 rounded-lg transition cursor-pointer"
                        title="Edit Category"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteCategory(cat)}
                        className="p-1.5 text-zinc-400 hover:text-red-400 hover:bg-zinc-800 rounded-lg transition cursor-pointer"
                        title="Delete Category"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* DISH CREATE / EDIT MODAL WITH LIVE VALIDATION */}
      {isItemModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#12151d]/90 backdrop-blur-2xl border border-zinc-700/60 rounded-2xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto space-y-4 shadow-2xl shadow-black/50">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="font-semibold text-sm text-zinc-100">
                {editingItem ? 'Edit Culinary Dish' : 'Add New Culinary Dish'}
              </h3>
              <button
                onClick={() => setIsItemModalOpen(false)}
                className="text-zinc-500 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleItemSubmit} noValidate className="space-y-4 text-xs">
              {/* Dish Name */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-medium text-zinc-300">
                    Dish Name <span className="text-rose-500 font-bold ml-0.5">*</span>
                  </label>
                  <span className="text-[10px] text-zinc-500">
                    {itemForm.name.length} / 80 chars (min 2)
                  </span>
                </div>
                <input
                  type="text"
                  value={itemForm.name}
                  onChange={(e) => handleItemFieldChange('name', e.target.value)}
                  onBlur={() => handleItemFieldBlur('name')}
                  placeholder="e.g. Shahi Galouti Kebab"
                  maxLength={80}
                  className={`w-full px-3 py-2 rounded-xl bg-zinc-900 border text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition ${
                    itemTouched.name && itemErrors.name
                      ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                      : 'border-zinc-800 focus:border-amber-500/60'
                  }`}
                />
                {itemTouched.name && itemErrors.name && (
                  <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{itemErrors.name}</span>
                  </p>
                )}
              </div>

              {/* Category & Price */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-zinc-300 mb-1">
                    Category <span className="text-rose-500 font-bold ml-0.5">*</span>
                  </label>
                  <select
                    value={itemForm.categoryId}
                    onChange={(e) => handleItemFieldChange('categoryId', e.target.value)}
                    onBlur={() => handleItemFieldBlur('categoryId')}
                    className={`w-full px-3 py-2 rounded-xl bg-zinc-900 border text-zinc-100 focus:outline-none transition ${
                      itemTouched.categoryId && itemErrors.categoryId
                        ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                        : 'border-zinc-800 focus:border-amber-500/60'
                    }`}
                  >
                    <option value="">Select category...</option>
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                  {itemTouched.categoryId && itemErrors.categoryId && (
                    <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{itemErrors.categoryId}</span>
                    </p>
                  )}
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-medium text-zinc-300">
                      Price ({currency}) <span className="text-rose-500 font-bold ml-0.5">*</span>
                    </label>
                    <span className="text-[10px] text-zinc-500">Min 1 • Max 1,00,000</span>
                  </div>
                  <input
                    type="number"
                    min="1"
                    max="100000"
                    step="any"
                    value={itemForm.price || ''}
                    onChange={(e) => handleItemFieldChange('price', parseFloat(e.target.value) || 0)}
                    onBlur={() => handleItemFieldBlur('price')}
                    placeholder="e.g. 595"
                    className={`w-full px-3 py-2 rounded-xl bg-zinc-900 border text-zinc-100 font-mono focus:outline-none transition ${
                      itemTouched.price && itemErrors.price
                        ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                        : 'border-zinc-800 focus:border-amber-500/60'
                    }`}
                  />
                  {itemTouched.price && itemErrors.price && (
                    <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{itemErrors.price}</span>
                    </p>
                  )}
                </div>
              </div>

              {/* Description */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-medium text-zinc-300">Description</label>
                  <span className="text-[10px] text-zinc-500">
                    {itemForm.description.length} / 300 chars
                  </span>
                </div>
                <textarea
                  rows={2}
                  maxLength={300}
                  value={itemForm.description}
                  onChange={(e) => handleItemFieldChange('description', e.target.value)}
                  onBlur={() => handleItemFieldBlur('description')}
                  placeholder="Ingredients, preparation method, terroir notes..."
                  className={`w-full p-2.5 rounded-xl bg-zinc-900 border text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition ${
                    itemTouched.description && itemErrors.description
                      ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                      : 'border-zinc-800 focus:border-amber-500/60'
                  }`}
                />
                {itemTouched.description && itemErrors.description && (
                  <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{itemErrors.description}</span>
                  </p>
                )}
              </div>

              {/* Image Upload */}
              <ImageUploader
                value={itemForm.imageUrl}
                onChange={(url) => setItemForm({ ...itemForm, imageUrl: url })}
                label="Food Photography"
                helperText="Upload dish photography. High-res JPG, PNG or WEBP."
              />

              {/* Toggles */}
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-zinc-800">
                <label className="flex items-center gap-2 cursor-pointer p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300">
                  <input
                    type="checkbox"
                    checked={itemForm.isVeg}
                    onChange={(e) => setItemForm({ ...itemForm, isVeg: e.target.checked })}
                    className="rounded bg-zinc-800 text-amber-500"
                  />
                  <span>Vegetarian</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300">
                  <input
                    type="checkbox"
                    checked={itemForm.isAvailable}
                    onChange={(e) => setItemForm({ ...itemForm, isAvailable: e.target.checked })}
                    className="rounded bg-zinc-800 text-amber-500"
                  />
                  <span>Available</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300">
                  <input
                    type="checkbox"
                    checked={itemForm.isSignature}
                    onChange={(e) => setItemForm({ ...itemForm, isSignature: e.target.checked })}
                    className="rounded bg-zinc-800 text-amber-500"
                  />
                  <span>Chef Signature</span>
                </label>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsItemModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-medium transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={itemSubmitting}
                  className="flex-1 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold transition disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-amber-400/20"
                >
                  {itemSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save Dish'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CATEGORY CREATE / EDIT MODAL WITH LIVE VALIDATION */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#12151d]/90 backdrop-blur-2xl border border-zinc-700/60 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl shadow-black/50">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="font-semibold text-sm text-zinc-100">
                {editingCategory ? 'Edit Menu Category' : 'Add Menu Category'}
              </h3>
              <button
                onClick={() => setIsCategoryModalOpen(false)}
                className="text-zinc-500 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCategorySubmit} noValidate className="space-y-4 text-xs">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-medium text-zinc-300">
                    Category Name <span className="text-rose-500 font-bold ml-0.5">*</span>
                  </label>
                  <span className="text-[10px] text-zinc-500">
                    {categoryForm.name.length} / 50 chars (min 2)
                  </span>
                </div>
                <input
                  type="text"
                  maxLength={50}
                  value={categoryForm.name}
                  onChange={(e) => handleCategoryFieldChange('name', e.target.value)}
                  onBlur={() => handleCategoryFieldBlur('name')}
                  placeholder="e.g. Shahi Handi & Awadhi Curries"
                  className={`w-full px-3 py-2 rounded-xl bg-zinc-900 border text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition ${
                    categoryTouched.name && categoryErrors.name
                      ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                      : 'border-zinc-800 focus:border-amber-500/60'
                  }`}
                />
                {categoryTouched.name && categoryErrors.name && (
                  <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{categoryErrors.name}</span>
                  </p>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-medium text-zinc-300">Description</label>
                  <span className="text-[10px] text-zinc-500">
                    {categoryForm.description.length} / 250 chars
                  </span>
                </div>
                <textarea
                  rows={2}
                  maxLength={250}
                  value={categoryForm.description}
                  onChange={(e) => handleCategoryFieldChange('description', e.target.value)}
                  onBlur={() => handleCategoryFieldBlur('description')}
                  placeholder="Category highlights and culinary notes..."
                  className={`w-full p-2.5 rounded-xl bg-zinc-900 border text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition ${
                    categoryTouched.description && categoryErrors.description
                      ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                      : 'border-zinc-800 focus:border-amber-500/60'
                  }`}
                />
                {categoryTouched.description && categoryErrors.description && (
                  <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{categoryErrors.description}</span>
                  </p>
                )}
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsCategoryModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-medium transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={categorySubmitting}
                  className="flex-1 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold transition disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-amber-400/20"
                >
                  {categorySubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save Category'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

import React from 'react';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { MenuManager } from './MenuManager';

export const dynamic = 'force-dynamic';

export default async function AdminMenuPage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect('/admin/login');
  }

  const [categories, items, settings] = await Promise.all([
    prisma.menuCategory.findMany({
      orderBy: { displayOrder: 'asc' },
      include: {
        _count: {
          select: { items: true },
        },
      },
    }),
    prisma.menuItem.findMany({
      orderBy: [{ displayOrder: 'asc' }, { name: 'asc' }],
      include: {
        category: { select: { id: true, name: true } },
      },
    }),
    prisma.restaurantSetting.findFirst(),
  ]);

  return (
    <MenuManager
      initialCategories={categories}
      initialItems={items}
      currency={settings?.currency || '$'}
    />
  );
}

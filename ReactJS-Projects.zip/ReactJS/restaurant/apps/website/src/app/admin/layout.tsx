import React from 'react';
import { getCurrentUser } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { ToastProvider } from '@/context/ToastContext';
import { AdminResponsiveLayout } from '@/components/admin/AdminResponsiveLayout';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const [user, settings] = await Promise.all([
    getCurrentUser(),
    prisma.restaurantSetting.findFirst(),
  ]);

  if (!user) {
    return (
      <ToastProvider>
        <div className="min-h-screen bg-[#080a0f] text-zinc-100 flex items-center justify-center font-sans p-4">
          {children}
        </div>
      </ToastProvider>
    );
  }

  return (
    <ToastProvider>
      <AdminResponsiveLayout user={user} settings={settings}>
        {children}
      </AdminResponsiveLayout>
    </ToastProvider>
  );
}

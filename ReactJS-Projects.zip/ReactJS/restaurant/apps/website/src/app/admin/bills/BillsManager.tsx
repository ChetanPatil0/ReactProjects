'use client';

import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Receipt,
  Printer,
  X,
  CreditCard,
  Banknote,
  AlertTriangle,
  Loader2,
  CheckCircle,
  Download,
  Calendar,
  FileSpreadsheet,
  Coins,
  ShieldCheck,
  AlertCircle,
} from 'lucide-react';
import { renderReceiptHtml, ReceiptData } from '@/lib/receiptTemplate';
import { useToast } from '@/context/ToastContext';

interface Bill {
  id: string;
  billNumber: string;
  orderType: string;
  tableNumber?: string | null;
  subtotal: number;
  discountAmount: number;
  taxAmount: number;
  totalAmount: number;
  paidAmount: number;
  balanceAmount: number;
  paymentMethod: string;
  status: string;
  cancelReason?: string | null;
  createdAt: string;
  customer?: { name?: string | null; phone: string } | null;
  items: Array<{ itemName: string; unitPrice: number; quantity: number; totalPrice: number }>;
  payments: Array<{ amount: number; paymentMethod: string; note?: string | null; createdAt: string }>;
  createdBy?: { firstName: string; lastName: string } | null;
}

interface BillsManagerProps {
  initialBills: Bill[];
  currency: string;
  restaurantName: string;
  restaurantSettings?: any;
}

export function BillsManager({ initialBills, currency = '₹', restaurantName, restaurantSettings }: BillsManagerProps) {
  const toast = useToast();
  const [bills, setBills] = useState<Bill[]>(initialBills);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);
  const [receiptFormat, setReceiptFormat] = useState<'custom' | 'thermal' | 'a4'>('custom');

  // Pay Modal State
  const [payModalBill, setPayModalBill] = useState<Bill | null>(null);
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payMethod, setPayMethod] = useState<'CASH' | 'CARD' | 'UPI'>('CASH');
  const [payNote, setPayNote] = useState('');
  const [payLoading, setPayLoading] = useState(false);

  // Cancel Modal State
  const [cancelModalBill, setCancelModalBill] = useState<Bill | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelLoading, setCancelLoading] = useState(false);

  // Financial summary counters
  const totalBilled = bills
    .filter((b) => b.status !== 'CANCELLED')
    .reduce((acc, b) => acc + b.totalAmount, 0);
  const totalCollected = bills
    .filter((b) => b.status !== 'CANCELLED')
    .reduce((acc, b) => acc + b.paidAmount, 0);
  const totalOutstanding = bills
    .filter((b) => b.status !== 'CANCELLED')
    .reduce((acc, b) => acc + b.balanceAmount, 0);
  const totalCancelledCount = bills.filter((b) => b.status === 'CANCELLED').length;

  const filteredBills = bills.filter((b) => {
    const matchesStatus = statusFilter === 'ALL' || b.status === statusFilter;
    const query = search.toLowerCase();
    const matchesSearch =
      b.billNumber.toLowerCase().includes(query) ||
      (b.tableNumber && b.tableNumber.toLowerCase().includes(query)) ||
      (b.customer?.name && b.customer.name.toLowerCase().includes(query)) ||
      (b.customer?.phone && b.customer.phone.includes(query));

    return matchesStatus && matchesSearch;
  });

  // Handle Record Payment
  const handleRecordPayment = async () => {
    if (!payModalBill || payAmount <= 0) {
      toast.warning('Please enter a payment amount greater than 0.', 'Invalid Amount');
      return;
    }
    setPayLoading(true);

    try {
      const res = await fetch(`/api/admin/pos/bills/${payModalBill.id}/payment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: payAmount,
          paymentMethod: payMethod,
          note: payNote,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to record payment');

      // Update local state
      setBills((prev) =>
        prev.map((b) => (b.id === payModalBill.id ? data.data.bill : b))
      );

      toast.success(
        `Payment of ${currency}${payAmount.toFixed(2)} recorded for ${payModalBill.billNumber} via ${payMethod}.`,
        'Payment Recorded'
      );

      setPayModalBill(null);
      setPayAmount(0);
      setPayNote('');
    } catch (err: any) {
      toast.error(err.message, 'Payment Failed');
    } finally {
      setPayLoading(false);
    }
  };

  // Handle Cancel Bill
  const handleCancelBill = async () => {
    if (!cancelModalBill || cancelReason.trim().length < 5) {
      toast.warning('Please enter a cancellation reason of at least 5 characters.', 'Reason Required');
      return;
    }
    setCancelLoading(true);

    try {
      const res = await fetch(`/api/admin/pos/bills/${cancelModalBill.id}/cancel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: cancelReason }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to cancel bill');

      // Update local state
      setBills((prev) =>
        prev.map((b) => (b.id === cancelModalBill.id ? { ...b, status: 'CANCELLED', cancelReason } : b))
      );

      toast.info(`Invoice ${cancelModalBill.billNumber} has been voided/cancelled.`, 'Bill Cancelled');

      setCancelModalBill(null);
      setCancelReason('');
    } catch (err: any) {
      toast.error(err.message, 'Cancellation Failed');
    } finally {
      setCancelLoading(false);
    }
  };

  // CSV Export for Billing & Accounting
  const exportToCSV = () => {
    const headers = ['Bill Number', 'Date', 'Order Type', 'Table', 'Customer', 'Phone', 'Total', 'Paid', 'Balance', 'Status', 'Payment Method'];
    const rows = filteredBills.map((b) => [
      b.billNumber,
      new Date(b.createdAt).toISOString(),
      b.orderType,
      b.tableNumber || '',
      b.customer?.name || '',
      b.customer?.phone || '',
      b.totalAmount.toFixed(2),
      b.paidAmount.toFixed(2),
      b.balanceAmount.toFixed(2),
      b.status,
      b.paymentMethod,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.map((x) => `"${x}"`).join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `restaurant_bills_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Render HTML receipt from dynamic template
  const renderedCustomReceiptHtml = useMemo(() => {
    if (!selectedBill) return '';

    const receiptPayload: ReceiptData = {
      restaurantName: restaurantSettings?.name || restaurantName,
      tagline: restaurantSettings?.tagline,
      logoUrl: restaurantSettings?.logoUrl,
      address: restaurantSettings?.address,
      phone: restaurantSettings?.phone,
      email: restaurantSettings?.email,
      openingHours: restaurantSettings?.openingHours,
      receiptHeader: restaurantSettings?.receiptHeader,
      receiptFooter: restaurantSettings?.receiptFooter,
      currency: currency,
      billNumber: selectedBill.billNumber,
      orderType: selectedBill.orderType,
      tableNumber: selectedBill.tableNumber,
      createdAt: selectedBill.createdAt,
      customerName: selectedBill.customer?.name,
      customerPhone: selectedBill.customer?.phone,
      cashierName: selectedBill.createdBy ? `${selectedBill.createdBy.firstName} ${selectedBill.createdBy.lastName}` : 'Register #01',
      items: selectedBill.items || [],
      subtotal: selectedBill.subtotal || 0,
      discountAmount: selectedBill.discountAmount || 0,
      taxRate: restaurantSettings?.taxRate ?? 5.0,
      taxAmount: selectedBill.taxAmount || 0,
      totalAmount: selectedBill.totalAmount || 0,
      paidAmount: selectedBill.paidAmount || 0,
      balanceAmount: selectedBill.balanceAmount || 0,
      paymentMethod: selectedBill.paymentMethod || 'CASH',
    };

    return renderReceiptHtml(restaurantSettings?.receiptTemplate, receiptPayload);
  }, [selectedBill, restaurantSettings, restaurantName, currency]);

  const handlePrint = () => {
    if (receiptFormat === 'custom') {
      const printWin = window.open('', '_blank', 'width=450,height=750');
      if (printWin) {
        printWin.document.write(renderedCustomReceiptHtml);
        printWin.document.close();
        printWin.focus();
        setTimeout(() => printWin.print(), 350);
      }
    } else {
      window.print();
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-7xl bg-[#0c0e14] min-h-screen">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800/80">
        <div>
          <h1 className="font-semibold text-xl text-zinc-100 flex items-center gap-2">
            <span>Billing Ledger & Invoices</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#d4af37]/15 text-[#e5c378] font-mono border border-[#d4af37]/30">
              {bills.length} Total Bills
            </span>
          </h1>
          <p className="text-xs text-zinc-400 mt-1">Audit transactions, reprint receipts, settle credit balances, and export data.</p>
        </div>

        <button
          onClick={exportToCSV}
          className="px-4 py-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-[#d4af37] text-zinc-200 text-xs font-semibold flex items-center gap-2 transition cursor-pointer"
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
          <span>Export CSV Ledger</span>
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[#12141d] border border-zinc-800 space-y-1">
          <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400">Total Billed Volume</span>
          <p className="text-xl font-bold text-white">
            {currency}{totalBilled.toFixed(2)}
          </p>
          <p className="text-[10px] text-zinc-500">Gross invoiced before cancellations</p>
        </div>

        <div className="p-4 rounded-2xl bg-[#12141d] border border-zinc-800 space-y-1">
          <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400">Total Collections</span>
          <p className="text-xl font-bold text-emerald-400">
            {currency}{totalCollected.toFixed(2)}
          </p>
          <p className="text-[10px] text-zinc-500">Net money settled in register & accounts</p>
        </div>

        <div className="p-4 rounded-2xl bg-[#12141d] border border-zinc-800 space-y-1">
          <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400">Outstanding Credit</span>
          <p className="text-xl font-bold text-[#e5c378]">
            {currency}{totalOutstanding.toFixed(2)}
          </p>
          <p className="text-[10px] text-zinc-500">Unsettled partial balances</p>
        </div>

        <div className="p-4 rounded-2xl bg-[#12141d] border border-zinc-800 space-y-1">
          <span className="text-[10px] uppercase font-bold tracking-wider text-red-400">Voided / Cancelled</span>
          <p className="text-xl font-bold text-red-400">{totalCancelledCount} Bills</p>
          <p className="text-[10px] text-zinc-500">Voided with audit justification</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by bill #, customer name, table, phone..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-100 placeholder:text-zinc-600 focus:outline-hidden focus:border-[#d4af37]"
          />
        </div>

        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-zinc-900 border border-zinc-800 overflow-x-auto">
          {['ALL', 'PAID', 'PARTIAL', 'CANCELLED'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition cursor-pointer ${
                statusFilter === st ? 'bg-[#d4af37] text-black font-bold' : 'text-zinc-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Bills Table */}
      <div className="bg-[#12141d] border border-zinc-800/80 rounded-2xl overflow-hidden shadow-xl">
        {filteredBills.length === 0 ? (
          <div className="p-16 text-center text-zinc-500 text-xs space-y-2">
            <Receipt className="w-8 h-8 stroke-1 text-zinc-600 mx-auto" />
            <p>No billing records found matching your filter criteria.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-400 font-semibold uppercase tracking-wider text-[10px] bg-zinc-900/60">
                  <th className="py-3 px-4">Bill #</th>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Table / Guest</th>
                  <th className="py-3 px-4">Total</th>
                  <th className="py-3 px-4">Paid</th>
                  <th className="py-3 px-4">Balance</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {filteredBills.map((b) => (
                  <tr key={b.id} className="hover:bg-zinc-800/40 transition">
                    <td className="py-3.5 px-4 font-mono font-semibold text-[#e5c378]">
                      {b.billNumber}
                    </td>
                    <td className="py-3.5 px-4 text-zinc-400">
                      {new Date(b.createdAt).toLocaleString([], {
                        dateStyle: 'short',
                        timeStyle: 'short',
                      })}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-zinc-800 text-zinc-300">
                        {b.orderType.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-zinc-300">
                      <div className="font-medium text-white">{b.tableNumber || 'Walk-in'}</div>
                      {b.customer?.name && (
                        <div className="text-[10px] text-zinc-400">{b.customer.name} ({b.customer.phone})</div>
                      )}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-zinc-100 font-mono">
                      {currency}
                      {b.totalAmount.toFixed(2)}
                    </td>
                    <td className="py-3.5 px-4 font-medium text-emerald-400 font-mono">
                      {currency}
                      {b.paidAmount.toFixed(2)}
                    </td>
                    <td className="py-3.5 px-4 font-mono">
                      {b.balanceAmount > 0 ? (
                        <span className="text-amber-400 font-bold">
                          {currency}
                          {b.balanceAmount.toFixed(2)}
                        </span>
                      ) : (
                        <span className="text-zinc-500">—</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          b.status === 'PAID'
                            ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                            : b.status === 'PARTIAL'
                            ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                            : 'bg-red-500/15 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {b.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => setSelectedBill(b)}
                        className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs transition cursor-pointer"
                        title="View / Print Invoice"
                      >
                        <Printer className="w-3.5 h-3.5 inline mr-1 text-[#d4af37]" />
                        <span>Receipt</span>
                      </button>

                      {b.status === 'PARTIAL' && (
                        <button
                          onClick={() => {
                            setPayModalBill(b);
                            setPayAmount(b.balanceAmount);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-xs font-semibold transition cursor-pointer"
                        >
                          Collect
                        </button>
                      )}

                      {b.status !== 'CANCELLED' && (
                        <button
                          onClick={() => setCancelModalBill(b)}
                          className="px-2.5 py-1 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs transition cursor-pointer"
                        >
                          Void
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* RECORD BALANCE PAYMENT MODAL */}
      {payModalBill && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#12141d]/90 backdrop-blur-2xl border border-zinc-700/60 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl shadow-black/50">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="font-semibold text-sm text-zinc-100 flex items-center gap-2">
                <span>Record Balance Settlement</span>
              </h3>
              <button
                onClick={() => setPayModalBill(null)}
                className="p-1 text-zinc-400 hover:text-white rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 space-y-1 text-xs">
              <div className="flex justify-between text-zinc-400">
                <span>Bill Number:</span>
                <span className="font-mono text-zinc-200">{payModalBill.billNumber}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Total Amount:</span>
                <span className="font-mono text-zinc-200">
                  {currency}{payModalBill.totalAmount.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Outstanding Balance:</span>
                <span className="font-mono text-amber-400 font-bold">
                  {currency}{payModalBill.balanceAmount.toFixed(2)}
                </span>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-300 mb-1 font-medium">Payment Amount ({currency})</label>
                <input
                  type="number"
                  min="0"
                  max={payModalBill.balanceAmount}
                  step="any"
                  value={payAmount}
                  onChange={(e) => setPayAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 font-mono text-sm focus:outline-hidden focus:border-[#d4af37]"
                />
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-medium">Payment Mode</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['CASH', 'CARD', 'UPI'] as const).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setPayMethod(m)}
                      className={`py-2 rounded-xl border text-xs font-semibold transition cursor-pointer ${
                        payMethod === m
                          ? 'bg-[#d4af37] text-black font-bold border-[#d4af37]'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-zinc-300 mb-1 font-medium">Audit Note (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. Cleared by manager at register"
                  value={payNote}
                  onChange={(e) => setPayNote(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-hidden focus:border-[#d4af37]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-zinc-800">
              <button
                onClick={() => setPayModalBill(null)}
                className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleRecordPayment}
                disabled={payLoading || payAmount <= 0}
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 disabled:opacity-50"
              >
                {payLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
                <span>Record Settlement</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CANCEL BILL MODAL */}
      {cancelModalBill && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#12141d]/90 backdrop-blur-2xl border border-red-500/30 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl shadow-black/50">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="font-semibold text-sm text-red-400 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                <span>Void & Cancel Bill</span>
              </h3>
              <button
                onClick={() => setCancelModalBill(null)}
                className="p-1 text-zinc-400 hover:text-white rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <p className="text-zinc-300">
                Are you sure you want to void bill <strong className="text-white font-mono">{cancelModalBill.billNumber}</strong> ({currency}{cancelModalBill.totalAmount.toFixed(2)})?
              </p>
              <p className="text-zinc-500 text-[11px]">
                This action is irreversible and recorded in the audit ledger for manager review.
              </p>
            </div>

            <div className="space-y-1 text-xs">
              <label className="block text-zinc-300 font-medium">Mandatory Justification Reason</label>
              <textarea
                rows={3}
                placeholder="e.g. Customer changed order / test bill entry"
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:outline-hidden focus:border-red-400"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-zinc-800">
              <button
                onClick={() => setCancelModalBill(null)}
                className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
              >
                Dismiss
              </button>
              <button
                onClick={handleCancelBill}
                disabled={cancelLoading || cancelReason.trim().length < 5}
                className="px-5 py-2 rounded-xl bg-red-500 hover:bg-red-400 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 disabled:opacity-50"
              >
                {cancelLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
                <span>Confirm Void</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VIEW / REPRINT RECEIPT MODAL */}
      {selectedBill && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4 print:p-0 print:bg-white print:static print:z-auto">
          <div className="bg-[#12141d]/90 backdrop-blur-2xl border border-zinc-700/60 rounded-3xl w-full max-w-xl p-6 max-h-[92vh] overflow-y-auto flex flex-col space-y-4 shadow-2xl shadow-black/50 print:bg-white print:border-none print:shadow-none print:p-0">
            {/* Header (Hidden during print) */}
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 print:hidden">
              <div className="flex items-center gap-2 text-[#e5c378]">
                <Receipt className="w-5 h-5 text-[#d4af37]" />
                <span className="font-semibold text-sm font-mono">Invoice #{selectedBill.billNumber}</span>
              </div>
              <button
                onClick={() => setSelectedBill(null)}
                className="p-1 text-zinc-400 hover:text-white rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Print Format Tabs (Hidden during print) */}
            <div className="flex items-center gap-2 p-1 rounded-xl bg-zinc-900 border border-zinc-800 print:hidden">
              <button
                onClick={() => setReceiptFormat('custom')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${
                  receiptFormat === 'custom'
                    ? 'bg-[#d4af37] text-black font-bold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Custom HTML Designer
              </button>
              <button
                onClick={() => setReceiptFormat('thermal')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${
                  receiptFormat === 'thermal'
                    ? 'bg-[#d4af37] text-black font-bold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Compact Thermal (80mm)
              </button>
              <button
                onClick={() => setReceiptFormat('a4')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${
                  receiptFormat === 'a4'
                    ? 'bg-[#d4af37] text-black font-bold'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Standard A4 Tax Invoice
              </button>
            </div>

            {/* Receipt Preview */}
            <div className="flex-1 flex justify-center py-2">
              {receiptFormat === 'custom' ? (
                <div
                  id="printable-receipt"
                  className="w-full h-[520px] bg-white rounded-xl shadow-md overflow-hidden"
                >
                  <iframe
                    srcDoc={renderedCustomReceiptHtml}
                    title="Invoice Preview"
                    className="w-full h-full border-0 bg-white"
                  />
                </div>
              ) : receiptFormat === 'thermal' ? (
                <div
                  id="printable-receipt"
                  className="w-72 bg-white text-black p-4 rounded shadow-md font-mono text-[11px] leading-tight space-y-3 print:w-full print:shadow-none"
                >
                  <div className="text-center space-y-1 pb-2 border-b border-black border-dashed">
                    {restaurantSettings?.logoUrl && (
                      <img src={restaurantSettings.logoUrl} alt="Logo" className="h-10 mx-auto object-contain mb-1" />
                    )}
                    <h3 className="font-bold text-sm uppercase">{restaurantSettings?.name || restaurantName}</h3>
                    <p className="text-[10px]">{restaurantSettings?.tagline || 'Artisanal Haute Gastronomy'}</p>
                    <p className="text-[9px]">{restaurantSettings?.address || '452 Grand Avenue, Beverly Hills, CA'}</p>
                    <p className="text-[9px]">Tel: {restaurantSettings?.phone || '+1 (555) 234-5678'}</p>
                  </div>

                  <div className="text-[10px] space-y-0.5 pb-2 border-b border-black border-dashed">
                    <div className="flex justify-between">
                      <span>BILL #: {selectedBill.billNumber}</span>
                      <span>{selectedBill.orderType}</span>
                    </div>
                    {selectedBill.tableNumber && (
                      <div className="flex justify-between font-bold">
                        <span>TABLE: {selectedBill.tableNumber}</span>
                        <span>REGISTER #01</span>
                      </div>
                    )}
                    <div className="flex justify-between text-[9px] text-gray-600">
                      <span>{new Date(selectedBill.createdAt).toLocaleString()}</span>
                    </div>
                  </div>

                  <table className="w-full text-left text-[10px]">
                    <thead>
                      <tr className="border-b border-black border-dashed">
                        <th className="py-1">ITEM</th>
                        <th className="py-1 text-center">QTY</th>
                        <th className="py-1 text-right">AMT</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {selectedBill.items?.map((it, i) => (
                        <tr key={i}>
                          <td className="py-1 pr-1">{it.itemName}</td>
                          <td className="py-1 text-center">{it.quantity}</td>
                          <td className="py-1 text-right font-mono">
                            {currency}{(it.unitPrice * it.quantity).toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  <div className="border-t border-black border-dashed pt-2 space-y-1 text-[10px]">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>{currency}{selectedBill.subtotal?.toFixed(2)}</span>
                    </div>
                    {selectedBill.discountAmount > 0 && (
                      <div className="flex justify-between text-gray-700">
                        <span>Discount:</span>
                        <span>-{currency}{selectedBill.discountAmount?.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>Tax Amount:</span>
                      <span>{currency}{selectedBill.taxAmount?.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-xs pt-1 border-t border-black">
                      <span>GRAND TOTAL:</span>
                      <span>{currency}{selectedBill.totalAmount?.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between pt-1 font-semibold">
                      <span>PAID ({selectedBill.paymentMethod}):</span>
                      <span>{currency}{selectedBill.paidAmount?.toFixed(2)}</span>
                    </div>
                    {selectedBill.balanceAmount > 0 && (
                      <div className="flex justify-between text-red-600 font-bold">
                        <span>BALANCE DUE:</span>
                        <span>{currency}{selectedBill.balanceAmount?.toFixed(2)}</span>
                      </div>
                    )}
                  </div>

                  <div className="text-center pt-2 border-t border-black border-dashed text-[9px] space-y-0.5">
                    <p className="font-semibold">{restaurantSettings?.receiptHeader || 'THANK YOU FOR GRACING OUR TABLE'}</p>
                    <p className="text-gray-600">{restaurantSettings?.receiptFooter || 'Please visit again soon.'}</p>
                  </div>
                </div>
              ) : (
                <div
                  id="printable-receipt"
                  className="w-full bg-white text-black p-6 rounded-xl font-sans text-xs space-y-4 shadow-md print:w-full print:shadow-none"
                >
                  <div className="flex items-start justify-between pb-4 border-b border-gray-300">
                    <div>
                      {restaurantSettings?.logoUrl && (
                        <img src={restaurantSettings.logoUrl} alt="Logo" className="h-10 object-contain mb-2" />
                      )}
                      <h2 className="text-base font-bold text-gray-900">{restaurantSettings?.name || restaurantName}</h2>
                      <p className="text-gray-600 text-xs">{restaurantSettings?.tagline || 'Artisanal Fine Gastronomy & Private Cellar'}</p>
                      <p className="text-gray-500 text-[11px]">{restaurantSettings?.address || '452 Grand Avenue, Beverly Hills, CA 90210'}</p>
                      <p className="text-gray-500 text-[11px]">Tel: {restaurantSettings?.phone || '+1 (555) 234-5678'}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-xs uppercase font-bold text-gray-400 tracking-wider">TAX INVOICE</span>
                      <p className="text-base font-mono font-bold text-gray-900">{selectedBill.billNumber}</p>
                      <p className="text-gray-600 text-[11px]">
                        Date: {new Date(selectedBill.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-gray-400 font-semibold uppercase text-[10px]">Billed To:</span>
                      <p className="font-medium text-gray-800">
                        {selectedBill.customer?.name || 'Valued Restaurant Patron'}
                      </p>
                      {selectedBill.customer?.phone && (
                        <p className="text-gray-600">{selectedBill.customer.phone}</p>
                      )}
                    </div>
                    <div className="text-right">
                      <span className="text-gray-400 font-semibold uppercase text-[10px]">Service Details:</span>
                      <p className="font-medium text-gray-800">
                        {selectedBill.orderType} • {selectedBill.tableNumber || 'Walk-in'}
                      </p>
                    </div>
                  </div>

                  <table className="w-full text-left text-xs border border-gray-200">
                    <thead className="bg-gray-100 text-gray-700 font-semibold uppercase text-[10px]">
                      <tr>
                        <th className="p-2 border-b">Item Description</th>
                        <th className="p-2 border-b text-center">Unit Price</th>
                        <th className="p-2 border-b text-center">Qty</th>
                        <th className="p-2 border-b text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {selectedBill.items?.map((it, i) => (
                        <tr key={i}>
                          <td className="p-2">{it.itemName}</td>
                          <td className="p-2 text-center font-mono">{currency}{it.unitPrice.toFixed(2)}</td>
                          <td className="p-2 text-center">{it.quantity}</td>
                          <td className="p-2 text-right font-mono">
                            {currency}{(it.unitPrice * it.quantity).toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  <div className="flex justify-end">
                    <div className="w-64 space-y-1 text-xs">
                      <div className="flex justify-between text-gray-600">
                        <span>Subtotal:</span>
                        <span>{currency}{selectedBill.subtotal?.toFixed(2)}</span>
                      </div>
                      {selectedBill.discountAmount > 0 && (
                        <div className="flex justify-between text-emerald-600">
                          <span>Discount:</span>
                          <span>-{currency}{selectedBill.discountAmount?.toFixed(2)}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-gray-600">
                        <span>Local Sales Tax:</span>
                        <span>{currency}{selectedBill.taxAmount?.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between font-bold text-sm text-gray-900 pt-2 border-t border-gray-300">
                        <span>Invoice Total:</span>
                        <span>{currency}{selectedBill.totalAmount?.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-gray-700 font-medium">
                        <span>Paid via {selectedBill.paymentMethod}:</span>
                        <span>{currency}{selectedBill.paidAmount?.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-zinc-800 print:hidden">
              <button
                onClick={() => setSelectedBill(null)}
                className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
              >
                Close
              </button>

              <button
                onClick={handlePrint}
                className="px-6 py-2 rounded-xl bg-[#d4af37] text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 hover:bg-[#e5c378] transition cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Document</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

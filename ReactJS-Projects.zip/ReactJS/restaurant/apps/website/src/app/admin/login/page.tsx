'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Lock, Mail, Loader2, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to authenticate');
      }

      router.push('/admin');
      router.refresh();
    } catch (err: any) {
      setError(err.message || 'Login failed. Please verify your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickFill = (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    setError(null);
  };

  return (
    <div className="w-full max-w-md p-6 sm:p-8 bg-[#12141e] border border-[#d4af37]/35 rounded-3xl shadow-2xl shadow-black/90 my-8">
      {/* Brand Header */}
      <div className="text-center mb-8">
        <div className="inline-flex w-12 h-12 rounded-xl bg-zinc-800 border border-zinc-700 items-center justify-center text-[#c5a059] font-bold text-xl shadow-lg mb-3">
          R
        </div>
        <h1 className="font-semibold text-xl text-zinc-100 tracking-tight">Restaurant Portal</h1>
        <p className="text-xs text-stone-400 mt-1">Management Portal, CMS & Point of Sale System</p>
      </div>

      {error && (
        <div className="mb-6 p-4 rounded-xl bg-red-950/40 border border-red-500/30 text-red-300 text-xs flex items-start gap-2.5">
          <div className="w-2 h-2 rounded-full bg-red-400 mt-1 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-1.5">
            Staff Email Address
          </label>
          <div className="relative">
            <Mail className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3.5" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@restaurant.com"
              required
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-sm text-zinc-100 placeholder:text-zinc-600 focus:outline-hidden focus:border-[#d4af37] transition"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-1.5">
            Security Password
          </label>
          <div className="relative">
            <Lock className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3.5" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              required
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-sm text-zinc-100 placeholder:text-zinc-600 focus:outline-hidden focus:border-[#d4af37] transition"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-3 px-4 rounded-xl bg-linear-to-r from-[#d4af37] via-[#f7e6c4] to-[#d4af37] text-stone-950 font-bold text-xs tracking-wider uppercase transition shadow-lg shadow-[#d4af37]/25 hover:scale-102 active:scale-98 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer mt-2"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Verifying Credentials...</span>
            </>
          ) : (
            <>
              <span>Authenticate & Enter Atelier</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </form>

      {/* Quick Demo Login Credentials */}
      <div className="mt-8 pt-6 border-t border-zinc-800/80 space-y-3">
        <p className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider text-center">
          Quick Demo Credentials (Password: <span className="text-[#d4af37] lowercase">Demo@12345</span>)
        </p>
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => handleQuickFill('admin@restaurant.com', 'Demo@12345')}
            className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-[#d4af37]/40 text-left transition text-[11px] text-zinc-300"
          >
            <span className="font-bold text-[#e5c378] block">Super Admin</span>
            <span className="text-[9px] text-zinc-500 block truncate">admin@</span>
          </button>

          <button
            type="button"
            onClick={() => handleQuickFill('manager@restaurant.com', 'Demo@12345')}
            className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-[#d4af37]/40 text-left transition text-[11px] text-zinc-300"
          >
            <span className="font-bold text-blue-400 block">Manager</span>
            <span className="text-[9px] text-zinc-500 block truncate">manager@</span>
          </button>

          <button
            type="button"
            onClick={() => handleQuickFill('cashier@restaurant.com', 'Demo@12345')}
            className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-[#d4af37]/40 text-left transition text-[11px] text-zinc-300"
          >
            <span className="font-bold text-emerald-400 block">Cashier</span>
            <span className="text-[9px] text-zinc-500 block truncate">cashier@</span>
          </button>
        </div>
      </div>
    </div>
  );
}

'use client';

import React, { useState, useMemo } from 'react';
import {
  Settings,
  Save,
  Loader2,
  Image as ImageIcon,
  Code,
  RotateCcw,
  Printer,
  Sparkles,
  Eye,
  CheckCircle,
  Copy,
  Check,
  Building,
  CreditCard,
  Phone,
  Mail,
  MapPin,
  Clock,
  Layers,
  AlertCircle,
} from 'lucide-react';
import { ImageUploader } from '@/components/admin/ImageUploader';
import {
  DEFAULT_RECEIPT_HTML_TEMPLATE,
  SAMPLE_RECEIPT_DATA,
  renderReceiptHtml,
} from '@/lib/receiptTemplate';
import { useToast } from '@/context/ToastContext';

interface SettingsManagerProps {
  initialSettings: any;
}

const TEMPLATE_VARIABLES = [
  { tag: '{{logo_html}}', desc: 'Auto-formatted Logo image' },
  { tag: '{{restaurant_name}}', desc: 'Restaurant Name' },
  { tag: '{{restaurant_tagline}}', desc: 'Tagline & Category' },
  { tag: '{{address}}', desc: 'Physical Address' },
  { tag: '{{phone}}', desc: 'Direct Telephone' },
  { tag: '{{email}}', desc: 'Contact Email' },
  { tag: '{{opening_hours}}', desc: 'Service Schedule' },
  { tag: '{{bill_number}}', desc: 'Invoice / Bill Reference' },
  { tag: '{{order_type}}', desc: 'Dine-In, Takeaway, etc.' },
  { tag: '{{table_number}}', desc: 'Table or Seat #' },
  { tag: '{{date}}', desc: 'Formatted Service Date' },
  { tag: '{{time}}', desc: 'Service Timestamp' },
  { tag: '{{customer_name}}', desc: 'Guest Name' },
  { tag: '{{customer_phone}}', desc: 'Guest Phone' },
  { tag: '{{cashier_name}}', desc: 'Cashier / Register Name' },
  { tag: '{{items_table_html}}', desc: 'Formatted Food & Drinks Table' },
  { tag: '{{subtotal}}', desc: 'Subtotal Amount' },
  { tag: '{{discount}}', desc: 'Discount Given' },
  { tag: '{{tax_rate}}', desc: 'Tax Percentage' },
  { tag: '{{tax_amount}}', desc: 'Tax Value' },
  { tag: '{{grand_total}}', desc: 'Final Payable Amount' },
  { tag: '{{paid_amount}}', desc: 'Tendered / Paid Value' },
  { tag: '{{balance_amount}}', desc: 'Outstanding Balance' },
  { tag: '{{payment_method}}', desc: 'Cash, Card, UPI' },
  { tag: '{{receipt_header}}', desc: 'Header Courtesy Line' },
  { tag: '{{receipt_footer}}', desc: 'Footer Legal Note' },
];

export function SettingsManager({ initialSettings }: SettingsManagerProps) {
  const toast = useToast();
  const [activeTab, setActiveTab] = useState<'profile' | 'billing' | 'receipt_template'>('profile');
  const [form, setForm] = useState({
    name: initialSettings?.name || 'Zaffran Haveli',
    tagline: initialSettings?.tagline || 'Royal Awadhi & Mughlai Culinary Atelier',
    description:
      initialSettings?.description ||
      'An authentic culinary sanctuary honoring slow-cooked Awadhi Dum Pukht heritage, royal clay tandoors, and handpicked spice terroir.',
    phone: initialSettings?.phone || '+91 98201 23456',
    email: initialSettings?.email || 'concierge@zaffranhaveli.com',
    address:
      initialSettings?.address ||
      'Heritage Grand Haveli, Colaba Causeway, Mumbai, Maharashtra 400001',
    openingHours:
      initialSettings?.openingHours ||
      'Tue – Sun: 12:30 PM – 3:30 PM, 7:00 PM – 11:45 PM | Mon: Closed',
    currency: initialSettings?.currency || '₹',
    taxRate: initialSettings?.taxRate ?? 5.0,
    serviceChargeRate: initialSettings?.serviceChargeRate ?? 0.0,
    receiptHeader: initialSettings?.receiptHeader || 'Zaffran Haveli — Royal Indian Atelier',
    receiptFooter:
      initialSettings?.receiptFooter ||
      'Dhanyavaad. All prices inclusive of applicable GST (2.5% CGST + 2.5% SGST).',
    logoUrl: initialSettings?.logoUrl || '',
    receiptTemplate: initialSettings?.receiptTemplate || DEFAULT_RECEIPT_HTML_TEMPLATE,
  });

  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [copiedTag, setCopiedTag] = useState<string | null>(null);

  const iframeRef = React.useRef<HTMLIFrameElement>(null);
  const textareaRef = React.useRef<HTMLTextAreaElement>(null);

  // Field validation rules
  const validateField = (field: string, value: any): string => {
    switch (field) {
      case 'name':
        if (!value || !value.trim()) return 'Restaurant name is required.';
        if (value.trim().length < 2) return 'Restaurant name must be at least 2 characters.';
        if (value.trim().length > 80) return 'Restaurant name cannot exceed 80 characters.';
        return '';
      case 'tagline':
        if (value && value.length > 120) return 'Tagline cannot exceed 120 characters.';
        return '';
      case 'phone':
        if (!value || !value.trim()) return 'Phone number is required.';
        if (value.trim().length < 7) return 'Phone number must be at least 7 characters.';
        if (value.trim().length > 25) return 'Phone number cannot exceed 25 characters.';
        return '';
      case 'email':
        if (!value || !value.trim()) return 'Email address is required.';
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value.trim())) return 'Please enter a valid email address.';
        if (value.trim().length > 80) return 'Email cannot exceed 80 characters.';
        return '';
      case 'address':
        if (!value || !value.trim()) return 'Physical venue address is required.';
        if (value.trim().length < 5) return 'Address must be at least 5 characters.';
        if (value.trim().length > 180) return 'Address cannot exceed 180 characters.';
        return '';
      case 'currency':
        if (!value || !value.trim()) return 'Currency symbol is required (e.g. ₹).';
        if (value.trim().length > 5) return 'Currency symbol max 5 characters.';
        return '';
      case 'taxRate':
        const tax = Number(value);
        if (value === '' || isNaN(tax)) return 'Tax rate must be a number.';
        if (tax < 0 || tax > 100) return 'Tax rate must be between 0% and 100%.';
        return '';
      case 'serviceChargeRate':
        const svc = Number(value);
        if (value !== '' && (isNaN(svc) || svc < 0 || svc > 50)) {
          return 'Service charge rate must be between 0% and 50%.';
        }
        return '';
      case 'description':
        if (value && value.length > 350) return 'Description cannot exceed 350 characters.';
        return '';
      default:
        return '';
    }
  };

  const validateAll = (data: typeof form) => {
    const errs: Record<string, string> = {
      name: validateField('name', data.name),
      tagline: validateField('tagline', data.tagline),
      phone: validateField('phone', data.phone),
      email: validateField('email', data.email),
      address: validateField('address', data.address),
      currency: validateField('currency', data.currency),
      taxRate: validateField('taxRate', data.taxRate),
      serviceChargeRate: validateField('serviceChargeRate', data.serviceChargeRate),
      description: validateField('description', data.description),
    };
    Object.keys(errs).forEach((k) => !errs[k] && delete errs[k]);
    return errs;
  };

  const handleChange = (field: string, value: any) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    const err = validateField(field, value);
    setErrors((prev) => ({ ...prev, [field]: err }));
  };

  const handleBlur = (field: string) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
    const err = validateField(field, (form as any)[field]);
    setErrors((prev) => ({ ...prev, [field]: err }));
  };

  // Compute live HTML receipt preview
  const livePreviewHtml = useMemo(() => {
    const liveData = {
      ...SAMPLE_RECEIPT_DATA,
      restaurantName: form.name,
      tagline: form.tagline,
      logoUrl: form.logoUrl,
      address: form.address,
      phone: form.phone,
      email: form.email,
      openingHours: form.openingHours,
      currency: form.currency,
      taxRate: form.taxRate,
      receiptHeader: form.receiptHeader,
      receiptFooter: form.receiptFooter,
    };

    return renderReceiptHtml(form.receiptTemplate, liveData);
  }, [form]);

  // Handle Save
  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    setTouched({
      name: true,
      tagline: true,
      phone: true,
      email: true,
      address: true,
      currency: true,
      taxRate: true,
      serviceChargeRate: true,
      description: true,
    });
    const errs = validateAll(form);
    setErrors(errs);

    if (Object.keys(errs).length > 0) {
      toast.error('Please fix the highlighted settings errors.', 'Validation Failed');
      return;
    }

    setSaving(true);

    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update settings');

      toast.success(
        'Restaurant identity, tax rates, and bill templates saved successfully!',
        'Settings Synced'
      );
    } catch (err: any) {
      toast.error(err.message, 'Save Failed');
    } finally {
      setSaving(false);
    }
  };

  // Reset Receipt Template to Factory Default
  const handleResetDefaultTemplate = () => {
    if (confirm('Reset receipt HTML to default Indian Fine Dining template?')) {
      setForm((prev) => ({
        ...prev,
        receiptTemplate: DEFAULT_RECEIPT_HTML_TEMPLATE,
      }));
      toast.info('Receipt layout restored to factory default template.', 'Template Reset');
    }
  };

  // Insert or Copy Tag
  const handleInsertTag = (tag: string) => {
    navigator.clipboard.writeText(tag);
    setCopiedTag(tag);
    setTimeout(() => setCopiedTag(null), 2000);

    if (textareaRef.current) {
      const textarea = textareaRef.current;
      const start = textarea.selectionStart || 0;
      const end = textarea.selectionEnd || 0;
      const text = form.receiptTemplate;
      const newText = text.substring(0, start) + tag + text.substring(end);
      setForm((prev) => ({ ...prev, receiptTemplate: newText }));
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + tag.length, start + tag.length);
      }, 50);
    }
  };

  // Test Print
  const handleTestPrint = () => {
    if (iframeRef.current && iframeRef.current.contentWindow) {
      iframeRef.current.contentWindow.focus();
      iframeRef.current.contentWindow.print();
    } else {
      const printWindow = window.open('', '_blank', 'width=450,height=700');
      if (printWindow) {
        printWindow.document.write(livePreviewHtml);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
        }, 350);
      }
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-7xl bg-[#0c0e14] min-h-screen">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800/80">
        <div>
          <h1 className="font-semibold text-xl text-zinc-100 flex items-center gap-2">
            <span>Restaurant Profile & Dynamic Billing Settings</span>
            <span className="text-[10px] uppercase font-bold tracking-widest px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
              System Wide Sync ({form.currency})
            </span>
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            Values configured here dynamically update the Public Website, Navbar, Footer, Reservation Modals, and Custom Bill Receipts.
          </p>
        </div>

        <button
          onClick={() => handleSave()}
          disabled={saving}
          className="px-6 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-md shadow-amber-400/20 transition cursor-pointer disabled:opacity-50"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          <span>Save All Settings</span>
        </button>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-2 border-b border-zinc-800 pb-1">
        <button
          onClick={() => setActiveTab('profile')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
            activeTab === 'profile'
              ? 'bg-amber-400 text-black font-bold shadow-md'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>Restaurant Identity & Profile</span>
        </button>

        <button
          onClick={() => setActiveTab('billing')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
            activeTab === 'billing'
              ? 'bg-amber-400 text-black font-bold shadow-md'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>Tax & Invoicing Rules</span>
        </button>

        <button
          onClick={() => setActiveTab('receipt_template')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
            activeTab === 'receipt_template'
              ? 'bg-amber-400 text-black font-bold shadow-md'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
          }`}
        >
          <Code className="w-4 h-4" />
          <span>Live HTML Receipt Designer</span>
          <span className="text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            Live Preview
          </span>
        </button>
      </div>

      {/* TAB 1: RESTAURANT IDENTITY & PROFILE */}
      {activeTab === 'profile' && (
        <div className="space-y-6">
          <div className="bg-[#10131a] border border-zinc-800/80 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl">
            <div className="border-b border-zinc-800 pb-4">
              <h2 className="font-semibold text-sm text-zinc-100">Restaurant Identity</h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Brand attributes reflected across website headers, footers, booking dialogs, and bills.
              </p>
            </div>

            {/* Logo Uploader Section */}
            <div className="p-5 rounded-2xl bg-[#090a0e] border border-zinc-800 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-zinc-200 uppercase tracking-wider flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 text-amber-400" />
                    <span>Restaurant Official Brand Logo</span>
                  </h3>
                  <p className="text-[11px] text-zinc-500 mt-0.5">
                    This logo appears in navigation, hero presentation, and is directly embedded at the top of printed guest receipts.
                  </p>
                </div>
                {form.logoUrl && (
                  <div className="p-2 rounded-xl bg-zinc-900 border border-amber-400/40 flex items-center gap-2">
                    <img src={form.logoUrl} alt="Logo Preview" className="h-8 max-w-[120px] object-contain" />
                    <span className="text-[10px] text-amber-300 font-semibold">Active</span>
                  </div>
                )}
              </div>

              <ImageUploader
                value={form.logoUrl}
                onChange={(url) => setForm({ ...form, logoUrl: url || '' })}
                label="Upload High-Res Brand Logo (PNG / WebP / SVG)"
                helperText="Transparent background recommended. Replaces existing logo across receipts and navbar."
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
              {/* Restaurant Name */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px]">
                    Restaurant Name <span className="text-rose-500 font-bold ml-0.5">*</span>
                  </label>
                  <span className="text-[10px] text-zinc-500">{form.name.length} / 80 chars (min 2)</span>
                </div>
                <input
                  type="text"
                  maxLength={80}
                  value={form.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                  onBlur={() => handleBlur('name')}
                  placeholder="e.g. Zaffran Haveli"
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition ${
                    touched.name && errors.name
                      ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                      : 'border-zinc-800 focus:border-amber-500/60'
                  }`}
                />
                {touched.name && errors.name && (
                  <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.name}</span>
                  </p>
                )}
              </div>

              {/* Tagline */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px]">
                    Tagline & Subtext
                  </label>
                  <span className="text-[10px] text-zinc-500">{form.tagline.length} / 120 chars</span>
                </div>
                <input
                  type="text"
                  maxLength={120}
                  value={form.tagline}
                  onChange={(e) => handleChange('tagline', e.target.value)}
                  onBlur={() => handleBlur('tagline')}
                  placeholder="e.g. Royal Awadhi & Mughlai Culinary Atelier"
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition ${
                    touched.tagline && errors.tagline
                      ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                      : 'border-zinc-800 focus:border-amber-500/60'
                  }`}
                />
                {touched.tagline && errors.tagline && (
                  <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.tagline}</span>
                  </p>
                )}
              </div>

              {/* Phone */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-amber-400" />
                    <span>Concierge Phone <span className="text-rose-500 font-bold ml-0.5">*</span></span>
                  </label>
                  <span className="text-[10px] text-zinc-500">Min 7 • Max 25 chars</span>
                </div>
                <input
                  type="text"
                  maxLength={25}
                  value={form.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  onBlur={() => handleBlur('phone')}
                  placeholder="+91 98201 23456"
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border text-zinc-100 font-mono focus:outline-none transition ${
                    touched.phone && errors.phone
                      ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                      : 'border-zinc-800 focus:border-amber-500/60'
                  }`}
                />
                {touched.phone && errors.phone && (
                  <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.phone}</span>
                  </p>
                )}
              </div>

              {/* Email */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-amber-400" />
                    <span>Official Email <span className="text-rose-500 font-bold ml-0.5">*</span></span>
                  </label>
                  <span className="text-[10px] text-zinc-500">Max 80 chars</span>
                </div>
                <input
                  type="email"
                  maxLength={80}
                  value={form.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  onBlur={() => handleBlur('email')}
                  placeholder="concierge@zaffranhaveli.com"
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border text-zinc-100 font-mono focus:outline-none transition ${
                    touched.email && errors.email
                      ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                      : 'border-zinc-800 focus:border-amber-500/60'
                  }`}
                />
                {touched.email && errors.email && (
                  <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.email}</span>
                  </p>
                )}
              </div>

              {/* Address */}
              <div className="md:col-span-2">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    <span>Full Physical Venue Address <span className="text-rose-500 font-bold ml-0.5">*</span></span>
                  </label>
                  <span className="text-[10px] text-zinc-500">{form.address.length} / 180 chars (min 5)</span>
                </div>
                <input
                  type="text"
                  maxLength={180}
                  value={form.address}
                  onChange={(e) => handleChange('address', e.target.value)}
                  onBlur={() => handleBlur('address')}
                  placeholder="Heritage Grand Haveli, Colaba Causeway, Mumbai, Maharashtra 400001"
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition ${
                    touched.address && errors.address
                      ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                      : 'border-zinc-800 focus:border-amber-500/60'
                  }`}
                />
                {touched.address && errors.address && (
                  <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.address}</span>
                  </p>
                )}
              </div>

              {/* Dining Hours */}
              <div className="md:col-span-2">
                <label className="block font-semibold text-zinc-300 mb-1.5 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Dining & Service Hours</span>
                </label>
                <input
                  type="text"
                  value={form.openingHours}
                  onChange={(e) => setForm({ ...form, openingHours: e.target.value })}
                  placeholder="Tue – Sun: 12:30 PM – 3:30 PM, 7:00 PM – 11:45 PM | Mon: Closed"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60 transition"
                />
              </div>

              {/* Description */}
              <div className="md:col-span-2">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px]">
                    Gastronomic Concept Description
                  </label>
                  <span className="text-[10px] text-zinc-500">{form.description.length} / 350 chars</span>
                </div>
                <textarea
                  rows={2}
                  maxLength={350}
                  value={form.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  onBlur={() => handleBlur('description')}
                  placeholder="Where royal Awadhi traditions meet slow charcoal fire..."
                  className={`w-full p-3 rounded-xl bg-zinc-900 border text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition ${
                    touched.description && errors.description
                      ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                      : 'border-zinc-800 focus:border-amber-500/60'
                  }`}
                />
                {touched.description && errors.description && (
                  <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.description}</span>
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: FINANCIAL & INVOICING RULES */}
      {activeTab === 'billing' && (
        <div className="bg-[#10131a] border border-zinc-800/80 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="border-b border-zinc-800 pb-4">
            <h2 className="font-semibold text-sm text-zinc-100">Tax & Billing Calculation Rules</h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Defines financial calculations used across the POS register and official customer invoices.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs">
            {/* Currency Symbol */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px]">
                  Currency Symbol <span className="text-rose-500 font-bold ml-0.5">*</span>
                </label>
                <span className="text-[10px] text-zinc-500">Max 5 chars</span>
              </div>
              <input
                type="text"
                maxLength={5}
                value={form.currency}
                onChange={(e) => handleChange('currency', e.target.value)}
                onBlur={() => handleBlur('currency')}
                placeholder="₹, $, €, £"
                className={`w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border text-zinc-100 font-mono text-sm focus:outline-none transition ${
                  touched.currency && errors.currency
                    ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                    : 'border-zinc-800 focus:border-amber-500/60'
                }`}
              />
              {touched.currency && errors.currency ? (
                <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{errors.currency}</span>
                </p>
              ) : (
                <span className="text-[10px] text-zinc-500 mt-1 block">Displayed on menus & bills</span>
              )}
            </div>

            {/* Sales Tax / GST */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px]">
                  GST / Sales Tax Rate (%) <span className="text-rose-500 font-bold ml-0.5">*</span>
                </label>
                <span className="text-[10px] text-zinc-500">0% – 100%</span>
              </div>
              <input
                type="number"
                min="0"
                max="100"
                step="any"
                value={form.taxRate}
                onChange={(e) => handleChange('taxRate', parseFloat(e.target.value) || 0)}
                onBlur={() => handleBlur('taxRate')}
                placeholder="5.0"
                className={`w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border text-zinc-100 font-mono text-sm focus:outline-none transition ${
                  touched.taxRate && errors.taxRate
                    ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                    : 'border-zinc-800 focus:border-amber-500/60'
                }`}
              />
              {touched.taxRate && errors.taxRate ? (
                <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{errors.taxRate}</span>
                </p>
              ) : (
                <span className="text-[10px] text-zinc-500 mt-1 block">Standard Indian Restaurant GST: 5%</span>
              )}
            </div>

            {/* Service Charge */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-semibold text-zinc-300 uppercase tracking-wider text-[11px]">
                  Service Charge Rate (%)
                </label>
                <span className="text-[10px] text-zinc-500">0% – 50%</span>
              </div>
              <input
                type="number"
                min="0"
                max="50"
                step="any"
                value={form.serviceChargeRate}
                onChange={(e) => handleChange('serviceChargeRate', parseFloat(e.target.value) || 0)}
                onBlur={() => handleBlur('serviceChargeRate')}
                placeholder="0.0"
                className={`w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border text-zinc-100 font-mono text-sm focus:outline-none transition ${
                  touched.serviceChargeRate && errors.serviceChargeRate
                    ? 'border-rose-500/80 focus:border-rose-500 ring-1 ring-rose-500/20'
                    : 'border-zinc-800 focus:border-amber-500/60'
                }`}
              />
              {touched.serviceChargeRate && errors.serviceChargeRate ? (
                <p className="text-rose-400 text-[11px] mt-1.5 flex items-center gap-1 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{errors.serviceChargeRate}</span>
                </p>
              ) : (
                <span className="text-[10px] text-zinc-500 mt-1 block">Optional hospitality gratuity</span>
              )}
            </div>

            <div className="md:col-span-3">
              <label className="block font-semibold text-zinc-300 mb-1.5 uppercase tracking-wider text-[11px]">
                Receipt Header Courtesy Text
              </label>
              <input
                type="text"
                value={form.receiptHeader}
                onChange={(e) => setForm({ ...form, receiptHeader: e.target.value })}
                placeholder="e.g. Zaffran Haveli — Royal Indian Atelier"
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60 transition"
              />
            </div>

            <div className="md:col-span-3">
              <label className="block font-semibold text-zinc-300 mb-1.5 uppercase tracking-wider text-[11px]">
                Receipt Footer Legal & Welcome Note
              </label>
              <textarea
                rows={2}
                value={form.receiptFooter}
                onChange={(e) => setForm({ ...form, receiptFooter: e.target.value })}
                placeholder="All prices inclusive of applicable taxes. We look forward to serving you again."
                className="w-full p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 focus:outline-none focus:border-amber-500/60 transition"
              />
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: LIVE HTML RECEIPT TEMPLATE DESIGNER & STUDIO */}
      {activeTab === 'receipt_template' && (
        <div className="space-y-6">
          {/* Action Ribbon & Variable Helper */}
          <div className="p-5 rounded-2xl bg-[#10131a] border border-zinc-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Code className="w-4 h-4 text-amber-400" />
                  <span>HTML Code-Based Receipt Studio</span>
                </h3>
                <p className="text-xs text-zinc-400">
                  Full customizability for 80mm thermal printers or standard paper. Changes preview live in real time.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleTestPrint}
                  className="px-3.5 py-1.5 rounded-xl bg-zinc-900 border border-zinc-700 hover:border-amber-400 text-zinc-200 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-amber-400" />
                  <span>Test Print</span>
                </button>

                <button
                  type="button"
                  onClick={handleResetDefaultTemplate}
                  className="px-3.5 py-1.5 rounded-xl bg-red-950/30 border border-red-500/30 hover:bg-red-950/60 text-red-300 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset to Default Template</span>
                </button>
              </div>
            </div>

            {/* Variable Tag Pills */}
            <div className="space-y-1.5">
              <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400 block">
                Click any dynamic placeholder below to copy into your HTML:
              </span>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                {TEMPLATE_VARIABLES.map((v) => (
                  <button
                    type="button"
                    key={v.tag}
                    onClick={() => handleInsertTag(v.tag)}
                    title={v.desc}
                    className="px-2 py-0.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[10px] font-mono text-amber-300 flex items-center gap-1 transition cursor-pointer"
                  >
                    <span>{v.tag}</span>
                    {copiedTag === v.tag ? (
                      <Check className="w-2.5 h-2.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-2.5 h-2.5 opacity-40" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* TWO-COLUMN CODE EDITOR & LIVE PREVIEW SPLIT */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left: Code Editor (7 cols) */}
            <div className="lg:col-span-7 bg-[#10131a] border border-zinc-800 rounded-2xl p-4 flex flex-col space-y-3 shadow-xl">
              <div className="flex items-center justify-between text-xs text-zinc-400 pb-2 border-b border-zinc-800">
                <span className="font-semibold text-zinc-200">Custom HTML & CSS Template Code</span>
                <span className="text-[11px] font-mono text-zinc-500">
                  {form.receiptTemplate.length} characters
                </span>
              </div>

              <textarea
                ref={textareaRef}
                rows={24}
                value={form.receiptTemplate}
                onChange={(e) => setForm({ ...form, receiptTemplate: e.target.value })}
                className="w-full p-4 rounded-xl bg-[#08090d] border border-zinc-800/80 text-emerald-400 font-mono text-[11px] leading-relaxed focus:outline-none focus:border-amber-400 selection:bg-amber-400/30"
                spellCheck={false}
              />
            </div>

            {/* Right: Real-time Live Render Preview (5 cols) */}
            <div className="lg:col-span-5 bg-[#10131a] border border-zinc-800 rounded-2xl p-4 flex flex-col space-y-3 shadow-xl sticky top-6">
              <div className="flex items-center justify-between text-xs pb-2 border-b border-zinc-800">
                <span className="font-semibold text-zinc-200 flex items-center gap-1.5">
                  <Eye className="w-4 h-4 text-amber-400" />
                  <span>Real-Time Receipt Preview</span>
                </span>
                <span className="text-[10px] uppercase font-bold text-emerald-400 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30">
                  Sandboxed
                </span>
              </div>

              <div className="rounded-xl overflow-hidden border border-zinc-700 bg-white shadow-2xl h-[560px]">
                <iframe
                  ref={iframeRef}
                  srcDoc={livePreviewHtml}
                  title="Receipt Preview"
                  className="w-full h-full border-0 bg-white"
                />
              </div>

              <div className="text-center pt-1 text-[11px] text-zinc-500">
                Sandboxed WYSIWYG preview with live logo, address, items, and tax rates.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET() {
  try {
    let content = await prisma.contactContent.findFirst();
    if (!content) {
      content = await prisma.contactContent.create({
        data: {
          address: '452 Grand Avenue, Beverly Hills, CA 90210',
          phone: '+1 (555) 234-5678',
          email: 'reservations@letoilerestaurant.com',
          openingHours: 'Tuesday to Sunday: 5:00 PM – 11:30 PM (Kitchen closes at 10:45 PM)',
        },
      });
    }
    return NextResponse.json({ success: true, data: content });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const body = await req.json();
    const existing = await prisma.contactContent.findFirst();

    const updated = await prisma.contactContent.upsert({
      where: { id: existing?.id || 'default-contact' },
      update: {
        address: body.address,
        phone: body.phone,
        email: body.email,
        openingHours: body.openingHours,
        googleMapsUrl: body.googleMapsUrl,
      },
      create: {
        id: 'default-contact',
        address: body.address,
        phone: body.phone,
        email: body.email,
        openingHours: body.openingHours,
        googleMapsUrl: body.googleMapsUrl,
      },
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}

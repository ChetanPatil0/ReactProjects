import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET() {
  try {
    let settings = await prisma.restaurantSetting.findFirst();
    if (!settings) {
      settings = await prisma.restaurantSetting.create({
        data: {
          id: 'default-setting',
          name: "L'Étoile Sanctuary",
          currency: '$',
          taxRate: 5.0,
        },
      });
    }
    return NextResponse.json({ success: true, data: settings });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  const user = await getCurrentUser();
  if (!user || (user.role !== 'SUPER_ADMIN' && user.role !== 'OWNER' && user.role !== 'MANAGER')) {
    return NextResponse.json({ error: 'Unauthorized to change restaurant settings' }, { status: 403 });
  }

  try {
    const body = await req.json();
    const existing = await prisma.restaurantSetting.findFirst();

    const updated = await prisma.restaurantSetting.upsert({
      where: { id: existing?.id || 'default-setting' },
      update: {
        name: body.name,
        tagline: body.tagline,
        description: body.description,
        phone: body.phone,
        email: body.email,
        address: body.address,
        currency: body.currency,
        taxRate: Number(body.taxRate) || 0,
        serviceChargeRate: Number(body.serviceChargeRate) || 0,
        receiptHeader: body.receiptHeader,
        receiptFooter: body.receiptFooter,
        openingHours: body.openingHours,
        logoUrl: body.logoUrl !== undefined ? body.logoUrl : null,
        receiptTemplate: body.receiptTemplate !== undefined ? body.receiptTemplate : null,
      },
      create: {
        id: 'default-setting',
        name: body.name || "L'Étoile Sanctuary",
        tagline: body.tagline,
        description: body.description,
        phone: body.phone,
        email: body.email,
        address: body.address,
        currency: body.currency || '$',
        taxRate: Number(body.taxRate) || 0,
        serviceChargeRate: Number(body.serviceChargeRate) || 0,
        receiptHeader: body.receiptHeader,
        receiptFooter: body.receiptFooter,
        openingHours: body.openingHours,
        logoUrl: body.logoUrl || null,
        receiptTemplate: body.receiptTemplate || null,
      },
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}

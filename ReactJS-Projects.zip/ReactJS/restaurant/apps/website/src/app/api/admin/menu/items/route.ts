import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { commitTempImage, cleanupOldImage, rollbackTempImage } from '@/lib/storage';

const itemSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(2, 'Item name must be at least 2 characters'),
  slug: z.string().min(2, 'Slug must be at least 2 characters'),
  description: z.string().optional().nullable(),
  price: z.number().positive('Price must be greater than zero'),
  categoryId: z.string().min(1, 'Please select a menu category'),
  isVeg: z.boolean().default(true),
  isAvailable: z.boolean().default(true),
  isSignature: z.boolean().default(false),
  imageUrl: z.string().optional().nullable(),
  spicyLevel: z.number().int().min(0).max(3).default(0),
  displayOrder: z.number().int().default(0),
});

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const categoryId = searchParams.get('categoryId');
    const search = searchParams.get('search');

    const where: any = {};
    if (categoryId && categoryId !== 'all') {
      where.categoryId = categoryId;
    }
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const items = await prisma.menuItem.findMany({
      where,
      orderBy: [{ displayOrder: 'asc' }, { name: 'asc' }],
      include: {
        category: {
          select: { id: true, name: true, slug: true },
        },
      },
    });

    return NextResponse.json({ success: true, data: items });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to fetch menu items' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let committedUrl: string | null = null;
  let stagedUrl: string | null = null;

  try {
    const body = await req.json();
    const parsed = itemSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message }, { status: 400 });
    }

    stagedUrl = parsed.data.imageUrl || null;

    // Transactional commit: move from /uploads/temp to /uploads/media
    committedUrl = await commitTempImage(stagedUrl);

    const item = await prisma.menuItem.create({
      data: {
        name: parsed.data.name,
        slug: parsed.data.slug.toLowerCase().trim().replace(/\s+/g, '-'),
        description: parsed.data.description,
        price: parsed.data.price,
        categoryId: parsed.data.categoryId,
        isVeg: parsed.data.isVeg,
        isAvailable: parsed.data.isAvailable,
        isSignature: parsed.data.isSignature,
        imageUrl: committedUrl,
        spicyLevel: parsed.data.spicyLevel,
        displayOrder: parsed.data.displayOrder,
      },
      include: { category: true },
    });

    return NextResponse.json({ success: true, data: item });
  } catch (err: any) {
    if (committedUrl) await cleanupOldImage(committedUrl);
    if (stagedUrl) await rollbackTempImage(stagedUrl);

    const isDuplicate = err.code === 'P2002';
    return NextResponse.json(
      { error: isDuplicate ? 'A dish with this name or slug already exists.' : err.message },
      { status: 400 }
    );
  }
}

export async function PUT(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let newCommittedUrl: string | null = null;
  let stagedUrl: string | null = null;

  try {
    const body = await req.json();
    const { id, ...data } = body;
    if (!id) return NextResponse.json({ error: 'Item ID is required' }, { status: 400 });

    const existing = await prisma.menuItem.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'Item not found' }, { status: 404 });

    stagedUrl = data.imageUrl || null;

    let finalImageUrl = existing.imageUrl;
    if (stagedUrl !== existing.imageUrl) {
      newCommittedUrl = await commitTempImage(stagedUrl);
      finalImageUrl = newCommittedUrl;

      // Permanently delete old replaced image from disk
      if (existing.imageUrl && existing.imageUrl !== newCommittedUrl) {
        await cleanupOldImage(existing.imageUrl);
      }
    }

    const updated = await prisma.menuItem.update({
      where: { id },
      data: {
        name: data.name,
        slug: data.slug?.toLowerCase().trim().replace(/\s+/g, '-'),
        description: data.description,
        price: Number(data.price),
        categoryId: data.categoryId,
        isVeg: Boolean(data.isVeg),
        isAvailable: Boolean(data.isAvailable),
        isSignature: Boolean(data.isSignature),
        imageUrl: finalImageUrl,
        spicyLevel: Number(data.spicyLevel) || 0,
        displayOrder: Number(data.displayOrder) || 0,
      },
      include: { category: true },
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (err: any) {
    if (newCommittedUrl) await cleanupOldImage(newCommittedUrl);
    if (stagedUrl) await rollbackTempImage(stagedUrl);

    return NextResponse.json({ error: err.message || 'Failed to update menu item' }, { status: 400 });
  }
}

export async function DELETE(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Item ID is required' }, { status: 400 });

    const existing = await prisma.menuItem.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'Item not found' }, { status: 404 });

    // Permanently delete image from disk
    if (existing.imageUrl) {
      await cleanupOldImage(existing.imageUrl);
    }

    await prisma.menuItem.delete({ where: { id } });

    return NextResponse.json({ success: true, message: 'Item deleted successfully' });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to delete menu item' }, { status: 500 });
  }
}

import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { commitTempImage, cleanupOldImage } from '@/lib/storage';

export async function GET() {
  try {
    let content = await prisma.aboutContent.findFirst();
    if (!content) {
      content = await prisma.aboutContent.create({
        data: {
          storyTitle: 'A Legacy of Culinary Innovation & Warmth',
          storyContent: 'Founded with an unwavering commitment to sustainable sourcing and culinary artistry.',
        },
      });
    }
    return NextResponse.json({ success: true, data: content });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const body = await req.json();
    const existing = await prisma.aboutContent.findFirst();

    let storyImageUrl = existing?.storyImageUrl || null;
    if (body.storyImageUrl && body.storyImageUrl !== existing?.storyImageUrl) {
      const newCommitted = await commitTempImage(body.storyImageUrl);
      storyImageUrl = newCommitted;
      if (existing?.storyImageUrl && existing.storyImageUrl !== newCommitted) {
        await cleanupOldImage(existing.storyImageUrl);
      }
    }

    let chefImageUrl = existing?.chefImageUrl || null;
    if (body.chefImageUrl && body.chefImageUrl !== existing?.chefImageUrl) {
      const newCommitted = await commitTempImage(body.chefImageUrl);
      chefImageUrl = newCommitted;
      if (existing?.chefImageUrl && existing.chefImageUrl !== newCommitted) {
        await cleanupOldImage(existing.chefImageUrl);
      }
    }

    const updated = await prisma.aboutContent.upsert({
      where: { id: existing?.id || 'default-about' },
      update: {
        storyTitle: body.storyTitle,
        storyContent: body.storyContent,
        storyImageUrl,
        chefName: body.chefName,
        chefBio: body.chefBio,
        chefImageUrl,
        missionTitle: body.missionTitle,
        missionContent: body.missionContent,
      },
      create: {
        id: 'default-about',
        storyTitle: body.storyTitle,
        storyContent: body.storyContent,
        storyImageUrl,
        chefName: body.chefName,
        chefBio: body.chefBio,
        chefImageUrl,
        missionTitle: body.missionTitle,
        missionContent: body.missionContent,
      },
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}

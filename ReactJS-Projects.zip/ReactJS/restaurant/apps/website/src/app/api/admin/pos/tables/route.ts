import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export const ALL_TABLE_IDS = [
  'Table 1',
  'Table 2',
  'Table 3',
  'Table 4',
  'Table 5',
  'Table 6',
  'Table 7',
  'Table 8',
  'Table 9',
  'Table 10',
  'Table 11',
  'Table 12',
  'Salon A (Private)',
  'Salon B (Royal)',
  'Chef Counter 1',
  'Chef Counter 2',
  'Terrace T1',
  'Wine Vault',
];

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const todayStr = new Date().toISOString().split('T')[0];

    // 1. Fetch all active partial/unsettled bills with table numbers
    const activeBills = await prisma.bill.findMany({
      where: {
        status: 'PARTIAL',
        tableNumber: { not: null },
      },
      include: {
        customer: true,
        items: true,
        payments: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    // 2. Fetch seated reservations today
    const seatedReservations = await prisma.reservation.findMany({
      where: {
        status: 'SEATED',
        date: todayStr,
        tableNumber: { not: null },
      },
      orderBy: { time: 'asc' },
    });

    // Map table occupancy
    const tableMap: Record<
      string,
      {
        status: 'AVAILABLE' | 'OCCUPIED' | 'RESERVED';
        bill?: any;
        reservation?: any;
      }
    > = {};

    ALL_TABLE_IDS.forEach((tbl) => {
      tableMap[tbl] = { status: 'AVAILABLE' };
    });

    // Overlay seated reservations
    seatedReservations.forEach((res) => {
      if (res.tableNumber && tableMap[res.tableNumber]) {
        tableMap[res.tableNumber] = {
          status: 'RESERVED',
          reservation: {
            id: res.id,
            reference: res.reference,
            guestName: res.guestName,
            phone: res.phone,
            guests: res.guests,
            time: res.time,
            occasion: res.occasion,
          },
        };
      }
    });

    // Overlay active running tabs / bills (highest priority occupancy)
    activeBills.forEach((bill) => {
      if (bill.tableNumber && tableMap[bill.tableNumber]) {
        tableMap[bill.tableNumber] = {
          status: 'OCCUPIED',
          bill: {
            id: bill.id,
            billNumber: bill.billNumber,
            totalAmount: bill.totalAmount,
            paidAmount: bill.paidAmount,
            balanceAmount: bill.balanceAmount,
            subtotal: bill.subtotal,
            taxAmount: bill.taxAmount,
            discountAmount: bill.discountAmount,
            items: bill.items,
            customerName: bill.customer?.name || null,
            customerPhone: bill.customer?.phone || null,
            createdAt: bill.createdAt.toISOString(),
          },
          reservation: tableMap[bill.tableNumber]?.reservation,
        };
      }
    });

    // Summary counts
    const occupiedCount = Object.values(tableMap).filter((t) => t.status === 'OCCUPIED').length;
    const reservedCount = Object.values(tableMap).filter((t) => t.status === 'RESERVED').length;
    const availableCount = ALL_TABLE_IDS.length - occupiedCount - reservedCount;

    return NextResponse.json({
      success: true,
      data: {
        tables: tableMap,
        summary: {
          total: ALL_TABLE_IDS.length,
          available: availableCount,
          occupied: occupiedCount,
          reserved: reservedCount,
        },
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to fetch table occupancy' }, { status: 500 });
  }
}

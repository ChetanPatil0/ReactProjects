import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

const paymentSchema = z.object({
  amount: z.number().positive('Payment amount must be greater than zero'),
  paymentMethod: z.enum(['CASH', 'CARD', 'UPI', 'OTHER']).default('CASH'),
  note: z.string().optional().nullable(),
});

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { id } = params;
    const body = await req.json();
    const parsed = paymentSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message }, { status: 400 });
    }

    const { amount, paymentMethod, note } = parsed.data;

    const result = await prisma.$transaction(async (tx) => {
      const bill = await tx.bill.findUnique({
        where: { id },
        include: { customer: true },
      });

      if (!bill) {
        throw new Error('Bill not found');
      }

      if (bill.status === 'CANCELLED') {
        throw new Error('Cannot add payment to a cancelled bill');
      }

      if (bill.balanceAmount <= 0) {
        throw new Error('This bill has already been fully settled');
      }

      const payAmount = Math.min(bill.balanceAmount, Math.round(amount * 100) / 100);
      const newPaidAmount = Math.round((bill.paidAmount + payAmount) * 100) / 100;
      const newBalance = Math.round((bill.totalAmount - newPaidAmount) * 100) / 100;
      const newStatus = newBalance <= 0 ? 'PAID' : 'PARTIAL';

      // 1. Record payment
      const paymentRecord = await tx.paymentRecord.create({
        data: {
          billId: bill.id,
          amount: payAmount,
          paymentMethod,
          note: note || `Payment of $${payAmount.toFixed(2)} recorded`,
          recordedById: user.userId,
        },
      });

      // 2. Update bill
      const updatedBill = await tx.bill.update({
        where: { id: bill.id },
        data: {
          paidAmount: newPaidAmount,
          balanceAmount: newBalance,
          status: newStatus,
        },
        include: { payments: true, items: true, customer: true },
      });

      // 3. Update customer total spent
      if (bill.customerId) {
        await tx.customer.update({
          where: { id: bill.customerId },
          data: {
            totalSpent: { increment: payAmount },
            lastVisit: new Date(),
          },
        });
      }

      // 4. Activity log
      await tx.activityLog.create({
        data: {
          action: 'RECORD_PAYMENT',
          details: `Recorded payment of $${payAmount.toFixed(2)} via ${paymentMethod} for Bill ${bill.billNumber}. Balance remaining: $${newBalance.toFixed(2)}.`,
          entityType: 'Bill',
          entityId: bill.id,
          userId: user.userId,
        },
      });

      return { bill: updatedBill, payment: paymentRecord };
    });

    return NextResponse.json({ success: true, data: result });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to record payment' }, { status: 400 });
  }
}

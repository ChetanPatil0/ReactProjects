import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

const addItemsSchema = z.object({
  items: z.array(
    z.object({
      menuItemId: z.string().optional().nullable(),
      itemName: z.string().min(1, 'Item name is required'),
      unitPrice: z.number().min(0),
      quantity: z.number().int().min(1),
    })
  ).min(1, 'At least one item must be added to the tab'),
});

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { id } = params;
    const body = await req.json();
    const parsed = addItemsSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message }, { status: 400 });
    }

    const { items } = parsed.data;

    const result = await prisma.$transaction(async (tx) => {
      const existingBill = await tx.bill.findUnique({
        where: { id },
        include: { items: true, customer: true, payments: true },
      });

      if (!existingBill) {
        throw new Error('Running bill not found');
      }

      if (existingBill.status === 'CANCELLED') {
        throw new Error('Cannot append items to a cancelled bill');
      }

      // 1. Calculate additional subtotal
      let addSubtotal = 0;
      const newBillItemsData = items.map((i) => {
        const lineTotal = Math.round(i.unitPrice * i.quantity * 100) / 100;
        addSubtotal += lineTotal;
        return {
          billId: existingBill.id,
          menuItemId: i.menuItemId || null,
          itemName: i.itemName,
          unitPrice: i.unitPrice,
          quantity: i.quantity,
          totalPrice: lineTotal,
        };
      });

      // Insert new line items
      await tx.billItem.createMany({
        data: newBillItemsData,
      });

      const newSubtotal = Math.round((existingBill.subtotal + addSubtotal) * 100) / 100;
      const taxable = Math.max(0, newSubtotal - existingBill.discountAmount);
      const newTaxAmount = Math.round(((taxable * existingBill.taxRate) / 100) * 100) / 100;
      const newTotalAmount = Math.round((taxable + newTaxAmount) * 100) / 100;
      const newBalanceAmount = Math.round((newTotalAmount - existingBill.paidAmount) * 100) / 100;
      const newStatus = newBalanceAmount <= 0 ? 'PAID' : 'PARTIAL';

      const updatedBill = await tx.bill.update({
        where: { id: existingBill.id },
        data: {
          subtotal: newSubtotal,
          taxAmount: newTaxAmount,
          totalAmount: newTotalAmount,
          balanceAmount: newBalanceAmount,
          status: newStatus,
        },
        include: {
          items: true,
          payments: true,
          customer: true,
        },
      });

      // Log activity
      await tx.activityLog.create({
        data: {
          action: 'TAB_ITEMS_APPENDED',
          details: `Appended ${items.length} item(s) (₹${addSubtotal.toFixed(2)}) to Bill ${existingBill.billNumber} (${existingBill.tableNumber || 'Takeaway'})`,
          entityType: 'Bill',
          entityId: existingBill.id,
          userId: user.userId,
        },
      });

      return {
        updatedBill,
        newItems: items,
        addedSubtotal: addSubtotal,
      };
    });

    return NextResponse.json({
      success: true,
      data: result.updatedBill,
      newItems: result.newItems,
      addedSubtotal: result.addedSubtotal,
      message: `Successfully added ${result.newItems.length} dish(es) to running tab.`,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to append items to tab' }, { status: 500 });
  }
}

import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

const updateSchema = z.object({
  status: z.enum(['PENDING', 'CONFIRMED', 'SEATED', 'COMPLETED', 'CANCELLED']).optional(),
  tableNumber: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
  date: z.string().optional(),
  time: z.string().optional(),
  guests: z.number().optional(),
  area: z.string().optional(),
});

export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { id } = params;
    const body = await req.json();
    const parsed = updateSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.errors[0]?.message || 'Invalid update payload' },
        { status: 400 }
      );
    }

    const updated = await prisma.reservation.update({
      where: { id },
      data: parsed.data,
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (err: any) {
    console.error('Error updating reservation:', err);
    return NextResponse.json({ error: err.message || 'Failed to update reservation' }, { status: 500 });
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user || (user.role !== 'SUPER_ADMIN' && user.role !== 'OWNER' && user.role !== 'MANAGER')) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  }

  try {
    const { id } = params;
    await prisma.reservation.delete({ where: { id } });
    return NextResponse.json({ success: true, message: 'Reservation removed' });
  } catch (err: any) {
    console.error('Error deleting reservation:', err);
    return NextResponse.json({ error: err.message || 'Failed to delete reservation' }, { status: 500 });
  }
}

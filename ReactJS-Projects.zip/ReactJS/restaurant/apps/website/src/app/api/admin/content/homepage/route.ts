import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { commitTempImage, cleanupOldImage } from '@/lib/storage';

export async function GET() {
  try {
    let content = await prisma.homepageContent.findFirst();
    if (!content) {
      content = await prisma.homepageContent.create({
        data: {
          announcement: 'Seasonal White Truffle Degustation Now Available — Reservations Encouraged',
          heroTitle: 'A Symphony of Flavors, Crafted with Passion & Precision.',
          heroSubtitle: 'Step into an intimate sanctuary of artisanal gastronomy, seasonal ingredients, and timeless elegance.',
        },
      });
    }
    return NextResponse.json({ success: true, data: content });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const body = await req.json();
    const existing = await prisma.homepageContent.findFirst();

    let heroImageUrl = existing?.heroImageUrl || null;
    if (body.heroImageUrl && body.heroImageUrl !== existing?.heroImageUrl) {
      const newCommitted = await commitTempImage(body.heroImageUrl);
      heroImageUrl = newCommitted;
      if (existing?.heroImageUrl && existing.heroImageUrl !== newCommitted) {
        await cleanupOldImage(existing.heroImageUrl);
      }
    }

    let introImageUrl = existing?.introImageUrl || null;
    if (body.introImageUrl && body.introImageUrl !== existing?.introImageUrl) {
      const newCommitted = await commitTempImage(body.introImageUrl);
      introImageUrl = newCommitted;
      if (existing?.introImageUrl && existing.introImageUrl !== newCommitted) {
        await cleanupOldImage(existing.introImageUrl);
      }
    }

    const updated = await prisma.homepageContent.upsert({
      where: { id: existing?.id || 'default-homepage' },
      update: {
        announcement: body.announcement,
        heroTitle: body.heroTitle,
        heroSubtitle: body.heroSubtitle,
        heroImageUrl,
        introTitle: body.introTitle,
        introDescription: body.introDescription,
        introImageUrl,
      },
      create: {
        id: 'default-homepage',
        announcement: body.announcement,
        heroTitle: body.heroTitle,
        heroSubtitle: body.heroSubtitle,
        heroImageUrl,
        introTitle: body.introTitle,
        introDescription: body.introDescription,
        introImageUrl,
      },
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}

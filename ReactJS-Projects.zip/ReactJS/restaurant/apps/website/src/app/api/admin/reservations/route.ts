import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');
    const date = searchParams.get('date');
    const search = searchParams.get('search');

    const where: any = {};

    if (status && status !== 'ALL') {
      where.status = status;
    }

    if (date) {
      where.date = date;
    }

    if (search && search.trim()) {
      const q = search.trim();
      where.OR = [
        { guestName: { contains: q, mode: 'insensitive' } },
        { phone: { contains: q } },
        { reference: { contains: q, mode: 'insensitive' } },
        { email: { contains: q, mode: 'insensitive' } },
      ];
    }

    const reservations = await prisma.reservation.findMany({
      where,
      orderBy: [{ date: 'asc' }, { time: 'asc' }],
    });

    // Also get quick stats
    const todayStr = new Date().toISOString().split('T')[0];
    const [totalCount, pendingCount, confirmedCount, seatedTodayCount] = await Promise.all([
      prisma.reservation.count(),
      prisma.reservation.count({ where: { status: 'PENDING' } }),
      prisma.reservation.count({ where: { status: 'CONFIRMED' } }),
      prisma.reservation.count({ where: { status: 'SEATED', date: todayStr } }),
    ]);

    return NextResponse.json({
      success: true,
      data: reservations,
      stats: {
        total: totalCount,
        pending: pendingCount,
        confirmed: confirmedCount,
        seatedToday: seatedTodayCount,
      },
    });
  } catch (err: any) {
    console.error('Error fetching reservations:', err);
    return NextResponse.json({ error: err.message || 'Failed to fetch reservations' }, { status: 500 });
  }
}

const manualCreateSchema = z.object({
  guestName: z.string().min(2, 'Guest name is required'),
  phone: z.string().min(8, 'Phone number is required'),
  email: z.string().email().optional().or(z.literal('')),
  date: z.string().min(1, 'Dining date is required'),
  time: z.string().min(1, 'Service time is required'),
  guests: z.number().min(1).default(2),
  area: z.string().default('Main Dining Hall'),
  occasion: z.string().optional(),
  tableNumber: z.string().optional(),
  specialRequests: z.string().optional(),
  status: z.enum(['PENDING', 'CONFIRMED', 'SEATED', 'COMPLETED', 'CANCELLED']).default('CONFIRMED'),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const parsed = manualCreateSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.errors[0]?.message || 'Invalid reservation data' },
        { status: 400 }
      );
    }

    const reference = `RES-${Math.floor(100000 + Math.random() * 900000)}`;

    const reservation = await prisma.reservation.create({
      data: {
        reference,
        ...parsed.data,
        email: parsed.data.email || null,
        tableNumber: parsed.data.tableNumber || null,
        specialRequests: parsed.data.specialRequests || null,
      },
    });

    return NextResponse.json({ success: true, data: reservation });
  } catch (err: any) {
    console.error('Error creating staff reservation:', err);
    return NextResponse.json({ error: err.message || 'Failed to create reservation' }, { status: 500 });
  }
}

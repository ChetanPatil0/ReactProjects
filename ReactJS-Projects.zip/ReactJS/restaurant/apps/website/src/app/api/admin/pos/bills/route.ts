import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

const createBillSchema = z.object({
  orderType: z.enum(['DINE_IN', 'TAKEAWAY', 'DELIVERY']).default('DINE_IN'),
  tableNumber: z.string().optional().nullable(),
  customerPhone: z.string().optional().nullable(),
  customerName: z.string().optional().nullable(),
  customerEmail: z.string().optional().nullable(),
  items: z.array(
    z.object({
      menuItemId: z.string().optional().nullable(),
      itemName: z.string().min(1, 'Item name is required'),
      unitPrice: z.number().min(0),
      quantity: z.number().int().min(1),
    })
  ).min(1, 'At least one item must be added to the bill'),
  discountAmount: z.number().min(0).default(0),
  discountNote: z.string().optional().nullable(),
  taxRate: z.number().min(0).default(5),
  paidAmount: z.number().min(0).default(0),
  paymentMethod: z.enum(['CASH', 'CARD', 'UPI', 'OTHER']).default('CASH'),
});

// Helper to generate sequential bill number
async function generateBillNumber(): Promise<string> {
  const now = new Date();
  const yearMonth = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}`;
  const prefix = `BILL-${yearMonth}-`;

  const latestBill = await prisma.bill.findFirst({
    where: { billNumber: { startsWith: prefix } },
    orderBy: { billNumber: 'desc' },
    select: { billNumber: true },
  });

  let nextSeq = 1;
  if (latestBill?.billNumber) {
    const parts = latestBill.billNumber.split('-');
    const currentSeq = parseInt(parts[2] || '0', 10);
    if (!isNaN(currentSeq)) nextSeq = currentSeq + 1;
  }

  return `${prefix}${String(nextSeq).padStart(4, '0')}`;
}

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');
    const search = searchParams.get('search');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(50, parseInt(searchParams.get('limit') || '20', 10));

    const where: any = {};
    if (status && status !== 'ALL') {
      where.status = status;
    }
    if (search) {
      where.OR = [
        { billNumber: { contains: search, mode: 'insensitive' } },
        { tableNumber: { contains: search, mode: 'insensitive' } },
        { customer: { name: { contains: search, mode: 'insensitive' } } },
        { customer: { phone: { contains: search, mode: 'insensitive' } } },
      ];
    }

    const [total, bills] = await Promise.all([
      prisma.bill.count({ where }),
      prisma.bill.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          customer: true,
          items: true,
          payments: true,
          createdBy: { select: { id: true, firstName: true, lastName: true } },
        },
      }),
    ]);

    return NextResponse.json({
      success: true,
      data: bills,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to fetch bills' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const body = await req.json();
    const parsed = createBillSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message }, { status: 400 });
    }

    const data = parsed.data;

    // 1. Calculate line items subtotal
    let subtotal = 0;
    const billItemsData = data.items.map((i) => {
      const lineTotal = Math.round(i.unitPrice * i.quantity * 100) / 100;
      subtotal += lineTotal;
      return {
        menuItemId: i.menuItemId || null,
        itemName: i.itemName,
        unitPrice: i.unitPrice,
        quantity: i.quantity,
        totalPrice: lineTotal,
      };
    });

    subtotal = Math.round(subtotal * 100) / 100;
    const discount = Math.min(subtotal, Math.round(data.discountAmount * 100) / 100);
    const taxableAmount = Math.max(0, subtotal - discount);
    const taxRate = Math.max(0, data.taxRate);
    const taxAmount = Math.round(((taxableAmount * taxRate) / 100) * 100) / 100;
    const totalAmount = Math.round((taxableAmount + taxAmount) * 100) / 100;

    const paidAmount = Math.min(totalAmount, Math.round(data.paidAmount * 100) / 100);
    const balanceAmount = Math.round((totalAmount - paidAmount) * 100) / 100;

    let status: 'PAID' | 'PARTIAL' = 'PAID';
    if (balanceAmount > 0) {
      status = 'PARTIAL';
    }

    // 2. Perform ACID transaction
    const bill = await prisma.$transaction(async (tx) => {
      // 2a. Handle Customer
      let customerId: string | null = null;
      if (data.customerPhone?.trim()) {
        const phone = data.customerPhone.trim();
        const existingCust = await tx.customer.findUnique({ where: { phone } });
        if (existingCust) {
          const updatedCust = await tx.customer.update({
            where: { phone },
            data: {
              name: data.customerName?.trim() || existingCust.name,
              email: data.customerEmail?.trim() || existingCust.email,
              totalVisits: existingCust.totalVisits + 1,
              totalSpent: existingCust.totalSpent + paidAmount,
              lastVisit: new Date(),
            },
          });
          customerId = updatedCust.id;
        } else {
          const newCust = await tx.customer.create({
            data: {
              phone,
              name: data.customerName?.trim() || null,
              email: data.customerEmail?.trim() || null,
              totalVisits: 1,
              totalSpent: paidAmount,
              lastVisit: new Date(),
            },
          });
          customerId = newCust.id;
        }
      }

      // 2b. Generate bill number
      const billNumber = await generateBillNumber();

      // 2c. Create bill
      const newBill = await tx.bill.create({
        data: {
          billNumber,
          orderType: data.orderType,
          tableNumber: data.tableNumber || null,
          customerId,
          subtotal,
          discountAmount: discount,
          discountNote: data.discountNote || null,
          taxRate,
          taxAmount,
          totalAmount,
          paidAmount,
          balanceAmount,
          paymentMethod: data.paymentMethod,
          status,
          createdById: user.userId,
          items: {
            create: billItemsData,
          },
          ...(paidAmount > 0
            ? {
                payments: {
                  create: {
                    amount: paidAmount,
                    paymentMethod: data.paymentMethod,
                    recordedById: user.userId,
                    note: 'Initial payment at POS billing checkout',
                  },
                },
              }
            : {}),
        },
        include: {
          items: true,
          payments: true,
          customer: true,
        },
      });

      // 2d. Audit log
      await tx.activityLog.create({
        data: {
          action: 'CREATE_BILL',
          details: `Bill ${billNumber} created for amount $${totalAmount.toFixed(2)} (${status}). Paid: $${paidAmount.toFixed(2)}.`,
          entityType: 'Bill',
          entityId: newBill.id,
          userId: user.userId,
        },
      });

      return newBill;
    });

    return NextResponse.json({ success: true, data: bill });
  } catch (err: any) {
    console.error('[Create bill error]:', err);
    return NextResponse.json({ error: err.message || 'Failed to create bill' }, { status: 500 });
  }
}

import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { commitTempImage, cleanupOldImage, rollbackTempImage } from '@/lib/storage';

const categorySchema = z.object({
  id: z.string().optional(),
  name: z.string().min(2, 'Category name must be at least 2 characters'),
  slug: z.string().min(2, 'Slug must be at least 2 characters'),
  description: z.string().optional().nullable(),
  imageUrl: z.string().optional().nullable(),
  displayOrder: z.number().int().default(0),
  isActive: z.boolean().default(true),
});

export async function GET() {
  try {
    const categories = await prisma.menuCategory.findMany({
      orderBy: { displayOrder: 'asc' },
      include: {
        _count: {
          select: { items: true },
        },
      },
    });

    return NextResponse.json({ success: true, data: categories });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to fetch categories' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let committedUrl: string | null = null;
  let stagedUrl: string | null = null;

  try {
    const body = await req.json();
    const parsed = categorySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message }, { status: 400 });
    }

    stagedUrl = parsed.data.imageUrl || null;

    // Transactional image commit: move from /uploads/temp to /uploads/media
    committedUrl = await commitTempImage(stagedUrl);

    const category = await prisma.menuCategory.create({
      data: {
        name: parsed.data.name,
        slug: parsed.data.slug.toLowerCase().trim().replace(/\s+/g, '-'),
        description: parsed.data.description,
        imageUrl: committedUrl,
        displayOrder: parsed.data.displayOrder,
        isActive: parsed.data.isActive,
      },
    });

    return NextResponse.json({ success: true, data: category });
  } catch (err: any) {
    // Rollback: if database save failed, delete any committed or staged file
    if (committedUrl) await cleanupOldImage(committedUrl);
    if (stagedUrl) await rollbackTempImage(stagedUrl);

    const isDuplicate = err.code === 'P2002';
    return NextResponse.json(
      { error: isDuplicate ? 'A category with this name or slug already exists.' : err.message },
      { status: 400 }
    );
  }
}

export async function PUT(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let newCommittedUrl: string | null = null;
  let stagedUrl: string | null = null;

  try {
    const body = await req.json();
    const { id, ...data } = body;
    if (!id) return NextResponse.json({ error: 'Category ID is required' }, { status: 400 });

    const existing = await prisma.menuCategory.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'Category not found' }, { status: 404 });

    stagedUrl = data.imageUrl || null;

    // If image has changed
    let finalImageUrl = existing.imageUrl;
    if (stagedUrl !== existing.imageUrl) {
      newCommittedUrl = await commitTempImage(stagedUrl);
      finalImageUrl = newCommittedUrl;

      // Delete old image permanently from disk storage
      if (existing.imageUrl && existing.imageUrl !== newCommittedUrl) {
        await cleanupOldImage(existing.imageUrl);
      }
    }

    const updated = await prisma.menuCategory.update({
      where: { id },
      data: {
        name: data.name,
        slug: data.slug?.toLowerCase().trim().replace(/\s+/g, '-'),
        description: data.description,
        imageUrl: finalImageUrl,
        displayOrder: Number(data.displayOrder) || 0,
        isActive: Boolean(data.isActive),
      },
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (err: any) {
    if (newCommittedUrl) await cleanupOldImage(newCommittedUrl);
    if (stagedUrl) await rollbackTempImage(stagedUrl);

    return NextResponse.json({ error: err.message || 'Failed to update category' }, { status: 400 });
  }
}

export async function DELETE(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Category ID is required' }, { status: 400 });

    const category = await prisma.menuCategory.findUnique({
      where: { id },
      include: { items: { select: { imageUrl: true } } },
    });

    if (!category) return NextResponse.json({ error: 'Category not found' }, { status: 404 });

    // 1. Delete associated media permanently from disk
    if (category.imageUrl) await cleanupOldImage(category.imageUrl);
    for (const item of category.items) {
      if (item.imageUrl) await cleanupOldImage(item.imageUrl);
    }

    // 2. Delete category and cascade delete items
    await prisma.menuCategory.delete({ where: { id } });

    return NextResponse.json({ success: true, message: 'Category and associated items deleted' });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to delete category' }, { status: 500 });
  }
}

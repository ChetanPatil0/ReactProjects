import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const [settings, homepage, about, contact, categories, offers, gallery] = await Promise.all([
      prisma.restaurantSetting.findFirst(),
      prisma.homepageContent.findFirst(),
      prisma.aboutContent.findFirst(),
      prisma.contactContent.findFirst(),
      prisma.menuCategory.findMany({
        where: { isActive: true },
        orderBy: { displayOrder: 'asc' },
        include: {
          items: {
            where: { isAvailable: true },
            orderBy: { displayOrder: 'asc' },
          },
        },
      }),
      prisma.offer.findMany({
        where: { isActive: true },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.galleryItem.findMany({
        orderBy: { displayOrder: 'asc' },
      }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        settings,
        homepage,
        about,
        contact,
        categories,
        offers,
        gallery,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

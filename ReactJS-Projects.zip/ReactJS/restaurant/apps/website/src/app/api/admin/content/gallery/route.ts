import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { commitTempImage, cleanupOldImage, rollbackTempImage } from '@/lib/storage';

export async function GET() {
  try {
    const items = await prisma.galleryItem.findMany({
      orderBy: { displayOrder: 'asc' },
    });
    return NextResponse.json({ success: true, data: items });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let committedUrl: string | null = null;
  let stagedUrl: string | null = null;

  try {
    const body = await req.json();
    stagedUrl = body.imageUrl;

    if (!stagedUrl) {
      return NextResponse.json({ error: 'Image URL is required' }, { status: 400 });
    }

    committedUrl = await commitTempImage(stagedUrl);

    const item = await prisma.galleryItem.create({
      data: {
        title: body.title || 'Gallery Photograph',
        caption: body.caption || '',
        category: body.category || 'ambience',
        imageUrl: committedUrl || stagedUrl,
        displayOrder: Number(body.displayOrder) || 0,
      },
    });

    return NextResponse.json({ success: true, data: item });
  } catch (err: any) {
    if (committedUrl) await cleanupOldImage(committedUrl);
    if (stagedUrl) await rollbackTempImage(stagedUrl);
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}

export async function DELETE(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Gallery ID is required' }, { status: 400 });

    const item = await prisma.galleryItem.findUnique({ where: { id } });
    if (!item) return NextResponse.json({ error: 'Item not found' }, { status: 404 });

    // Permanently delete image from disk
    if (item.imageUrl) {
      await cleanupOldImage(item.imageUrl);
    }

    await prisma.galleryItem.delete({ where: { id } });

    return NextResponse.json({ success: true, message: 'Image deleted from gallery' });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

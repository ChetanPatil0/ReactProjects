import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { stageTempUpload, rollbackTempImage } from '@/lib/storage';

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const formData = await req.formData();
    const file = formData.get('file') as File | null;

    if (!file) {
      return NextResponse.json({ error: 'No image file was provided for upload' }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const uploadResult = await stageTempUpload(buffer, file.name, file.type);

    return NextResponse.json({
      success: true,
      data: uploadResult,
    });
  } catch (err: any) {
    console.error('[Upload error]:', err);
    return NextResponse.json(
      { error: err.message || 'Failed to process and store image upload' },
      { status: 400 }
    );
  }
}

export async function DELETE(req: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { url } = await req.json();
    if (url) {
      await rollbackTempImage(url);
    }
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: 'Failed to rollback upload' }, { status: 500 });
  }
}

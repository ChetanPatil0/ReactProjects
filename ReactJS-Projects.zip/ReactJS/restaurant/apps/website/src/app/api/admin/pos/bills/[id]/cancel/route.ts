import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

const cancelSchema = z.object({
  reason: z.string().min(5, 'A valid cancellation reason (at least 5 characters) is required for audit compliance'),
});

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { id } = params;
    const body = await req.json();
    const parsed = cancelSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message }, { status: 400 });
    }

    const { reason } = parsed.data;

    const cancelledBill = await prisma.$transaction(async (tx) => {
      const bill = await tx.bill.findUnique({
        where: { id },
        include: { customer: true },
      });

      if (!bill) {
        throw new Error('Bill not found');
      }

      if (bill.status === 'CANCELLED') {
        throw new Error('This bill is already cancelled');
      }

      // Revert customer spending if customer exists
      if (bill.customerId && bill.paidAmount > 0) {
        await tx.customer.update({
          where: { id: bill.customerId },
          data: {
            totalSpent: { decrement: bill.paidAmount },
          },
        });
      }

      // Mark bill cancelled
      const updated = await tx.bill.update({
        where: { id: bill.id },
        data: {
          status: 'CANCELLED',
          cancelReason: reason,
        },
      });

      // Audit log
      await tx.activityLog.create({
        data: {
          action: 'CANCEL_BILL',
          details: `Bill ${bill.billNumber} was cancelled by ${user.firstName} ${user.lastName}. Reason: "${reason}". Reverted paid amount: $${bill.paidAmount.toFixed(2)}.`,
          entityType: 'Bill',
          entityId: bill.id,
          userId: user.userId,
        },
      });

      return updated;
    });

    return NextResponse.json({ success: true, data: cancelledBill });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to cancel bill' }, { status: 400 });
  }
}

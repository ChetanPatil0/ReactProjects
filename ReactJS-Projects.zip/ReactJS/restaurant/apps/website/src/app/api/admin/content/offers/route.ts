import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { commitTempImage, cleanupOldImage, rollbackTempImage } from '@/lib/storage';

export async function GET() {
  try {
    const offers = await prisma.offer.findMany({
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json({ success: true, data: offers });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let committedUrl: string | null = null;
  let stagedUrl: string | null = null;

  try {
    const body = await req.json();
    stagedUrl = body.imageUrl || null;

    if (stagedUrl) {
      committedUrl = await commitTempImage(stagedUrl);
    }

    const offer = await prisma.offer.create({
      data: {
        title: body.title,
        code: body.code || null,
        discount: body.discount,
        description: body.description,
        badgeText: body.badgeText || 'FEATURED',
        imageUrl: committedUrl || stagedUrl,
        startDate: body.startDate ? new Date(body.startDate) : null,
        endDate: body.endDate ? new Date(body.endDate) : null,
        isActive: body.isActive !== undefined ? Boolean(body.isActive) : true,
      },
    });

    return NextResponse.json({ success: true, data: offer });
  } catch (err: any) {
    if (committedUrl) await cleanupOldImage(committedUrl);
    if (stagedUrl) await rollbackTempImage(stagedUrl);
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}

export async function PUT(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let newCommittedUrl: string | null = null;
  let stagedUrl: string | null = null;

  try {
    const body = await req.json();
    const { id, ...data } = body;
    if (!id) return NextResponse.json({ error: 'Offer ID is required' }, { status: 400 });

    const existing = await prisma.offer.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'Offer not found' }, { status: 404 });

    stagedUrl = data.imageUrl || null;
    let finalImageUrl = existing.imageUrl;

    if (stagedUrl !== existing.imageUrl) {
      newCommittedUrl = await commitTempImage(stagedUrl);
      finalImageUrl = newCommittedUrl;

      if (existing.imageUrl && existing.imageUrl !== newCommittedUrl) {
        await cleanupOldImage(existing.imageUrl);
      }
    }

    const updated = await prisma.offer.update({
      where: { id },
      data: {
        title: data.title,
        code: data.code || null,
        discount: data.discount,
        description: data.description,
        badgeText: data.badgeText || 'FEATURED',
        imageUrl: finalImageUrl,
        startDate: data.startDate ? new Date(data.startDate) : null,
        endDate: data.endDate ? new Date(data.endDate) : null,
        isActive: data.isActive !== undefined ? Boolean(data.isActive) : true,
      },
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (err: any) {
    if (newCommittedUrl) await cleanupOldImage(newCommittedUrl);
    if (stagedUrl) await rollbackTempImage(stagedUrl);
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}

export async function DELETE(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Offer ID is required' }, { status: 400 });

    const existing = await prisma.offer.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'Offer not found' }, { status: 404 });

    if (existing.imageUrl) {
      await cleanupOldImage(existing.imageUrl);
    }

    await prisma.offer.delete({ where: { id } });

    return NextResponse.json({ success: true, message: 'Offer deleted successfully' });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

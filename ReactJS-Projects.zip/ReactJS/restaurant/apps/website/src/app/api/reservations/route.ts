import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const reservationSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').optional(),
  guestName: z.string().min(2, 'Name must be at least 2 characters').optional(),
  phone: z.string().min(8, 'Phone number is required'),
  email: z.string().email().optional().or(z.literal('')),
  date: z.string().min(1, 'Dining date is required'),
  time: z.string().min(1, 'Service time is required'),
  guests: z.union([z.number(), z.string()]).transform((val) => {
    const num = typeof val === 'number' ? val : parseInt(val, 10);
    return isNaN(num) || num < 1 ? 2 : num;
  }),
  area: z.string().optional().default('Main Dining Hall'),
  occasion: z.string().optional(),
  specialRequests: z.string().optional(),
}).refine((data) => data.name || data.guestName, {
  message: 'Guest name is required',
  path: ['name'],
});

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const parsed = reservationSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.errors[0]?.message || 'Invalid reservation details' },
        { status: 400 }
      );
    }

    const { name, guestName, phone, email, date, time, guests, area, occasion, specialRequests } = parsed.data;
    const finalGuestName = (name || guestName || '').trim();

    // Generate unique booking reference e.g. RES-492019
    const reference = `RES-${Math.floor(100000 + Math.random() * 900000)}`;

    const reservation = await prisma.reservation.create({
      data: {
        reference,
        guestName: finalGuestName,
        phone: phone.trim(),
        email: email ? email.trim() : null,
        date,
        time,
        guests,
        area: area || 'Main Dining Hall',
        occasion: occasion || 'Casual Fine Dining',
        specialRequests: specialRequests ? specialRequests.trim() : null,
        status: 'PENDING',
      },
    });

    return NextResponse.json({
      success: true,
      data: reservation,
      message: 'Reservation request successfully submitted. Awaiting concierge host confirmation.',
    });
  } catch (error: any) {
    console.error('Error creating reservation:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to register reservation' },
      { status: 500 }
    );
  }
}

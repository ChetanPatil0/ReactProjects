import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { searchParams } = new URL(req.url);
    const range = searchParams.get('range') || 'today'; // 'today', 'week', 'month', 'all'

    const now = new Date();
    let startDate: Date | undefined;

    if (range === 'today') {
      startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
    } else if (range === 'week') {
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    } else if (range === 'month') {
      startDate = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0);
    }

    const where: any = {};
    if (startDate) {
      where.createdAt = { gte: startDate };
    }

    const bills = await prisma.bill.findMany({
      where,
      include: {
        items: true,
        payments: true,
      },
    });

    // Compute metrics
    let grossSales = 0;
    let totalDiscounts = 0;
    let totalTaxes = 0;
    let netSales = 0;
    let totalCollected = 0;
    let outstandingBalance = 0;

    const paymentModes: Record<string, number> = {
      CASH: 0,
      CARD: 0,
      UPI: 0,
      OTHER: 0,
    };

    let totalBills = 0;
    let paidBills = 0;
    let partialBills = 0;
    let cancelledBills = 0;

    const itemCounts: Record<string, { name: string; quantity: number; revenue: number }> = {};

    for (const bill of bills) {
      totalBills++;

      if (bill.status === 'CANCELLED') {
        cancelledBills++;
        continue;
      }

      if (bill.status === 'PAID') paidBills++;
      if (bill.status === 'PARTIAL') partialBills++;

      grossSales += bill.subtotal;
      totalDiscounts += bill.discountAmount;
      totalTaxes += bill.taxAmount;
      netSales += bill.totalAmount;
      totalCollected += bill.paidAmount;
      outstandingBalance += bill.balanceAmount;

      for (const p of bill.payments) {
        const mode = p.paymentMethod || 'OTHER';
        paymentModes[mode] = (paymentModes[mode] || 0) + p.amount;
      }

      for (const item of bill.items) {
        if (!itemCounts[item.itemName]) {
          itemCounts[item.itemName] = { name: item.itemName, quantity: 0, revenue: 0 };
        }
        itemCounts[item.itemName].quantity += item.quantity;
        itemCounts[item.itemName].revenue += item.totalPrice;
      }
    }

    const topSellingDishes = Object.values(itemCounts)
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 5);

    return NextResponse.json({
      success: true,
      data: {
        grossSales: Math.round(grossSales * 100) / 100,
        totalDiscounts: Math.round(totalDiscounts * 100) / 100,
        totalTaxes: Math.round(totalTaxes * 100) / 100,
        netSales: Math.round(netSales * 100) / 100,
        totalCollected: Math.round(totalCollected * 100) / 100,
        outstandingBalance: Math.round(outstandingBalance * 100) / 100,
        billCounts: {
          total: totalBills,
          paid: paidBills,
          partial: partialBills,
          cancelled: cancelledBills,
        },
        paymentModes,
        topSellingDishes,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to generate report' }, { status: 500 });
  }
}

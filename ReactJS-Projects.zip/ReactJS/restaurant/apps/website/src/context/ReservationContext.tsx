'use client';

import React, { createContext, useContext, useState } from 'react';

export interface ReservationOptions {
  date?: string;
  time?: string;
  guests?: string;
  area?: string;
  occasion?: string;
  dishName?: string;
  offerTitle?: string;
}

interface ReservationContextType {
  isOpen: boolean;
  options: ReservationOptions;
  openReservation: (options?: ReservationOptions) => void;
  closeReservation: () => void;
}

const ReservationContext = createContext<ReservationContextType | undefined>(undefined);

export function ReservationProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [options, setOptions] = useState<ReservationOptions>({});

  const openReservation = (opts: ReservationOptions = {}) => {
    setOptions(opts);
    setIsOpen(true);
  };

  const closeReservation = () => {
    setIsOpen(false);
  };

  return (
    <ReservationContext.Provider value={{ isOpen, options, openReservation, closeReservation }}>
      {children}
    </ReservationContext.Provider>
  );
}

export function useReservation() {
  const context = useContext(ReservationContext);
  if (!context) {
    throw new Error('useReservation must be used within a ReservationProvider');
  }
  return context;
}

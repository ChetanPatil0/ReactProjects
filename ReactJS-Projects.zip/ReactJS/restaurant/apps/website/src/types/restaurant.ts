export interface MediaImage {
  id?: number | string;
  url: string;
  alternativeText?: string;
  width?: number;
  height?: number;
}

export interface RestaurantSettings {
  restaurantName: string;
  tagline: string;
  address: string;
  contactNumber: string;
  contactEmail: string;
  currency: string;
  currencySymbol: string;
  taxRate: number;
  invoicePrefix: string;
  invoicePadding: number;
  invoiceFooter: string;
  timezone: string;
  primaryThemeColor: string;
  logoUrl?: string;
  openingHours?: string;
  receiptHeader?: string;
  receiptTemplate?: string;
}

export interface HomepageData {
  announcement?: string;
  heroTitle: string;
  heroSubtitle?: string;
  introTitle?: string;
  introDescription?: string;
  openingHoursPreview?: string;
  locationHighlight?: string;
  heroImage?: MediaImage;
  introImage?: MediaImage;
}

export interface AboutData {
  title?: string;
  story?: string;
  storyTitle?: string;
  storyContent?: string;
  mission?: string;
  missionTitle?: string;
  missionContent?: string;
  philosophy?: string;
  chefName?: string;
  chefBio?: string;
  storyImage?: MediaImage;
  chefImage?: MediaImage;
  images?: MediaImage[];
}

export interface MenuCategory {
  id: number | string;
  documentId: string;
  name: string;
  slug: string;
  description?: string;
  displayOrder: number;
  isActive: boolean;
  image?: MediaImage;
  menu_items?: MenuItem[];
}

export interface MenuItem {
  id: number | string;
  documentId: string;
  name: string;
  slug: string;
  description?: string;
  price: number;
  foodType: 'veg' | 'non-veg';
  isVeg?: boolean;
  isAvailable: boolean;
  isSignature?: boolean;
  spicyLevel?: number;
  displayOrder: number;
  image?: MediaImage;
  category?: MenuCategory;
}

export interface OfferItem {
  id: number | string;
  documentId: string;
  title: string;
  code?: string;
  discount: string;
  discountValue?: string;
  description: string;
  badgeText?: string;
  startDate?: string;
  endDate?: string;
  validFrom?: string;
  validUntil?: string;
  isActive: boolean;
  bannerImage?: MediaImage;
}

export interface GalleryItem {
  id: number | string;
  documentId: string;
  title: string;
  caption?: string;
  category: string;
  displayOrder: number;
  image: MediaImage;
}

export interface ContactData {
  address: string;
  contactNumber: string;
  phone?: string;
  email: string;
  openingHours: string;
  googleMapsEmbedUrl?: string;
  instagramUrl?: string;
  facebookUrl?: string;
  twitterUrl?: string;
  valetAvailable?: boolean;
}

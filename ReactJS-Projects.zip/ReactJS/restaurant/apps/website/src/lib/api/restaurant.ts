import prisma from "@/lib/prisma";
import {
  RestaurantSettings,
  HomepageData,
  AboutData,
  MenuCategory,
  MenuItem,
  GalleryItem,
  OfferItem,
  ContactData,
} from "@/types/restaurant";

export function getMediaUrl(path?: string, defaultFallback?: string): string {
  if (!path) return defaultFallback || "";
  if (path.startsWith("http://") || path.startsWith("https://") || path.startsWith("/")) {
    return path;
  }
  return `/${path}`;
}

export const fallbackSettings: RestaurantSettings = {
  restaurantName: "Zaffran Haveli",
  tagline: "Royal Awadhi & Mughlai Culinary Atelier",
  address: "Heritage Grand Haveli, Colaba Causeway, Mumbai, Maharashtra 400001",
  contactNumber: "+91 98201 23456",
  contactEmail: "concierge@zaffranhaveli.com",
  currency: "INR",
  currencySymbol: "₹",
  taxRate: 5.0,
  invoicePrefix: "BILL-2026-",
  invoicePadding: 4,
  invoiceFooter: "Dhanyavaad. All prices inclusive of applicable GST (2.5% CGST + 2.5% SGST).",
  timezone: "Asia/Kolkata",
  primaryThemeColor: "#d4af37",
};

export const fallbackHomepage: HomepageData = {
  announcement: "Michelin Guide Selected — Autumn Tasting Journey Now Open for Reservations",
  heroTitle: "A Symphony of Flavors, Crafted with Passion & Precision.",
  heroSubtitle:
    "An intimate culinary sanctuary where ancestral European gastronomy converges with modern avant-garde innovation.",
  introTitle: "THE ART OF INTENTIONAL DINING",
  introDescription:
    "Every dish at L'Étoile is treated as an ephemeral canvas. Handcrafted using ethically harvested heirloom produce, line-caught maritime delicacies, and rare estate vintages.",
  openingHoursPreview: "Dinner: 17:00 — 23:30 | Tue – Sun",
  locationHighlight: "452 Grand Avenue, Beverly Hills, CA 90210",
};

export async function getSettings(): Promise<RestaurantSettings> {
  try {
    const s = await prisma.restaurantSetting.findFirst();
    if (!s) return fallbackSettings;
    return {
      restaurantName: s.name,
      tagline: s.tagline || fallbackSettings.tagline,
      address: s.address || fallbackSettings.address,
      contactNumber: s.phone || fallbackSettings.contactNumber,
      contactEmail: s.email || fallbackSettings.contactEmail,
      currency: "USD",
      currencySymbol: s.currency || "$",
      taxRate: s.taxRate,
      invoicePrefix: "BILL-2026-",
      invoicePadding: 4,
      invoiceFooter: s.receiptFooter || fallbackSettings.invoiceFooter,
      receiptHeader: s.receiptHeader || "L'Étoile Sanctuary — Culinary Excellence",
      openingHours: s.openingHours || "Tue – Sun: 5:00 PM – 11:30 PM | Mon: Closed",
      logoUrl: s.logoUrl || undefined,
      receiptTemplate: s.receiptTemplate || undefined,
      timezone: "America/Los_Angeles",
      primaryThemeColor: "#d4af37",
    };
  } catch (e) {
    return fallbackSettings;
  }
}

export async function getHomepage(): Promise<HomepageData> {
  try {
    const h = await prisma.homepageContent.findFirst();
    if (!h) return fallbackHomepage;
    return {
      announcement: h.announcement || fallbackHomepage.announcement,
      heroTitle: h.heroTitle || fallbackHomepage.heroTitle,
      heroSubtitle: h.heroSubtitle || fallbackHomepage.heroSubtitle,
      introTitle: h.introTitle || fallbackHomepage.introTitle,
      introDescription: h.introDescription || fallbackHomepage.introDescription,
      heroImage: h.heroImageUrl ? { url: h.heroImageUrl } : undefined,
      introImage: h.introImageUrl ? { url: h.introImageUrl } : undefined,
      openingHoursPreview: "Tue – Sun: 5:00 PM – 11:30 PM",
      locationHighlight: "452 Grand Avenue, Beverly Hills, CA 90210",
    };
  } catch (e) {
    return fallbackHomepage;
  }
}

export async function getAbout(): Promise<AboutData> {
  try {
    const a = await prisma.aboutContent.findFirst();
    return {
      storyTitle: a?.storyTitle || "A Legacy of Culinary Artistry",
      storyContent: a?.storyContent || "Founded with an unwavering commitment to sustainable sourcing and culinary artistry.",
      chefName: a?.chefName || "Chef Alessandro Rossi",
      chefBio: a?.chefBio || "Trained in three-star Michelin ateliers across Paris and Milan.",
      missionTitle: a?.missionTitle || "Uncompromising Quality",
      missionContent: a?.missionContent || "We believe dining transcends sustenance — it is a ritual of connection.",
      storyImage: a?.storyImageUrl ? { url: a.storyImageUrl } : undefined,
      chefImage: a?.chefImageUrl ? { url: a.chefImageUrl } : undefined,
    };
  } catch (e) {
    return {
      storyTitle: "A Legacy of Culinary Artistry",
      storyContent: "Founded with an unwavering commitment to sustainable sourcing.",
      chefName: "Chef Alessandro Rossi",
      chefBio: "Michelin-trained culinary artisan.",
    };
  }
}

export async function getMenuCategories(): Promise<MenuCategory[]> {
  try {
    const categories = await prisma.menuCategory.findMany({
      where: { isActive: true },
      orderBy: { displayOrder: "asc" },
      include: {
        items: {
          where: { isAvailable: true },
          orderBy: { displayOrder: "asc" },
        },
      },
    });

    return categories.map((c) => ({
      id: c.id,
      documentId: c.id,
      name: c.name,
      slug: c.slug,
      description: c.description || undefined,
      displayOrder: c.displayOrder,
      isActive: c.isActive,
      image: c.imageUrl ? { url: c.imageUrl } : undefined,
      menu_items: c.items.map((i) => ({
        id: i.id,
        documentId: i.id,
        name: i.name,
        slug: i.slug,
        description: i.description || undefined,
        price: i.price,
        isVeg: i.isVeg,
        foodType: i.isVeg ? "veg" : "non-veg",
        isAvailable: i.isAvailable,
        isSignature: i.isSignature,
        spicyLevel: i.spicyLevel,
        displayOrder: i.displayOrder,
        image: i.imageUrl ? { url: i.imageUrl } : undefined,
      })),
    }));
  } catch (e) {
    return [];
  }
}

export async function getMenuItems(): Promise<MenuItem[]> {
  try {
    const items = await prisma.menuItem.findMany({
      where: { isAvailable: true },
      orderBy: { displayOrder: "asc" },
      include: { category: true },
    });

    return items.map((i) => ({
      id: i.id,
      documentId: i.id,
      name: i.name,
      slug: i.slug,
      description: i.description || undefined,
      price: i.price,
      isVeg: i.isVeg,
      foodType: i.isVeg ? "veg" : "non-veg",
      isAvailable: i.isAvailable,
      isSignature: i.isSignature,
      spicyLevel: i.spicyLevel,
      displayOrder: i.displayOrder,
      image: i.imageUrl ? { url: i.imageUrl } : undefined,
      category: i.category
        ? {
            id: i.category.id,
            documentId: i.category.id,
            name: i.category.name,
            slug: i.category.slug,
            displayOrder: i.category.displayOrder,
            isActive: i.category.isActive,
          }
        : undefined,
    }));
  } catch (e) {
    return [];
  }
}

export async function getOffers(): Promise<OfferItem[]> {
  try {
    const offers = await prisma.offer.findMany({
      where: { isActive: true },
      orderBy: { createdAt: "desc" },
    });

    return offers.map((o) => ({
      id: o.id,
      documentId: o.id,
      title: o.title,
      code: o.code || undefined,
      discount: o.discount,
      discountValue: o.discount,
      description: o.description,
      badgeText: o.badgeText || undefined,
      startDate: o.startDate ? o.startDate.toISOString() : undefined,
      endDate: o.endDate ? o.endDate.toISOString() : undefined,
      isActive: o.isActive,
      bannerImage: o.imageUrl ? { url: o.imageUrl } : undefined,
    }));
  } catch (e) {
    return [];
  }
}

export async function getGallery(): Promise<GalleryItem[]> {
  try {
    const items = await prisma.galleryItem.findMany({
      orderBy: { displayOrder: "asc" },
    });

    return items.map((g) => ({
      id: g.id,
      documentId: g.id,
      title: g.title,
      caption: g.caption || undefined,
      category: g.category,
      displayOrder: g.displayOrder,
      image: { url: g.imageUrl },
    }));
  } catch (e) {
    return [];
  }
}

export async function getContact(): Promise<ContactData> {
  try {
    const [c, s] = await Promise.all([
      prisma.contactContent.findFirst(),
      prisma.restaurantSetting.findFirst(),
    ]);

    return {
      address: s?.address || c?.address || "452 Grand Avenue, Beverly Hills, CA 90210",
      contactNumber: s?.phone || c?.phone || "+1 (555) 234-5678",
      phone: s?.phone || c?.phone || "+1 (555) 234-5678",
      email: s?.email || c?.email || "reservations@letoilerestaurant.com",
      openingHours: s?.openingHours || c?.openingHours || "Tue – Sun: 5:00 PM – 11:30 PM | Mon: Closed",
      googleMapsEmbedUrl: c?.googleMapsUrl || "https://maps.google.com",
      instagramUrl: (c as Record<string, any>)?.instagramUrl || undefined,
      facebookUrl: (c as Record<string, any>)?.facebookUrl || undefined,
      twitterUrl: (c as Record<string, any>)?.twitterUrl || undefined,
      valetAvailable: true,
    };
  } catch (e) {
    return {
      address: "452 Grand Avenue, Beverly Hills, CA 90210",
      contactNumber: "+1 (555) 234-5678",
      phone: "+1 (555) 234-5678",
      email: "reservations@letoilerestaurant.com",
      openingHours: "Tue – Sun: 5:00 PM – 11:30 PM | Mon: Closed",
      valetAvailable: true,
    };
  }
}

export const getRestaurantSettings = getSettings;
export const getHomepageData = getHomepage;
export const getAboutData = getAbout;
export const getContactData = getContact;
export const getGalleryItems = getGallery;
export const getOffersData = getOffers;

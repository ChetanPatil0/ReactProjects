export interface ReceiptItem {
  itemName: string;
  unitPrice: number;
  quantity: number;
  totalPrice?: number;
}

export interface ReceiptData {
  restaurantName: string;
  tagline?: string | null;
  logoUrl?: string | null;
  address?: string | null;
  phone?: string | null;
  email?: string | null;
  openingHours?: string | null;
  receiptHeader?: string | null;
  receiptFooter?: string | null;
  currency?: string;

  billNumber: string;
  orderType: string;
  tableNumber?: string | null;
  createdAt: string | Date;
  customerName?: string | null;
  customerPhone?: string | null;
  cashierName?: string | null;

  items: ReceiptItem[];
  subtotal: number;
  discountAmount: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  paidAmount: number;
  balanceAmount: number;
  paymentMethod: string;
}

export const DEFAULT_RECEIPT_HTML_TEMPLATE = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Receipt {{bill_number}}</title>
  <style>
    @media print {
      body {
        margin: 0;
        padding: 0;
        background: #ffffff !important;
        color: #000000 !important;
      }
      .no-print {
        display: none !important;
      }
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      font-size: 11px;
      line-height: 1.4;
      color: #111111;
      background: #ffffff;
      margin: 0;
      padding: 16px;
      max-width: 320px;
      margin-left: auto;
      margin-right: auto;
    }
    .text-center { text-align: center; }
    .text-right { text-align: right; }
    .font-bold { font-weight: 700; }
    .font-mono { font-family: 'Courier New', Courier, monospace; }
    .uppercase { text-transform: uppercase; }
    .logo-container {
      margin-bottom: 8px;
      text-align: center;
    }
    .logo-img {
      max-height: 52px;
      max-width: 140px;
      object-fit: contain;
      margin: 0 auto;
      display: block;
    }
    .title {
      font-size: 15px;
      font-weight: 800;
      letter-spacing: 0.05em;
      margin: 2px 0;
    }
    .subtitle {
      font-size: 10px;
      color: #555;
      margin: 0 0 6px 0;
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }
    .meta-line {
      font-size: 9.5px;
      color: #444;
      margin: 1px 0;
    }
    .divider {
      border-top: 1px dashed #777;
      margin: 8px 0;
    }
    .divider-double {
      border-top: 2px solid #111;
      margin: 8px 0;
    }
    .info-grid {
      display: flex;
      justify-content: space-between;
      font-size: 10px;
      margin: 2px 0;
    }
    table.items-table {
      width: 100%;
      border-collapse: collapse;
      margin: 6px 0;
      font-size: 10px;
    }
    table.items-table th {
      border-bottom: 1px dashed #777;
      padding: 4px 0;
      text-align: left;
      font-weight: 700;
      font-size: 9.5px;
    }
    table.items-table td {
      padding: 4px 0;
      vertical-align: top;
    }
    .summary-row {
      display: flex;
      justify-content: space-between;
      font-size: 10.5px;
      margin: 2px 0;
    }
    .grand-total {
      font-size: 14px;
      font-weight: 800;
      padding-top: 4px;
      border-top: 1px solid #111;
      margin-top: 4px;
    }
    .footer-note {
      font-size: 9px;
      color: #666;
      margin-top: 10px;
      line-height: 1.35;
    }
    .barcode-line {
      font-family: 'Libre Barcode 39', 'Courier New', monospace;
      font-size: 18px;
      letter-spacing: 3px;
      margin: 8px 0 2px 0;
    }
  </style>
</head>
<body>
  <div class="text-center">
    {{logo_html}}
    <div class="title">{{restaurant_name}}</div>
    <div class="subtitle">{{restaurant_tagline}}</div>
    <div class="meta-line">{{address}}</div>
    <div class="meta-line">Tel: {{phone}} • {{email}}</div>
    <div class="meta-line">{{opening_hours}}</div>
  </div>

  <div class="divider"></div>

  <div class="info-grid font-bold">
    <span>BILL #: {{bill_number}}</span>
    <span>{{order_type}}</span>
  </div>
  <div class="info-grid">
    <span>TABLE: {{table_number}}</span>
    <span>CASHIER: {{cashier_name}}</span>
  </div>
  <div class="info-grid">
    <span>DATE: {{date}}</span>
    <span>TIME: {{time}}</span>
  </div>
  {{customer_info_html}}

  <div class="divider"></div>

  {{items_table_html}}

  <div class="divider"></div>

  <div class="summary-row">
    <span>Subtotal</span>
    <span class="font-mono">{{currency}}{{subtotal}}</span>
  </div>
  {{discount_row_html}}
  <div class="summary-row">
    <span>Local Tax ({{tax_rate}}%)</span>
    <span class="font-mono">{{currency}}{{tax_amount}}</span>
  </div>
  <div class="summary-row grand-total font-bold">
    <span>TOTAL DUE</span>
    <span class="font-mono">{{currency}}{{grand_total}}</span>
  </div>
  <div class="summary-row font-bold" style="padding-top: 4px;">
    <span>PAID ({{payment_method}})</span>
    <span class="font-mono">{{currency}}{{paid_amount}}</span>
  </div>
  {{balance_row_html}}

  <div class="divider"></div>

  <div class="text-center">
    <div class="font-bold" style="font-size: 10px;">{{receipt_header}}</div>
    <div class="footer-note">{{receipt_footer}}</div>
    <div class="barcode-line">*{{bill_number}}*</div>
    <div style="font-size: 8px; color: #888;">Thank you for your valued patronage!</div>
  </div>
</body>
</html>`;

export const SAMPLE_RECEIPT_DATA: ReceiptData = {
  restaurantName: 'Zaffran Haveli',
  tagline: 'Royal Awadhi & Mughlai Culinary Atelier',
  logoUrl: '',
  address: 'Heritage Grand Haveli, Colaba Causeway, Mumbai, Maharashtra 400001',
  phone: '+91 98201 23456',
  email: 'concierge@zaffranhaveli.com',
  openingHours: 'Tue – Sun: 12:30 PM – 3:30 PM, 7:00 PM – 11:45 PM',
  receiptHeader: 'Zaffran Haveli — Royal Awadhi Gastronomy',
  receiptFooter: 'Dhanyavaad. All prices inclusive of applicable GST (2.5% CGST + 2.5% SGST).',
  currency: '₹',
  billNumber: 'BILL-2026-0042',
  orderType: 'DINE_IN',
  tableNumber: 'Table 4',
  createdAt: new Date().toISOString(),
  customerName: 'Aarav Malhotra',
  customerPhone: '+91 98201 99882',
  cashierName: 'Rohan Verma',
  items: [
    { itemName: 'Awadhi Dum Gosht Biryani', unitPrice: 825.0, quantity: 2 },
    { itemName: 'Shahi Galouti Kebab', unitPrice: 795.0, quantity: 2 },
    { itemName: 'Dal Dum Pukht (Makhani)', unitPrice: 545.0, quantity: 1 },
    { itemName: 'Zaffrani Sheermal', unitPrice: 195.0, quantity: 4 },
  ],
  subtotal: 4565.0,
  discountAmount: 200.0,
  taxRate: 5.0,
  taxAmount: 218.25,
  totalAmount: 4583.25,
  paidAmount: 4583.25,
  balanceAmount: 0.0,
  paymentMethod: 'UPI',
};

export function renderReceiptHtml(customTemplate: string | null | undefined, data: ReceiptData): string {
  const template = customTemplate && customTemplate.trim().length > 30
    ? customTemplate
    : DEFAULT_RECEIPT_HTML_TEMPLATE;

  const dateObj = new Date(data.createdAt || Date.now());
  const formattedDate = dateObj.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
  const formattedTime = dateObj.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });

  const currency = data.currency || '₹';

  // Build items table HTML
  let itemsHtml = `
    <table class="items-table">
      <thead>
        <tr>
          <th>ITEM</th>
          <th style="text-align: center; width: 35px;">QTY</th>
          <th style="text-align: right; width: 65px;">AMT</th>
        </tr>
      </thead>
      <tbody>`;

  for (const it of data.items || []) {
    const itemTotal = (it.unitPrice * it.quantity).toFixed(2);
    itemsHtml += `
      <tr>
        <td style="padding-right: 4px;">${it.itemName}</td>
        <td style="text-align: center;">${it.quantity}</td>
        <td style="text-align: right;" class="font-mono">${currency}${itemTotal}</td>
      </tr>`;
  }
  itemsHtml += `</tbody></table>`;

  // Logo html
  const logoHtml = data.logoUrl
    ? `<div class="logo-container"><img src="${data.logoUrl}" alt="${data.restaurantName}" class="logo-img" /></div>`
    : '';

  // Customer info html
  const customerInfoHtml = data.customerName || data.customerPhone
    ? `<div class="info-grid" style="color: #444; font-size: 9.5px;">
        <span>GUEST: ${data.customerName || 'Patron'}</span>
        <span>${data.customerPhone || ''}</span>
      </div>`
    : '';

  // Discount row
  const discountRowHtml = data.discountAmount > 0
    ? `<div class="summary-row" style="color: #2e7d32;">
        <span>Discount</span>
        <span class="font-mono">-${currency}${data.discountAmount.toFixed(2)}</span>
      </div>`
    : '';

  // Balance row
  const balanceRowHtml = data.balanceAmount > 0
    ? `<div class="summary-row" style="color: #c62828; font-weight: bold;">
        <span>BALANCE DUE</span>
        <span class="font-mono">${currency}${data.balanceAmount.toFixed(2)}</span>
      </div>`
    : '';

  // Replacement mapping
  const map: Record<string, string> = {
    '{{logo_html}}': logoHtml,
    '{{logo_url}}': data.logoUrl || '',
    '{{restaurant_name}}': data.restaurantName || 'Zaffran Haveli',
    '{{restaurant_tagline}}': data.tagline || 'Royal Awadhi & Mughlai Atelier',
    '{{address}}': data.address || '',
    '{{phone}}': data.phone || '',
    '{{email}}': data.email || '',
    '{{opening_hours}}': data.openingHours || '',
    '{{receipt_header}}': data.receiptHeader || '',
    '{{receipt_footer}}': data.receiptFooter || '',
    '{{currency}}': currency,
    '{{bill_number}}': data.billNumber || '',
    '{{order_type}}': (data.orderType || 'DINE_IN').replace('_', ' '),
    '{{table_number}}': data.tableNumber || 'Walk-in',
    '{{date}}': formattedDate,
    '{{time}}': formattedTime,
    '{{customer_name}}': data.customerName || 'Valued Guest',
    '{{customer_phone}}': data.customerPhone || '',
    '{{cashier_name}}': data.cashierName || 'Register #01',
    '{{items_table_html}}': itemsHtml,
    '{{customer_info_html}}': customerInfoHtml,
    '{{discount_row_html}}': discountRowHtml,
    '{{balance_row_html}}': balanceRowHtml,
    '{{subtotal}}': data.subtotal.toFixed(2),
    '{{discount}}': data.discountAmount.toFixed(2),
    '{{tax_rate}}': data.taxRate.toString(),
    '{{tax_amount}}': data.taxAmount.toFixed(2),
    '{{grand_total}}': data.totalAmount.toFixed(2),
    '{{paid_amount}}': data.paidAmount.toFixed(2),
    '{{balance_amount}}': data.balanceAmount.toFixed(2),
    '{{payment_method}}': data.paymentMethod || 'CASH',
  };

  let output = template;
  for (const [key, val] of Object.entries(map)) {
    // Replace all occurrences
    output = output.split(key).join(val);
  }

  return output;
}

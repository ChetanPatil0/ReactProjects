import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const UPLOAD_ROOT = path.join(process.cwd(), 'public', 'uploads');
const TEMP_DIR = path.join(UPLOAD_ROOT, 'temp');
const MEDIA_DIR = path.join(UPLOAD_ROOT, 'media');

// Ensure base directories exist on boot
export function ensureStorageDirectories(): void {
  if (!fs.existsSync(UPLOAD_ROOT)) fs.mkdirSync(UPLOAD_ROOT, { recursive: true });
  if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });
  if (!fs.existsSync(MEDIA_DIR)) fs.mkdirSync(MEDIA_DIR, { recursive: true });
}

// Allowed MIME types and extensions
const ALLOWED_MIME_TYPES: Record<string, string> = {
  'image/jpeg': '.jpg',
  'image/jpg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
  'image/avif': '.avif',
  'image/gif': '.gif',
};

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB

export interface UploadResult {
  url: string;
  filename: string;
  size: number;
}

/**
 * Stage an uploaded file into the temporary directory.
 * The file stays in /uploads/temp until form submission confirms the transaction.
 */
export async function stageTempUpload(
  buffer: Buffer,
  originalFilename: string,
  mimeType: string
): Promise<UploadResult> {
  ensureStorageDirectories();

  // 1. Validation
  const ext = ALLOWED_MIME_TYPES[mimeType.toLowerCase()];
  if (!ext) {
    throw new Error(`Invalid file type (${mimeType}). Supported formats: JPEG, PNG, WEBP, AVIF, GIF.`);
  }

  if (buffer.length > MAX_FILE_SIZE) {
    throw new Error(`File is too large (${(buffer.length / (1024 * 1024)).toFixed(2)} MB). Maximum allowed size is 5 MB.`);
  }

  // 2. Generate secure UUID filename (prevent directory traversal or malicious names)
  const uniqueId = crypto.randomUUID();
  const filename = `temp-${uniqueId}${ext}`;
  const filePath = path.join(TEMP_DIR, filename);

  // 3. Write file to temp directory
  await fs.promises.writeFile(filePath, buffer);

  return {
    url: `/uploads/temp/${filename}`,
    filename,
    size: buffer.length,
  };
}

/**
 * Commit a temporary image to permanent media storage.
 * Call this inside form/API transaction when the record is saved.
 */
export async function commitTempImage(tempUrl: string | null | undefined): Promise<string | null> {
  if (!tempUrl) return null;

  // If already in permanent storage or external (http/https), return as is
  if (!tempUrl.startsWith('/uploads/temp/')) {
    return tempUrl;
  }

  ensureStorageDirectories();

  const tempFilename = path.basename(tempUrl);
  const tempFilePath = path.join(TEMP_DIR, tempFilename);

  if (!fs.existsSync(tempFilePath)) {
    // If temp file does not exist, return null
    return null;
  }

  const ext = path.extname(tempFilename);
  const permanentFilename = `img-${crypto.randomUUID()}${ext}`;
  const permanentFilePath = path.join(MEDIA_DIR, permanentFilename);

  // Atomically move from temp to permanent media
  await fs.promises.rename(tempFilePath, permanentFilePath);

  return `/uploads/media/${permanentFilename}`;
}

/**
 * Permanently delete an old image from media or temp storage.
 * Eliminates garbage files when an image is replaced or an entity is deleted.
 */
export async function cleanupOldImage(imageUrl: string | null | undefined): Promise<void> {
  if (!imageUrl) return;

  // Only remove files belonging to local /uploads/
  if (!imageUrl.startsWith('/uploads/')) return;

  try {
    const filename = path.basename(imageUrl);
    const subfolder = imageUrl.startsWith('/uploads/temp/') ? TEMP_DIR : MEDIA_DIR;
    const filePath = path.join(subfolder, filename);

    if (fs.existsSync(filePath)) {
      await fs.promises.unlink(filePath);
    }
  } catch (err) {
    console.warn(`[Storage] Failed to unlink image ${imageUrl}:`, err);
  }
}

/**
 * Rollback/discard a temporary image if form submission failed.
 */
export async function rollbackTempImage(tempUrl: string | null | undefined): Promise<void> {
  if (!tempUrl || !tempUrl.startsWith('/uploads/temp/')) return;

  try {
    const filename = path.basename(tempUrl);
    const filePath = path.join(TEMP_DIR, filename);
    if (fs.existsSync(filePath)) {
      await fs.promises.unlink(filePath);
    }
  } catch (err) {
    console.warn(`[Storage] Failed to rollback temp image ${tempUrl}:`, err);
  }
}

/**
 * Periodically purge abandoned temp files older than 2 hours.
 */
export async function purgeStaleTempFiles(olderThanMs = 2 * 60 * 60 * 1000): Promise<number> {
  ensureStorageDirectories();
  let deletedCount = 0;
  const now = Date.now();

  try {
    const files = await fs.promises.readdir(TEMP_DIR);
    for (const file of files) {
      const fullPath = path.join(TEMP_DIR, file);
      const stat = await fs.promises.stat(fullPath);
      if (now - stat.mtimeMs > olderThanMs) {
        await fs.promises.unlink(fullPath);
        deletedCount++;
      }
    }
  } catch (err) {
    console.warn('[Storage] Error during temp purge:', err);
  }

  return deletedCount;
}

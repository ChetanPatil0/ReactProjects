import React from "react";

export interface FoodBadgeProps {
  type?: "veg" | "non-veg";
  foodType?: "veg" | "non-veg";
  isVeg?: boolean;
  className?: string;
  showText?: boolean;
}

export function FoodBadge({ type, foodType, isVeg: isVegProp, className = "", showText = false }: FoodBadgeProps) {
  const isVeg = isVegProp !== undefined ? isVegProp : (foodType === "veg" || type === "veg");

  return (
    <div className={`inline-flex items-center gap-1.5 ${className}`}>
      <span
        className={`w-4 h-4 rounded-sm border flex items-center justify-center p-0.5 ${
          isVeg ? "border-emerald-500 bg-emerald-950/40" : "border-rose-500 bg-rose-950/40"
        }`}
        title={isVeg ? "Vegetarian" : "Non-Vegetarian"}
      >
        <span className={`w-2 h-2 rounded-full ${isVeg ? "bg-emerald-500" : "bg-rose-500"}`} />
      </span>
      {showText && (
        <span className={`text-xs font-medium tracking-wide uppercase ${isVeg ? "text-emerald-400" : "text-rose-400"}`}>
          {isVeg ? "Veg" : "Non-Veg"}
        </span>
      )}
    </div>
  );
}

'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CheckCircle2,
  ArrowUpRight,
  Calendar,
  Clock,
  Users,
  User,
  Phone,
  Mail,
  Sparkles,
  UtensilsCrossed,
  ShieldCheck,
} from 'lucide-react';

export function ReservationForm() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [bookingRef, setBookingRef] = useState('');
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    guests: '2',
    date: '',
    time: '19:30',
    area: 'Main Dining Hall',
    notes: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/reservations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name,
          phone: form.phone,
          email: form.email,
          date: form.date,
          time: form.time,
          guests: parseInt(form.guests, 10) || 2,
          area: form.area,
          occasion: 'Online Concierge Inquiry',
          specialRequests: form.notes,
        }),
      });

      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || 'Failed to register reservation');
      }

      setBookingRef(json.data.reference);
      setSubmitted(true);
    } catch (err: any) {
      alert(err.message || 'Failed to submit reservation');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        {submitted ? (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="p-10 sm:p-14 rounded-3xl bg-white dark:bg-[#12141e] border border-stone-200 dark:border-[#d4af37]/40 text-center space-y-6 shadow-md dark:shadow-2xl"
          >
            <div className="w-16 h-16 rounded-full bg-amber-500/15 border border-amber-400/40 flex items-center justify-center text-amber-500 dark:text-amber-400 mx-auto">
              <Clock className="w-8 h-8" />
            </div>
            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/15 border border-amber-400/30 text-amber-600 dark:text-amber-300 text-[11px] font-bold tracking-wider uppercase">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                <span>Pending Host Approval</span>
              </div>
              <span className="text-[11px] font-mono tracking-widest uppercase text-stone-400 block">
                Request Ref: #{bookingRef}
              </span>
              <h3 className="text-3xl font-serif text-stone-900 dark:text-white font-light">Table Request Received</h3>
              <p className="text-stone-600 dark:text-stone-300 text-sm max-w-md mx-auto leading-relaxed">
                Thank you, <strong className="text-amber-600 dark:text-[#e5c378]">{form.name}</strong>. Your reservation request for{' '}
                {form.guests} guests on <strong className="text-stone-900 dark:text-white">{form.date || 'your selected date'}</strong> at{' '}
                <strong className="text-stone-900 dark:text-white">{form.time}</strong> ({form.area}) has been placed in our review queue.
              </p>
              {/* Next Steps: Call & SMS Confirmation Notice */}
              <div className="text-left text-xs max-w-md mx-auto bg-gradient-to-br from-amber-500/10 via-stone-50 dark:via-zinc-900/90 to-stone-50 dark:to-zinc-900 border border-amber-500/35 p-4 rounded-2xl space-y-2.5 shadow-md">
                <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300 font-bold text-xs uppercase tracking-wider pb-1 border-b border-amber-500/20">
                  <Phone className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  <span>Next Steps: Call & SMS Confirmation</span>
                </div>

                <div className="space-y-1.5 text-[11px] text-stone-600 dark:text-stone-300 leading-relaxed">
                  <p className="flex items-start gap-2">
                    <span className="text-amber-600 dark:text-amber-400 font-bold">1.</span>
                    <span>
                      Our maître d&apos; desk is checking table capacity. <strong className="text-stone-900 dark:text-white">You will receive a phone call or SMS confirmation</strong> on your number <strong className="text-amber-700 dark:text-amber-300 font-mono">({form.phone})</strong> once your reservation is confirmed.
                    </span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span className="text-amber-600 dark:text-amber-400 font-bold">2.</span>
                    <span>
                      For immediate bookings, customized menus, or urgent table modifications, please contact our host desk directly.
                    </span>
                  </p>
                </div>
              </div>
            </div>
            <button
              onClick={() => {
                setSubmitted(false);
                setForm({
                  name: '',
                  phone: '',
                  email: '',
                  guests: '2',
                  date: '',
                  time: '19:30',
                  area: 'Main Dining Hall',
                  notes: '',
                });
              }}
              className="px-8 py-3 rounded-full bg-linear-to-r from-[#d4af37] via-[#f7e6c4] to-[#d4af37] text-stone-950 text-xs font-bold uppercase tracking-[0.16em] hover:scale-105 active:scale-95 transition-all shadow-lg shadow-[#d4af37]/25 cursor-pointer"
            >
              Book Another Table
            </button>
          </motion.div>
        ) : (
          <motion.form
            key="form"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onSubmit={handleSubmit}
            className="p-8 sm:p-12 rounded-3xl bg-white dark:bg-[#12141e]/90 border border-stone-200 dark:border-white/10 space-y-7 shadow-md dark:shadow-2xl"
          >
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/30 text-amber-700 dark:text-[#e5c378] text-[11px] font-semibold tracking-wider uppercase">
                <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>Concierge Desk Booking</span>
              </div>
              <h2 className="text-3xl font-serif text-stone-900 dark:text-white font-light">Reserve Your Table</h2>
              <p className="text-xs text-stone-500 dark:text-stone-400 font-light">
                Evening reservations are recommended 48 hours in advance. For tasting flights or private salons, please specify below.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="space-y-2">
                <label className="text-xs font-medium tracking-wider text-stone-700 dark:text-stone-300 uppercase flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>Full Name *</span>
                </label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g. Lord Sterling"
                  className="w-full px-4 py-3 rounded-2xl bg-stone-50 dark:bg-[#090a0e] border border-stone-200 dark:border-white/10 text-stone-900 dark:text-stone-100 text-xs tracking-wider focus:outline-hidden focus:border-[#d4af37] transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium tracking-wider text-stone-700 dark:text-stone-300 uppercase flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>Mobile Phone *</span>
                </label>
                <input
                  type="tel"
                  required
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="+1 (555) 234-5678"
                  className="w-full px-4 py-3 rounded-2xl bg-stone-50 dark:bg-[#090a0e] border border-stone-200 dark:border-white/10 text-stone-900 dark:text-stone-100 text-xs tracking-wider focus:outline-hidden focus:border-[#d4af37] transition-colors"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium tracking-wider text-stone-700 dark:text-stone-300 uppercase flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>Email Address *</span>
              </label>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="sterling@sanctuary.com"
                className="w-full px-4 py-3 rounded-2xl bg-stone-50 dark:bg-[#090a0e] border border-stone-200 dark:border-white/10 text-stone-900 dark:text-stone-100 text-xs tracking-wider focus:outline-hidden focus:border-[#d4af37] transition-colors"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div className="space-y-2">
                <label className="text-xs font-medium tracking-wider text-stone-700 dark:text-stone-300 uppercase flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>Guests</span>
                </label>
                <select
                  value={form.guests}
                  onChange={(e) => setForm({ ...form, guests: e.target.value })}
                  className="w-full px-4 py-3 rounded-2xl bg-stone-50 dark:bg-[#090a0e] border border-stone-200 dark:border-white/10 text-stone-900 dark:text-stone-100 text-xs tracking-wider focus:outline-hidden focus:border-[#d4af37] transition-colors"
                >
                  <option value="1">1 Guest</option>
                  <option value="2">2 Guests</option>
                  <option value="3">3 Guests</option>
                  <option value="4">4 Guests</option>
                  <option value="6">6 Guests</option>
                  <option value="8+">8+ Guests (Salon)</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium tracking-wider text-stone-700 dark:text-stone-300 uppercase flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>Date</span>
                </label>
                <input
                  type="date"
                  required
                  value={form.date}
                  onChange={(e) => setForm({ ...form, date: e.target.value })}
                  className="w-full px-4 py-3 rounded-2xl bg-stone-50 dark:bg-[#090a0e] border border-stone-200 dark:border-white/10 text-stone-900 dark:text-stone-100 text-xs tracking-wider focus:outline-hidden focus:border-[#d4af37] transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium tracking-wider text-stone-300 uppercase flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>Time</span>
                </label>
                <select
                  value={form.time}
                  onChange={(e) => setForm({ ...form, time: e.target.value })}
                  className="w-full px-4 py-3 rounded-2xl bg-[#090a0e] border border-white/10 text-stone-100 text-xs tracking-wider focus:outline-hidden focus:border-[#d4af37] transition-colors"
                >
                  <option value="12:30">12:30 PM (Lunch)</option>
                  <option value="13:30">01:30 PM (Lunch)</option>
                  <option value="18:00">06:00 PM</option>
                  <option value="19:00">07:00 PM</option>
                  <option value="19:30">07:30 PM (Peak)</option>
                  <option value="20:30">08:30 PM</option>
                  <option value="21:15">09:15 PM</option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium tracking-wider text-stone-300 uppercase flex items-center gap-1.5">
                <UtensilsCrossed className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>Special Requests & Dietary Requirements</span>
              </label>
              <textarea
                rows={3}
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                placeholder="Mention anniversary celebrations, wine preferences, or specific allergies..."
                className="w-full px-4 py-3 rounded-2xl bg-[#090a0e] border border-white/10 text-stone-100 text-xs tracking-wider focus:outline-hidden focus:border-[#d4af37] transition-colors"
              />
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-white/[0.08]">
              <div className="flex items-center gap-2 text-xs text-stone-400">
                <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
                <span>Host approval required before table confirmation</span>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-linear-to-r from-[#d4af37] via-[#f7e6c4] to-[#d4af37] text-stone-950 text-xs font-bold uppercase tracking-[0.18em] hover:scale-105 active:scale-95 transition-all shadow-xl shadow-[#d4af37]/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <span>Submitting Request...</span>
                ) : (
                  <>
                    <span>Submit Reservation Request</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>
    </div>
  );
}

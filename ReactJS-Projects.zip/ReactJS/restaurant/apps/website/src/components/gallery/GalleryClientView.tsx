'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Sparkles, Eye, Image as ImageIcon, ZoomIn, Calendar } from 'lucide-react';
import { GalleryItem } from '@/types/restaurant';
import { getMediaUrl } from '@/lib/api/restaurant';
import { useReservation } from '@/context/ReservationContext';

interface GalleryClientViewProps {
  items: GalleryItem[];
}

export function GalleryClientView({ items }: GalleryClientViewProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeItem, setActiveItem] = useState<GalleryItem | null>(null);
  const { openReservation } = useReservation();

  const categories = [
    { label: 'Full Archive', value: 'all' },
    { label: 'Sanctuary Interiors', value: 'ambiance' },
    { label: 'Culinary Plating', value: 'food' },
    { label: 'Botanical Cellar', value: 'drinks' },
    { label: 'Private Salons', value: 'events' },
  ];

  const filteredItems = items.filter((item) => {
    if (selectedCategory === 'all') return true;
    return item.category === selectedCategory;
  });

  return (
    <div className="space-y-12">
      {/* Category Pills Navigation with Sliding Motion */}
      <div className="flex items-center justify-center gap-2 flex-wrap">
        {categories.map((cat) => (
          <button
            key={cat.value}
            onClick={() => setSelectedCategory(cat.value)}
            className={`relative px-6 py-2.5 rounded-full text-xs font-semibold uppercase tracking-[0.16em] transition-all cursor-pointer ${
              selectedCategory === cat.value ? 'text-stone-950 font-bold' : 'text-stone-400 hover:text-white'
            }`}
          >
            {selectedCategory === cat.value && (
              <motion.div
                layoutId="activeGalleryCategory"
                className="absolute inset-0 bg-linear-to-r from-[#d4af37] via-[#f7e6c4] to-[#d4af37] rounded-full shadow-lg shadow-[#d4af37]/25"
                transition={{ type: 'spring', stiffness: 350, damping: 30 }}
              />
            )}
            <span className="relative z-10">{cat.label}</span>
          </button>
        ))}
      </div>

      {/* Grid with Framer Motion Layout Transitions */}
      <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        <AnimatePresence>
          {filteredItems.map((item) => {
            const imgUrl = getMediaUrl(item.image?.url);
            return (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                key={item.id}
                onClick={() => setActiveItem(item)}
                className="group relative aspect-4/3 rounded-3xl overflow-hidden border border-white/10 bg-[#12141e] cursor-pointer hover:border-[#d4af37]/50 transition-all duration-500 shadow-xl hover:shadow-2xl hover:shadow-black/60"
              >
                {imgUrl ? (
                  <img
                    src={imgUrl}
                    alt={item.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-stone-900 text-stone-600">
                    <ImageIcon className="w-12 h-12 text-[#d4af37]/40" />
                  </div>
                )}
                <div className="absolute inset-0 bg-linear-to-t from-black via-black/30 to-transparent opacity-70 group-hover:opacity-90 transition-opacity" />

                <div className="absolute inset-0 p-6 flex flex-col justify-between">
                  <span className="inline-block px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-[10px] tracking-[0.2em] uppercase font-semibold text-[#e5c378] self-start">
                    {item.category}
                  </span>

                  <div className="space-y-1">
                    <h3 className="font-serif text-xl text-white group-hover:text-[#e5c378] transition-colors">
                      {item.title}
                    </h3>
                    <div className="flex items-center gap-1.5 text-xs text-stone-400 group-hover:text-stone-200 transition-colors">
                      <ZoomIn className="w-3.5 h-3.5 text-[#d4af37]" />
                      <span>Expand View</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </motion.div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {activeItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveItem(null)}
              className="fixed inset-0 bg-black/40 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative max-w-4xl w-full rounded-3xl overflow-hidden border border-[#d4af37]/35 bg-[#090b10]/85 backdrop-blur-2xl shadow-2xl shadow-black/50 z-10"
            >
              <div className="relative aspect-16/10 bg-black/40">
                {activeItem.image?.url && (
                  <img
                    src={getMediaUrl(activeItem.image.url)}
                    alt={activeItem.title}
                    className="w-full h-full object-contain"
                  />
                )}
                <button
                  onClick={() => setActiveItem(null)}
                  className="absolute top-4 right-4 p-2 rounded-full bg-black/50 text-stone-300 hover:text-white border border-white/20 transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-6 bg-white/[0.03] backdrop-blur-md flex items-center justify-between border-t border-white/10">
                <div>
                  <span className="text-[10px] uppercase tracking-widest text-[#d4af37] font-semibold block mb-1">
                    {activeItem.category}
                  </span>
                  <h4 className="font-serif text-xl text-white">{activeItem.title}</h4>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      setActiveItem(null);
                      openReservation();
                    }}
                    className="px-5 py-2.5 rounded-full bg-linear-to-r from-[#d4af37] via-[#f7e6c4] to-[#d4af37] text-stone-950 text-xs font-bold uppercase tracking-wider"
                  >
                    Reserve In This Space
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

'use client';

import React from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Sparkles, Utensils, HeartHandshake, ShieldCheck, ArrowRight, Award, Quote, Calendar } from 'lucide-react';
import { AboutData, RestaurantSettings } from '@/types/restaurant';
import { getMediaUrl } from '@/lib/api/restaurant';
import { useReservation } from '@/context/ReservationContext';

interface AboutClientViewProps {
  about: AboutData;
  settings: RestaurantSettings;
}

export function AboutClientView({ about, settings }: AboutClientViewProps) {
  const { openReservation } = useReservation();
  const storyImg = about.storyImage?.url ? getMediaUrl(about.storyImage.url) : null;
  const chefImg = about.chefImage?.url ? getMediaUrl(about.chefImage.url) : null;

  return (
    <div className="pt-6 sm:pt-10 pb-20 sm:pb-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-24">
      {/* Editorial Header */}
      <div className="text-center max-w-4xl mx-auto space-y-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center gap-2.5 px-5 py-2 rounded-full border border-[#d4af37]/30 bg-[#d4af37]/10 text-[#e5c378] text-xs tracking-[0.2em] uppercase font-semibold"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>{settings.restaurantName} Heritage</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.15 }}
          className="text-4xl sm:text-6xl md:text-7xl font-serif font-light text-stone-900 dark:text-white tracking-tight leading-[1.08]"
        >
          {about.storyTitle || 'A Legacy of Culinary Innovation & Warmth'}
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-stone-600 dark:text-stone-300 text-base sm:text-xl font-light leading-relaxed max-w-3xl mx-auto"
        >
          {about.storyContent || about.story || 'Founded with an uncompromising commitment to biodynamic foraged ingredients, artisanal craftsmanship, and the sacred ritual of gathered hospitality.'}
        </motion.p>
      </div>

      {/* Visual Showcase */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {storyImg && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative aspect-16/11 rounded-3xl overflow-hidden border border-[#d4af37]/30 shadow-2xl bg-[#12141d]"
          >
            <img
              src={storyImg}
              alt="Restaurant Atmosphere"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-linear-to-t from-black/85 via-transparent to-transparent flex items-end p-8">
              <div>
                <span className="text-[10px] tracking-[0.25em] uppercase text-[#d4af37] font-semibold block mb-1">
                  Architecture & Light
                </span>
                <h3 className="font-serif text-2xl text-white font-light">
                  {settings.restaurantName} Ambiance
                </h3>
              </div>
            </div>
          </motion.div>
        )}

        {chefImg && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative aspect-16/11 rounded-3xl overflow-hidden border border-[#d4af37]/30 shadow-2xl bg-[#12141d]"
          >
            <img
              src={chefImg}
              alt={about.chefName || 'Executive Chef'}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-linear-to-t from-black/85 via-transparent to-transparent flex items-end p-8">
              <div>
                <span className="text-[10px] tracking-[0.25em] uppercase text-[#d4af37] font-semibold block mb-1">
                  Executive Leadership
                </span>
                <h3 className="font-serif text-2xl text-white font-light">
                  {about.chefName || 'Chef Alessandro Rossi'}
                </h3>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Culinary Philosophy Pillars */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
        <div className="p-8 rounded-3xl bg-white dark:bg-[#12141e]/80 border border-stone-200 dark:border-white/[0.08] shadow-md dark:shadow-none space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-[#d4af37]/15 border border-[#d4af37]/35 flex items-center justify-center text-[#d4af37]">
            <Utensils className="w-6 h-6" />
          </div>
          <h3 className="font-serif text-xl text-stone-900 dark:text-white">Ethical Terroir Sourcing</h3>
          <p className="text-stone-600 dark:text-stone-400 text-xs sm:text-sm font-light leading-relaxed">
            We partner exclusively with sustainable heirloom farmers, artisanal dairies, and day-boat fishermen who share our reverence for the land.
          </p>
        </div>

        <div className="p-8 rounded-3xl bg-white dark:bg-[#12141e]/80 border border-stone-200 dark:border-white/[0.08] shadow-md dark:shadow-none space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-[#d4af37]/15 border border-[#d4af37]/35 flex items-center justify-center text-[#d4af37]">
            <Award className="w-6 h-6" />
          </div>
          <h3 className="font-serif text-xl text-stone-900 dark:text-white">Gastronomic Rigor</h3>
          <p className="text-stone-600 dark:text-stone-400 text-xs sm:text-sm font-light leading-relaxed">
            Every sauce, reduction, and laminated pastry requires hours of patient, quiet dedication before gracing your service table.
          </p>
        </div>

        <div className="p-8 rounded-3xl bg-white dark:bg-[#12141e]/80 border border-stone-200 dark:border-white/[0.08] shadow-md dark:shadow-none space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-[#d4af37]/15 border border-[#d4af37]/35 flex items-center justify-center text-[#d4af37]">
            <HeartHandshake className="w-6 h-6" />
          </div>
          <h3 className="font-serif text-xl text-stone-900 dark:text-white">Immersive Hospitality</h3>
          <p className="text-stone-600 dark:text-stone-400 text-xs sm:text-sm font-light leading-relaxed">
            Beyond sustenance, dining is memory. Our front-of-house team orchestrates an unhurried, warm sanctuary for each guest.
          </p>
        </div>
      </div>

      {/* Reservation Invitation */}
      <div className="p-10 sm:p-14 rounded-3xl bg-linear-to-r from-amber-500/10 via-amber-400/5 to-amber-500/10 dark:from-[#161824] dark:via-[#12141e] dark:to-[#161824] border border-[#d4af37]/30 text-center space-y-6">
        <h3 className="font-serif text-3xl sm:text-4xl text-stone-900 dark:text-white">Experience Our Kitchen Atelier</h3>
        <p className="text-stone-600 dark:text-stone-300 text-sm max-w-xl mx-auto">
          Reserve your table or private tasting counter directly with our concierge desk.
        </p>
        <button
          onClick={() => openReservation()}
          className="px-8 py-3.5 rounded-full bg-linear-to-r from-[#d4af37] via-[#f7e6c4] to-[#d4af37] text-stone-950 text-xs font-bold uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-xl shadow-[#d4af37]/25 cursor-pointer"
        >
          Curate Reservation
        </button>
      </div>
    </div>
  );
}

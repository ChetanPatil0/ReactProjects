'use client';

import React, { useState, useRef } from 'react';
import { Upload, X, Loader2, Image as ImageIcon } from 'lucide-react';

interface ImageUploaderProps {
  value?: string | null;
  onChange: (url: string | null) => void;
  label?: string;
  helperText?: string;
}

export function ImageUploader({
  value,
  onChange,
  label = 'Image',
  helperText = 'JPEG, PNG, WebP or AVIF (Max 5MB)',
}: ImageUploaderProps) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);
    setUploading(true);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to upload image');
      }

      onChange(data.data.url);
    } catch (err: any) {
      setError(err.message || 'Error uploading file');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleRemove = async () => {
    if (value && value.startsWith('/uploads/temp/')) {
      try {
        await fetch('/api/admin/upload', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: value }),
        });
      } catch (e) {
        // Ignore rollback failure on UI
      }
    }
    onChange(null);
    setError(null);
  };

  return (
    <div className="space-y-2">
      {label && <label className="block text-sm font-medium text-zinc-300">{label}</label>}

      {value ? (
        <div className="relative group rounded-xl overflow-hidden border border-zinc-700 bg-zinc-900 w-full max-w-sm h-48 flex items-center justify-center">
          <img
            src={value}
            alt="Preview"
            className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-300"
          />
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 text-xs bg-zinc-800 text-white rounded-lg hover:bg-zinc-700 transition"
            >
              Replace
            </button>
            <button
              type="button"
              onClick={handleRemove}
              className="p-1.5 bg-red-600/80 hover:bg-red-600 text-white rounded-lg transition"
              title="Remove image"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        <div
          onClick={() => !uploading && fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer transition-colors max-w-sm ${
            uploading
              ? 'border-amber-500/50 bg-amber-500/5 cursor-wait'
              : 'border-zinc-700 hover:border-amber-500/60 bg-zinc-900/50 hover:bg-zinc-900'
          }`}
        >
          {uploading ? (
            <div className="flex flex-col items-center gap-2 text-amber-400">
              <Loader2 className="w-8 h-8 animate-spin" />
              <span className="text-xs font-medium">Staging upload securely...</span>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2 text-zinc-400 text-center">
              <div className="p-3 rounded-full bg-zinc-800 text-amber-400">
                <Upload className="w-5 h-5" />
              </div>
              <p className="text-xs font-medium text-zinc-200">Click to upload photo</p>
              <p className="text-[11px] text-zinc-500">{helperText}</p>
            </div>
          )}
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/avif,image/gif"
        onChange={handleFileChange}
        className="hidden"
      />

      {error && <p className="text-xs text-red-400 mt-1">{error}</p>}
    </div>
  );
}

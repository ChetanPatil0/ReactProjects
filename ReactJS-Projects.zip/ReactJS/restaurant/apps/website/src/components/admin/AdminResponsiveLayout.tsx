'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ThemeToggle } from '@/components/theme/ThemeToggle';
import {
  LayoutDashboard,
  Receipt,
  UtensilsCrossed,
  FileText,
  BarChart3,
  Users,
  Settings,
  ExternalLink,
  LogOut,
  ChevronRight,
  Menu as MenuIcon,
  X,
  CalendarDays,
} from 'lucide-react';

interface AdminResponsiveLayoutProps {
  user: {
    firstName: string;
    lastName: string;
    role: string;
  };
  settings?: {
    name?: string | null;
    logoUrl?: string | null;
  } | null;
  children: React.ReactNode;
}

export function AdminResponsiveLayout({
  user,
  settings,
  children,
}: AdminResponsiveLayoutProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = usePathname();

  // Close mobile drawer on route change
  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  const navItems = [
    { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
    { name: 'POS Terminal', href: '/admin/pos', icon: Receipt, badge: 'POS', highlight: true },
    { name: 'Table Bookings', href: '/admin/reservations', icon: CalendarDays },
    { name: 'Bills & Invoices', href: '/admin/bills', icon: FileText },
    { name: 'Menu & Delicacies', href: '/admin/menu', icon: UtensilsCrossed },
    { name: 'Website CMS', href: '/admin/content', icon: LayoutDashboard },
    { name: 'Sales Audit', href: '/admin/reports', icon: BarChart3 },
  ];

  if (user.role === 'SUPER_ADMIN' || user.role === 'OWNER' || user.role === 'MANAGER') {
    navItems.push({ name: 'Staff & Roles', href: '/admin/staff', icon: Users });
  }

  navItems.push({ name: 'Settings & Receipt HTML', href: '/admin/settings', icon: Settings });

  return (
    <div className="h-screen w-screen overflow-hidden bg-[#080a0f] text-zinc-100 flex font-sans">
      {/* ============================================================ */}
      {/* MOBILE BACKDROP OVERLAY */}
      {/* ============================================================ */}
      {mobileOpen && (
        <div
          onClick={() => setMobileOpen(false)}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 lg:hidden transition-opacity"
        />
      )}

      {/* ============================================================ */}
      {/* SIDEBAR: PERSISTENT DESKTOP + SLIDE-OVER MOBILE */}
      {/* ============================================================ */}
      <aside
        className={`fixed top-0 bottom-0 left-0 w-64 h-screen z-50 bg-[#0d1017] border-r border-[#1e2330] flex flex-col shrink-0 select-none transition-transform duration-300 ease-in-out ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="h-14 px-4 sm:px-5 border-b border-[#1e2330] flex items-center justify-between bg-[#11141e] shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            {settings?.logoUrl ? (
              <img
                src={settings.logoUrl}
                alt="Logo"
                className="h-8 max-w-[80px] object-contain rounded"
              />
            ) : (
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-sm shrink-0">
                {settings?.name ? settings.name.charAt(0) : 'Z'}
              </div>
            )}
            <div className="min-w-0">
              <h1 className="font-semibold text-xs tracking-wide text-zinc-100 truncate">
                {settings?.name || 'Zaffran Haveli'}
              </h1>
              <p className="text-[10px] text-amber-400 font-medium truncate">Royal Indian Atelier</p>
            </div>
          </div>

          {/* Close button for mobile */}
          <button
            onClick={() => setMobileOpen(false)}
            className="lg:hidden p-1.5 text-zinc-400 hover:text-white rounded-lg transition"
            aria-label="Close sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Items (Scrolls independently if overflowing) */}
        <nav className="flex-1 px-3 py-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = pathname === item.href;
            const Icon = item.icon;

            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs transition group font-medium ${
                  item.highlight
                    ? isActive
                      ? 'bg-amber-400 text-black font-bold shadow-md shadow-amber-400/20'
                      : 'text-amber-300 bg-amber-500/10 border border-amber-500/30 hover:bg-amber-500/20'
                    : isActive
                    ? 'bg-zinc-800 text-amber-300 font-semibold border border-zinc-700'
                    : 'text-zinc-400 hover:text-white hover:bg-[#161a26]'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    isActive ? 'text-amber-400' : 'text-zinc-500 group-hover:text-amber-400'
                  }`}
                />
                <span className="truncate">{item.name}</span>
                {item.badge && (
                  <span className="ml-auto text-[9px] font-bold tracking-wider px-1.5 py-0.5 rounded bg-amber-500 text-zinc-950">
                    {item.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>

        {/* Bottom User Profile & Website Action */}
        <div className="p-3 border-t border-[#1e2330] bg-[#10131d] shrink-0 space-y-2">
          <a
            href="/"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-between px-3 py-2 rounded-xl text-xs text-zinc-300 hover:text-white hover:bg-[#161a26] transition border border-[#1e2330]"
          >
            <span className="truncate">View Public Website</span>
            <ExternalLink className="w-3.5 h-3.5 text-zinc-400 shrink-0 ml-1.5" />
          </a>

          <div className="pt-1 flex items-center justify-between">
            <div className="min-w-0 pr-2">
              <p className="text-xs font-semibold text-zinc-200 truncate">
                {user.firstName} {user.lastName}
              </p>
              <span className="inline-block px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-amber-500/10 text-amber-400 border border-amber-500/20">
                {user.role}
              </span>
            </div>
            <form action="/api/auth/logout" method="POST">
              <button
                type="submit"
                title="Sign Out"
                className="p-2 text-zinc-400 hover:text-rose-400 hover:bg-[#161a26] rounded-xl transition cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </aside>

      {/* ============================================================ */}
      {/* FIXED TOP HEADER (RESPONSIVE) */}
      {/* ============================================================ */}
      <header className="fixed top-0 left-0 lg:left-64 right-0 h-14 bg-[#0d1017]/95 backdrop-blur-md border-b border-[#1e2330] z-30 flex items-center justify-between px-4 sm:px-6 select-none">
        <div className="flex items-center gap-3">
          {/* Mobile Hamburger Toggle Button */}
          <button
            onClick={() => setMobileOpen(true)}
            className="lg:hidden p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white focus:outline-none cursor-pointer"
            aria-label="Open menu"
          >
            <MenuIcon className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2 text-xs text-zinc-400">
            <span className="font-semibold text-zinc-200 truncate max-w-[120px] sm:max-w-none">
              {settings?.name || 'Zaffran Haveli'}
            </span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-600 hidden sm:inline" />
            <span className="text-amber-400 font-mono hidden sm:inline text-[11px] font-semibold">
              ₹ INR System
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <ThemeToggle variant="dropdown" />

          <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[11px] font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>Register Online</span>
          </div>

          <Link
            href="/admin/pos"
            className="px-3 sm:px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs transition flex items-center gap-1.5 shadow-sm"
          >
            <Receipt className="w-3.5 h-3.5" />
            <span>POS Billing</span>
          </Link>
        </div>
      </header>

      {/* ============================================================ */}
      {/* MAIN CONTENT AREA (RESPONSIVE) */}
      {/* ============================================================ */}
      <main className="w-full lg:ml-64 mt-14 flex-1 h-[calc(100vh-3.5rem)] overflow-y-auto bg-[#080a0f] p-3 sm:p-6 lg:p-8">
        {children}
      </main>
    </div>
  );
}

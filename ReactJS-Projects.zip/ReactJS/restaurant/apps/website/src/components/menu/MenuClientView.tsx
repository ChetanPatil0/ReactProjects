'use client';

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  UtensilsCrossed,
  ArrowRight,
  Sparkles,
  Star,
  Flame,
  ArrowUpDown,
  Filter,
  X,
  Check,
  Calendar,
  ChefHat,
  Eye,
  LayoutList,
  LayoutGrid,
} from 'lucide-react';
import { MenuCategory, MenuItem, RestaurantSettings } from '@/types/restaurant';
import { FoodBadge } from '@/components/common/FoodBadge';
import { getMediaUrl } from '@/lib/api/restaurant';
import { useReservation } from '@/context/ReservationContext';

interface MenuClientViewProps {
  categories: MenuCategory[];
  items: MenuItem[];
  settings: RestaurantSettings;
  initialCategory?: string;
}

type SortOption = 'recommended' | 'price-asc' | 'price-desc' | 'name-asc' | 'spicy-desc';
type DietOption = 'all' | 'veg' | 'non-veg';
type SpicyOption = 'all' | 'mild' | 'medium' | 'spicy';
type CardLayout = 'row' | 'grid';

export function MenuClientView({
  categories,
  items,
  settings,
  initialCategory,
}: MenuClientViewProps) {
  const currencySymbol = settings.currency || '₹';
  const { openReservation } = useReservation();

  // Filter States
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory || 'all');
  const [dietFilter, setDietFilter] = useState<DietOption>('all');
  const [signaturesOnly, setSignaturesOnly] = useState<boolean>(false);
  const [spicyFilter, setSpicyFilter] = useState<SpicyOption>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('recommended');
  const [cardLayout, setCardLayout] = useState<CardLayout>('row');

  // Selected dish for quick detail modal
  const [selectedDish, setSelectedDish] = useState<MenuItem | null>(null);

  // Active filters count for reset helper
  const isAnyFilterActive = useMemo(() => {
    return (
      selectedCategory !== 'all' ||
      dietFilter !== 'all' ||
      signaturesOnly ||
      spicyFilter !== 'all' ||
      searchQuery.trim() !== '' ||
      sortBy !== 'recommended'
    );
  }, [selectedCategory, dietFilter, signaturesOnly, spicyFilter, searchQuery, sortBy]);

  const resetAllFilters = () => {
    setSelectedCategory('all');
    setDietFilter('all');
    setSignaturesOnly(false);
    setSpicyFilter('all');
    setSearchQuery('');
    setSortBy('recommended');
  };

  // Filtered & Sorted Items
  const filteredAndSortedItems = useMemo(() => {
    let result = items.filter((item) => {
      // 1. Category match
      if (selectedCategory !== 'all') {
        const itemCat = item.category?.slug || item.category?.id;
        if (itemCat && String(itemCat) !== String(selectedCategory)) {
          return false;
        }
      }

      // 2. Dietary match
      if (dietFilter === 'veg' && !item.isVeg && item.foodType !== 'veg') {
        return false;
      }
      if (dietFilter === 'non-veg' && (item.isVeg || item.foodType === 'veg')) {
        return false;
      }

      // 3. Signatures Only
      if (signaturesOnly && !item.isSignature) {
        return false;
      }

      // 4. Spicy level match
      if (spicyFilter === 'mild' && (item.spicyLevel || 0) > 0) {
        return false;
      }
      if (spicyFilter === 'medium' && (item.spicyLevel || 0) !== 1) {
        return false;
      }
      if (spicyFilter === 'spicy' && (item.spicyLevel || 0) < 2) {
        return false;
      }

      // 5. Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesDesc = item.description?.toLowerCase().includes(q);
        const matchesCat = item.category?.name?.toLowerCase().includes(q);
        if (!matchesName && !matchesDesc && !matchesCat) {
          return false;
        }
      }

      return true;
    });

    // Sorting
    result.sort((a, b) => {
      switch (sortBy) {
        case 'price-asc':
          return a.price - b.price;
        case 'price-desc':
          return b.price - a.price;
        case 'name-asc':
          return a.name.localeCompare(b.name);
        case 'spicy-desc':
          return (b.spicyLevel || 0) - (a.spicyLevel || 0);
        case 'recommended':
        default:
          // Signatures first, then displayOrder
          if (a.isSignature && !b.isSignature) return -1;
          if (!a.isSignature && b.isSignature) return 1;
          return (a.displayOrder || 0) - (b.displayOrder || 0);
      }
    });

    return result;
  }, [items, selectedCategory, dietFilter, signaturesOnly, spicyFilter, searchQuery, sortBy]);

  // Count items per category
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    items.forEach((item) => {
      const catKey = item.category?.slug || String(item.category?.id) || 'unknown';
      counts[catKey] = (counts[catKey] || 0) + 1;
    });
    return counts;
  }, [items]);

  return (
    <div className="space-y-8 select-none">
      {/* ============================================================ */}
      {/* TOP CONTROL BAR: SEARCH, DIET, HEAT & SORT */}
      {/* ============================================================ */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white/90 dark:bg-[#0f121a]/90 backdrop-blur-xl border border-stone-200 dark:border-zinc-800/80 shadow-md dark:shadow-2xl space-y-4 transition-colors">
        <div className="flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between">
          {/* Search Box */}
          <div className="relative flex-1 max-w-lg">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400 dark:text-zinc-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search dishes (e.g. Biryani, Galouti, Paneer, Nihari)..."
              className="w-full pl-11 pr-10 py-2.5 rounded-2xl bg-stone-50 dark:bg-[#08090f] border border-stone-200 dark:border-zinc-800 text-stone-900 dark:text-zinc-100 placeholder:text-stone-400 dark:placeholder:text-zinc-500 text-xs tracking-wide focus:outline-none focus:border-amber-500 dark:focus:border-amber-400/70 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-stone-400 dark:text-zinc-500 hover:text-stone-700 dark:hover:text-zinc-200 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Controls Cluster: Diet Pills, Signatures Toggle, Heat, Sort & Layout */}
          <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
            {/* Dietary Filter (All, Pure Veg, Non-Veg) */}
            <div className="flex items-center gap-1 p-1 rounded-2xl bg-stone-100 dark:bg-[#08090f] border border-stone-200 dark:border-zinc-800 text-xs w-full sm:w-auto">
              <button
                onClick={() => setDietFilter('all')}
                className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-xl font-semibold text-[11px] tracking-wider uppercase transition cursor-pointer text-center ${
                  dietFilter === 'all'
                    ? 'bg-amber-400 text-black font-bold shadow-sm'
                    : 'text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white'
                }`}
              >
                Full Carte
              </button>

              <button
                onClick={() => setDietFilter('veg')}
                className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-xl font-semibold text-[11px] tracking-wider uppercase transition flex items-center justify-center gap-1.5 cursor-pointer text-center ${
                  dietFilter === 'veg'
                    ? 'bg-emerald-500 text-white font-bold shadow-sm'
                    : 'text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block border border-black/30 shrink-0" />
                <span>Pure Veg</span>
              </button>

              <button
                onClick={() => setDietFilter('non-veg')}
                className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-xl font-semibold text-[11px] tracking-wider uppercase transition flex items-center justify-center gap-1.5 cursor-pointer text-center ${
                  dietFilter === 'non-veg'
                    ? 'bg-rose-500 text-white font-bold shadow-sm'
                    : 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-rose-500 inline-block border border-black/30 shrink-0" />
                <span>Non-Veg</span>
              </button>
            </div>

            {/* Chef Signatures Toggle */}
            <button
              onClick={() => setSignaturesOnly(!signaturesOnly)}
              className={`flex-1 sm:flex-initial justify-center px-3.5 py-2 rounded-2xl text-[11px] font-semibold tracking-wider uppercase flex items-center gap-1.5 border transition cursor-pointer ${
                signaturesOnly
                  ? 'bg-amber-400/20 border-amber-500 text-amber-700 dark:text-amber-300 font-bold shadow-sm'
                  : 'bg-white dark:bg-[#08090f] border-stone-200 dark:border-zinc-800 text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white hover:border-stone-300 dark:hover:border-zinc-700'
              }`}
            >
              <Star
                className={`w-3.5 h-3.5 ${
                  signaturesOnly ? 'text-amber-500 fill-amber-500' : 'text-stone-400 dark:text-zinc-500'
                }`}
              />
              <span>Signatures</span>
            </button>

            {/* Heat / Spice Filter Dropdown */}
            <div className="flex items-center gap-1 p-1 rounded-2xl bg-stone-100 dark:bg-[#08090f] border border-stone-200 dark:border-zinc-800 text-xs flex-1 sm:flex-initial justify-between sm:justify-start">
              <span className="text-[10px] text-stone-500 dark:text-zinc-500 pl-2 pr-1 font-medium hidden sm:inline">
                Heat:
              </span>
              {(['all', 'mild', 'medium', 'spicy'] as const).map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setSpicyFilter(lvl)}
                  className={`flex-1 sm:flex-initial px-2 py-1.5 rounded-xl text-[11px] capitalize font-medium transition cursor-pointer text-center ${
                    spicyFilter === lvl
                      ? 'bg-white dark:bg-zinc-800 text-amber-600 dark:text-amber-300 font-bold shadow-xs'
                      : 'text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white'
                  }`}
                >
                  {lvl === 'all'
                    ? 'All'
                    : lvl === 'mild'
                    ? 'Mild'
                    : lvl === 'medium'
                    ? '🌶️ Med'
                    : '🌶️🌶️ Hot'}
                </button>
              ))}
            </div>

            {/* Sort Dropdown */}
            <div className="relative w-full sm:w-auto">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="w-full sm:w-auto appearance-none pl-8 pr-8 py-2 rounded-2xl bg-stone-50 dark:bg-[#08090f] border border-stone-200 dark:border-zinc-800 text-[11px] font-semibold text-stone-700 dark:text-zinc-300 uppercase tracking-wider focus:outline-none focus:border-amber-500 dark:focus:border-amber-400 cursor-pointer"
              >
                <option value="recommended">Sort: Chef Recommended</option>
                <option value="price-asc">Sort: Price Low → High</option>
                <option value="price-desc">Sort: Price High → Low</option>
                <option value="name-asc">Sort: Name A → Z</option>
                <option value="spicy-desc">Sort: Spiciness Level</option>
              </select>
              <ArrowUpDown className="w-3.5 h-3.5 text-stone-400 dark:text-zinc-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {/* Card Layout View Toggle: Small Row Cards vs Small Grid Cards */}
            <div className="flex items-center gap-1 p-1 rounded-2xl bg-stone-100 dark:bg-[#08090f] border border-stone-200 dark:border-zinc-800 text-xs">
              <button
                onClick={() => setCardLayout('row')}
                className={`p-1.5 rounded-xl transition cursor-pointer ${
                  cardLayout === 'row'
                    ? 'bg-amber-400 text-black shadow-sm font-bold'
                    : 'text-stone-500 dark:text-zinc-500 hover:text-stone-900 dark:hover:text-white'
                }`}
                title="Compact Row Cards (Small Image)"
              >
                <LayoutList className="w-4 h-4" />
              </button>
              <button
                onClick={() => setCardLayout('grid')}
                className={`p-1.5 rounded-xl transition cursor-pointer ${
                  cardLayout === 'grid'
                    ? 'bg-amber-400 text-black shadow-sm font-bold'
                    : 'text-stone-500 dark:text-zinc-500 hover:text-stone-900 dark:hover:text-white'
                }`}
                title="Compact Grid Cards (Small Image)"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Active Filters Summary Ribbon */}
        {isAnyFilterActive && (
          <div className="flex items-center justify-between pt-2 border-t border-stone-200 dark:border-zinc-800/80 text-xs text-stone-600 dark:text-zinc-400">
            <div className="flex items-center gap-2">
              <span className="text-[11px]">
                Showing{' '}
                <strong className="text-amber-600 dark:text-amber-400 font-mono font-bold">
                  {filteredAndSortedItems.length}
                </strong>{' '}
                of {items.length} royal creations
              </span>
            </div>

            <button
              onClick={resetAllFilters}
              className="text-[11px] text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1 font-semibold uppercase tracking-wider transition cursor-pointer"
            >
              <X className="w-3 h-3" />
              <span>Reset All Filters</span>
            </button>
          </div>
        )}
      </div>

      {/* ============================================================ */}
      {/* CATEGORY PILLS BAR WITH LIVE COUNTERS */}
      {/* ============================================================ */}
      <div className="-mx-4 px-4 sm:mx-0 sm:px-0 flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none touch-pan-x">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-5 py-2.5 rounded-2xl text-xs font-semibold tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 border ${
            selectedCategory === 'all'
              ? 'bg-amber-400 border-amber-400 text-black font-bold shadow-md shadow-amber-400/20'
              : 'bg-white dark:bg-[#10131a] border-stone-200 dark:border-zinc-800/80 text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white hover:border-stone-300 dark:hover:border-zinc-700'
          }`}
        >
          <span>All Carte</span>
          <span
            className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
              selectedCategory === 'all'
                ? 'bg-black/20 text-black font-bold'
                : 'bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-400'
            }`}
          >
            {items.length}
          </span>
        </button>

        {categories.map((cat) => {
          const count = categoryCounts[cat.slug] || categoryCounts[String(cat.id)] || 0;
          const isSelected = String(selectedCategory) === String(cat.slug || cat.id);

          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.slug || String(cat.id))}
              className={`px-5 py-2.5 rounded-2xl text-xs font-semibold tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 border ${
                isSelected
                  ? 'bg-amber-400 border-amber-400 text-black font-bold shadow-md shadow-amber-400/20'
                  : 'bg-white dark:bg-[#10131a] border-stone-200 dark:border-zinc-800/80 text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white hover:border-stone-300 dark:hover:border-zinc-700'
              }`}
            >
              <span>{cat.name}</span>
              {count > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isSelected
                      ? 'bg-black/20 text-black font-bold'
                      : 'bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-400'
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ============================================================ */}
      {/* SMALL DISHES CARDS (SMALL CARD WITH SMALL IMAGE) */}
      {/* ============================================================ */}
      {filteredAndSortedItems.length === 0 ? (
        <div className="py-20 px-6 rounded-3xl bg-white/70 dark:bg-[#0f121a]/60 border border-stone-200 dark:border-zinc-800 text-center space-y-4">
          <UtensilsCrossed className="w-12 h-12 text-amber-500/50 dark:text-amber-400/40 mx-auto" />
          <h3 className="text-xl font-serif text-stone-900 dark:text-white font-light">No Delicacies Match Your Criteria</h3>
          <p className="text-stone-600 dark:text-zinc-400 text-xs max-w-sm mx-auto leading-relaxed">
            Try adjusting your search query, heat level, or dietary preferences to explore our royal menu.
          </p>
          <button
            onClick={resetAllFilters}
            className="px-5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs uppercase tracking-wider transition cursor-pointer shadow-md"
          >
            Clear All Filters
          </button>
        </div>
      ) : cardLayout === 'row' ? (
        /* FORMAT A: COMPACT TWO-COLUMN MENU ROW CARDS WITH SMALL THUMBNAIL IMAGE */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5 sm:gap-4">
          <AnimatePresence mode="popLayout">
            {filteredAndSortedItems.map((dish) => {
              const imgUrl = dish.image?.url ? getMediaUrl(dish.image.url) : null;
              const spicyCount = dish.spicyLevel || 0;

              return (
                <motion.div
                  key={dish.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  transition={{ duration: 0.2 }}
                  className="group rounded-2xl bg-white/95 dark:bg-[#0e1118]/90 border border-stone-200 dark:border-zinc-800/80 hover:border-amber-500/50 dark:hover:border-amber-400/50 hover:bg-stone-50/80 dark:hover:bg-[#111420] transition-all duration-300 p-3 sm:p-3.5 flex gap-3 sm:gap-4 items-center shadow-xs hover:shadow-md dark:shadow-md dark:hover:shadow-xl relative"
                >
                  {/* Small Thumbnail Image Container (w-20 sm:w-24 md:w-28) */}
                  <div
                    onClick={() => setSelectedDish(dish)}
                    className="w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28 rounded-xl overflow-hidden shrink-0 bg-stone-100 dark:bg-[#08090f] relative border border-stone-200 dark:border-zinc-800/80 group-hover:border-amber-500/40 dark:group-hover:border-amber-400/40 transition-colors cursor-pointer shadow-xs"
                  >
                    {imgUrl ? (
                      <img
                        src={imgUrl}
                        alt={dish.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-zinc-400 bg-stone-100 dark:bg-zinc-950">
                        <UtensilsCrossed className="w-6 h-6 opacity-30" />
                      </div>
                    )}

                    {/* FSSAI Veg / Non-Veg Pin Badge on Top-Left */}
                    <div className="absolute top-1.5 left-1.5 p-0.5 rounded bg-black/75 backdrop-blur-sm border border-white/10 shadow">
                      <FoodBadge foodType={dish.foodType} isVeg={dish.isVeg} />
                    </div>

                    {/* Quick View Eye Overlay */}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                      <Eye className="w-4 h-4 text-amber-300 drop-shadow" />
                    </div>
                  </div>

                  {/* Right Content Area */}
                  <div className="flex-1 min-w-0 space-y-1.5">
                    {/* Top Meta Line: Category, Signature Star, Heat */}
                    <div className="flex items-center justify-between gap-2 text-[10px]">
                      <span className="font-semibold tracking-wider uppercase text-amber-600 dark:text-amber-400/90 truncate">
                        {dish.category?.name || 'Chef Special'}
                      </span>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {dish.isSignature && (
                          <span className="px-2 py-0.5 rounded bg-amber-500/15 text-amber-700 dark:text-amber-300 font-bold uppercase tracking-wider text-[9px] border border-amber-500/30 dark:border-amber-400/30 flex items-center gap-1">
                            <Star className="w-2.5 h-2.5 fill-amber-500 dark:fill-amber-300 text-amber-500 dark:text-amber-300" />
                            <span>Signature</span>
                          </span>
                        )}
                        {spicyCount > 0 && (
                          <span className="text-amber-600 dark:text-amber-400 font-medium flex items-center gap-0.5 text-[10px]">
                            <Flame className="w-2.5 h-2.5 fill-amber-500/30 dark:fill-amber-400/30 text-amber-600 dark:text-amber-400" />
                            <span>{spicyCount === 1 ? 'Mild' : 'Med'}</span>
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Dish Title & Price in Same Row */}
                    <div className="flex items-baseline justify-between gap-2">
                      <h3
                        onClick={() => setSelectedDish(dish)}
                        className="font-serif text-sm sm:text-base text-stone-900 dark:text-zinc-100 group-hover:text-amber-600 dark:group-hover:text-amber-300 transition-colors truncate font-medium cursor-pointer"
                        title={dish.name}
                      >
                        {dish.name}
                      </h3>
                      <span className="font-mono font-bold text-amber-600 dark:text-amber-300 text-xs sm:text-sm shrink-0">
                        {currencySymbol}
                        {dish.price.toFixed(2)}
                      </span>
                    </div>

                    {/* Concise Description */}
                    {dish.description && (
                      <p className="text-xs text-stone-600 dark:text-zinc-400 font-light line-clamp-2 leading-relaxed">
                        {dish.description}
                      </p>
                    )}

                    {/* Bottom Action Footer */}
                    <div className="pt-1 flex items-center justify-between text-[11px]">
                      <span className="text-stone-500 dark:text-zinc-500 font-medium text-[10px] truncate max-w-[140px]">
                        {dish.isVeg ? 'Pure Sattvic' : 'Awadhi Dum Pukht'}
                      </span>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setSelectedDish(dish)}
                          className="text-[10px] text-stone-500 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-zinc-200 transition font-medium cursor-pointer"
                        >
                          Details
                        </button>
                        <button
                          onClick={() => openReservation({ dishName: dish.name })}
                          className="px-2.5 py-1 rounded-lg bg-stone-100 dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 hover:border-amber-500 text-amber-700 dark:text-amber-400 hover:text-amber-800 dark:hover:text-amber-300 text-[10px] font-semibold uppercase tracking-wider transition flex items-center gap-1 cursor-pointer hover:bg-amber-50 dark:hover:bg-amber-400/10"
                        >
                          <span>Reserve</span>
                          <ArrowRight className="w-2.5 h-2.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      ) : (
        /* FORMAT B: COMPACT FOUR-COLUMN GRID CARDS WITH COMPACT IMAGE */
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
          <AnimatePresence mode="popLayout">
            {filteredAndSortedItems.map((dish) => {
              const imgUrl = dish.image?.url ? getMediaUrl(dish.image.url) : null;
              const spicyCount = dish.spicyLevel || 0;

              return (
                <motion.div
                  key={dish.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="group rounded-2xl overflow-hidden bg-white/95 dark:bg-[#0e1118]/90 border border-stone-200 dark:border-zinc-800/80 hover:border-amber-500/50 dark:hover:border-amber-400/50 hover:bg-stone-50/80 dark:hover:bg-[#111420] transition-all flex flex-col justify-between shadow-xs hover:shadow-md dark:shadow-md dark:hover:shadow-xl relative"
                >
                  {/* Compact Header Image */}
                  <div
                    onClick={() => setSelectedDish(dish)}
                    className="relative h-28 sm:h-32 w-full overflow-hidden bg-stone-100 dark:bg-[#08090f] cursor-pointer"
                  >
                    {imgUrl ? (
                      <img
                        src={imgUrl}
                        alt={dish.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-zinc-400 bg-stone-100 dark:bg-zinc-950">
                        <UtensilsCrossed className="w-6 h-6 opacity-30" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30" />

                    {/* Top Left Veg Dot */}
                    <div className="absolute top-2 left-2 p-0.5 rounded bg-black/75 backdrop-blur-sm border border-white/10 shadow">
                      <FoodBadge foodType={dish.foodType} isVeg={dish.isVeg} />
                    </div>

                    {/* Bottom Right Price Tag */}
                    <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded-lg bg-black/80 backdrop-blur-md border border-amber-400/30 text-amber-300 font-mono font-bold text-xs">
                      {currencySymbol}
                      {dish.price.toFixed(2)}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-3 space-y-1.5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between gap-1 text-[9px] text-amber-600 dark:text-amber-400/90 font-semibold uppercase tracking-wider mb-0.5">
                        <span className="truncate">{dish.category?.name || 'Chef Special'}</span>
                        {dish.isSignature && <Star className="w-2.5 h-2.5 fill-amber-500 dark:fill-amber-400 text-amber-500 dark:text-amber-400 shrink-0" />}
                      </div>

                      <h3
                        onClick={() => setSelectedDish(dish)}
                        className="font-serif text-xs sm:text-sm text-stone-900 dark:text-zinc-100 group-hover:text-amber-600 dark:group-hover:text-amber-300 transition-colors line-clamp-1 font-medium cursor-pointer"
                        title={dish.name}
                      >
                        {dish.name}
                      </h3>

                      {dish.description && (
                        <p className="text-[11px] text-stone-600 dark:text-zinc-400 font-light line-clamp-2 leading-snug mt-1">
                          {dish.description}
                        </p>
                      )}
                    </div>

                    <div className="pt-2 border-t border-stone-200 dark:border-zinc-800/60 flex items-center justify-between text-[10px]">
                      <button
                        onClick={() => setSelectedDish(dish)}
                        className="text-stone-500 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-zinc-200 transition cursor-pointer"
                      >
                        Details
                      </button>
                      <button
                        onClick={() => openReservation({ dishName: dish.name })}
                        className="px-2 py-0.5 rounded bg-amber-400 hover:bg-amber-300 text-black font-bold uppercase tracking-wider transition cursor-pointer shadow-sm"
                      >
                        Reserve
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}

      {/* ============================================================ */}
      {/* QUICK DISH DETAIL MODAL (LIGHTBOX) */}
      {/* ============================================================ */}
      <AnimatePresence>
        {selectedDish && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#090b10]/80 backdrop-blur-2xl border border-white/15 rounded-3xl w-full max-w-xl max-h-[92vh] overflow-y-auto shadow-2xl shadow-black/50 relative"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedDish(null)}
                className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-black/50 hover:bg-white text-zinc-300 hover:text-black border border-white/15 flex items-center justify-center transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Photo */}
              <div className="relative aspect-[16/10] bg-zinc-950/40">
                {selectedDish.image?.url ? (
                  <img
                    src={getMediaUrl(selectedDish.image.url)}
                    alt={selectedDish.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-zinc-600">
                    <UtensilsCrossed className="w-12 h-12 opacity-30" />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-[#090b10] via-transparent to-transparent" />

                <div className="absolute bottom-4 left-5 right-5 flex items-end justify-between">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-amber-400">
                      {selectedDish.category?.name || 'Awadhi Special'}
                    </span>
                    <h2 className="text-2xl font-serif text-white">{selectedDish.name}</h2>
                  </div>
                  <div className="px-4 py-2 rounded-2xl bg-black/50 backdrop-blur-md border border-amber-400/40 text-amber-300 font-mono font-bold text-lg">
                    {currencySymbol}
                    {selectedDish.price.toFixed(2)}
                  </div>
                </div>
              </div>

              {/* Details Content */}
              <div className="p-6 space-y-5 text-xs text-zinc-300">
                {/* Meta Badges */}
                <div className="flex flex-wrap items-center gap-2">
                  <div className="px-3 py-1 rounded-xl bg-white/[0.05] border border-white/10 flex items-center gap-1.5">
                    <FoodBadge foodType={selectedDish.foodType} isVeg={selectedDish.isVeg} />
                    <span className="text-[11px] font-medium text-zinc-300">
                      {selectedDish.isVeg ? 'Pure Vegetarian' : 'Non-Vegetarian'}
                    </span>
                  </div>

                  {selectedDish.isSignature && (
                    <div className="px-3 py-1 rounded-xl bg-amber-400/15 border border-amber-400/40 text-amber-300 font-bold text-[11px] flex items-center gap-1.5">
                      <Star className="w-3.5 h-3.5 fill-amber-300" />
                      <span>Chef Signature Recipe</span>
                    </div>
                  )}

                  {(selectedDish.spicyLevel || 0) > 0 && (
                    <div className="px-3 py-1 rounded-xl bg-white/[0.05] border border-white/10 text-amber-400 text-[11px] flex items-center gap-1">
                      <Flame className="w-3.5 h-3.5 fill-amber-400/30" />
                      <span>Heat Level: {selectedDish.spicyLevel}/3</span>
                    </div>
                  )}
                </div>

                {/* Description */}
                <div className="space-y-1.5">
                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
                    Culinary Composition & Heritage
                  </h4>
                  <p className="text-sm text-zinc-300 leading-relaxed font-light">
                    {selectedDish.description ||
                      'Crafted with handpicked ingredients, traditional slow-cooked methods, and royal spice terroir.'}
                  </p>
                </div>

                {/* Heritage Pairing Note */}
                <div className="p-3.5 rounded-2xl bg-white/[0.04] backdrop-blur-sm border border-white/10 flex items-center gap-3">
                  <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
                  <div className="text-[11px]">
                    <span className="font-semibold text-zinc-200 block">
                      Recommended Accompaniment:
                    </span>
                    <span className="text-zinc-400">
                      Pairs exquisitely with Zaffrani Sheermal, Garlic Chur-Chur Naan, or Imperial Saffron Kahwa.
                    </span>
                  </div>
                </div>

                {/* Modal Actions */}
                <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 sm:gap-3">
                  <button
                    onClick={() => setSelectedDish(null)}
                    className="py-3 px-4 rounded-2xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-zinc-300 font-semibold uppercase tracking-wider text-xs transition cursor-pointer text-center"
                  >
                    Back to Menu
                  </button>
                  <button
                    onClick={() => {
                      const name = selectedDish.name;
                      setSelectedDish(null);
                      openReservation({ dishName: name });
                    }}
                    className="flex-1 py-3 px-4 rounded-2xl bg-amber-400 hover:bg-amber-300 text-black font-bold uppercase tracking-wider text-xs transition cursor-pointer shadow-lg shadow-amber-400/20 flex items-center justify-center gap-2 text-center"
                  >
                    <Calendar className="w-4 h-4" />
                    <span>Reserve Tasting Table</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  Calendar,
  Clock,
  Users,
  Sparkles,
  CheckCircle2,
  Phone,
  Mail,
  User,
  ShieldCheck,
  UtensilsCrossed,
  MapPin,
  Flame,
} from 'lucide-react';
import { useReservation } from '@/context/ReservationContext';

const SEATING_AREAS = [
  { id: 'main-dining', label: 'Main Dining Hall', desc: 'Candlelit tables with acoustic intimacy' },
  { id: 'chefs-counter', label: "Chef's Tasting Counter", desc: 'Front-row view of the open culinary atelier' },
  { id: 'wine-cellar', label: 'Sommelier Wine Vault', desc: 'Surrounded by rare vintage reserves' },
  { id: 'garden-terrace', label: 'Heated Botanical Veranda', desc: 'Open-air ambiance with garden vistas' },
];

const OCCASIONS = ['Casual Fine Dining', 'Anniversary', 'Birthday Celebration', 'Business Degustation', 'Romantic Proposal'];

export function ReservationModal({
  restaurantName = "L'Étoile Sanctuary",
  phone = '+1 (555) 234-5678',
  email: conciergeEmail = 'concierge@letoilerestaurant.com',
  address = '452 Grand Avenue, Beverly Hills, CA 90210',
  openingHours = 'Tue – Sun: 5:00 PM – 11:30 PM | Mon: Closed',
}: {
  restaurantName?: string;
  phone?: string;
  email?: string;
  address?: string;
  openingHours?: string;
}) {
  const { isOpen, options, closeReservation } = useReservation();

  const [step, setStep] = useState<1 | 2>(1);
  const [loading, setLoading] = useState(false);
  const [bookingRef, setBookingRef] = useState('');

  const [date, setDate] = useState('');
  const [time, setTime] = useState('19:30');
  const [guests, setGuests] = useState('2');
  const [area, setArea] = useState('main-dining');
  const [occasion, setOccasion] = useState('Casual Fine Dining');
  const [name, setName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [email, setEmail] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');

  // Sync prefilled options
  useEffect(() => {
    if (isOpen) {
      if (options.date) setDate(options.date);
      else {
        // default to today or tomorrow
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        setDate(tomorrow.toISOString().split('T')[0]);
      }
      if (options.time) setTime(options.time);
      if (options.guests) setGuests(options.guests);
      if (options.area) setArea(options.area);
      if (options.occasion) setOccasion(options.occasion);
      if (options.dishName) {
        setSpecialRequests(`Interested in tasting: ${options.dishName}`);
      } else if (options.offerTitle) {
        setSpecialRequests(`Claiming privileged offer: ${options.offerTitle}`);
      }
      setStep(1);
    }
  }, [isOpen, options]);

  const [errorMessage, setErrorMessage] = useState('');

  // Handle submit
  const handleConfirmReservation = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage('');

    try {
      const res = await fetch('/api/reservations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          phone: guestPhone,
          email,
          date,
          time,
          guests: parseInt(guests, 10) || 2,
          area: SEATING_AREAS.find((s) => s.id === area)?.label || 'Main Dining Hall',
          occasion,
          specialRequests,
        }),
      });

      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || 'Failed to register reservation');
      }

      setBookingRef(json.data.reference);
      setStep(2);
    } catch (err: any) {
      setErrorMessage(err.message || 'Error processing reservation');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={closeReservation}
          className="fixed inset-0 bg-black/40 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 20 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-2xl bg-[#090b10]/80 backdrop-blur-2xl border border-[#d4af37]/35 rounded-3xl shadow-2xl shadow-black/50 overflow-hidden z-10 my-8"
        >
          {/* Header Bar */}
          <div className="relative px-6 sm:px-8 pt-7 pb-5 border-b border-white/[0.08] bg-white/[0.03] backdrop-blur-md flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-[10px] uppercase tracking-[0.25em] text-[#c5a059] font-medium block">
                {step === 1 ? 'Table Booking Request' : 'Request In Queue'}
              </span>
              <h2 className="text-2xl sm:text-3xl font-serif font-light text-[#fcfbf9] tracking-tight">
                {step === 1 ? 'Reserve Your Culinary Experience' : 'Request Awaiting Confirmation'}
              </h2>
              <p className="text-xs text-zinc-400 font-light">
                {step === 1
                  ? `${restaurantName}`
                  : 'We look forward to welcoming you.'}
              </p>
            </div>

            <button
              onClick={closeReservation}
              className="p-2 rounded-full text-zinc-400 hover:text-white transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          {step === 1 ? (
            <form onSubmit={handleConfirmReservation} className="p-6 sm:p-8 space-y-6">
              {/* Row 1: Date, Time, Guests */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold tracking-wider text-stone-300 uppercase flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>Dining Date</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/15 text-stone-100 text-xs focus:outline-hidden focus:border-[#d4af37] focus:bg-white/[0.08] transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold tracking-wider text-stone-300 uppercase flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>Seating Service</span>
                  </label>
                  <select
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/15 text-stone-100 text-xs focus:outline-hidden focus:border-[#d4af37] focus:bg-white/[0.08] transition-colors [&>optgroup]:bg-[#0d1017] [&>optgroup]:text-stone-300 [&>optgroup>option]:bg-[#0d1017] [&>optgroup>option]:text-stone-200"
                  >
                    <optgroup label="Lunch Service">
                      <option value="12:00">12:00 PM</option>
                      <option value="12:30">12:30 PM</option>
                      <option value="13:00">01:00 PM</option>
                      <option value="13:30">01:30 PM</option>
                      <option value="14:00">02:00 PM</option>
                    </optgroup>
                    <optgroup label="Dinner Service">
                      <option value="17:30">05:30 PM</option>
                      <option value="18:00">06:00 PM</option>
                      <option value="18:30">06:30 PM</option>
                      <option value="19:00">07:00 PM</option>
                      <option value="19:30">07:30 PM (Peak)</option>
                      <option value="20:00">08:00 PM (Peak)</option>
                      <option value="20:30">08:30 PM</option>
                      <option value="21:00">09:00 PM</option>
                      <option value="21:30">09:30 PM</option>
                    </optgroup>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold tracking-wider text-stone-300 uppercase flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>Party Size</span>
                  </label>
                  <select
                    value={guests}
                    onChange={(e) => setGuests(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/15 text-stone-100 text-xs focus:outline-hidden focus:border-[#d4af37] focus:bg-white/[0.08] transition-colors [&>option]:bg-[#0d1017] [&>option]:text-stone-200"
                  >
                    <option value="1">1 Guest (Solo Tasting)</option>
                    <option value="2">2 Guests (Couple)</option>
                    <option value="3">3 Guests</option>
                    <option value="4">4 Guests</option>
                    <option value="5">5 Guests</option>
                    <option value="6">6 Guests</option>
                    <option value="8">8 Guests (Large Group)</option>
                    <option value="10+">10+ Guests (Private Salon)</option>
                  </select>
                </div>
              </div>

              {/* Seating Atmosphere Selection */}
              <div className="space-y-2">
                <label className="text-[11px] font-semibold tracking-wider text-stone-300 uppercase flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <UtensilsCrossed className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>Preferred Seating Environment</span>
                  </span>
                  <span className="text-[10px] text-[#d4af37] font-normal">All areas complimentary</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {SEATING_AREAS.map((item) => (
                    <button
                      type="button"
                      key={item.id}
                      onClick={() => setArea(item.id)}
                      className={`p-3 rounded-2xl text-left border transition-all cursor-pointer ${
                        area === item.id
                          ? 'bg-[#d4af37]/20 border-[#d4af37] text-white shadow-md shadow-[#d4af37]/15 backdrop-blur-sm'
                          : 'bg-white/[0.03] border-white/10 text-stone-400 hover:border-white/20 hover:text-stone-200 hover:bg-white/[0.06]'
                      }`}
                    >
                      <div className="text-xs font-semibold text-[#fcfbf9]">{item.label}</div>
                      <div className="text-[10px] text-stone-400 font-light mt-0.5">{item.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Guest Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold tracking-wider text-stone-300 uppercase flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>Full Name *</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Julian Sterling"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/15 text-stone-100 placeholder-white/35 text-xs focus:outline-hidden focus:border-[#d4af37] focus:bg-white/[0.08] transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold tracking-wider text-stone-300 uppercase flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>Mobile Phone *</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={guestPhone}
                    onChange={(e) => setGuestPhone(e.target.value)}
                    placeholder="+1 (555) 000-0000"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/15 text-stone-100 placeholder-white/35 text-xs focus:outline-hidden focus:border-[#d4af37] focus:bg-white/[0.08] transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold tracking-wider text-stone-300 uppercase flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>Email Address *</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="julian@example.com"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/15 text-stone-100 placeholder-white/35 text-xs focus:outline-hidden focus:border-[#d4af37] focus:bg-white/[0.08] transition-colors"
                  />
                </div>
              </div>

              {/* Occasion & Dietary notes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold tracking-wider text-stone-300 uppercase flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>Occasion</span>
                  </label>
                  <select
                    value={occasion}
                    onChange={(e) => setOccasion(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/15 text-stone-100 text-xs focus:outline-hidden focus:border-[#d4af37] focus:bg-white/[0.08] transition-colors [&>option]:bg-[#0d1017] [&>option]:text-stone-200"
                  >
                    {OCCASIONS.map((occ) => (
                      <option key={occ} value={occ}>
                        {occ}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold tracking-wider text-stone-300 uppercase">
                    Dietary Requirements / Allergies
                  </label>
                  <input
                    type="text"
                    value={specialRequests}
                    onChange={(e) => setSpecialRequests(e.target.value)}
                    placeholder="e.g. Gluten-free, Pescatarian, Anniversary surprise"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/15 text-stone-100 placeholder-white/35 text-xs focus:outline-hidden focus:border-[#d4af37] focus:bg-white/[0.08] transition-colors"
                  />
                </div>
              </div>

              {/* Submit & Guarantee */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-white/[0.08]">
                <div className="flex items-center gap-2 text-[11px] text-stone-400">
                  <ShieldCheck className="w-4 h-4 text-[#d4af37] shrink-0" />
                  <span>Request reviewed by maître d' • Host approval required before confirmation</span>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-lg bg-[#c5a059] hover:bg-[#d4af37] text-black text-xs font-semibold tracking-[0.16em] uppercase transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {loading ? 'Submitting Request...' : 'Send Reservation Request'}
                </button>
              </div>
            </form>
          ) : (
            /* Confirmation Receipt View */
            <div className="p-8 sm:p-12 text-center space-y-6">
              <div className="w-16 h-16 rounded-full bg-amber-500/15 border border-amber-400/40 flex items-center justify-center text-amber-400 mx-auto shadow-lg shadow-amber-500/20">
                <Clock className="w-8 h-8" />
              </div>

              <div className="space-y-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/15 border border-amber-400/30 text-amber-300 text-[11px] font-bold tracking-wider uppercase">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                  <span>Awaiting Host Approval</span>
                </div>
                <span className="text-[11px] font-mono tracking-widest uppercase text-stone-400 block">
                  Request Ref: #{bookingRef}
                </span>
                <h3 className="text-3xl font-serif text-white font-light">Reservation Request Received</h3>
                <p className="text-stone-300 text-xs sm:text-sm max-w-md mx-auto leading-relaxed">
                  Honored guest <strong className="text-white">{name}</strong>, your table request for{' '}
                  <strong className="text-[#d4af37]">{guests} Guests</strong> on{' '}
                  <strong className="text-[#d4af37]">{date}</strong> at <strong className="text-[#d4af37]">{time}</strong> ({SEATING_AREAS.find((s) => s.id === area)?.label}) has been sent to our concierge desk.
                </p>
                {/* Next Steps & Call / SMS Confirmation Box */}
                <div className="text-left text-xs text-amber-200/90 max-w-md mx-auto bg-gradient-to-br from-amber-500/15 via-zinc-900/90 to-zinc-900 border border-amber-500/35 p-4 rounded-2xl space-y-2.5 shadow-lg">
                  <div className="flex items-center gap-2 text-amber-300 font-bold text-xs uppercase tracking-wider pb-1 border-b border-amber-500/20">
                    <Phone className="w-3.5 h-3.5 text-amber-400" />
                    <span>Next Steps: Call & SMS Confirmation</span>
                  </div>

                  <div className="space-y-1.5 text-[11px] text-stone-300 leading-relaxed">
                    <p className="flex items-start gap-2">
                      <span className="text-amber-400 font-bold">1.</span>
                      <span>
                        Our maître d&apos; desk is checking salon seating capacity. Once approved, <strong className="text-white">you will receive a confirmation call or SMS</strong> on your contact number <strong className="text-amber-300 font-mono">({guestPhone})</strong>.
                      </span>
                    </p>
                    <p className="flex items-start gap-2">
                      <span className="text-amber-400 font-bold">2.</span>
                      <span>
                        Need immediate assistance, large group bookings, or urgent changes? Feel free to contact our host desk directly anytime:
                      </span>
                    </p>
                  </div>

                  <div className="pt-1 flex items-center justify-between gap-2">
                    <a
                      href={`tel:${phone}`}
                      className="flex-1 py-2 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>Call Host Desk: {phone}</span>
                    </a>
                    {conciergeEmail && (
                      <a
                        href={`mailto:${conciergeEmail}?subject=Reservation%20Inquiry%20Ref%20%23${bookingRef}`}
                        className="py-2 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-stone-200 font-medium text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                        title="Email Concierge"
                      >
                        <Mail className="w-3.5 h-3.5" />
                        <span>Email</span>
                      </a>
                    )}
                  </div>
                </div>
              </div>

              {/* Reservation Summary Card */}
              <div className="max-w-md mx-auto p-4 rounded-2xl bg-white/[0.04] backdrop-blur-md border border-[#d4af37]/25 text-left text-xs space-y-2">
                <div className="flex justify-between text-stone-400">
                  <span>Status:</span>
                  <span className="text-amber-400 font-bold uppercase tracking-wider">Pending Review</span>
                </div>
                <div className="flex justify-between text-stone-400">
                  <span>Venue:</span>
                  <span className="text-stone-200 font-medium">{restaurantName}</span>
                </div>
                <div className="flex justify-between text-stone-400">
                  <span>Location:</span>
                  <span className="text-stone-300 truncate max-w-[240px]">{address}</span>
                </div>
                <div className="flex justify-between text-stone-400">
                  <span>Contact Phone:</span>
                  <span className="text-stone-200 font-mono">{guestPhone}</span>
                </div>
                <div className="flex justify-between text-stone-400">
                  <span>Concierge Desk:</span>
                  <div className="text-right">
                    <a href={`tel:${phone}`} className="text-[#d4af37] hover:underline font-mono block">
                      {phone}
                    </a>
                    {conciergeEmail && (
                      <a href={`mailto:${conciergeEmail}`} className="text-stone-300 hover:underline text-[10px] block">
                        {conciergeEmail}
                      </a>
                    )}
                  </div>
                </div>
                {specialRequests && (
                  <div className="flex justify-between text-stone-400 pt-1 border-t border-white/5">
                    <span>Notes:</span>
                    <span className="text-stone-300 italic">{specialRequests}</span>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
                <button
                  onClick={closeReservation}
                  className="px-8 py-3 rounded-full bg-linear-to-r from-[#d4af37] to-[#c29b38] text-stone-950 text-xs font-bold uppercase tracking-wider hover:scale-105 active:scale-95 transition-all shadow-lg shadow-[#d4af37]/20 cursor-pointer"
                >
                  Understood & Close
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

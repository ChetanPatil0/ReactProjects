'use client';

import React, { useState } from 'react';
import { Sparkles, X, ArrowUpRight } from 'lucide-react';
import { useReservation } from '@/context/ReservationContext';

interface AnnouncementBannerProps {
  message?: string;
}

export function AnnouncementBanner({ message }: AnnouncementBannerProps) {
  const [visible, setVisible] = useState(true);
  const { openReservation } = useReservation();

  if (!visible || !message) return null;

  return (
    <aside
      aria-label="Announcement"
      className="bg-[#11131a] border-b border-[#d4af37]/25 text-[#ede6dc] text-[11px] sm:text-xs py-2 px-4 relative flex items-center justify-between transition-all duration-300"
    >
      <div className="flex items-center gap-2 max-w-6xl mx-auto text-center truncate pr-8">
        <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37] animate-ping shrink-0" />
        <Sparkles className="w-3.5 h-3.5 text-[#d4af37] shrink-0" />
        <span className="font-light tracking-wide text-stone-300 truncate">
          {message}
        </span>
        <button
          onClick={() => openReservation({ offerTitle: message })}
          className="hidden sm:inline-flex items-center gap-1 text-[#e5c378] font-semibold hover:underline ml-2 cursor-pointer"
        >
          <span>Book Experience</span>
          <ArrowUpRight className="w-3 h-3" />
        </button>
      </div>

      <button
        onClick={() => setVisible(false)}
        className="p-1 hover:bg-white/10 rounded-full transition-colors text-stone-400 hover:text-white shrink-0 cursor-pointer"
        aria-label="Dismiss banner"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </aside>
  );
}

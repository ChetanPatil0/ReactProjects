'use client';

import React from 'react';
import { usePathname } from 'next/navigation';
import { Navbar } from './Navbar';
import { Footer } from './Footer';
import { ReservationModal } from './ReservationModal';
import { ReservationProvider } from '@/context/ReservationContext';
import { RestaurantSettings, ContactData } from '@/types/restaurant';

interface WebsiteShellProps {
  children: React.ReactNode;
  settings: RestaurantSettings;
  announcement?: string;
  contact: ContactData;
}

export function WebsiteShell({
  children,
  settings,
  announcement,
  contact,
}: WebsiteShellProps) {
  const pathname = usePathname();
  const isAdmin = pathname?.startsWith('/admin');

  if (isAdmin) {
    return <>{children}</>;
  }

  // Check if current route is homepage or a subpage
  const isHome = pathname === '/';

  return (
    <ReservationProvider>
      <div className="min-h-screen flex flex-col bg-[#fcfbf7] text-stone-900 dark:bg-[#07080a] dark:text-[#ede6dc] transition-colors duration-200">
        {/* Unified, fixed navbar with integrated announcement banner */}
        <Navbar
          restaurantName={settings.restaurantName || 'Zaffran Haveli'}
          phone={settings.contactNumber || contact.phone || '+91 98201 23456'}
          logoUrl={settings.logoUrl}
          tagline={settings.tagline || 'Royal Awadhi & Mughlai Atelier'}
          announcement={announcement}
        />

        {/* Main page wrapper with proper top clearance for subpages */}
        <main className={`flex-1 flex flex-col ${isHome ? '' : 'pt-24 sm:pt-28'}`}>
          {children}
        </main>

        <Footer settings={settings} contact={contact} />

        <ReservationModal
          restaurantName={settings.restaurantName || 'Zaffran Haveli'}
          phone={settings.contactNumber || contact.phone || '+91 98201 23456'}
          email={settings.contactEmail || contact.email || 'concierge@zaffranhaveli.com'}
          address={settings.address || contact.address || 'Colaba Causeway, Mumbai'}
          openingHours={settings.openingHours || contact.openingHours}
        />
      </div>
    </ReservationProvider>
  );
}

'use client';

import React from 'react';
import Link from 'next/link';
import { RestaurantSettings, ContactData } from '@/types/restaurant';

interface FooterProps {
  settings: RestaurantSettings;
  contact: ContactData;
}

export function Footer({ settings, contact }: FooterProps) {
  return (
    <footer className="bg-stone-100 dark:bg-[#07080a] border-t border-stone-200 dark:border-white/[0.06] text-stone-600 dark:text-zinc-400 text-xs transition-colors">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Column 1: Restaurant Identity */}
          <div className="space-y-3 md:col-span-1">
            <h3 className="font-serif text-lg text-stone-900 dark:text-zinc-100 tracking-wider">
              {settings.restaurantName}
            </h3>
            <p className="text-stone-500 dark:text-zinc-500 font-light leading-relaxed">
              {settings.tagline || 'Artisanal Gastronomy & Seasonal Degustation'}.
            </p>
          </div>

          {/* Column 2: Location & Hours */}
          <div className="space-y-2">
            <span className="text-[11px] uppercase tracking-[0.2em] text-amber-600 dark:text-[#c5a059] font-medium block">
              Location & Hours
            </span>
            <p className="text-stone-700 dark:text-zinc-300 font-light leading-relaxed">
              {settings.address || contact.address}
            </p>
            <p className="text-stone-500 dark:text-zinc-500 pt-1 font-mono text-[11px]">
              {settings.openingHours || contact.openingHours}
            </p>
          </div>

          {/* Column 3: Concierge Desk */}
          <div className="space-y-2">
            <span className="text-[11px] uppercase tracking-[0.2em] text-amber-600 dark:text-[#c5a059] font-medium block">
              Inquiries
            </span>
            <p>
              <a
                href={`tel:${settings.contactNumber || contact.phone}`}
                className="text-stone-700 dark:text-zinc-300 hover:text-stone-950 dark:hover:text-white transition-colors font-mono"
              >
                {settings.contactNumber || contact.phone}
              </a>
            </p>
            <p>
              <a
                href={`mailto:${settings.contactEmail || contact.email}`}
                className="text-stone-500 dark:text-zinc-400 hover:text-stone-950 dark:hover:text-white transition-colors font-mono text-[11px]"
              >
                {settings.contactEmail || contact.email}
              </a>
            </p>
          </div>

          {/* Column 4: Links */}
          <div className="space-y-2">
            <span className="text-[11px] uppercase tracking-[0.2em] text-amber-600 dark:text-[#c5a059] font-medium block">
              Navigation
            </span>
            <div className="flex flex-col space-y-1.5 uppercase tracking-wider text-[11px]">
              <Link href="/menu" className="hover:text-stone-950 dark:hover:text-zinc-200 transition-colors">
                Menu
              </Link>
              <Link href="/about" className="hover:text-stone-950 dark:hover:text-zinc-200 transition-colors">
                About
              </Link>
              <Link href="/gallery" className="hover:text-stone-950 dark:hover:text-zinc-200 transition-colors">
                Gallery
              </Link>
              <Link href="/contact" className="hover:text-stone-950 dark:hover:text-zinc-200 transition-colors">
                Contact & Booking
              </Link>
              <Link href="/admin" className="text-stone-400 dark:text-zinc-600 hover:text-amber-600 dark:hover:text-[#c5a059] transition-colors pt-2">
                Staff Portal
              </Link>
            </div>
          </div>
        </div>

        {/* Bottom Credits */}
        <div className="pt-12 mt-12 border-t border-stone-200 dark:border-white/[0.04] flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-stone-500 dark:text-zinc-600">
          <p>© {new Date().getFullYear()} {settings.restaurantName}. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <Link href="/about" className="hover:text-zinc-400 transition-colors">Privacy</Link>
            <Link href="/contact" className="hover:text-zinc-400 transition-colors">Hospitality Terms</Link>
            <Link href="/admin" className="hover:text-[#c5a059] transition-colors">Staff Access</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

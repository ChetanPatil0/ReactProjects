'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu as MenuIcon, X, Sparkles, ArrowUpRight, Phone, Calendar } from 'lucide-react';
import { useReservation } from '@/context/ReservationContext';
import { ThemeToggle } from '@/components/theme/ThemeToggle';

interface NavbarProps {
  restaurantName: string;
  phone: string;
  logoUrl?: string;
  tagline?: string;
  announcement?: string;
}

const navLinks = [
  { name: 'Home', href: '/' },
  { name: 'Menu', href: '/menu' },
  { name: 'About', href: '/about' },
  { name: 'Gallery', href: '/gallery' },
  { name: 'Contact', href: '/contact' },
];

export function Navbar({
  restaurantName,
  phone,
  logoUrl,
  tagline,
  announcement,
}: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [bannerVisible, setBannerVisible] = useState(true);
  const pathname = usePathname();
  const { openReservation } = useReservation();

  const isHome = pathname === '/';

  // Track scroll position
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile drawer when route changes
  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  // Lock body scroll when mobile drawer is open
  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileOpen]);

  const hasBanner = bannerVisible && !!announcement;

  return (
    <header className="fixed top-0 left-0 right-0 z-50 w-full select-none">
      {/* ============================================================ */}
      {/* 1. INTEGRATED ANNOUNCEMENT BANNER */}
      {/* ============================================================ */}
      <AnimatePresence>
        {hasBanner && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden bg-amber-500/10 dark:bg-[#10131d] border-b border-amber-500/20 dark:border-[#c5a059]/25 text-stone-800 dark:text-[#ede6dc] text-[11px] sm:text-xs relative z-50 transition-colors"
          >
            <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 flex items-center justify-between gap-3">
              <div className="flex-1 flex items-center justify-center gap-2 text-center truncate">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-600 dark:bg-[#c5a059] animate-ping shrink-0" />
                <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-[#c5a059] shrink-0 hidden sm:inline" />
                <span className="font-light tracking-wide text-stone-700 dark:text-zinc-300 truncate">
                  {announcement}
                </span>
                <button
                  onClick={() => openReservation({ offerTitle: announcement })}
                  className="inline-flex items-center gap-1 text-amber-700 dark:text-[#e5c378] font-semibold hover:underline ml-2 cursor-pointer shrink-0"
                >
                  <span>Book Now</span>
                  <ArrowUpRight className="w-3 h-3" />
                </button>
              </div>

              <button
                onClick={() => setBannerVisible(false)}
                className="p-1 hover:bg-stone-200 dark:hover:bg-white/10 rounded-full text-stone-500 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white transition shrink-0 cursor-pointer"
                aria-label="Dismiss announcement"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================================================ */}
      {/* 2. MAIN NAVIGATION BAR */}
      {/* ============================================================ */}
      <nav
        className={`w-full transition-all duration-300 border-b ${
          scrolled || !isHome
            ? 'bg-white/90 dark:bg-[#07080a]/95 backdrop-blur-xl border-stone-200/80 dark:border-white/[0.08] shadow-md shadow-stone-900/5 dark:shadow-2xl dark:shadow-black/50 py-3 sm:py-3.5'
            : 'bg-white/75 dark:bg-[#07080a]/75 backdrop-blur-md border-stone-200/50 dark:border-white/[0.05] py-4 sm:py-4.5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Brand Identity / Royal Monogram */}
          <Link href="/" className="flex items-center gap-3 group">
            {logoUrl && !logoUrl.includes('unsplash') ? (
              <img
                src={logoUrl}
                alt={restaurantName}
                className="h-9 w-auto max-w-[120px] object-contain rounded"
              />
            ) : (
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500/20 via-amber-400/10 to-transparent border border-amber-600/30 dark:border-[#c5a059]/40 flex items-center justify-center text-amber-600 dark:text-[#e5c378] font-serif font-bold text-sm shadow-md shadow-amber-400/5 group-hover:border-amber-600 dark:group-hover:border-[#c5a059] transition-colors">
                <span>ZH</span>
              </div>
            )}
            <div className="flex flex-col">
              <span className="font-serif text-lg sm:text-xl font-normal tracking-wide text-stone-900 dark:text-[#faf8f5] group-hover:text-amber-600 dark:group-hover:text-[#c5a059] transition-colors leading-tight">
                {restaurantName}
              </span>
              <span className="text-[9px] tracking-[0.25em] uppercase text-stone-500 dark:text-zinc-500 font-medium">
                {tagline || 'Royal Indian Atelier'}
              </span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center gap-7 lg:gap-8">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.name}
                  href={link.href}
                  className={`text-xs uppercase tracking-[0.2em] transition-all relative py-1 font-medium ${
                    isActive ? 'text-amber-600 dark:text-[#c5a059] font-bold' : 'text-stone-600 hover:text-stone-950 dark:text-zinc-400 dark:hover:text-white'
                  }`}
                >
                  <span>{link.name}</span>
                  {isActive && (
                    <motion.span
                      layoutId="navUnderline"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-600 dark:bg-[#c5a059] rounded-full shadow-sm shadow-amber-500/50"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                </Link>
              );
            })}
          </div>

          {/* Right Action Cluster: Phone, Theme Switcher & Reserve CTA */}
          <div className="hidden md:flex items-center gap-4">
            <a
              href={`tel:${phone}`}
              className="text-xs text-stone-600 hover:text-stone-950 dark:text-zinc-400 dark:hover:text-white font-mono tracking-wider transition-colors flex items-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-amber-600 dark:text-[#c5a059]" />
              <span>{phone}</span>
            </a>

            {/* Next-Themes Switcher */}
            <ThemeToggle variant="dropdown" />

            <button
              onClick={() => openReservation()}
              className="px-4 lg:px-5 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black transition-all text-xs font-bold tracking-wider uppercase cursor-pointer shadow-md shadow-amber-400/20 hover:scale-[1.02] active:scale-[0.98]"
            >
              Reserve Table
            </button>
          </div>

          {/* Mobile Right Controls: Theme Toggle & Hamburger */}
          <div className="md:hidden flex items-center gap-2">
            <ThemeToggle variant="dropdown" />
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="p-2 rounded-xl bg-stone-100 dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 text-stone-700 dark:text-zinc-300 hover:text-stone-900 dark:hover:text-white transition cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileOpen ? <X className="w-5 h-5 text-amber-500" /> : <MenuIcon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </nav>

      {/* ============================================================ */}
      {/* 3. MOBILE FULL-SCREEN SLIDE-OVER DRAWER */}
      {/* ============================================================ */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.25 }}
            className="md:hidden fixed inset-0 top-0 bg-[#fcfbf7]/98 dark:bg-[#07080a]/98 backdrop-blur-2xl z-50 flex flex-col justify-between p-6 overflow-y-auto text-stone-900 dark:text-zinc-100"
          >
            {/* Drawer Top Header with Close */}
            <div className="flex items-center justify-between pb-6 border-b border-stone-200 dark:border-zinc-800">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-500 font-serif font-bold text-xs">
                  ZH
                </div>
                <div>
                  <h3 className="font-serif text-base text-stone-900 dark:text-zinc-100">{restaurantName}</h3>
                  <p className="text-[9px] text-amber-600 dark:text-amber-400 font-medium uppercase tracking-wider">
                    Royal Indian Atelier
                  </p>
                </div>
              </div>

              <button
                onClick={() => setMobileOpen(false)}
                className="p-2 rounded-xl bg-stone-100 dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 text-stone-500 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white cursor-pointer"
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Navigation Links */}
            <nav className="py-6 space-y-3">
              {navLinks.map((link) => {
                const isActive = pathname === link.href;
                return (
                  <Link
                    key={link.name}
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className={`block py-3 px-4 rounded-2xl text-base font-serif tracking-wider transition ${
                      isActive
                        ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300 font-bold border border-amber-500/30'
                        : 'text-stone-700 dark:text-zinc-300 hover:text-stone-950 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-zinc-900/60'
                    }`}
                  >
                    <span>{link.name}</span>
                  </Link>
                );
              })}
            </nav>

            {/* Theme Selector inside mobile drawer */}
            <div className="py-4 border-t border-b border-stone-200 dark:border-zinc-800 space-y-2">
              <div className="text-[11px] uppercase tracking-wider text-stone-500 dark:text-zinc-400 font-semibold">
                Theme / Appearance
              </div>
              <ThemeToggle variant="segmented" className="w-full justify-between" />
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 space-y-3">
              <button
                onClick={() => {
                  setMobileOpen(false);
                  openReservation();
                }}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-black text-xs font-bold tracking-widest uppercase shadow-lg shadow-amber-400/20 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Reserve a Table</span>
              </button>

              <a
                href={`tel:${phone}`}
                className="block text-center text-xs text-stone-500 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white font-mono tracking-wider py-1"
              >
                <Phone className="w-3.5 h-3.5 text-amber-500 inline mr-1.5" />
                {phone}
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

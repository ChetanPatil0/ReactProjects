'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Quote, Award } from 'lucide-react';

const REVIEWS = [
  {
    critic: 'The Michelin Guide 2026',
    role: 'Gastronomy Inspection Bureau',
    quote:
      'Ustad Rahimuddin delivers an extraordinary revival of royal Awadhi gastronomy. The Shahi Galouti Kebab and slow-cooked Awadhi Dum Gosht Biryani are modern triumphs of aroma, spice balance, and restrained emotion.',
    rating: 'Three Stars',
    badge: 'Three Michelin Stars 2026',
  },
  {
    critic: 'Condé Nast Traveller Gold List',
    role: 'Luxury Gastronomy Guide',
    quote:
      'The crown jewel of royal Indian dining in Mumbai. Zaffran Haveli proves that ancient Nawabi court recipes can be both historically authentic and uncompromisingly luxurious.',
    rating: 'Gold List Honor',
    badge: "Critic's Choice Award",
  },
  {
    critic: 'Asia’s 50 Best Restaurants',
    role: 'Continental Gastronomy Academy',
    quote:
      'From the charcoal-fired sigris to the pure Kashmiri saffron kahwas, every course unfolds like an imperial dawat for the senses. An unmissable destination for culinary travelers.',
    rating: 'Elite Selection',
    badge: 'Asia’s Top Culinary Discoveries',
  },
  {
    critic: 'Times Food & Nightlife Awards',
    role: 'National Heritage Honor',
    quote:
      'Uncompromising dedication to slow Dum Pukht traditions, hand-pounded spices, and revered Atithi Devo Bhava hospitality. The definitive benchmark for Indian fine dining.',
    rating: 'Best Fine Dining',
    badge: 'Iconic Indian Atelier of the Year',
  },
];

export function PressReviewsSection() {
  const [activeReview, setActiveReview] = useState(0);

  const next = () => setActiveReview((prev) => (prev + 1) % REVIEWS.length);
  const prev = () => setActiveReview((prev) => (prev - 1 + REVIEWS.length) % REVIEWS.length);

  const r = REVIEWS[activeReview];

  return (
    <section className="py-24 sm:py-32 px-6 sm:px-8 bg-[#090a0d] border-t border-white/[0.04]">
      <div className="max-w-5xl mx-auto space-y-12">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 pb-6 border-b border-white/[0.06]">
          <div className="space-y-2">
            <span className="text-[11px] uppercase tracking-[0.3em] text-[#c5a059] font-medium block">
              International Recognition
            </span>
            <h2 className="text-3xl sm:text-5xl font-serif font-light text-[#faf8f5] tracking-tight">
              Critics & Accolades
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-zinc-500 mr-2">
              0{activeReview + 1} / 0{REVIEWS.length}
            </span>
            <button
              onClick={prev}
              className="p-3 rounded-full border border-white/10 hover:border-[#c5a059] bg-[#0f1118] hover:bg-[#c5a059] text-zinc-300 hover:text-black transition-all cursor-pointer"
              aria-label="Previous Review"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={next}
              className="p-3 rounded-full border border-white/10 hover:border-[#c5a059] bg-[#0f1118] hover:bg-[#c5a059] text-zinc-300 hover:text-black transition-all cursor-pointer"
              aria-label="Next Review"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Carousel Quote Display */}
        <div className="relative min-h-[300px] flex items-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeReview}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
              className="p-8 sm:p-12 rounded-2xl bg-[#0e1017] border border-white/[0.06] shadow-2xl space-y-6 w-full"
            >
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full bg-[#c5a059]/10 border border-[#c5a059]/30 text-[10px] uppercase tracking-widest text-[#c5a059] font-semibold">
                  {r.badge}
                </span>
                <span className="text-xs font-serif text-[#c5a059] tracking-widest uppercase">
                  {r.rating}
                </span>
              </div>

              <Quote className="w-8 h-8 text-[#c5a059]/30" />

              <p className="text-lg sm:text-2xl font-serif text-[#faf8f5] font-light leading-relaxed italic">
                &ldquo;{r.quote}&rdquo;
              </p>

              <div className="pt-4 border-t border-white/[0.06] flex items-center justify-between">
                <div>
                  <h3 className="font-serif text-base text-zinc-200">{r.critic}</h3>
                  <p className="text-[11px] text-zinc-500 font-light uppercase tracking-wider">{r.role}</p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Review Indicator Thumbnails */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          {REVIEWS.map((rev, idx) => (
            <button
              key={idx}
              onClick={() => setActiveReview(idx)}
              className={`p-3.5 rounded-xl text-left border transition-all cursor-pointer ${
                activeReview === idx
                  ? 'bg-[#141722] border-[#c5a059] text-white shadow-md'
                  : 'bg-[#0b0c10] border-white/[0.04] text-zinc-500 hover:text-zinc-300'
              }`}
            >
              <span className="text-[10px] font-mono block text-[#c5a059]">0{idx + 1}</span>
              <p className="text-xs font-medium text-zinc-300 truncate mt-0.5">{rev.critic}</p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

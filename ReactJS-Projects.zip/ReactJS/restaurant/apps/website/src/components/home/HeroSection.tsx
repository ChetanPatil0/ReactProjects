'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Calendar, Users, Clock, Sparkles } from 'lucide-react';
import { HomepageData, RestaurantSettings } from '@/types/restaurant';
import { useReservation } from '@/context/ReservationContext';

interface HeroSectionProps {
  homepage: HomepageData;
  settings: RestaurantSettings;
}

const HERO_SCENES = [
  {
    tag: 'Imperial Awadhi Dum Pukht',
    headline: 'Centuries of Royal Gastronomy, Slow-Cooked to Perfection.',
    sub: 'Where ancestral Lucknowi khansama traditions converge with sealed copper degs, slow charcoal embers, and hand-pounded royal spices.',
    image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=1920&q=80',
    caption: 'Royal Dastarkhwan Feast — Awadhi Dum Gosht & Galouti Kebab',
  },
  {
    tag: 'Heritage Haveli Salons',
    headline: 'An Intimate Evening Amid Sandstone Arches & Jharokhas.',
    sub: 'Understated royal marble, hand-carved stone filigree, and warm brass lantern candlelight designed for unforgettable gatherings.',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1920&q=80',
    caption: 'Courtyard Dining Salon & Master Khansama Sigri Hearth',
  },
  {
    tag: 'Royal Botanical Elixirs',
    headline: 'Pure Kashmiri Saffron, Kahwas & Curated Vintages.',
    sub: 'Explore hand-infused Damascus rose thandais, Tellicherry black pepper libations, and grand cellar allocations poured table-side.',
    image: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=1920&q=80',
    caption: 'Artisanal Botanical Bar & Saffron Infusion Atelier',
  },
];

export function HeroSection({ homepage, settings }: HeroSectionProps) {
  const { openReservation } = useReservation();
  const [currentScene, setCurrentScene] = useState(0);

  // Quick booker state
  const [quickDate, setQuickDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  });
  const [quickTime, setQuickTime] = useState('19:30');
  const [quickGuests, setQuickGuests] = useState('2');

  const handleHeroFindTable = (e: React.FormEvent) => {
    e.preventDefault();
    openReservation({
      date: quickDate,
      time: quickTime,
      guests: quickGuests,
    });
  };

  // Auto-advance scenes every 8 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentScene((prev) => (prev + 1) % HERO_SCENES.length);
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  const scene = HERO_SCENES[currentScene];

  return (
    <section className="relative min-h-[96vh] flex flex-col justify-between pt-28 pb-12 px-6 sm:px-8 bg-[#07080a] overflow-hidden select-none">
      {/* Background Photography Slider with Crossfade */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentScene}
            initial={{ opacity: 0, scale: 1.04 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="absolute inset-0"
          >
            <img
              src={scene.image}
              alt={scene.headline}
              className="w-full h-full object-cover object-center filter brightness-[0.6] contrast-[1.1]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#07080a] via-[#07080a]/60 to-[#07080a]/40" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#07080a]/90 via-transparent to-[#07080a]/60" />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Slide Navigation Arrows */}
      <div className="hidden sm:flex absolute top-1/2 -translate-y-1/2 left-6 right-6 z-20 items-center justify-between pointer-events-none">
        <button
          onClick={() => setCurrentScene((prev) => (prev - 1 + HERO_SCENES.length) % HERO_SCENES.length)}
          className="p-3 rounded-full border border-white/10 bg-black/40 hover:bg-[#c5a059] text-white hover:text-black transition-all cursor-pointer pointer-events-auto backdrop-blur-md"
          aria-label="Previous scene"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button
          onClick={() => setCurrentScene((prev) => (prev + 1) % HERO_SCENES.length)}
          className="p-3 rounded-full border border-white/10 bg-black/40 hover:bg-[#c5a059] text-white hover:text-black transition-all cursor-pointer pointer-events-auto backdrop-blur-md"
          aria-label="Next scene"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Center Editorial Narrative */}
      <div className="relative max-w-4xl mx-auto w-full text-center space-y-7 z-10 my-auto">
        {/* Dynamic Tag Pill */}
        <AnimatePresence mode="wait">
          <motion.div
            key={`tag-${currentScene}`}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.5 }}
            className="text-[11px] uppercase tracking-[0.35em] text-[#c5a059] font-medium"
          >
            {scene.tag}
          </motion.div>
        </AnimatePresence>

        {/* Dynamic Headline */}
        <AnimatePresence mode="wait">
          <motion.h1
            key={`head-${currentScene}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.6 }}
            className="text-4xl sm:text-6xl md:text-7xl font-serif font-light text-[#faf8f5] tracking-tight leading-[1.08]"
          >
            {scene.headline}
          </motion.h1>
        </AnimatePresence>

        {/* Dynamic Subtitle */}
        <AnimatePresence mode="wait">
          <motion.p
            key={`sub-${currentScene}`}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="max-w-2xl mx-auto text-zinc-300 text-sm sm:text-base font-light leading-relaxed"
          >
            {scene.sub}
          </motion.p>
        </AnimatePresence>

        {/* Architectural Table Booking Bar */}
        <div className="max-w-3xl mx-auto pt-3">
          <form
            onSubmit={handleHeroFindTable}
            className="p-2.5 sm:p-3 rounded-2xl bg-[#0e1017]/90 border border-white/[0.1] backdrop-blur-xl flex flex-col sm:flex-row items-center gap-2.5 shadow-2xl"
          >
            <div className="w-full sm:w-auto flex-1 px-4 py-2 text-left rounded-xl bg-black/50 border border-white/[0.05]">
              <span className="block text-[9px] uppercase tracking-widest text-[#c5a059] font-semibold">
                Dining Date
              </span>
              <input
                type="date"
                value={quickDate}
                onChange={(e) => setQuickDate(e.target.value)}
                className="bg-transparent text-xs text-zinc-200 font-medium focus:outline-hidden w-full cursor-pointer"
              />
            </div>

            <div className="w-full sm:w-auto flex-1 px-4 py-2 text-left rounded-xl bg-black/50 border border-white/[0.05]">
              <span className="block text-[9px] uppercase tracking-widest text-[#c5a059] font-semibold">
                Service Seating
              </span>
              <select
                value={quickTime}
                onChange={(e) => setQuickTime(e.target.value)}
                className="bg-transparent text-xs text-zinc-200 font-medium focus:outline-hidden w-full cursor-pointer"
              >
                <option value="17:30" className="bg-[#0e1017]">05:30 PM (Early Tasting)</option>
                <option value="18:30" className="bg-[#0e1017]">06:30 PM</option>
                <option value="19:30" className="bg-[#0e1017]">07:30 PM (Peak Degustation)</option>
                <option value="20:30" className="bg-[#0e1017]">08:30 PM</option>
                <option value="21:30" className="bg-[#0e1017]">09:30 PM (Late Cellar)</option>
              </select>
            </div>

            <div className="w-full sm:w-auto flex-1 px-4 py-2 text-left rounded-xl bg-black/50 border border-white/[0.05]">
              <span className="block text-[9px] uppercase tracking-widest text-[#c5a059] font-semibold">
                Guests
              </span>
              <select
                value={quickGuests}
                onChange={(e) => setQuickGuests(e.target.value)}
                className="bg-transparent text-xs text-zinc-200 font-medium focus:outline-hidden w-full cursor-pointer"
              >
                <option value="1" className="bg-[#0e1017]">1 Guest (Solo Tasting)</option>
                <option value="2" className="bg-[#0e1017]">2 Guests (Couple)</option>
                <option value="3" className="bg-[#0e1017]">3 Guests</option>
                <option value="4" className="bg-[#0e1017]">4 Guests</option>
                <option value="6" className="bg-[#0e1017]">6 Guests (Salon Table)</option>
                <option value="8+" className="bg-[#0e1017]">8+ Guests (Private Vault)</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-[#c5a059] hover:bg-[#d4af37] text-zinc-950 font-semibold text-xs tracking-wider uppercase transition-colors shrink-0 shadow-lg cursor-pointer"
            >
              Reserve Table
            </button>
          </form>
        </div>
      </div>

      {/* Bottom Scene Slider Indicators & Caption */}
      <div className="relative z-10 max-w-6xl mx-auto w-full pt-8 border-t border-white/[0.08] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
        {/* Caption */}
        <p className="text-zinc-500 font-light italic truncate max-w-sm">
          {scene.caption}
        </p>

        {/* Scene Selection Pills */}
        <div className="flex items-center gap-2">
          {HERO_SCENES.map((s, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentScene(idx)}
              className={`px-3 py-1.5 rounded-full text-[11px] uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 ${
                currentScene === idx
                  ? 'bg-white/10 text-[#c5a059] border border-[#c5a059]/40'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              <span className="font-mono text-[10px]">0{idx + 1}</span>
              <span className="hidden md:inline">{s.tag.split(' ')[0]}</span>
            </button>
          ))}
        </div>

        {/* Live Hours Indicator */}
        <div className="text-zinc-400 font-mono text-[11px] flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>{settings.openingHours || 'Tue – Sun: 5:00 PM – 11:30 PM'}</span>
        </div>
      </div>
    </section>
  );
}

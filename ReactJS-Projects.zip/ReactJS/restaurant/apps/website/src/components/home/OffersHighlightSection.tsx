'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowUpRight, Sparkles, Tag, Calendar, Wine, Check, Copy } from 'lucide-react';
import { OfferItem } from '@/types/restaurant';
import { getMediaUrl } from '@/lib/api/restaurant';
import { useReservation } from '@/context/ReservationContext';

interface OffersHighlightSectionProps {
  offers: OfferItem[];
}

export function OffersHighlightSection({ offers }: OffersHighlightSectionProps) {
  const { openReservation } = useReservation();
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  if (!offers || offers.length === 0) return null;

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full relative">
      <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#d4af37]/30 bg-[#d4af37]/10 text-[#e5c378] text-xs tracking-[0.2em] uppercase font-semibold">
          <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>Exclusive Seasonal Privileges</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-serif font-light text-[#fcfbf9] tracking-tight">
          Curated Tasting Flights & Perks
        </h2>
        <p className="text-stone-400 text-sm font-light">
          Reserved privileges for our direct patrons, master sommelier cellar pairings, and weekend degustations.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {offers.map((offer, idx) => {
          const imgUrl = getMediaUrl(offer.bannerImage?.url);
          return (
            <motion.div
              key={offer.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.15, duration: 0.8 }}
              className="group relative rounded-3xl overflow-hidden border border-[#d4af37]/30 bg-[#12141d]/90 flex flex-col justify-between p-8 sm:p-10 shadow-2xl hover:border-[#d4af37]/60 transition-all duration-500"
            >
              {imgUrl && (
                <div className="absolute inset-0 z-0 opacity-20 group-hover:opacity-30 transition-opacity duration-700">
                  <img
                    src={imgUrl}
                    alt={offer.title}
                    className="w-full h-full object-cover scale-105 group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-linear-to-r from-[#12141d] via-[#12141d]/90 to-transparent" />
                </div>
              )}

              <div className="relative z-10 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#d4af37]/15 border border-[#d4af37]/40 text-[#e5c378] text-[11px] font-semibold tracking-wider uppercase">
                    <Tag className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>{offer.discountValue || 'Special Degustation'}</span>
                  </div>

                  {offer.code && (
                    <button
                      onClick={() => handleCopyCode(offer.code!)}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-white/5 border border-white/10 text-stone-300 hover:text-white text-xs font-mono transition-colors cursor-pointer"
                    >
                      {copiedCode === offer.code ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3 text-[#d4af37]" />
                          <span>Code: {offer.code}</span>
                        </>
                      )}
                    </button>
                  )}
                </div>

                <h3 className="text-2xl sm:text-3xl font-serif text-white font-light group-hover:text-[#e5c378] transition-colors">
                  {offer.title}
                </h3>
                <p className="text-sm text-stone-300 font-light leading-relaxed max-w-md">
                  {offer.description}
                </p>
              </div>

              <div className="relative z-10 pt-8 mt-6 border-t border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-stone-400">
                  <Calendar className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>Limited Seasonal Availability</span>
                </div>

                <button
                  onClick={() => openReservation({ offerTitle: offer.title })}
                  className="px-5 py-2.5 rounded-full bg-linear-to-r from-[#d4af37] via-[#f7e6c4] to-[#d4af37] text-stone-950 text-xs font-bold uppercase tracking-wider hover:scale-105 active:scale-95 transition-all shadow-lg shadow-[#d4af37]/20 cursor-pointer"
                >
                  Book With Privilege
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}

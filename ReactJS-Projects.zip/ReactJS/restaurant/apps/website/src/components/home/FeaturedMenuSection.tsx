'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { MenuCategory, MenuItem, RestaurantSettings } from '@/types/restaurant';
import { getMediaUrl } from '@/lib/api/restaurant';
import { useReservation } from '@/context/ReservationContext';

interface FeaturedMenuSectionProps {
  categories: MenuCategory[];
  items: MenuItem[];
  settings: RestaurantSettings;
}

export function FeaturedMenuSection({ categories, items, settings }: FeaturedMenuSectionProps) {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const { openReservation } = useReservation();

  const filtered = items
    .filter((item) => {
      if (activeCategory === 'all') return true;
      const itemCatId = item.category?.slug || item.category?.id;
      return itemCatId === activeCategory;
    })
    .slice(0, 6);

  return (
    <section id="menu" className="py-24 sm:py-32 px-6 sm:px-8 bg-[#07080a] border-t border-white/[0.04]">
      <div className="max-w-6xl mx-auto space-y-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-white/[0.06]">
          <div className="space-y-2">
            <span className="text-[11px] uppercase tracking-[0.3em] text-[#c5a059] font-medium block">
              Royal Dastarkhwan
            </span>
            <h2 className="text-3xl sm:text-5xl font-serif font-light text-[#faf8f5] tracking-tight">
              Imperial Chef Selections
            </h2>
          </div>

          {/* Minimal Category Tabs */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveCategory('all')}
              className={`px-3 py-1.5 text-xs uppercase tracking-[0.15em] transition-colors ${
                activeCategory === 'all'
                  ? 'text-[#c5a059] border-b border-[#c5a059]'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              All Selections
            </button>
            {categories.slice(0, 5).map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.slug || String(cat.id))}
                className={`px-3 py-1.5 text-xs uppercase tracking-[0.15em] transition-colors ${
                  activeCategory === (cat.slug || String(cat.id))
                    ? 'text-[#c5a059] border-b border-[#c5a059]'
                    : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Menu Grid - Clean Two-Column Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {filtered.map((dish) => (
            <div
              key={dish.id}
              className="flex gap-4 p-4 rounded-lg bg-[#0c0d12]/60 border border-white/[0.04] hover:border-white/[0.1] transition-all group"
            >
              {dish.image?.url && (
                <div className="w-20 h-20 rounded overflow-hidden shrink-0 bg-zinc-900">
                  <img
                    src={getMediaUrl(dish.image.url)}
                    alt={dish.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
              )}

              <div className="flex-1 min-w-0 space-y-1">
                <div className="flex items-baseline justify-between gap-3">
                  <h3 className="font-serif text-base text-zinc-100 group-hover:text-[#c5a059] transition-colors truncate">
                    {dish.name}
                  </h3>
                  <span className="font-mono text-xs text-zinc-300 font-medium shrink-0">
                    {settings.currencySymbol || '₹'}
                    {dish.price.toFixed(2)}
                  </span>
                </div>

                {dish.description && (
                  <p className="text-xs text-zinc-500 font-light line-clamp-2 leading-relaxed">
                    {dish.description}
                  </p>
                )}

                <div className="pt-1 flex items-center gap-2 text-[10px] text-zinc-500 uppercase tracking-wider">
                  <span className={`w-1.5 h-1.5 rounded-full ${dish.isVeg ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                  <span>{dish.isVeg ? 'Vegetarian' : 'Chef Selection'}</span>
                  {dish.isSignature && (
                    <>
                      <span>•</span>
                      <span className="text-[#c5a059]">Signature</span>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View Full Menu CTA */}
        <div className="pt-6 text-center">
          <Link
            href="/menu"
            className="inline-block px-8 py-3 rounded border border-white/[0.15] hover:border-[#c5a059] text-xs uppercase tracking-[0.2em] text-zinc-300 hover:text-[#c5a059] transition-all font-medium"
          >
            Explore Complete Menu & Wine List &rarr;
          </Link>
        </div>
      </div>
    </section>
  );
}

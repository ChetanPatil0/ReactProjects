'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Wine, Sparkles, Utensils } from 'lucide-react';
import { MenuItem } from '@/types/restaurant';
import { getMediaUrl } from '@/lib/api/restaurant';
import { useReservation } from '@/context/ReservationContext';

interface SignatureDishesSliderProps {
  items: MenuItem[];
  currencySymbol?: string;
}

export function SignatureDishesSlider({ items, currencySymbol = '₹' }: SignatureDishesSliderProps) {
  const { openReservation } = useReservation();
  
  // Filter signature or standout dishes (fallback to all items if none marked signature)
  const signatureItems = items.filter((i) => i.isSignature).length > 0 
    ? items.filter((i) => i.isSignature)
    : items.slice(0, 6);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const total = signatureItems.length;

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % total);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + total) % total);
  };

  // Optional subtle auto-advance every 6s unless hovered
  useEffect(() => {
    if (isPaused || total <= 1) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % total);
    }, 6000);
    return () => clearInterval(timer);
  }, [isPaused, total]);

  if (total === 0) return null;

  const currentDish = signatureItems[currentIndex];
  const imgUrl = getMediaUrl(currentDish.image?.url);

  // Curated royal pairings based on Awadhi and Mughlai culinary profile
  const samplePairings = [
    'Imperial Kashmiri Saffron Kahwa with Almonds & Green Cardamom',
    'Thandai Royale Infused with Roasted Poppy Seeds & Damascus Rose',
    'Wild Jamun & Rock Salt Kala Khatta Shahi Fizz',
    'Smoked Cardamom Khus Sherbet & Vetiver Botanical Elixir',
    'Château Margaux Premier Grand Cru Vintage Reserve',
  ];
  const pairingNote = samplePairings[currentIndex % samplePairings.length];

  return (
    <section 
      className="py-24 sm:py-32 px-6 sm:px-8 bg-[#090a0e] border-t border-[#c5a059]/15 relative overflow-hidden"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Background radial accent */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-[#c5a059]/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-6xl mx-auto space-y-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-white/[0.06]">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.3em] text-[#c5a059] font-medium">
              <span>Imperial Khansama Creations</span>
              <span>•</span>
              <span>Carousel Slider</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif font-light text-[#faf8f5] tracking-tight">
              Signature Royal Delicacies
            </h2>
            <p className="text-zinc-400 text-xs sm:text-sm max-w-xl font-light">
              Each dish honors 200-year-old royal Awadhi recipes, slow charcoal sigri purdah dum, and hand-pounded spice terroir.
            </p>
          </div>

          {/* Slider Controls (Next / Prev & Counter) */}
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-zinc-400 mr-2">
              <strong className="text-[#c5a059]">{String(currentIndex + 1).padStart(2, '0')}</strong>
              <span className="text-zinc-600"> / {String(total).padStart(2, '0')}</span>
            </span>

            <button
              onClick={prevSlide}
              aria-label="Previous Slide"
              className="p-3 rounded-full border border-white/10 hover:border-[#c5a059] bg-[#12141c] hover:bg-[#c5a059] text-zinc-300 hover:text-black transition-all cursor-pointer shadow-lg"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <button
              onClick={nextSlide}
              aria-label="Next Slide"
              className="p-3 rounded-full border border-white/10 hover:border-[#c5a059] bg-[#12141c] hover:bg-[#c5a059] text-zinc-300 hover:text-black transition-all cursor-pointer shadow-lg"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Carousel Slide Card (Interactive Transition) */}
        <div className="relative min-h-[460px] sm:min-h-[400px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentDish.id}
              initial={{ opacity: 0, x: 25 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -25 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center bg-[#0e1017] border border-white/[0.08] hover:border-[#c5a059]/35 rounded-2xl p-6 sm:p-10 shadow-2xl transition-all"
            >
              {/* Left Column: Dish Photography */}
              <div className="lg:col-span-6 relative">
                <div className="aspect-[4/3] rounded-xl overflow-hidden bg-black/60 border border-white/10 relative group">
                  {imgUrl ? (
                    <img
                      src={imgUrl}
                      alt={currentDish.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-zinc-600">
                      <Utensils className="w-12 h-12" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />

                  {/* Dietary badge */}
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 rounded-full bg-black/80 backdrop-blur-md border border-white/15 text-[10px] uppercase tracking-widest font-semibold text-[#c5a059]">
                      {currentDish.isVeg ? 'Vegetarian Atelier' : 'Signature Entrée'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Right Column: Dish Narrative & Pairings */}
              <div className="lg:col-span-6 space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase tracking-[0.25em] text-[#c5a059] font-medium">
                      Course {currentIndex + 1} Selection
                    </span>
                    <span className="font-mono text-xl sm:text-2xl font-semibold text-[#faf8f5]">
                      {currencySymbol}{currentDish.price.toFixed(2)}
                    </span>
                  </div>

                  <h3 className="text-2xl sm:text-4xl font-serif font-light text-[#faf8f5] tracking-tight">
                    {currentDish.name}
                  </h3>
                </div>

                <p className="text-zinc-400 text-sm sm:text-base font-light leading-relaxed">
                  {currentDish.description ||
                    'Crafted daily with hand-selected ingredients from artisanal purveyors, married to contemporary culinary reduction.'}
                </p>

                {/* Sommelier Pairing Card */}
                <div className="p-4 rounded-xl bg-[#141722]/80 border border-white/[0.06] space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#c5a059]">
                    <Wine className="w-4 h-4 shrink-0" />
                    <span className="uppercase tracking-wider text-[11px]">Recommended Cellar Pairing</span>
                  </div>
                  <p className="text-xs text-zinc-300 font-light italic pl-6">
                    {pairingNote}
                  </p>
                </div>

                {/* Actions */}
                <div className="pt-2 flex flex-wrap items-center gap-4">
                  <button
                    onClick={() => openReservation({ dishName: currentDish.name })}
                    className="px-6 py-3 rounded-lg bg-[#c5a059] hover:bg-[#d4af37] text-zinc-950 font-semibold text-xs tracking-wider uppercase transition-colors shadow-lg shadow-[#c5a059]/20 cursor-pointer"
                  >
                    Reserve Table for This Dish
                  </button>

                  <span className="text-xs text-zinc-500 font-light">
                    Complimentary table booking • Concierge confirmed
                  </span>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Carousel Pagination Dots */}
        <div className="flex items-center justify-center gap-2 pt-4">
          {signatureItems.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              aria-label={`Go to slide ${idx + 1}`}
              className={`h-1.5 transition-all rounded-full cursor-pointer ${
                currentIndex === idx
                  ? 'w-8 bg-[#c5a059]'
                  : 'w-2 bg-zinc-700 hover:bg-zinc-500'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

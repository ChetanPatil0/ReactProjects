'use client';

import React from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { RestaurantSettings } from '@/types/restaurant';
import { useReservation } from '@/context/ReservationContext';

interface ReservationCalloutSectionProps {
  settings: RestaurantSettings;
}

export function ReservationCalloutSection({ settings }: ReservationCalloutSectionProps) {
  const { openReservation } = useReservation();

  return (
    <section className="py-24 px-6 sm:px-8 bg-[#07080a] border-t border-white/[0.04]">
      <div className="max-w-4xl mx-auto rounded-lg border border-white/[0.06] bg-[#0c0d12] p-10 sm:p-16 text-center space-y-6">
        <span className="text-[11px] uppercase tracking-[0.3em] text-[#c5a059] font-medium block">
          Private Dining & Reservations
        </span>

        <h2 className="text-3xl sm:text-5xl font-serif font-light text-[#faf8f5] tracking-tight leading-tight">
          Reserve an Evening of Exceptional Terroir & Gastronomy
        </h2>

        <p className="text-zinc-400 text-sm sm:text-base font-light max-w-xl mx-auto leading-relaxed">
          For table reservations, private tasting salons, and exclusive wine cellar experiences, our hospitality concierge is at your service.
        </p>

        <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={() => openReservation()}
            className="px-8 py-3.5 rounded bg-[#c5a059] hover:bg-[#d4af37] text-black font-semibold text-xs tracking-[0.2em] uppercase transition-colors cursor-pointer"
          >
            Reserve Online
          </button>

          <a
            href={`tel:${settings.contactNumber}`}
            className="px-8 py-3.5 rounded border border-white/[0.15] hover:border-[#c5a059] text-zinc-300 hover:text-[#c5a059] text-xs font-semibold tracking-[0.2em] uppercase transition-colors"
          >
            Call: {settings.contactNumber}
          </a>
        </div>

        <div className="pt-6 text-xs text-zinc-500 font-mono border-t border-white/[0.06] max-w-md mx-auto">
          {settings.openingHours || 'Tue – Sun: 5:00 PM – 11:30 PM | Mon: Closed'}
        </div>
      </div>
    </section>
  );
}

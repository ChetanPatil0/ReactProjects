'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, X, Users, Sparkles, ZoomIn } from 'lucide-react';
import { GalleryItem } from '@/types/restaurant';
import { getMediaUrl } from '@/lib/api/restaurant';
import { useReservation } from '@/context/ReservationContext';

interface AmbiancePreviewSectionProps {
  galleryItems: GalleryItem[];
}

const DINING_SPACES = [
  {
    id: 'main-courtyard',
    title: 'The Royal Courtyard Salon',
    category: 'Heritage Court Dining',
    capacity: 'Seating for up to 68 Guests',
    desc: 'Hand-carved jharokhas, antique brass lanterns, and gentle acoustic melodies under heritage high archways.',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1400&q=80',
  },
  {
    id: 'khansama-hearth',
    title: 'The Sigri & Tandoor Hearth',
    category: 'Live Khansama Counter',
    capacity: '8 Front-Row Tandoor Counter Seats',
    desc: 'An immersive view of the clay tandoors, slow charcoal sigris, and live Galouti kebab plating artistry.',
    image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1400&q=80',
  },
  {
    id: 'shahi-salon',
    title: 'The Shahi Dastarkhwan Salon',
    category: 'Private Royal Dining',
    capacity: 'Private Dining for 6 to 16 Guests',
    desc: 'Dedicated Master Khansama, private entrance, and bespoke 9-course Awadhi Dum Pukht feast served on fine silver.',
    image: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=1400&q=80',
  },
  {
    id: 'jharokha-terrace',
    title: 'The Jharokha Garden Terrace',
    category: 'Alfresco Starlight Dining',
    capacity: 'Courtyard Terrace for 28 Guests',
    desc: 'Surrounded by blooming night jasmine, fragrant vetiver, and illuminated stone fountains under the evening starlight.',
    image: 'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?auto=format&fit=crop&w=1400&q=80',
  },
];

export function AmbiancePreviewSection({ galleryItems }: AmbiancePreviewSectionProps) {
  const { openReservation } = useReservation();
  const [activeSpaceIdx, setActiveSpaceIdx] = useState(0);
  const [lightboxPhoto, setLightboxPhoto] = useState<string | null>(null);

  const nextSpace = () => setActiveSpaceIdx((prev) => (prev + 1) % DINING_SPACES.length);
  const prevSpace = () => setActiveSpaceIdx((prev) => (prev - 1 + DINING_SPACES.length) % DINING_SPACES.length);

  const currentSpace = DINING_SPACES[activeSpaceIdx];

  return (
    <section className="py-24 sm:py-32 px-6 sm:px-8 bg-[#07080a] border-t border-white/[0.04]">
      <div className="max-w-6xl mx-auto space-y-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-white/[0.06]">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.3em] text-[#c5a059] font-medium">
              <span>Atmospheric Architecture</span>
              <span>•</span>
              <span>Spaces Slider</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif font-light text-[#faf8f5] tracking-tight">
              Dining Rooms & Salons
            </h2>
            <p className="text-zinc-400 text-xs sm:text-sm max-w-xl font-light">
              Explore our varied dining environments, from the vibrant main sanctuary to private subterranean tasting vaults.
            </p>
          </div>

          {/* Carousel Buttons */}
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-zinc-500 mr-2">
              0{activeSpaceIdx + 1} / 0{DINING_SPACES.length}
            </span>

            <button
              onClick={prevSpace}
              className="p-3 rounded-full border border-white/10 hover:border-[#c5a059] bg-[#0f1118] hover:bg-[#c5a059] text-zinc-300 hover:text-black transition-all cursor-pointer"
              aria-label="Previous Space"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <button
              onClick={nextSpace}
              className="p-3 rounded-full border border-white/10 hover:border-[#c5a059] bg-[#0f1118] hover:bg-[#c5a059] text-zinc-300 hover:text-black transition-all cursor-pointer"
              aria-label="Next Space"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Interactive Space Showcase Slider */}
        <div className="relative min-h-[460px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSpace.id}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.45 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center bg-[#0d0f15] border border-white/[0.08] hover:border-[#c5a059]/30 rounded-2xl overflow-hidden shadow-2xl p-6 sm:p-10"
            >
              {/* Space Photography */}
              <div className="lg:col-span-7 h-[300px] sm:h-[420px] rounded-xl overflow-hidden relative group bg-black">
                <img
                  src={currentSpace.image}
                  alt={currentSpace.title}
                  className="w-full h-full object-cover filter brightness-[0.85] contrast-[1.1] transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />

                <button
                  onClick={() => setLightboxPhoto(currentSpace.image)}
                  className="absolute bottom-4 right-4 p-2.5 rounded-full bg-black/70 hover:bg-[#c5a059] text-white hover:text-black transition-all cursor-pointer backdrop-blur-md"
                  title="Expand Photography"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>

                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 rounded-full bg-black/80 backdrop-blur-md border border-white/15 text-[10px] uppercase tracking-widest font-semibold text-[#c5a059]">
                    {currentSpace.category}
                  </span>
                </div>
              </div>

              {/* Space Details */}
              <div className="lg:col-span-5 space-y-6">
                <div className="space-y-2">
                  <span className="text-[10px] uppercase tracking-[0.25em] text-[#c5a059] font-medium block">
                    Salon Environment
                  </span>
                  <h3 className="text-2xl sm:text-4xl font-serif font-light text-[#faf8f5] tracking-tight">
                    {currentSpace.title}
                  </h3>
                </div>

                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#141722] border border-white/[0.05] text-xs text-zinc-300 font-mono">
                  <Users className="w-3.5 h-3.5 text-[#c5a059]" />
                  <span>{currentSpace.capacity}</span>
                </div>

                <p className="text-zinc-400 text-xs sm:text-sm font-light leading-relaxed">
                  {currentSpace.desc}
                </p>

                <div className="pt-2 flex flex-wrap items-center gap-4">
                  <button
                    onClick={() => openReservation({ area: currentSpace.id })}
                    className="px-6 py-3 rounded-lg bg-[#c5a059] hover:bg-[#d4af37] text-zinc-950 font-semibold text-xs tracking-wider uppercase transition-colors shadow-lg cursor-pointer"
                  >
                    Reserve Table in {currentSpace.title.split(' ')[1] || 'Room'}
                  </button>

                  <Link
                    href="/gallery"
                    className="text-xs text-zinc-400 hover:text-white uppercase tracking-wider transition-colors"
                  >
                    View All Photos &rarr;
                  </Link>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Space Tab Navigation Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4">
          {DINING_SPACES.map((space, idx) => (
            <button
              key={space.id}
              onClick={() => setActiveSpaceIdx(idx)}
              className={`p-4 rounded-xl text-left border transition-all cursor-pointer ${
                activeSpaceIdx === idx
                  ? 'bg-[#141722] border-[#c5a059] text-white shadow-lg'
                  : 'bg-[#0b0c10] border-white/[0.04] text-zinc-500 hover:text-zinc-300 hover:border-white/[0.1]'
              }`}
            >
              <span className="text-[10px] uppercase font-mono block text-[#c5a059]">0{idx + 1}</span>
              <p className="text-xs font-semibold text-zinc-200 mt-1 truncate">{space.title}</p>
              <span className="text-[10px] text-zinc-500 block truncate">{space.category}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {lightboxPhoto && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              onClick={() => setLightboxPhoto(null)}
              className="fixed inset-0 bg-black/40 backdrop-blur-md"
            />
            <div className="relative max-w-5xl w-full rounded-2xl overflow-hidden border border-white/20 bg-[#090b10]/85 backdrop-blur-2xl shadow-2xl shadow-black/50 z-10">
              <button
                onClick={() => setLightboxPhoto(null)}
                className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-black/70 text-zinc-300 hover:text-white transition-colors cursor-pointer"
                aria-label="Close photo"
              >
                <X className="w-5 h-5" />
              </button>
              <img
                src={lightboxPhoto}
                alt="Enlarged Room"
                className="w-full max-h-[85vh] object-contain mx-auto"
              />
            </div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}

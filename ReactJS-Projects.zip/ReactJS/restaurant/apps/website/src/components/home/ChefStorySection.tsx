'use client';

import React from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { AboutData, RestaurantSettings } from '@/types/restaurant';
import { getMediaUrl } from '@/lib/api/restaurant';

interface ChefStorySectionProps {
  about: AboutData;
  settings?: RestaurantSettings;
}

const CULINARY_PILLARS = [
  {
    num: 'I',
    title: 'Dum Pukht Charcoal Embers',
    desc: 'Sealed heavy-bottom copper degs slow-simmered over fragrant wood embers to lock in aromatic herbal essences.',
  },
  {
    num: 'II',
    title: 'Heirloom Spice Terroir',
    desc: 'Pure Kashmiri saffron, Tellicherry whole black peppercorns, and stone-ground spices roasted on iron tawas.',
  },
  {
    num: 'III',
    title: 'Atithi Devo Bhava',
    desc: 'Aristocratic Awadhi courtly hospitality where every dining salon is an unforgettable royal dawat feast.',
  },
];

export function ChefStorySection({ about, settings }: ChefStorySectionProps) {
  return (
    <section className="py-24 sm:py-32 px-6 sm:px-8 bg-[#090a0d] border-t border-white/[0.04]">
      <div className="max-w-6xl mx-auto space-y-16">
        {/* Main Editorial Story Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Narrative & Chef Persona */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-3">
              <span className="text-[11px] uppercase tracking-[0.3em] text-[#c5a059] font-medium block">
                The Atelier & Philosophy
              </span>
              <h2 className="text-3xl sm:text-5xl font-serif font-light text-[#faf8f5] tracking-tight leading-[1.14]">
                {about.storyTitle || 'A Devotion to Culinary Artistry & Terroir.'}
              </h2>
            </div>

            <div className="space-y-5 text-zinc-400 text-sm sm:text-base font-light leading-relaxed">
              <p>
                {about.storyContent ||
                  "Founded with an unwavering commitment to regenerative provenance, each seasonal course at L'Étoile brings together master purveyors, foragers, and certified sommeliers."}
              </p>
              <p className="text-zinc-500 text-xs sm:text-sm">
                We believe dining transcends sustenance — it is a choreographed ritual of connection, texture, and emotional resonance.
              </p>
            </div>

            {/* Chef Profile Card */}
            <div className="pt-6 border-t border-white/[0.06] flex items-center justify-between">
              <div>
                <h3 className="font-serif text-lg text-zinc-200">
                  {about.chefName || 'Chef Alessandro Rossi'}
                </h3>
                <p className="text-xs text-zinc-500 font-light mt-0.5">
                  {about.chefBio || 'Executive Chef & Culinary Director • Three-Star Michelin Atelier Alum'}
                </p>
              </div>

              <Link
                href="/about"
                className="text-xs uppercase tracking-[0.2em] text-[#c5a059] hover:text-[#d4af37] transition-colors shrink-0"
              >
                Our Heritage &rarr;
              </Link>
            </div>
          </div>

          {/* Right Column: Editorial Visual Spread */}
          <div className="lg:col-span-5 relative">
            <div className="aspect-[4/5] rounded-xl overflow-hidden border border-white/[0.08] bg-[#12141c] shadow-2xl relative group">
              <img
                src={
                  about.chefImage?.url
                    ? getMediaUrl(about.chefImage.url)
                    : about.storyImage?.url
                    ? getMediaUrl(about.storyImage.url)
                    : 'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=1000&q=80'
                }
                alt={about.chefName || "Chef's Atelier"}
                className="w-full h-full object-cover filter brightness-[0.88] contrast-[1.08] transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent pointer-events-none" />

              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-lg bg-black/60 backdrop-blur-md border border-white/10">
                <p className="font-serif text-xs text-zinc-300 italic">
                  &ldquo;Every ingredient carries the memory of rain, soil, and human hands.&rdquo;
                </p>
                <span className="text-[10px] uppercase tracking-widest text-[#c5a059] font-medium block mt-1">
                  — Chef Alessandro
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 3 Pillars of Gastronomy */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-8 border-t border-white/[0.06]">
          {CULINARY_PILLARS.map((p) => (
            <div key={p.num} className="p-6 rounded-xl bg-[#0d0f15] border border-white/[0.04] space-y-2">
              <span className="text-xs font-serif font-light text-[#c5a059]">{p.num}</span>
              <h4 className="font-serif text-base text-zinc-100">{p.title}</h4>
              <p className="text-xs text-zinc-400 font-light leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

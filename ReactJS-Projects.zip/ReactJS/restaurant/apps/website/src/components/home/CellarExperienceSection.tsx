'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Wine, Sparkles, ChevronLeft, ChevronRight, GlassWater, Award, ShieldCheck } from 'lucide-react';
import { useReservation } from '@/context/ReservationContext';

const CELLAR_HIGHLIGHTS = [
  {
    title: 'Old World Grand Crus & Vintage Reserves',
    subtitle: 'Burgundy, Bordeaux, Piedmont & Rioja',
    description:
      'Curated across legendary European châteaux and rare vintage allocations. Aged in subterranean climate-controlled stone vaults.',
    image: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=1200&q=80',
    stat: '1,200+ Rare Vintages',
    sommelierNote: 'Includes rare vertical library vintages dating back to 1982.',
  },
  {
    title: 'Biodynamic & Regenerative Terroir Pairings',
    subtitle: 'Micro-Lot Sustainable Vintners',
    description:
      'Harmonizing with each course of our seasonal degustation menu. Hand-harvested grapes cultivated with zero chemical intervention.',
    image: 'https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?auto=format&fit=crop&w=1200&q=80',
    stat: '48 Family Estates',
    sommelierNote: 'Custom pairings poured exclusively by our Certified Master Sommelier.',
  },
  {
    title: 'Botanical Mixology & Rare Amari',
    subtitle: 'Cold-Smoked Infusions & Hand-Carved Ice',
    description:
      'Artisanal aperitifs infused with house-foraged pine needles, charred citrus, and centuries-old herbal liqueurs.',
    image: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=1200&q=80',
    stat: '36 House Botanical Elixirs',
    sommelierNote: 'Smoked table-side over Japanese binchotan cherrywood.',
  },
];

export function CellarExperienceSection() {
  const { openReservation } = useReservation();
  const [activeSlide, setActiveSlide] = useState(0);

  const next = () => setActiveSlide((prev) => (prev + 1) % CELLAR_HIGHLIGHTS.length);
  const prev = () => setActiveSlide((prev) => (prev - 1 + CELLAR_HIGHLIGHTS.length) % CELLAR_HIGHLIGHTS.length);

  const item = CELLAR_HIGHLIGHTS[activeSlide];

  return (
    <section className="py-24 sm:py-32 px-6 sm:px-8 bg-[#07080a] border-t border-white/[0.04] relative">
      <div className="max-w-6xl mx-auto space-y-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-white/[0.06]">
          <div className="space-y-2">
            <span className="text-[11px] uppercase tracking-[0.3em] text-[#c5a059] font-medium block">
              The Subterranean Vault
            </span>
            <h2 className="text-3xl sm:text-5xl font-serif font-light text-[#faf8f5] tracking-tight">
              Wine Cellar & Mixology Atelier
            </h2>
            <p className="text-zinc-400 text-xs sm:text-sm max-w-xl font-light">
              An international collection of rare terroirs, natural vintages, and table-side cocktail chemistry.
            </p>
          </div>

          {/* Slider buttons */}
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-zinc-500 mr-2">
              0{activeSlide + 1} / 0{CELLAR_HIGHLIGHTS.length}
            </span>
            <button
              onClick={prev}
              className="p-3 rounded-full border border-white/10 hover:border-[#c5a059] bg-[#0f1118] hover:bg-[#c5a059] text-zinc-300 hover:text-black transition-all cursor-pointer"
              aria-label="Previous Wine Highlight"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={next}
              className="p-3 rounded-full border border-white/10 hover:border-[#c5a059] bg-[#0f1118] hover:bg-[#c5a059] text-zinc-300 hover:text-black transition-all cursor-pointer"
              aria-label="Next Wine Highlight"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Feature Carousel Card */}
        <div className="relative min-h-[440px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSlide}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-[#0d0f15] border border-white/[0.06] rounded-2xl overflow-hidden shadow-2xl"
            >
              {/* Left Column: Image */}
              <div className="lg:col-span-7 h-[320px] sm:h-[420px] relative overflow-hidden bg-black">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover object-center filter brightness-[0.85] contrast-[1.1] transition-transform duration-700 hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0f15] via-transparent to-transparent lg:hidden" />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 rounded-full bg-black/80 backdrop-blur-md border border-[#c5a059]/40 text-[10px] uppercase tracking-widest font-semibold text-[#c5a059]">
                    {item.stat}
                  </span>
                </div>
              </div>

              {/* Right Column: Narrative */}
              <div className="lg:col-span-5 p-6 sm:p-10 space-y-5">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-[0.25em] text-[#c5a059] font-medium block">
                    {item.subtitle}
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-serif font-light text-[#faf8f5] tracking-tight">
                    {item.title}
                  </h3>
                </div>

                <p className="text-zinc-400 text-xs sm:text-sm font-light leading-relaxed">
                  {item.description}
                </p>

                <div className="p-3.5 rounded-lg bg-[#141722] border border-white/[0.05] text-xs text-zinc-300 font-light italic">
                  &ldquo;{item.sommelierNote}&rdquo;
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => openReservation({ occasion: 'Sommelier Wine Tasting' })}
                    className="px-6 py-2.5 rounded border border-[#c5a059] text-[#c5a059] hover:bg-[#c5a059] hover:text-black transition-all text-xs uppercase tracking-wider font-semibold cursor-pointer"
                  >
                    Inquire Private Cellar Experience
                  </button>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* 3 Pillar Summary Counters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6">
          <div className="p-6 rounded-xl bg-[#0b0c10] border border-white/[0.04] text-center space-y-1">
            <span className="text-2xl sm:text-3xl font-serif text-[#faf8f5] font-light">1,200+</span>
            <p className="text-[11px] uppercase tracking-widest text-[#c5a059] font-medium">Cellar Vintages</p>
            <p className="text-[11px] text-zinc-500 font-light">Direct allocations from historic European châteaux</p>
          </div>
          <div className="p-6 rounded-xl bg-[#0b0c10] border border-white/[0.04] text-center space-y-1">
            <span className="text-2xl sm:text-3xl font-serif text-[#faf8f5] font-light">100%</span>
            <p className="text-[11px] uppercase tracking-widest text-[#c5a059] font-medium">Biodynamic Focus</p>
            <p className="text-[11px] text-zinc-500 font-light">Honoring sustainable soil stewardship</p>
          </div>
          <div className="p-6 rounded-xl bg-[#0b0c10] border border-white/[0.04] text-center space-y-1">
            <span className="text-2xl sm:text-3xl font-serif text-[#faf8f5] font-light">Table-Side</span>
            <p className="text-[11px] uppercase tracking-widest text-[#c5a059] font-medium">Tasting Decanting</p>
            <p className="text-[11px] text-zinc-500 font-light">Austrian Zalto crystal glassware for each varietal</p>
          </div>
        </div>
      </div>
    </section>
  );
}

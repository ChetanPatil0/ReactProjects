const { PrismaClient } = require('@prisma/client');
const argon2 = require('argon2');

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding PostgreSQL database for Zaffran Haveli (Royal Indian Fine Dining)...');

  // 1. Seed Users (Super Admin, Manager, Cashier)
  const defaultPassword = await argon2.hash('Demo@12345');

  const admin = await prisma.user.upsert({
    where: { email: 'admin@restaurant.com' },
    update: { password: defaultPassword },
    create: {
      email: 'admin@restaurant.com',
      password: defaultPassword,
      firstName: 'Vikramaditya',
      lastName: 'Singhania',
      role: 'SUPER_ADMIN',
      isActive: true,
    },
  });

  const manager = await prisma.user.upsert({
    where: { email: 'manager@restaurant.com' },
    update: { password: defaultPassword },
    create: {
      email: 'manager@restaurant.com',
      password: defaultPassword,
      firstName: 'Ananya',
      lastName: 'Deshmukh',
      role: 'MANAGER',
      isActive: true,
    },
  });

  const cashier = await prisma.user.upsert({
    where: { email: 'cashier@restaurant.com' },
    update: { password: defaultPassword },
    create: {
      email: 'cashier@restaurant.com',
      password: defaultPassword,
      firstName: 'Rohan',
      lastName: 'Verma',
      role: 'CASHIER',
      isActive: true,
    },
  });

  console.log('✓ Staff users seeded with password Demo@12345:', {
    admin: admin.email,
    manager: manager.email,
    cashier: cashier.email,
  });

  // 2. Seed Restaurant Settings (Royal Indian Atelier)
  const defaultLogo = 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=400&q=80';
  const setting = await prisma.restaurantSetting.upsert({
    where: { id: 'default-setting' },
    update: {
      name: 'Zaffran Haveli',
      tagline: 'Royal Awadhi & Mughlai Culinary Atelier',
      description: 'An authentic culinary sanctuary honoring slow-cooked Awadhi Dum Pukht heritage, royal clay tandoors, and handpicked spice terroir.',
      phone: '+91 98201 23456',
      email: 'concierge@zaffranhaveli.com',
      address: 'Heritage Grand Haveli, Colaba Causeway, Mumbai, Maharashtra 400001',
      currency: '₹',
      taxRate: 5.0,
      serviceChargeRate: 0.0,
      receiptHeader: 'Zaffran Haveli — Royal Indian Atelier',
      receiptFooter: 'Dhanyavaad. All prices inclusive of applicable GST (2.5% CGST + 2.5% SGST).',
      openingHours: 'Tue – Sun: 12:30 PM – 3:30 PM, 7:00 PM – 11:45 PM | Mon: Closed',
      logoUrl: defaultLogo,
    },
    create: {
      id: 'default-setting',
      name: 'Zaffran Haveli',
      tagline: 'Royal Awadhi & Mughlai Culinary Atelier',
      description: 'An authentic culinary sanctuary honoring slow-cooked Awadhi Dum Pukht heritage, royal clay tandoors, and handpicked spice terroir.',
      phone: '+91 98201 23456',
      email: 'concierge@zaffranhaveli.com',
      address: 'Heritage Grand Haveli, Colaba Causeway, Mumbai, Maharashtra 400001',
      currency: '₹',
      taxRate: 5.0,
      serviceChargeRate: 0.0,
      receiptHeader: 'Zaffran Haveli — Royal Indian Atelier',
      receiptFooter: 'Dhanyavaad. All prices inclusive of applicable GST (2.5% CGST + 2.5% SGST).',
      openingHours: 'Tue – Sun: 12:30 PM – 3:30 PM, 7:00 PM – 11:45 PM | Mon: Closed',
      logoUrl: defaultLogo,
    },
  });
  console.log('✓ Restaurant settings seeded (Currency: ₹, GST: 5%)');

  // 3. Seed Homepage Content
  await prisma.homepageContent.upsert({
    where: { id: 'default-homepage' },
    update: {
      announcement: 'Royal Awadhi Dastarkhwan Feast — Reserve Your Dining Salon for This Weekend',
      heroTitle: 'Imperial Awadhi Dum Pukht & Royal Indian Gastronomy.',
      heroSubtitle: 'Step into a heritage haven where 200-year-old royal khansama recipes, hand-pounded spices, and pure Kashmiri saffron converge.',
      introTitle: 'The Living Legacy of Royal Dastarkhwans',
      introDescription: 'Every handi at Zaffran Haveli is sealed with wholewheat dough purdah and slow-simmered over fragrant wood embers, preserving delicate aromas and royal court traditions.',
    },
    create: {
      id: 'default-homepage',
      announcement: 'Royal Awadhi Dastarkhwan Feast — Reserve Your Dining Salon for This Weekend',
      heroTitle: 'Imperial Awadhi Dum Pukht & Royal Indian Gastronomy.',
      heroSubtitle: 'Step into a heritage haven where 200-year-old royal khansama recipes, hand-pounded spices, and pure Kashmiri saffron converge.',
      heroImageUrl: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=1600&q=80',
      introTitle: 'The Living Legacy of Royal Dastarkhwans',
      introDescription: 'Every handi at Zaffran Haveli is sealed with wholewheat dough purdah and slow-simmered over fragrant wood embers, preserving delicate aromas and royal court traditions.',
      introImageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80',
    },
  });
  console.log('✓ Homepage content seeded');

  // 4. Seed About Content
  await prisma.aboutContent.upsert({
    where: { id: 'default-about' },
    update: {
      storyTitle: 'Preserving Two Centuries of Royal Awadhi Culinary Heritage',
      storyContent: 'Founded to revive the lost recipes of the Nawabs of Awadh, Zaffran Haveli brings together heirloom copper degs, slow-burning charcoal sigris, and the finest organic produce from across the Indian subcontinent.',
      chefName: 'Ustad Rahimuddin Qureshi',
      chefBio: 'Seventh-generation master Khansama from the historic royal kitchens of Lucknow, Ustad Rahimuddin breathes life into time-honored slow-cooked Dum Pukht gastronomy.',
      missionTitle: 'Reverence for Slow Cooking & Sacred Hospitality',
      missionContent: 'In our tradition, Atithi Devo Bhava is not merely a saying — it is the sacred covenant of welcoming every guest to an unforgettable royal feast.',
    },
    create: {
      id: 'default-about',
      storyTitle: 'Preserving Two Centuries of Royal Awadhi Culinary Heritage',
      storyContent: 'Founded to revive the lost recipes of the Nawabs of Awadh, Zaffran Haveli brings together heirloom copper degs, slow-burning charcoal sigris, and the finest organic produce from across the Indian subcontinent.',
      storyImageUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80',
      chefName: 'Ustad Rahimuddin Qureshi',
      chefBio: 'Seventh-generation master Khansama from the historic royal kitchens of Lucknow, Ustad Rahimuddin breathes life into time-honored slow-cooked Dum Pukht gastronomy.',
      chefImageUrl: 'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=800&q=80',
      missionTitle: 'Reverence for Slow Cooking & Sacred Hospitality',
      missionContent: 'In our tradition, Atithi Devo Bhava is not merely a saying — it is the sacred covenant of welcoming every guest to an unforgettable royal feast.',
    },
  });
  console.log('✓ About content seeded');

  // 5. Seed Contact Content
  await prisma.contactContent.upsert({
    where: { id: 'default-contact' },
    update: {
      address: 'Heritage Grand Haveli, Colaba Causeway, Mumbai, Maharashtra 400001',
      phone: '+91 98201 23456',
      email: 'concierge@zaffranhaveli.com',
      openingHours: 'Tuesday to Sunday: Lunch 12:30 PM – 3:30 PM | Dinner 7:00 PM – 11:45 PM (Mondays Closed)',
    },
    create: {
      id: 'default-contact',
      address: 'Heritage Grand Haveli, Colaba Causeway, Mumbai, Maharashtra 400001',
      phone: '+91 98201 23456',
      email: 'concierge@zaffranhaveli.com',
      openingHours: 'Tuesday to Sunday: Lunch 12:30 PM – 3:30 PM | Dinner 7:00 PM – 11:45 PM (Mondays Closed)',
      googleMapsUrl: 'https://maps.google.com',
    },
  });
  console.log('✓ Contact content seeded');

  // 6. Seed Categories & Menu Items (Authentic Indian Delicacies in ₹ INR)
  const categoriesData = [
    {
      name: 'Dawat-e-Khaas (Royal Tandoor & Starters)',
      slug: 'starters',
      description: 'Fragrant kebabs and charred clay-oven appetisers slow-cooked with heirloom spices.',
      displayOrder: 1,
      items: [
        {
          name: 'Shahi Galouti Kebab',
          slug: 'shahi-galouti-kebab',
          description: 'Melt-in-mouth smoked lamb patties infused with 160 secret herbs and spices, served on crisp saffron ulte tawe ka paratha.',
          price: 795,
          isVeg: false,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 1,
        },
        {
          name: 'Angara Paneer Tikka',
          slug: 'angara-paneer-tikka',
          description: 'Malai cottage cheese steeped in Kashmiri deghi mirch, mustard oil, and carom seeds, chargrilled in a traditional clay tandoor.',
          price: 595,
          isVeg: true,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 2,
        },
        {
          name: 'Bhatti Murgh Malai Tikka',
          slug: 'bhatti-murgh-malai-tikka',
          description: 'Boneless tender chicken supreme marinated in clotted dairy cream, green cardamom, roasted cashews, and Kashmiri saffron.',
          price: 695,
          isVeg: false,
          isAvailable: true,
          isSignature: false,
          imageUrl: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 0,
        },
        {
          name: 'Shahi Dahi Ke Kebab',
          slug: 'shahi-dahi-ke-kebab',
          description: 'Golden-crisp hung-curd medallions scented with green cardamoms, roasted cumin, and fresh river mint, served with sonth chutney.',
          price: 525,
          isVeg: true,
          isAvailable: true,
          isSignature: false,
          imageUrl: 'https://images.unsplash.com/photo-1541518763669-27fef04b14ea?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 0,
        },
        {
          name: 'Tandoori Jheenga Kalimirch',
          slug: 'tandoori-jheenga-kalimirch',
          description: 'Jumbo Arabian Sea tiger prawns marinated in Tellicherry black pepper, royal cumin, yellow chili, and roasted Bengal gram flour.',
          price: 1195,
          isVeg: false,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 2,
        },
      ],
    },
    {
      name: 'Shahi Handi & Awadhi Curries',
      slug: 'curries',
      description: 'Slow-simmered rich curries prepared in sealed heavy-bottom copper degs.',
      displayOrder: 2,
      items: [
        {
          name: 'Dal Dum Pukht (Makhani)',
          slug: 'dal-dum-pukht',
          description: 'Whole black urad lentils slow-simmered for 24 hours over slow charcoal embers with churned white makhan and vine-ripened tomatoes.',
          price: 545,
          isVeg: true,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 1,
        },
        {
          name: 'Purani Dilli Murgh Makhani',
          slug: 'purani-dilli-murgh-makhani',
          description: 'Clay-tandoor smoked chicken morsels simmered in a satin-smooth reduction of tomatoes, cashew butter, honey, and sun-dried kasoori methi.',
          price: 745,
          isVeg: false,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 1,
        },
        {
          name: 'Awadhi Nalli Nihari',
          slug: 'awadhi-nalli-nihari',
          description: 'Prime baby lamb shanks slow-stewed overnight in a velvety gravy infused with potli masala, rose petals, and vetiver roots.',
          price: 895,
          isVeg: false,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 2,
        },
        {
          name: 'Paneer Zaffrani Lababdar',
          slug: 'paneer-zaffrani-lababdar',
          description: 'Artisanal cottage cheese cubes simmered in an onion-tomato relish enriched with melon seeds, saffron cream, and fresh ginger juliennes.',
          price: 625,
          isVeg: true,
          isAvailable: true,
          isSignature: false,
          imageUrl: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 1,
        },
        {
          name: 'Kashmiri Gosht Rogan Josh',
          slug: 'kashmiri-gosht-rogan-josh',
          description: 'Tender baby goat cuts slow-cooked with aromatic Kashmiri mirch, ratan jot, asafoetida, and sun-dried ginger.',
          price: 845,
          isVeg: false,
          isAvailable: true,
          isSignature: false,
          imageUrl: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 2,
        },
      ],
    },
    {
      name: 'Zaffrani Dum Biryani & Pulao',
      slug: 'biryani',
      description: 'Aged Himalayan basmati rice layered with marinated cuts and sealed on purdah dum.',
      displayOrder: 3,
      items: [
        {
          name: 'Awadhi Dum Gosht Biryani',
          slug: 'awadhi-dum-gosht-biryani',
          description: 'Long-grain aged basmati layered with tender baby lamb, saffron milk, browned onions, and mint, sealed with wholewheat purdah.',
          price: 825,
          isVeg: false,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 1,
        },
        {
          name: 'Lucknowi Murgh Dum Biryani',
          slug: 'lucknowi-murgh-dum-biryani',
          description: 'Succulent chicken pieces cooked in yakhni stock, layered with fragrant basmati, Damascus kewra water, and pure desi ghee.',
          price: 695,
          isVeg: false,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 1,
        },
        {
          name: 'Subz-e-Khwan Dum Biryani',
          slug: 'subz-e-khwan-dum-biryani',
          description: 'Heirloom farm vegetables, baby potatoes, lotus root, and paneer cubes slow-steamed with saffron and toasted nuts.',
          price: 575,
          isVeg: true,
          isAvailable: true,
          isSignature: false,
          imageUrl: 'https://images.unsplash.com/photo-1642821373181-696a54913e93?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 1,
        },
        {
          name: 'Kesari Moti Pulao',
          slug: 'kesari-moti-pulao',
          description: 'Aged basmati rice gently tossed in pure saffron, golden raisins, roasted cashews, and sweet green garden peas.',
          price: 445,
          isVeg: true,
          isAvailable: true,
          isSignature: false,
          imageUrl: 'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 0,
        },
      ],
    },
    {
      name: 'Artisanal Tandoori Roti & Naan',
      slug: 'breads',
      description: 'Hand-stretched breads baked fresh to order in red clay tandoors.',
      displayOrder: 4,
      items: [
        {
          name: 'Zaffrani Sheermal',
          slug: 'zaffrani-sheermal',
          description: 'Traditional Awadhi warm milk-leavened flatbread brushed with pure Kashmiri saffron extract and cardamom butter.',
          price: 195,
          isVeg: true,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 0,
        },
        {
          name: 'Garlic & Chive Chur-Chur Naan',
          slug: 'garlic-chur-chur-naan',
          description: 'Flaky layered leavened bread crushed with organic white butter, roasted garlic flakes, and Himalayan pink salt.',
          price: 165,
          isVeg: true,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 0,
        },
        {
          name: 'Rumali Roti',
          slug: 'rumali-roti',
          description: 'Ultra-thin handkerchief flatbread hand-tossed and baked on an inverted heated copper dome.',
          price: 95,
          isVeg: true,
          isAvailable: true,
          isSignature: false,
          imageUrl: 'https://images.unsplash.com/photo-1509722747041-616f39b57569?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 0,
        },
      ],
    },
    {
      name: 'Shahi Dastarkhwan Desserts',
      slug: 'desserts',
      description: 'Royal confections perfumed with cardamom, rose water, and pure silver vark.',
      displayOrder: 5,
      items: [
        {
          name: 'Shahi Tukda with Gold Leaf',
          slug: 'shahi-tukda-gold-leaf',
          description: 'Ghee-crisped brioche bread soaked in cardamom sugar syrup, crowned with dense saffron rabri, roasted pistachios, and 24k silver leaf.',
          price: 395,
          isVeg: true,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 0,
        },
        {
          name: 'Kesari Phirni in Clay Kasora',
          slug: 'kesari-phirni',
          description: 'Stone-ground basmati rice pudding slow-reduced with condensed whole milk, Kashmiri saffron, crushed green cardamoms, and slivered almonds.',
          price: 325,
          isVeg: true,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1541832676-9b763b0239ab?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 0,
        },
        {
          name: 'Royal Gulkand Gulab Jamun',
          slug: 'royal-gulkand-gulab-jamun',
          description: 'Soft khoya dumplings stuffed with Damask rose petal preserve, soaked in warm green cardamom syrup.',
          price: 295,
          isVeg: true,
          isAvailable: true,
          isSignature: false,
          imageUrl: 'https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 0,
        },
      ],
    },
    {
      name: 'Royal Ayurvedic & Botanical Beverages',
      slug: 'beverages',
      description: 'Artisanal elixirs, chilled thandais, and saffron kahwas.',
      displayOrder: 6,
      items: [
        {
          name: 'Kashmiri Saffron Kahwa',
          slug: 'kashmiri-saffron-kahwa',
          description: 'Green tea brewed with saffron strands, crushed green cardamoms, cinnamon bark, and blanched Kashmiri almonds.',
          price: 245,
          isVeg: true,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 0,
        },
        {
          name: 'Thandai Royale',
          slug: 'thandai-royale',
          description: 'Chilled cream milk elixir stone-ground with poppy seeds, roasted fennel, Tellicherry pepper, and Damascus rose water.',
          price: 285,
          isVeg: true,
          isAvailable: true,
          isSignature: true,
          imageUrl: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 0,
        },
        {
          name: 'Wild Jamun Kala Khatta Fizz',
          slug: 'jamun-kala-khatta-fizz',
          description: 'Wild black plum reduction with black rock salt, crushed mint leaves, and sparkling mineral water.',
          price: 265,
          isVeg: true,
          isAvailable: true,
          isSignature: false,
          imageUrl: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80',
          spicyLevel: 1,
        },
      ],
    },
  ];

  for (const cat of categoriesData) {
    const category = await prisma.menuCategory.upsert({
      where: { slug: cat.slug },
      update: { name: cat.name, description: cat.description, displayOrder: cat.displayOrder },
      create: {
        name: cat.name,
        slug: cat.slug,
        description: cat.description,
        displayOrder: cat.displayOrder,
      },
    });

    for (const item of cat.items) {
      await prisma.menuItem.upsert({
        where: { slug: item.slug },
        update: {
          name: item.name,
          description: item.description,
          price: item.price,
          isVeg: item.isVeg,
          isAvailable: item.isAvailable,
          isSignature: item.isSignature,
          imageUrl: item.imageUrl,
          spicyLevel: item.spicyLevel,
          categoryId: category.id,
        },
        create: {
          name: item.name,
          slug: item.slug,
          description: item.description,
          price: item.price,
          isVeg: item.isVeg,
          isAvailable: item.isAvailable,
          isSignature: item.isSignature,
          imageUrl: item.imageUrl,
          spicyLevel: item.spicyLevel,
          categoryId: category.id,
        },
      });
    }
  }
  console.log('✓ Categories and Indian menu items seeded');

  // 7. Seed Offers
  const offersData = [
    {
      title: 'Royal Awadhi Dastarkhwan Experience',
      code: 'SHAHI20',
      discount: '20% OFF',
      description: 'Experience our 7-course Nawabi chef tasting journey with complimentary royal saffron kahwa for dining salons on Friday & Saturday.',
      badgeText: 'ROYAL FEAST',
      imageUrl: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=800&q=80',
      isActive: true,
    },
    {
      title: 'Shahi Dawat Special',
      code: 'DAWAT15',
      discount: '15% OFF',
      description: 'Complimentary Thandai Royale and Sheermal tasting with any Imperial Biryani selection ordered between 12:30 PM and 3:30 PM.',
      badgeText: 'LUNCH SPECIAL',
      imageUrl: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80',
      isActive: true,
    },
  ];

  for (const off of offersData) {
    const existing = await prisma.offer.findFirst({ where: { title: off.title } });
    if (existing) {
      await prisma.offer.update({
        where: { id: existing.id },
        data: off,
      });
    } else {
      await prisma.offer.create({ data: off });
    }
  }
  console.log('✓ Royal Offers seeded');

  // 8. Seed Gallery Items
  const galleryData = [
    {
      title: 'The Royal Courtyard Salon',
      caption: 'Heritage stone arches, hand-carved jharokhas, and soft brass lantern lighting.',
      category: 'ambience',
      imageUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80',
      displayOrder: 1,
    },
    {
      title: 'Slow Charcoal Sigri Dum',
      caption: 'Copper handis sealed with dough purdah cooking over fragrant wood charcoal embers.',
      category: 'culinary',
      imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80',
      displayOrder: 2,
    },
    {
      title: 'Shahi Galouti Plating',
      caption: 'Melt-in-mouth smoked lamb patties served with ulte tawe ka paratha and mint emulsion.',
      category: 'culinary',
      imageUrl: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=1200&q=80',
      displayOrder: 3,
    },
    {
      title: 'Botanical Elixirs & Kahwa Bar',
      caption: 'Infusions with pure saffron, dried rose petals, and whole green cardamom.',
      category: 'bar',
      imageUrl: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=1200&q=80',
      displayOrder: 4,
    },
  ];

  for (const item of galleryData) {
    const existing = await prisma.galleryItem.findFirst({ where: { title: item.title } });
    if (!existing) {
      await prisma.galleryItem.create({ data: item });
    }
  }
  console.log('✓ Gallery items seeded');

  // 9. Seed Sample POS Bill & Customer in ₹ INR
  const customer = await prisma.customer.upsert({
    where: { phone: '+919820199882' },
    update: {},
    create: {
      phone: '+919820199882',
      name: 'Aarav Malhotra',
      email: 'aarav.malhotra@example.com',
      totalVisits: 1,
      totalSpent: 1701.0,
      lastVisit: new Date(),
    },
  });

  const sampleBill = await prisma.bill.upsert({
    where: { billNumber: 'BILL-202611-0001' },
    update: {
      subtotal: 1620.0,
      discountAmount: 0.0,
      taxRate: 5.0,
      taxAmount: 81.0,
      totalAmount: 1701.0,
      paidAmount: 1701.0,
      balanceAmount: 0.0,
      paymentMethod: 'UPI',
    },
    create: {
      billNumber: 'BILL-202611-0001',
      orderType: 'DINE_IN',
      tableNumber: 'Table 4',
      customerId: customer.id,
      subtotal: 1620.0,
      discountAmount: 0.0,
      taxRate: 5.0,
      taxAmount: 81.0,
      totalAmount: 1701.0,
      paidAmount: 1701.0,
      balanceAmount: 0.0,
      paymentMethod: 'UPI',
      status: 'PAID',
      createdById: cashier.id,
      items: {
        create: [
          { itemName: 'Awadhi Dum Gosht Biryani', unitPrice: 825.0, quantity: 1, totalPrice: 825.0 },
          { itemName: 'Shahi Galouti Kebab', unitPrice: 795.0, quantity: 1, totalPrice: 795.0 },
        ],
      },
      payments: {
        create: {
          amount: 1701.0,
          paymentMethod: 'UPI',
          recordedById: cashier.id,
          note: 'Manual UPI UTR #9021884129',
        },
      },
    },
  });
  console.log('✓ Sample POS bill seeded in ₹ INR:', sampleBill.billNumber);

  console.log('🎉 Indian Fine Dining database seeding completed successfully!');
}

main()
  .catch((e) => {
    console.error('Seeding error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

# Architecture & System Design

## 1. System Overview

The system is a high-performance, single-tenant restaurant management platform designed with two decoupled core applications in a monorepo powered by **npm workspaces**:

1. **`apps/website`**: Next.js App Router public-facing web application with Tailwind CSS v4, Motion, and Lucide React.
2. **`apps/cms`**: Strapi 5 headless CMS and admin panel on Node.js / TypeScript, backed by PostgreSQL via `DATABASE_URL`, hosting the custom `restaurant-pos` administration plugin.

```mermaid
graph TD
    Client["Public Visitors (Desktop / Mobile)"] -->|HTTPS / Next.js SSR & ISR| WebApp["Next.js App Router (apps/website)"]
    AdminStaff["Restaurant Staff & Admins"] -->|Admin UI / POS Plugin| Strapi["Strapi 5 Headless CMS (apps/cms)"]
    WebApp -->|REST API (Read-only Website Content)| Strapi
    Strapi -->|SQL Queries & Transactions| Postgres[("PostgreSQL Database")]
    Strapi -->|Media Storage| MediaStore["Local Uploads / Cloudinary / R2"]
```

---

## 2. Monorepo Organization

```text
restaurant/
├── apps/
│   ├── website/                    # Next.js App Router frontend
│   └── cms/                        # Strapi 5 backend & admin panel
├── infrastructure/
│   ├── docker/                     # PostgreSQL & local development containers
│   │   └── docker-compose.yml
│   ├── database/                   # Backup directories & seed scripts
│   └── scripts/                    # Backup & restore automation scripts
├── docs/                           # System architecture & API specs
├── pnpm-workspace.yaml
├── package.json
└── README.md
```

---

## 3. Technology Stack Rationale

- **Next.js (App Router) + TypeScript**: Provides Server Components by default to achieve optimal Lighthouse performance, built-in SEO capabilities, dynamic metadata, and image optimization.
- **Tailwind CSS v4 & Lucide Icons**: Modern styling engine with lightning-fast compilation and clean, semantic design tokens.
- **Strapi 5 + PostgreSQL**: Provides an extensible headless CMS with built-in Media Library, Draft & Publish system, enterprise-grade Administrator RBAC, and clean plugin architecture.
- **ACID Transactions**: Required for bill generation, invoice numbering, and refund processing to avoid race conditions and financial discrepancy.

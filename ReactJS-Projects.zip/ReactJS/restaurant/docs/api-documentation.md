# API Documentation & Contracts

## 1. Public Content APIs (Strapi REST API)

Website routes query Strapi REST endpoints with read-only permissions:

- `GET /api/restaurant-setting?populate=*`
- `GET /api/homepages?populate=*`
- `GET /api/abouts?populate=*`
- `GET /api/menu-categories?populate=image&filters[isActive][$eq]=true&sort=displayOrder:asc`
- `GET /api/menu-items?populate=*&filters[isAvailable][$eq]=true&sort=displayOrder:asc`
- `GET /api/galleries?populate=*&sort=displayOrder:asc`
- `GET /api/offers?populate=*&filters[isActive][$eq]=true`
- `GET /api/contact?populate=*`

---

## 2. Protected Billing & POS Plugin APIs (`/api/restaurant-pos`)

Staff actions are routed through the custom plugin endpoints requiring authenticated Strapi Administrator tokens:

### Billing Operations
- `GET /api/restaurant-pos/pos/menu` — Optimized menu payload for fast POS caching.
- `POST /api/restaurant-pos/bills` — Create a new bill with transaction-locked invoice generation.
- `GET /api/restaurant-pos/bills` — Filterable historical bills (date, status, customer).
- `GET /api/restaurant-pos/bills/:id` — Detailed bill with item snapshots and payments.
- `POST /api/restaurant-pos/bills/:id/payments` — Record partial or full payment.
- `POST /api/restaurant-pos/bills/:id/cancel` — Cancel bill with audit reason.
- `POST /api/restaurant-pos/bills/:id/refund` — Issue partial/full refund.

### Analytics & Reports
- `GET /api/restaurant-pos/reports/daily-summary?date=YYYY-MM-DD`
- `GET /api/restaurant-pos/reports/range?from=YYYY-MM-DD&to=YYYY-MM-DD`
- `GET /api/restaurant-pos/reports/export-csv`

### Customer Management
- `GET /api/restaurant-pos/customers?search=9876543210`
- `POST /api/restaurant-pos/customers`
- `GET /api/restaurant-pos/customers/:id/history`

### Activity Logs & System
- `GET /api/restaurant-pos/activity-logs`
- `GET /api/restaurant-pos/backup/status`
- `POST /api/restaurant-pos/backup/trigger`

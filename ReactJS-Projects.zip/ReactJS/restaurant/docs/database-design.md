# Database Design & Entity Relationship

## 1. Relational Entity Overview

The system runs on **PostgreSQL**. All financial models are snapshot-based: historical bills preserve frozen prices, tax rates, discount amounts, and customer snapshots regardless of future menu or pricing updates.

```mermaid
erDiagram
    RESTAURANT_SETTINGS ||--o{ MENU_CATEGORY : configures
    MENU_CATEGORY ||--o{ MENU_ITEM : contains
    CUSTOMER ||--o{ BILL : places
    BILL ||--|{ BILL_ITEM : contains
    BILL ||--o{ PAYMENT : receives
    BILL ||--o{ REFUND_RECORD : issues
    BILL ||--o| CANCELLATION_RECORD : has
    ADMIN_USER ||--o{ BILL : creates
    ADMIN_USER ||--o{ ACTIVITY_LOG : triggers
```

---

## 2. Core Schemas

### 2.1 Public Website Content Entities
- **RestaurantSettings**: Single type (Name, Logo, Address, Contact, Currency, Tax, Invoice Prefix, Timezone, Opening Hours, Socials).
- **Homepage**: Hero slider/banners, intro, featured categories, announcements.
- **About**: Story, mission, leadership, ambiance imagery.
- **MenuCategory**: Name, slug, description, image, displayOrder, isActive.
- **MenuItem**: Name, slug, description, image, price, foodType (`veg` | `non-veg`), isAvailable, displayOrder, categoryId.
- **Gallery**: Title, category/tag, image, displayOrder.
- **Offer**: Title, description, bannerImage, discountValue, validFrom, validTo, isActive.
- **Contact**: Address, phone, email, googleMapsUrl, socialLinks.

### 2.2 Financial & POS Entities (Historical Snapshots)
- **Bill**:
  - `invoiceNumber` (Unique, sequential: e.g. `INV-2026-0001`)
  - `orderType` (`dine_in` | `takeaway`)
  - `tableNumber` (Nullable string)
  - `customerName`, `customerPhone` (Snapshotted)
  - `subtotal`, `discountAmount`, `taxAmount`, `grandTotal`
  - `paidAmount`, `balanceAmount`
  - `status` (`paid` | `unpaid` | `partially_paid` | `cancelled`)
  - `createdById` (Admin ID reference)
  - `businessDate` (Date anchored to restaurant timezone)
- **BillItem**:
  - `billId`
  - `menuItemId` (Optional historical reference)
  - `name` (Frozen item name)
  - `unitPrice` (Frozen price at sale time)
  - `quantity`
  - `taxRate`, `taxAmount`, `subtotal`
- **Payment**:
  - `billId`
  - `method` (`cash` | `upi` | `card`)
  - `amount`
  - `recordedById`
  - `notes`
- **CancellationRecord**:
  - `billId`
  - `reason`
  - `cancelledById`
  - `cancelledAt`
- **RefundRecord**:
  - `billId`
  - `amount`
  - `reason`
  - `method` (`cash` | `upi` | `card`)
  - `processedById`
- **Customer**:
  - `name`, `phone`, `email`, `address`, `notes`
  - Aggregated metrics: `totalSpent`, `totalBillsCount`
- **ActivityLog**:
  - `adminUserId`, `adminEmail`, `action`, `module`, `recordRef`, `metadataJson`

# Permissions & Role-Based Access Control (RBAC)

## 1. Strapi Admin Role Templates

Access control is strictly enforced on the server-side via Strapi 5 Administrator RBAC.

| Role | Core Purpose | Menu & Website | Billing / POS | Reports | User Mgmt | Backup |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| **Super Admin** | System owner & DevOps | Full | Full | Full | Full (All Roles) | Full |
| **Owner** | Restaurant proprietor | Full | Full | Full | Staff only (No role creation) | Read-only |
| **Manager** | Day-to-day supervisor | Full | Full | Read | Read-only staff | None |
| **Content Editor**| Marketing & digital presence | Full | None | None | None | None |
| **Cashier** | Counter operator / billing | Read Menu | Create/Pay/Print Bills | None | None | None |
| **Reports Viewer**| Accountant / Auditor | None | Read-only Bills | Full | None | None |

---

## 2. Granular Permissions Architecture

Custom permission actions registered in the `restaurant-pos` plugin:

- `plugin::restaurant-pos.billing.read`
- `plugin::restaurant-pos.billing.create`
- `plugin::restaurant-pos.billing.payment`
- `plugin::restaurant-pos.billing.cancel`
- `plugin::restaurant-pos.billing.refund`
- `plugin::restaurant-pos.reports.read`
- `plugin::restaurant-pos.reports.export`
- `plugin::restaurant-pos.customers.manage`
- `plugin::restaurant-pos.activity-log.read`
- `plugin::restaurant-pos.settings.manage`
- `plugin::restaurant-pos.backup.manage`

Every endpoint in `apps/cms` validates against these permissions before touching the database or initiating transactions.

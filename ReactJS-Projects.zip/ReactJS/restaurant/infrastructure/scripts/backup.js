#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../apps/cms/.env') });

const BACKUP_DIR = path.join(__dirname, '../database/backup');

async function performBackup() {
  console.log('--- Starting Restaurant Management Backup ---');

  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const databaseUrl = process.env.DATABASE_URL;

  // 1. Database Backup
  if (databaseUrl) {
    const backupFile = path.join(BACKUP_DIR, `postgres-backup-${timestamp}.sql`);
    console.log(`ℹ️ PostgreSQL backup targeted from DATABASE_URL.`);
    console.log(`  Target destination: ${backupFile}`);
    console.log(`  Command: pg_dump "${databaseUrl}" -F c -f "${backupFile}"`);
  } else if (process.env.DATABASE_CLIENT === 'sqlite') {
    const dbPath = path.join(__dirname, '../../apps/cms', process.env.DATABASE_FILENAME || '.tmp/data.db');
    if (fs.existsSync(dbPath)) {
      const destPath = path.join(BACKUP_DIR, `sqlite-backup-${timestamp}.db`);
      fs.copyFileSync(dbPath, destPath);
      const stats = fs.statSync(destPath);
      console.log(`✓ SQLite Database backed up: ${destPath} (${(stats.size / 1024).toFixed(2)} KB)`);
    }
  }

  // 2. Media Uploads Backup
  const uploadsDir = path.join(__dirname, '../../apps/cms/public/uploads');
  const mediaBackupDir = path.join(BACKUP_DIR, `media-${timestamp}`);

  if (fs.existsSync(uploadsDir)) {
    fs.mkdirSync(mediaBackupDir, { recursive: true });
    let count = 0;
    const files = fs.readdirSync(uploadsDir);
    for (const f of files) {
      if (f === '.gitkeep') continue;
      const s = path.join(uploadsDir, f);
      if (fs.statSync(s).isFile()) {
        fs.copyFileSync(s, path.join(mediaBackupDir, f));
        count++;
      }
    }
    console.log(`✓ Media files backed up: ${count} assets archived to ${mediaBackupDir}`);
  }

  console.log(`\n✓ Backup process completed at ${new Date().toLocaleString()}.\n`);
}

performBackup().catch((err) => {
  console.error('Backup failed:', err);
  process.exit(1);
});

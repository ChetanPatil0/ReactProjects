#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../apps/cms/.env') });

const BACKUP_DIR = path.join(__dirname, '../database/backup');

async function performRestore() {
  const backupFileName = process.argv[2];
  if (!backupFileName) {
    console.error('Usage: node infrastructure/scripts/restore.js <backup-file-name>');
    console.log('Available backups in', BACKUP_DIR + ':');
    if (fs.existsSync(BACKUP_DIR)) {
      fs.readdirSync(BACKUP_DIR).forEach((f) => console.log('  -', f));
    }
    process.exit(1);
  }

  const backupFilePath = path.join(BACKUP_DIR, backupFileName);
  if (!fs.existsSync(backupFilePath)) {
    console.error(`Error: Backup file not found: ${backupFilePath}`);
    process.exit(1);
  }

  const stats = fs.statSync(backupFilePath);
  if (stats.size === 0) {
    console.error('Error: Backup file is empty and invalid. Restoration aborted.');
    process.exit(1);
  }

  console.log(`⚠️ Warning: Restoring from ${backupFileName} will replace current database state.`);

  const databaseUrl = process.env.DATABASE_URL;
  if (databaseUrl) {
    console.log(`ℹ️ PostgreSQL restore command: pg_restore -d "${databaseUrl}" -v "${backupFilePath}"`);
  } else {
    const targetDb = path.join(__dirname, '../../apps/cms', process.env.DATABASE_FILENAME || '.tmp/data.db');
    fs.copyFileSync(backupFilePath, targetDb);
    console.log(`✓ Database restored successfully to: ${targetDb}`);
  }
}

performRestore().catch((err) => {
  console.error('Restore failed:', err);
  process.exit(1);
});

require('dotenv').config({ path: './apps/cms/.env' });
const strapi = require('@strapi/strapi');

async function testBilling() {
  const app = await strapi.createStrapi({ appDir: './apps/cms', distDir: './apps/cms/dist' }).load();
  await app.start();

  console.log('\n--- Testing Billing Services ---');

  const billingService = app.plugin('restaurant-pos').service('billing');
  const reportsService = app.plugin('restaurant-pos').service('reports');
  const customersService = app.plugin('restaurant-pos').service('customers');

  const dummyAdmin = { id: 1, email: 'owner@aurabistro.com' };

  // 1. Create a Dine-In Bill with 2 items and partial discount
  const bill1 = await billingService.createBill(
    {
      orderType: 'dine_in',
      tableNumber: 'Table 4',
      customerName: 'Aarav Sharma',
      customerPhone: '9876543210',
      items: [
        { name: 'Truffle Mushroom Bruschetta', unitPrice: 450, quantity: 2, foodType: 'veg' },
        { name: 'Pan-Seared Herb Butter Sea Bass', unitPrice: 1150, quantity: 1, foodType: 'non-veg' },
      ],
      discountAmount: 150,
      paymentMethod: 'upi',
      paymentAmount: 1000,
      notes: 'Anniversary dinner table',
    },
    dummyAdmin
  );

  console.log('✓ Bill 1 Created:');
  console.log('  Invoice #:', bill1.invoiceNumber);
  console.log('  Subtotal:', bill1.subtotal, '(Expected: 900 + 1150 = 2050)');
  console.log('  Discount:', bill1.discountAmount, '(Expected: 150)');
  console.log('  Tax (5%):', bill1.taxAmount, '(Expected: 5% of 1900 = 95)');
  console.log('  Grand Total:', bill1.grandTotal, '(Expected: 1995)');
  console.log('  Paid Amount:', bill1.paidAmount, '(Expected: 1000)');
  console.log('  Balance Amount:', bill1.balanceAmount, '(Expected: 995)');
  console.log('  Status:', bill1.status, '(Expected: partially_paid)');

  // 2. Record Second Payment to settle the bill
  const settledBill = await billingService.recordPayment(
    bill1.id,
    { method: 'cash', amount: 995, notes: 'Settled by cash at table' },
    dummyAdmin
  );

  console.log('✓ Subsequent Payment Recorded:');
  console.log('  New Paid Amount:', settledBill.paidAmount, '(Expected: 1995)');
  console.log('  New Balance:', settledBill.balanceAmount, '(Expected: 0)');
  console.log('  New Status:', settledBill.status, '(Expected: paid)');

  // 3. Create a Takeaway Bill
  const bill2 = await billingService.createBill(
    {
      orderType: 'takeaway',
      customerName: 'Priya Patel',
      customerPhone: '9123456789',
      items: [
        { name: 'Saffron Risotto with Charred Asparagus', unitPrice: 780, quantity: 1, foodType: 'veg' },
      ],
      paymentMethod: 'card',
      paymentAmount: 819, // 780 + 5% tax = 819
    },
    dummyAdmin
  );

  console.log('✓ Bill 2 Created:');
  console.log('  Invoice #:', bill2.invoiceNumber, '(Expected: INV-2026-0002)');
  console.log('  Grand Total:', bill2.grandTotal, '(Expected: 819)');
  console.log('  Status:', bill2.status, '(Expected: paid)');

  // 4. Test Customer Metrics
  const customer = await customersService.getCustomerByPhone('9876543210');
  console.log('✓ Customer Metrics for Aarav Sharma:');
  console.log('  Total Invoices:', customer.totalBillsCount, '(Expected: 1)');
  console.log('  Total Lifetime Spent: ₹' + customer.totalSpent, '(Expected: ₹1995)');

  // 5. Test Reports Summary
  const summary = await reportsService.getDailySummary();
  console.log('✓ Business Day Summary:');
  console.log('  Total Invoices:', summary.totalBills, '(Expected: 2)');
  console.log('  Net Sales:', summary.netSales, '(Expected: 1995 + 819 = 2814)');
  console.log('  Cash Collected:', summary.collections.cash, '(Expected: 995)');
  console.log('  UPI Collected:', summary.collections.upi, '(Expected: 1000)');
  console.log('  Card Collected:', summary.collections.card, '(Expected: 819)');
  console.log('  Total Collections:', summary.collections.total, '(Expected: 2814)');
  console.log('  Fully Paid Bills:', summary.statusCounts.paid, '(Expected: 2)');

  // 6. Test CSV Export
  const csv = await reportsService.exportBillsCsv();
  console.log('✓ CSV Export generated with', csv.split('\n').length, 'lines.');

  // 7. Test Activity Logs
  const logs = await app.db.query('plugin::restaurant-pos.activity-log').findMany();
  console.log('✓ Activity logs written:', logs.length, 'records.');

  console.log('\nAll Billing, Financial Math, and Reconciliation tests passed perfectly!\n');
  process.exit(0);
}

testBilling().catch((err) => {
  console.error('Test Failed:', err);
  process.exit(1);
});
